<?php
global $global_fromdate;
global $global_todate;
global $global_buy_mobile;
global $global_value_taken;
global $ivalue;
ini_set('session.name','SID');
$_SESSION['global_value_taken'] = "NO";
$_SESSION['ivalue']=0;
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	
	public function index()
	{
 
		$this->load->view('loginForm.php');
	}
	
	public function loginSubmit()
	{
		if ($this->form_validation->run('Login') == TRUE)
                {
                        $post = $this->input->post();
						$this->load->model('Login_model');
						$loginData = $this->Login_model->login($post['username'], $post['password']);
						if($loginData){
							if($loginData->type == 'admin'){
								$this->session->set_userdata('username', $post['username']);
								$this->session->set_userdata('type', $loginData->type);
							}else{
								$this->session->set_userdata('username', $post['username']);
								$this->session->set_userdata('type', $loginData->type);
							}
							return redirect('Dashboard');
						}else{
							$this->session->set_flashdata('submitRevert', 'Invalid Login');
							return redirect('Login');
						}
						
                }
                else
                {
                       $this->load->view('loginForm.php');
                }
	}
	
	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('type');
		return redirect('Login');
	}
}
