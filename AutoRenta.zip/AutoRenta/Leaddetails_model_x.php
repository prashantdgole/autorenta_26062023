<?php

class Leaddetails_model extends CI_Model {
	
	

	public function dealersLeadsTable($fromdate, $todate){
	    
	 $q = $this->db->where("buy_created between '".$fromdate."' and '".$todate."'")->group_by("buy_name")
         ->order_by('buy_created DESC')->get('tb_buying_leads');


	return $q->result();
	}
	


	public function buyingLeadsTable($fromdate, $todate){
 		$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%'")->group_by("buy_name")
 				 ->order_by('buy_created DESC')->get('tb_buying_leads');
	return $q->result();
	}


	public function buyingLeadsTableLedsUser($fromdate, $todate,$limit,$start){

		// $q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and buy_city='Mumbai'")->group_by("buy_name")
		//		 ->order_by('buy_created DESC')->get('tb_buying_leads');
 

     $fm =     $_SESSION['global_fromdate'] ;
     $to = $_SESSION['global_todate'];



        $this->db->limit($limit, $start) ; // db  
              if ($start <= 0 )
              {
              $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fm . "' and  '" . $to . "' 
                  group by buy_mobile  order by kount desc , buy_name asc limit " . $limit );
               }
              else
              {
                 $newstart = ($start-1) * $limit; //  20;
// echo  $limit . " - ";
// echo $start* $limit . "<br>";
// echo "n " . $newstart;
//echo $fm . " fm ";
//echo $to . " to ";
// die("model");
              $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fm . "' and  '" . $to . "' 
                  group by buy_mobile  order by kount desc limit " . $limit . " offset " . $newstart );
              }
if ($q->num_rows() > 0 and $start > 0)
{
 // die("end");
}
	return $q->result();
	}

	public function buyingLeadsTableLedsUser_count($fromdate, $todate){

		// $q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and buy_city='Mumbai'")->group_by("buy_name")
		//		 ->order_by('buy_created DESC')->get('tb_buying_leads');



              $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fromdate . "' and  '" . $todate . "' 
                  group by buy_mobile  order by kount desc" );
	return $q->num_rows(); // $q->result(); echo $query->num_rows();
	}


	public function buyingLeadsAnalysisverifiedTableLedsUser_count($fromdate, $todate){

		// $q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and buy_city='Mumbai'")->group_by("buy_name")
		//		 ->order_by('buy_created DESC')->get('tb_buying_leads');

              $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fromdate . "' and  '" . $todate . "' and buy_verified='1' 
                  group by buy_mobile  order by kount desc" );
	return $q->num_rows(); // $q->result(); echo $query->num_rows();
	}



	public function buyingLeadsTableLedsUser_particular_mobile($buy_mobile)
        { // $fromdate, $todate,$buy_mobile

                $fromdate =    $_SESSION['global_fromdate']; /// ($this->session->delierdata['key_name1']);
                $todate = $_SESSION['global_todate'];
		// $q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and buy_city='Mumbai'")->group_by("buy_name")
		//		 ->order_by('buy_created DESC')->get('tb_buying_leads');
                $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile 
                  FROM tb_buying_leads 
                  where  buy_mobile = $buy_mobile and buy_created between '" . $fromdate . "' and  '" . $todate . "' " );
   
	return $q->result();
	}

        public function buyingLeadsTableLedsUser_particular_brand($buy_mobile)
        { // $fromdate, $todate,$buy_mobile

                $fromdate =    $_SESSION['global_fromdate']; /// ($this->session->delierdata['key_name1']);
                $todate = $_SESSION['global_todate'];
                $q = $this->db->querty("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,
                      buy_email_id, buy_mobile , count(*) as kount , count(buy_model) as mk 
                      FROM tb_buying_leads 
                      where 
                      buy_mobile='" . $buy_mobile . "'and 
                      buy_created between '" . $fromdate . "' and  '" . $todate . "' 
                      group by buy_mobile,buy_brand 
                      order by buy_name asc");
 
	return $q->result();
	}


        public function buyingLeadsTableLedsUser_show_mobile_buy_model($buy_mobile)
        {
             $fromdate =    $_SESSION['global_fromdate']; /// ($this->session->delierdata['key_name1']);
             $todate = $_SESSION['global_todate'];
             $q = $this->db->query("select tb_buying_leads.buy_name, 
                  tb_buying_leads.buy_mobile,tb_buying_leads.buy_model , 
                  tb_buying_leads.buy_brand,tb_buying_leads.buy_created 
                  from tb_buying_leads 
                  where 
                  buy_mobile ='" .  $buy_mobile .  "' and 
                  buy_created between '" . $fromdate . "' and  '" . $todate . "' 
                  and 
                   tb_buying_leads.buy_mobile in 
                  (select tb_buying_leads.buy_mobile from tb_buying_leads 
                    GROUP by tb_buying_leads.buy_brand, tb_buying_leads.buy_model, 
                    tb_buying_leads.buy_mobile) 
                  group by buy_mobile, buy_brand ,buy_model 
                 order by tb_buying_leads.buy_mobile");
            return $q->result();
	}
	public function buyingLeadsTableVerified($fromdate, $todate){
		$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%'  and (buy_verified='1')")->group_by("buy_name")
				 ->order_by('buy_created DESC')->get('tb_buying_leads');
				 
	return $q->result();
	}
	
	public function buyingLeadsTableLedsUserVerified($fromdate, $todate){
		$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and (buy_verified='1') and (buy_state='Maharashtra')")
				 ->order_by('buy_created DESC')->get('tb_buying_leads');
				 
	return $q->result();
	}

//  verfied 

	public function buyingLeadsAnalysisTableVerified($fromdate, $todate){
		$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%'  and (buy_verified='1')")->group_by("buy_name")
				 ->order_by('buy_created DESC')->get('tb_buying_leads');
				 
	return $q->result();
	}
	
	public function buyingLeadsAnalysisTableLedsUserVerified($fromdate, $todate,$limit,$start){
	//	$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and (buy_verified='1') and (buy_state='Maharashtra')")
	//			 ->order_by('buy_created DESC')->get('tb_buying_leads');

                $fm =     $_SESSION['global_fromdate'] ;
                $to = $_SESSION['global_todate'];
                $this->db->limit($limit, $start) ; // db  
                $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fromdate . "' and  '" . $todate . "' and (buy_verified='1') and (buy_state='Maharashtra')
                  group by buy_mobile  order by kount desc , buy_name asc limit " . $limit );
            
				 
	return $q->result();
	}

// verified end


	
	public function financeLeadsTableVerified($fromdate, $todate){
		$q = $this->db->where("fin_lead_last_modified between '".$fromdate."%' and '".$todate."%' and fin_lead_veh_type='Used'")->group_by("fin_lead_name")
				 ->order_by('fin_lead_last_modified DESC')->get('tb_finance_leads');
				 
	return $q->result();
	}
	
	public function financeLeadsTableLedsUserVerified($fromdate, $todate){
		$q = $this->db->where("fin_lead_last_modified between '".$fromdate."%' and '".$todate."%'  and fin_lead_veh_type='Used' and fin_lead_state='Maharashtra'")->group_by("fin_lead_name")
				 ->order_by('fin_lead_last_modified DESC')->get('tb_finance_leads');
				 
	return $q->result();
	}
	
	public function NewfinanceLeadsTableVerified($fromdate, $todate){
		$q = $this->db->where("fin_lead_last_modified between '".$fromdate."%' and '".$todate."%' and fin_lead_veh_type='New'")->group_by("fin_lead_name")
				 ->order_by('fin_lead_last_modified DESC')->get('tb_finance_leads');
				 
	return $q->result();
	}
	
	public function NewfinanceLeadsTableLedsUserVerified($fromdate, $todate){
		$q = $this->db->where("fin_lead_last_modified between '".$fromdate."%' and '".$todate."%'  and fin_lead_veh_type='New' and fin_lead_state='Maharashtra'")->group_by("fin_lead_name")
				->order_by('fin_lead_last_modified DESC')->get('tb_finance_leads');


				 
	return $q->result();
	}
/* analysis part */

	public function buyingLeadsAnalysisTableLedsUser_particular_mobile($buy_mobile)
        { // $fromdate, $todate,$buy_mobile

                $fromdate =    $_SESSION['global_fromdate']; /// ($this->session->delierdata['key_name1']);
                $todate = $_SESSION['global_todate'];
                $q= $this->db->query("select tb_buying_leads.* , tb_selling_dtls.* , tb_customer_dtls.*   
                      FROM tb_buying_leads, tb_selling_dtls , tb_customer_dtls 
                      where  
                      tb_buying_leads.buy_ad_id =tb_selling_dtls.sell_ad_id 
                      AND
                      tb_selling_dtls.sell_cust_id = tb_customer_dtls.cust_id 
                      and 
                      buy_mobile = $buy_mobile 
                      and 
                      buy_created between '" . $fromdate . "' and  '" . $todate . "' " );
	return $q->result();
	}

// verified

	public function buyingLeadsAnalysisverifiedTableLedsUser_particular_mobile($buy_mobile)
        { // $fromdate, $todate,$buy_mobile

                $fromdate =    $_SESSION['global_fromdate']; /// ($this->session->delierdata['key_name1']);
                $todate = $_SESSION['global_todate'];
                $q= $this->db->query("select tb_buying_leads.* , tb_selling_dtls.* , tb_customer_dtls.*   
                      FROM tb_buying_leads, tb_selling_dtls , tb_customer_dtls 
                      where  
                      tb_buying_leads.buy_ad_id =tb_selling_dtls.sell_ad_id 
                      AND
                      tb_selling_dtls.sell_cust_id = tb_customer_dtls.cust_id 
                      and 
                      buy_mobile = $buy_mobile 
                      and 
                      buy_created between '" . $fromdate . "' and  '" . $todate . "' 
                      and 
                      buy_verified = '1' 
                      and 
                      buy_state = 'Maharashtra' " );
	return $q->result();
	}



// verified end

// mktg start

	public function buyingLeadsmktgTableLedsUser($fromdate, $todate)
        {
// $q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%' and buy_city='Mumbai'")->group_by("buy_name")
//		 ->order_by('buy_created DESC')->get('tb_buying_leads');
              $fm =     $_SESSION['global_fromdate'] ;
              $to = $_SESSION['global_todate'];
 

              $q= $this->db->query("SELECT buy_created, buy_name ,buy_brand, buy_model ,buy_state ,buy_email_id, buy_mobile , 
                  count(*) as kount , count(buy_model) as mk , 0 as chkbx
                  FROM tb_buying_leads 
                  where  buy_created between '" . $fm . "' and  '" . $to . "' 
                  group by buy_mobile  order by kount desc , buy_name asc");
	return $q->result();
	}



// mktg end

// selling leads

	public function SellingLeadsTable_count($fromdate, $todate)
        {
              $q= $this->db->query("SELECT * FROM tb_selling_dtls where
                                sell_created BETWEEN  '" . $fromdate . "' and  '" . $todate . "' 
                                order by sell_name;" );  
	      return $q->num_rows(); 
	}

	public function buyingLeadsTable_for_sales_analysis($fromdate, $todate){
// 		$q = $this->db->where("buy_created between '".$fromdate."%' and '".$todate."%'")->group_by("buy_name")
// 				 ->order_by('buy_created DESC')->get('tb_buying_leads');

               $q = $this->db->query("SELECT sell_ad_id,sell_name ,sell_total_views,sell_brand,
                        sell_model ,sell_state,sell_city,sell_phone,sell_email  ,
                        cust_name , cust_mobile_no  
                               from tb_selling_dtls
                               inner join tb_customer_dtls on tb_selling_dtls.sell_cust_id = tb_customer_dtls.cust_id
                               WHERE
                              tb_selling_dtls.sell_created BETWEEN '" . $fromdate . "' and '" . $todate . "' order by sell_ad_id "); 
	return $q->result();
	}


        public function SellingLeadsTable_Page_Wise($fromdate, $todate,$limit,$start)
        {
          $fm =     $_SESSION['global_fromdate'] ;
          $to = $_SESSION['global_todate'];
          $this->db->limit($limit, $start) ; // db  
          if ($start <= 0 )
          {
              $q= $this->db->query("SELECT tb_selling_dtls.* , tb_customer_dtls.cust_name , 
                        tb_customer_dtls.cust_mobile_no
                        FROM tb_selling_dtls , tb_customer_dtls 
                        where 
                        sell_cust_id = cust_id and
                        sell_created BETWEEN  '" . $fromdate . "' and  '" . $todate . "' 
                        order by sell_name limit " . $limit);
           }
           else
           {
               $newstart = ($start-1) * $limit; //  20;
               $q= $this->db->query("SELECT tb_selling_dtls.* , tb_customer_dtls.cust_name ,
                                tb_customer_dtls.cust_mobile_no
                                FROM tb_selling_dtls , tb_customer_dtls 
                                where sell_cust_id = cust_id and 
                                sell_created BETWEEN  '" . $fromdate . "' and  '" . $todate . "' 
                                order by sell_name limit " . $limit  . " offset " . $newstart );
            }
            return $q->result();
	}

	public function SellingLeadsTable_buy_data($fromdate, $todate,$buyadid)
        {
              $q= $this->db->query("SELECT * FROM tb_buying_leads 
                                where
                                buy_created BETWEEN  '" . $fromdate . "' and  '" . $todate . "' 
                                and
                                tb_buying_leads.buy_ad_id = '" . $buyadid . "'
                                order by buy_name asc" );  
	      return $q->result(); 
	}

	public function SellingLeadsTable_buy_data_count($fromdate, $todate,$buyadid)
        {
              $q= $this->db->query("SELECT * FROM tb_buying_leads 
                                where
                                buy_created BETWEEN  '" . $fromdate . "' and  '" . $todate . "' 
                                and
                                tb_buying_leads.buy_ad_id = '" . $buyadid . "'
                                order by buy_name asc" );  

	      return $q->num_rows(); 
	}

// selling leads end

}