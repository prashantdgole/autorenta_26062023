<?php

//This script is designed by Android-Examples.com
//Define your host here.
$servername = "localhost" ; // "mysql.hostinger.in";
//Define your database username here.
$username = "root"; // "u727224026_demo";
//Define your database password here.
$password = ""; // "1234567890";
//Define your database name here.
$dbname = "demo"; // "u727224026_demo";

?>