<html>
<body>
<form name="fromeme" method="GET" action="http://localhost/dr_raje/get_in_php.php?username=".&username."&password=".$password. "&usertype=".$usertype />
<table border="1">
  <tr> <td> username </td> 
       <td> </td>
       <td> <input type="text" name="username" value=""> </td> 
  </tr>
  <tr> <td>password  </td> 
       <td> </td>
       <td> <input type="password" name="password" value=""> </td> 
  </tr>
 <tr> <td> usertype </td> 
       <td> </td>
       <td> <input type="text" name="usertype" value=""> </td> 
  </tr>
</table>
<br>
<br>
<input type="submit" value="Send">
</form>
</body>
</html>