<?php
// FOR PETS ADD LATER
   $uname = $_GET['username'];
   $upass = $_GET['password'];
   $d1 = $_GET['usertype'];
   
//  echo $uname . "<br>";
//  echo $upass . "<br>";
//  echo $d1 . "<br>";
  // $utype = $_GET['usertype'];
   $json = array();
   $db_host =  "sql305.epizy.com"; // "sql313.gungoos.com"; // "localhost"; //  "207.174.212.181" ; // "localhost";   http://198.251.86.153/ 
   $db_username =  "epiz_23920363"; //  "gungo_23120970"; // "pushpzii_root"; // "root";   
   $db_pass = "im2kIM80mwH9qD"; //  "Dattaraje@2019"; //  "drraje1234"; //  "Pdg_Admin@1234"; // '';    
   $db_name =  "epiz_23920363_demo"; // "gungo_23120970_demo"; // "pushpzii_pushpzii_ct"; // "demo";  
   $con = new mysqli($db_host, $db_username, $db_pass, $db_name);  
   if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 
   $rowcount = 0;
   $con = new mysqli($db_host, $db_username, $db_pass, $db_name);  
   $sql = "SELECT * FROM signup where username='$uname' and password='$upass'"; 
   // echo $sql;
   if ($result = mysqli_query($con,$sql)) 
   {
      $rowcount = mysqli_num_rows($result); 
     // echo "<br>" . " nos " . $rowcount . " == ";
      if ($rowcount > 0) 
      { 
        // echo "<br>". " in ";
        while($row[] = $result->fetch_assoc()) 
        {
 	        $json = json_encode($row);
        }
        echo $json;
      } 
      else 
      {          
         $json="0 results";
         echo  "0 results";
      }
   }
$con->close();
?>  