-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2022 at 05:07 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorenta`
--

-- --------------------------------------------------------

--
-- Table structure for table `accodeledger`
--

CREATE TABLE `accodeledger` (
  `id` int(11) NOT NULL,
  `accode` int(11) NOT NULL,
  `acname` varchar(100) NOT NULL,
  `typeledger` varchar(15) NOT NULL,
  `openingbalance` decimal(14,2) NOT NULL,
  `amountgiventotal` decimal(14,2) NOT NULL,
  `amountspendtotal` decimal(14,2) NOT NULL,
  `balanceamount` decimal(14,2) NOT NULL,
  `date` date NOT NULL,
  `monthledger` int(11) NOT NULL,
  `yearledger` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accodeledger`
--

INSERT INTO `accodeledger` (`id`, `accode`, `acname`, `typeledger`, `openingbalance`, `amountgiventotal`, `amountspendtotal`, `balanceamount`, `date`, `monthledger`, `yearledger`) VALUES
(1, 100, 'Petty Cash', 'BANK', '2874.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(2, 200, 'Miscellaneous Expenses', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(4, 201, 'Tea and Snacks', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(5, 300, 'Transfer From Bank to Petty Cash', 'INC', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(6, 202, 'Speed Post', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(7, 203, 'Coupons', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(8, 204, 'Printing', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(9, 205, 'Tyre Expenses', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(10, 206, 'Car Parking', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(11, 207, 'Toll Parking', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(12, 208, 'Car Maintenance', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(13, 209, 'Pass  ', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accodeledger`
--
ALTER TABLE `accodeledger`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accodeledger`
--
ALTER TABLE `accodeledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
