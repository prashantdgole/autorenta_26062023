-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2022 at 05:07 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorenta`
--

-- --------------------------------------------------------

--
-- Table structure for table `accodeledger`
--

CREATE TABLE `accodeledger` (
  `id` int(11) NOT NULL,
  `accode` int(11) NOT NULL,
  `acname` varchar(100) NOT NULL,
  `typeledger` varchar(15) NOT NULL,
  `openingbalance` decimal(14,2) NOT NULL,
  `amountgiventotal` decimal(14,2) NOT NULL,
  `amountspendtotal` decimal(14,2) NOT NULL,
  `balanceamount` decimal(14,2) NOT NULL,
  `date` date NOT NULL,
  `monthledger` int(11) NOT NULL,
  `yearledger` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accodeledger`
--

INSERT INTO `accodeledger` (`id`, `accode`, `acname`, `typeledger`, `openingbalance`, `amountgiventotal`, `amountspendtotal`, `balanceamount`, `date`, `monthledger`, `yearledger`) VALUES
(1, 100, 'Petty Cash', 'BANK', '2874.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(2, 200, 'Miscellaneous Expenses', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(4, 201, 'Tea and Snacks', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(5, 300, 'Transfer From Bank to Petty Cash', 'INC', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(6, 202, 'Speed Post', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(7, 203, 'Coupons', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(8, 204, 'Printing', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(9, 205, 'Tyre Expenses', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(10, 206, 'Car Parking', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(11, 207, 'Toll Parking', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(12, 208, 'Car Maintenance', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0),
(13, 209, 'Pass  ', 'EXP', '0.00', '0.00', '0.00', '0.00', '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `mobile1`, `mobile2`) VALUES
(1, 'Ms Smita Amin', '', ''),
(2, 'David Karkhanis', '', ''),
(12, 'a', '', ''),
(13, 'b', '', ''),
(14, 'c', '', ''),
(15, 'd', '', ''),
(16, 'e', '', ''),
(17, 'f', '', ''),
(18, 'g', '', ''),
(19, 'h', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `daaentry`
--

CREATE TABLE `daaentry` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `empid` int(10) NOT NULL,
  `presentabsent` varchar(5) NOT NULL,
  `duty` varchar(10) DEFAULT NULL,
  `outstationdatefrom` date DEFAULT NULL,
  `outstationdateto` date DEFAULT NULL,
  `shift` varchar(10) DEFAULT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` int(10) NOT NULL,
  `passengername` varchar(100) DEFAULT NULL,
  `reportingtime` varchar(15) DEFAULT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `actualintime` varchar(15) NOT NULL,
  `actualouttime` varchar(15) NOT NULL,
  `worktime` varchar(15) NOT NULL,
  `ottime` varchar(15) NOT NULL,
  `totalduration` varchar(15) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `basicsalary` decimal(19,2) NOT NULL,
  `totalallowance` decimal(19,2) NOT NULL,
  `cleaningallowance` decimal(19,2) NOT NULL,
  `nightallowance` decimal(19,2) NOT NULL,
  `dayallowance` decimal(19,2) NOT NULL,
  `doubleshift` decimal(19,2) NOT NULL,
  `latecoming` decimal(19,2) NOT NULL,
  `overtime` decimal(19,2) NOT NULL,
  `daysalary` decimal(19,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daaentry`
--

INSERT INTO `daaentry` (`id`, `date`, `empid`, `presentabsent`, `duty`, `outstationdatefrom`, `outstationdateto`, `shift`, `customername`, `customerid`, `passengername`, `reportingtime`, `intime`, `outtime`, `actualintime`, `actualouttime`, `worktime`, `ottime`, `totalduration`, `remarks`, `basicsalary`, `totalallowance`, `cleaningallowance`, `nightallowance`, `dayallowance`, `doubleshift`, `latecoming`, `overtime`, `daysalary`) VALUES
(259, '2022-11-28', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '900.00'),
(260, '2022-11-28', 5, 'PO', 'O', '2022-11-28', '2022-11-28', 'D', '0', 0, '', '', '07:40', '16:30', '07:40', '16:30', '09:00', '0:00', '09:00', '', '50.00', '800.00', '0.00', '0.00', '400.00', '0.00', '0.00', '0.00', '850.00'),
(261, '2022-11-28', 6, 'DD', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '0.00', '500.00', '0.00', '0.00', '0.00', '100.00', '0.00', '0.00', '500.00'),
(262, '2022-11-28', 7, 'DH', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '00:00', '07:30', '00:00', '16:30', '0:00', '16:30', 'Earlier Closing Time was 1', '0.00', '600.00', '0.00', '0.00', '0.00', '200.00', '0.00', '0.00', '600.00'),
(263, '2022-11-28', 18, 'HN', 'L', NULL, NULL, 'D', '0', 0, NULL, '', '00:00', '00:00', '00:00', '00:00', '00:00', '0:00', '00:00', '', '0.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '400.00'),
(264, '2022-11-28', 9, 'PN', NULL, '2022-11-28', '2022-11-28', '', '0', 0, '', '', '', '', '', '', '', '0:00', '', 'No Duty', '50.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '450.00'),
(265, '2022-11-28', 10, 'AB', NULL, '2022-11-28', '2022-11-28', '', '0', 0, '', '', '', '', '', '', '', '0:00', '', 'Absent', '0.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '400.00'),
(266, '2022-11-28', 11, 'HD', '0', '2022-11-28', '2022-11-28', 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '100.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(267, '2022-11-28', 12, 'WO', NULL, '2022-11-28', '2022-11-28', '', '0', 0, '', '', '', '16:00', '', '', '', '0:00', '', 'Weekly Off No Duty', '50.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '450.00'),
(268, '2022-11-28', 13, 'WD', '0', '2022-11-28', '2022-11-28', 'D', '0', 0, '', '', '07:00', '16:00', '07:00', '16:00', '09:00', '0:00', '09:00', '', '100.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(269, '2022-11-29', 1, 'HN', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '900.00'),
(270, '2022-11-28', 1, 'HN', 'L', NULL, NULL, 'D', '0', 0, 'test', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '900.00'),
(271, '2022-12-02', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '900.00'),
(272, '2022-12-03', 1, 'PR', 'L', '2022-12-02', '2022-12-02', 'D', '0', 0, 'test 2 on 03  12 2022', '', '07:30', '16:30', '', '', '09:00', '0:00', '09:00', '', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00'),
(273, '2022-12-04', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(274, '2022-12-05', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(275, '2022-12-05', 1, 'HN', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '0.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '400.00'),
(276, '2022-12-06', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(277, '2022-12-06', 5, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:40', '16:30', '07:40', '16:30', '09:00', '0:00', '09:00', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(278, '2022-12-06', 1, 'HN', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '0.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '400.00'),
(279, '2022-12-06', 5, 'HN', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:40', '16:30', '07:40', '16:30', '09:00', '0:00', '09:00', '', '0.00', '400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '400.00'),
(280, '2022-12-09', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '7:30', '20:30', '09:00', '4:0', '13:0', '', '500.00', '160.00', '0.00', '0.00', '0.00', '0.00', '0.00', '160.00', '660.00');

-- --------------------------------------------------------

--
-- Table structure for table `emptable`
--

CREATE TABLE `emptable` (
  `ecode` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `shift` varchar(10) NOT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `tottime` varchar(15) NOT NULL,
  `basicsal` decimal(18,2) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `doj` date NOT NULL,
  `inhh` varchar(2) NOT NULL,
  `inmm` varchar(2) NOT NULL,
  `outhh` varchar(2) NOT NULL,
  `outmm` varchar(2) NOT NULL,
  `tothh` varchar(2) NOT NULL,
  `totmm` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emptable`
--

INSERT INTO `emptable` (`ecode`, `name`, `shift`, `intime`, `outtime`, `tottime`, `basicsal`, `designation`, `doj`, `inhh`, `inmm`, `outhh`, `outmm`, `tothh`, `totmm`) VALUES
(1, 'Deepak Patel', 'D', '07:30', '16:30', '09:00', '15000.00', 'Manager', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(5, 'Mr, Vijay Rathod', 'D', '07:40', '16:30', '09:00', '1500.00', '', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(6, 'Vishnu Vandre', 'D', '07:30', '16:30', '09:00', '1500.00', 'drive', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(7, '1', 'D', '07:30', '00:00', '16:30', '1500.00', 'driver', '0000-00-00', '07', '30', '00', '00', '16', '30'),
(8, '21', 'D1', '07:301', '16:301', '09:001', '1500.00', 'driver11', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(9, '3', 'D', '07:30', '16:30', '09:00', '1500.00', 'DRIVER', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(10, '4', 'D', '07:30', '16:30', '09:00', '1500.00', 'driver', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(11, '5', 'D', '07:30', '16:30', '09:00', '1500.00', 'driver', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(12, '7', 'D', '07:00', '16:00', '09:00', '1500.00', 'driver', '0000-00-00', '07', '00', '16', '00', '09', '00'),
(13, '8', 'D', '07:00', '16:00', '09:00', '1500.00', 'driver', '0000-00-00', '07', '00', '16', '00', '09', '00'),
(18, 'zz', 'D', '00:00', '00:00', '00:00', '0.00', 'zzz', '0000-00-00', '00', '00', '00', '00', '00', '00');

-- --------------------------------------------------------

--
-- Table structure for table `paymentregister`
--

CREATE TABLE `paymentregister` (
  `id` int(11) NOT NULL,
  `glcodedr` int(11) NOT NULL,
  `glcodecr` int(11) NOT NULL,
  `accode` int(11) NOT NULL,
  `acname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `openingbalance` decimal(14,2) DEFAULT NULL,
  `amountgiven` decimal(14,2) DEFAULT NULL,
  `amountspend` decimal(14,2) DEFAULT NULL,
  `narration1` varchar(100) NOT NULL,
  `narration2` varchar(100) NOT NULL,
  `amountadjusted` decimal(14,2) DEFAULT NULL,
  `salarymonth` int(11) DEFAULT NULL,
  `salaryyear` int(11) DEFAULT NULL,
  `remarks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentregister`
--

INSERT INTO `paymentregister` (`id`, `glcodedr`, `glcodecr`, `accode`, `acname`, `date`, `openingbalance`, `amountgiven`, `amountspend`, `narration1`, `narration2`, `amountadjusted`, `salarymonth`, `salaryyear`, `remarks`) VALUES
(52, 1, 5, 0, '0', '2022-12-04', '0.00', '4000.00', '0.00', 'amount trf from bank of baroda', '', '0.00', NULL, NULL, ''),
(53, 4, 1, 0, '0', '2022-12-04', '0.00', '0.00', '100.00', 'morning tea to staff', '', '0.00', NULL, NULL, ''),
(54, 2, 1, 5, '5', '2022-12-04', '0.00', '100.00', '0.00', 'petrol charges', '', '0.00', NULL, NULL, ''),
(55, 0, 0, 5, '5', '2022-12-04', '0.00', '0.00', '90.00', 'petrol in mh-02 ba 2234', '', '0.00', 0, 0, ''),
(56, 0, 0, 5, '5', '2022-12-04', '0.00', '0.00', '0.00', '', '', '10.00', 12, 2022, 'adjusted balance in salary ');

-- --------------------------------------------------------

--
-- Table structure for table `shifttable`
--

CREATE TABLE `shifttable` (
  `id` int(11) NOT NULL,
  `shift` varchar(15) NOT NULL,
  `intime` varchar(11) NOT NULL,
  `outime` varchar(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `workduration` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shifttable`
--

INSERT INTO `shifttable` (`id`, `shift`, `intime`, `outime`, `description`, `workduration`) VALUES
(1, 'GS', '07:30', '16:30', 'General Shift', '09:00'),
(2, 'DP', '06:30', '15:30', 'Dyanesh', '09:00'),
(3, 'D', '07:00', '16:00', 'Day Time', '09:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `nameofperson` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL,
  `workin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `user_type`, `user_password`, `nameofperson`, `mobile1`, `mobile2`, `workin`) VALUES
(1, 'Deepak', 'ADMIN', 'deepak@1236', 'Deepak Patel', '1', '2', 'DAA'),
(2, 'Jayant', 'ADMIN', 'Jayant@9999', 'Jayant Deshpande.', '11', '21', 'DAA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accodeledger`
--
ALTER TABLE `accodeledger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daaentry`
--
ALTER TABLE `daaentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emptable`
--
ALTER TABLE `emptable`
  ADD UNIQUE KEY `ecode` (`ecode`);

--
-- Indexes for table `paymentregister`
--
ALTER TABLE `paymentregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shifttable`
--
ALTER TABLE `shifttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accodeledger`
--
ALTER TABLE `accodeledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `daaentry`
--
ALTER TABLE `daaentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=281;

--
-- AUTO_INCREMENT for table `emptable`
--
ALTER TABLE `emptable`
  MODIFY `ecode` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `paymentregister`
--
ALTER TABLE `paymentregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `shifttable`
--
ALTER TABLE `shifttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
