<?php
     $fromdate = $_SESSION['global_fromdate'] ;
     $todate = $_SESSION['global_todate'] ;
?>
<!DOCTYPE html>
<html>
<head>
<title>Mktg View</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript">
function click_chk_box(cb)
{
 var varchkall;
 var tsms;
 tsms = eval(document.mktg.noofsms.value);
/* alert (tsms);  */
 varchkall = document.mktg.chkall.value;

 if ( varchkall == 1 ) /* check all */
 {
    if (cb.checked)
    {
      tsms = tsms + 1;
      document.mktg.noofsms.value = tsms ;
    }
    else
    {
      tsms = tsms -1;
      document.mktg.noofsms.value = tsms ;
/*      alert ('remoce chk'); */
    }
 }
 else
 {
    if (cb.checked)
    {
       tsms = tsms + 1;
       document.mktg.noofsms.value = tsms ;
/*       alert ('click chk');  */
    }
    else
    {
       tsms = tsms - 1;
       document.mktg.noofsms.value = tsms ;
/*       alert ('click chk n');  */
    }

 }
}
</script>
<style>
body {
font-family: 'Raleway', sans-serif;
}
.main
{
width: 1015px;
position: absolute;
top: 10%;
left: 20%;
}
#form_head
{
text-align: center;
background-color: #61CAFA;
height: 66px;
margin: 0 0 -29px 0;
padding-top: 35px;
border-radius: 8px 8px 0 0;
color: rgb(255, 255, 255);
}
#content {
position: absolute;
width: 450px;
height: 390px;
border: 2px solid gray;
border-radius: 10px;
}
#form_input
{
margin-left: 110px;
margin-top: 30px;
}
label
{
margin-right: 6px;
font-weight: bold;
}
#pagination{
margin: 40 40 0;
}
.input_text {
display: inline;
margin: 100px;
}
.input_name {
display: inline;
margin: 65px;
}
.input_email {
display: inline;
margin-left: 73px;
}
.input_num {
display: inline;
margin: 36px;
}
.input_country {
display: inline;
margin: 53px;
}
ul.tsc_pagination li a
{
border:solid 1px;
border-radius:3px;
-moz-border-radius:3px;
-webkit-border-radius:3px;
padding:6px 9px 6px 9px;
}
ul.tsc_pagination li
{
padding-bottom:1px;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
color:#FFFFFF;
box-shadow:0px 1px #EDEDED;
-moz-box-shadow:0px 1px #EDEDED;
-webkit-box-shadow:0px 1px #EDEDED;
}
ul.tsc_pagination
{
margin:4px 0;
padding:0px;
height:100%;
overflow:hidden;
font:12px 'Tahoma';
list-style-type:none;
}
ul.tsc_pagination li
{
float:left;
margin:0px;
padding:0px;
margin-left:5px;
}
ul.tsc_pagination li a
{
color:black;
display:block;
text-decoration:none;
padding:7px 10px 7px 10px;
}
ul.tsc_pagination li a img
{
border:none;
}
ul.tsc_pagination li a
{
color:#0A7EC5;
border-color:#8DC5E6;
background:#F8FCFF;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
text-shadow:0px 1px #388DBE;
border-color:#3390CA;
background:#58B0E7;
background:-moz-linear-gradient(top, #B4F6FF 1px, #63D0FE 1px, #58B0E7);
background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #B4F6FF), color-stop(0.02, #63D0FE), color-stop(1, #58B0E7));
}
</style>

<style>
.pagination {
  display: inline-block;
}
.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}
.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}
.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
</head>
<body>
<div class="main-panel">
<div class="content-wrapper">
<form name="mktg" action="<?php echo site_url('Leaddetails/buyingLeadsmarketingsendsms_ctr'); ?>" method="POST">
   <?php $nsms = $trec; ?>
   <div class="form-group row col-12"> 
          <label class="col-sm-1 col-form-label">From Date  :</label>
          <div class="col-sm-2">
             <?php echo $fromdate; ?> 
            </div>
          <label class="col-sm-1 col-form-label">To Date : </label>
          <div class="col-sm-2">
                <?php echo $todate; ?> 
          </div>
   </div>
   <div class="form-group row col-12"> 
   <label class="col-sm-1 col-form-label">Total Records:</label>
   <div class="col-sm-3">
    <input class="form-control" type="text" name="tsms"  readonly value="<?php echo $trec; ?>"> 
   </div>
<!--   <div class="form-group row col-12">  -->
   <label class="col-sm-1 col-form-label">Total SMS Send:</label>
   <div class="col-sm-3">
   <?php 
    if($data1 ==1)
    { ?>
    <input class="form-control" type="text" name="noofsms" readonly value="<?php echo $nsms; ?>"> 
    <?php
    } 
    else
    { $nsms = 0 ;?>
    <input class="form-control" type="text" name="noofsms" readonly value="<?php echo $nsms; ?>"> 
    <?php
    }?>
   </div>
   <div class="col-sm-3">
     <button type="submit" id="subbtn" class="btn btn-success btn-square btn-fw buyingdatesubmitbtn"  value="SMS" name="getcustattsubmitbtn">SEND SMS</button>
   </div>
  <div class="col-sm-3">
     <input class="form-control" type="text" name="chkall" hidden readonly value="<?php echo $data1; ?>">
   </div>
   </div>
        <!--   Table  -->
        <div class="row">
           <div class="col-md-12" style="background-color:white;">
             <div class="table-responsive" style="height: auto;padding:10px;overflow:auto;display:block;">
             <table class="table table-hover" id="dataTable">
               <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Cust. Phone</th>
<!--                <th>State</th> -->
                    <th>Cust. Name</th>
<!--                <th>Brand</th>   -->
                    <th>Select / (ALL) <input type="checkbox" name="cball" id="cball"> </th>         
                </tr>
              </thead>
            <tbody>
            <?php 
// echo " i = ...................... " .  $i . "<br>";
              if(count($buyingLeadsTablepagination))
              {    
                $i=1;
                  foreach($buyingLeadsTablepagination as $tabData){
              ?>
             <tr>
               <td><?php echo $i; ?></td>
               <td><?php echo $tabData->buy_mobile; ?></td>
<!--                <td><?php echo $tabData->buy_state; ?></td> -->
               <?php
                if ($tabData->kount >0 )
                { ?>
                     <?php $dataarray=$fromdate . "," . $todate . "," . $tabData->buy_mobile ;  ?>
                  <?php $newsite = base_url() .  "index.php/Leaddetails/buyingLeads_for_Particular/" . $tabData->buy_mobile   ; ?> 
                  <td> <?php echo $tabData->buy_name . "( " . '<a href="'.  $newsite  .'"' . ' target="_blank" ' . '>' . $tabData->kount . "<a>" . " )" ;?></td>
                <?php
                }
                else
                { ?>
                   <td><?php echo $tabData->buy_name ; ?></td>
 
                <?php
                } ?>
<!--                <td><?php echo $tabData->buy_brand." ".$tabData->buy_model  ; ?></td> -->
                <?php
//                 echo $data1;
                if($data1 ==1)
                { ?>
                    <td> <input type="checkbox" onclick="click_chk_box(this)" name="chkg".$i checked value=""> </td>
                <?php
                }
                else
                { ?>
                    <td> <input type="checkbox" onclick="click_chk_box(this)" name="chkg".$i  value=""> </td>
                <?php
                }
                ?>             </tr>
             <?php
               $i++; 
              // $_SESSION['ivalue']= i;
             }
             }else{
             ?>
            <tr>
            <td colspan="7" align="center"> No Data Found From <?php echo date('d-m-Y',strtotime($fromdate)); ?> To  <?php echo date('d-m-Y',strtotime($todate)); ?></td>
            </tr>
            <?php
            }
             ?>
            </tbody>
     </table>
<!--     <p>   <?php echo $links; ?>  </p> 	 
     <p> <div class="pagination"> <?php echo $links; ?> </div> </p> -->
      </div>
   </div>
   </div>
 </form>

 </div>
<!--   </div> -->
  </div>
</body>
</html>