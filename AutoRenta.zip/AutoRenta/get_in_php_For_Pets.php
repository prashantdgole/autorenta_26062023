<?php
// FOR PETS ADD LATER
   $uname = $_GET['username'];
   $upass = $_GET['password'];
   $utype = $_GET['usertype'];
   $json = array();
   $db_host = "localhost";   
   $db_username = "root";   
   $db_pass = '';    
   $db_name =  "demo";  
 //  $con=mysqli_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
   $con = new mysqli($db_host, $db_username, $db_pass, $db_name);  // for local pc
//  $con=mysqli_connect("sql313.gungoos.com","gungo_23120970","drraje1234","gungo_23120970_demo");  //  for server
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT * FROM user_login where user_name='$uname' and user_password='$upass' and user_type='$utype' and PetHuman='PETS'"; //  TextViewTable";
$result = $con->query($sql);
if ($result->num_rows > 0) 
{ 
    while($row[] = $result->fetch_assoc()) 
    {
 	   $json = json_encode($row);
	   
    }
     echo $json;
} 
else 
{          
    $json="0 results";
    echo  "0 results";
}
$con->close();
?>  