<?php
// FOR PETS ADD LATER
   $uname = $_GET['username'];
   $upass = $_GET['password'];
   $utype = $_GET['usertype'];
   $json = array();
   $db_host = "localhost";   
   $db_username = "root";   
   $db_pass = '';    
   $db_name =  "demo";  
   $con=mysqli_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
   mysqli_connect($db_host , $db_username,$db_pass) or die ("could not connect to mysql");
   mysqli_select_db($con,"demo");
   $result = mysqli_query($con,"SELECT PetHuman FROM user_login where user_name = '" . $uname . "' and user_password='". $upass . "' and user_type = '" . $utype . "'" );
   $row = $result->num_rows; // mysqli_fetch_array($result);
   if ($row>0)
   {
     $json['success']=1;
     $json['message']="Success";
    // echo "success";
//     echo $json['message'];
   }
   else
   {
     $json['success']=0;
     $json['message']="In Correct Login Details";
//     echo "not success";
//     echo $json['message'];
   }
return $json['message']; // $json;
?>