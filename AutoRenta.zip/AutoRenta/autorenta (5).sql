-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2022 at 04:14 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorenta`
--

-- --------------------------------------------------------

--
-- Table structure for table `accodeledger`
--

CREATE TABLE `accodeledger` (
  `id` int(11) NOT NULL,
  `accode` int(11) NOT NULL,
  `acname` varchar(100) NOT NULL,
  `amountgiventotal` decimal(14,2) NOT NULL,
  `amountspendtotal` decimal(14,2) NOT NULL,
  `balanceamount` decimal(14,2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `mobile1`, `mobile2`) VALUES
(1, 'Ms Smita Amin', '', ''),
(2, 'David Karkhanis', '', ''),
(12, 'a', '', ''),
(13, 'b', '', ''),
(14, 'c', '', ''),
(15, 'd', '', ''),
(16, 'e', '', ''),
(17, 'f', '', ''),
(18, 'g', '', ''),
(19, 'h', '', ''),
(20, 'i', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `daaentry`
--

CREATE TABLE `daaentry` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `empid` int(10) NOT NULL,
  `presentabsent` varchar(5) NOT NULL,
  `duty` varchar(10) DEFAULT NULL,
  `outstationdatefrom` date DEFAULT NULL,
  `outstationdateto` date DEFAULT NULL,
  `shift` varchar(10) DEFAULT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` int(10) NOT NULL,
  `passengername` varchar(100) DEFAULT NULL,
  `reportingtime` varchar(15) DEFAULT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `actualintime` varchar(15) NOT NULL,
  `actualouttime` varchar(15) NOT NULL,
  `worktime` varchar(15) NOT NULL,
  `ottime` varchar(15) NOT NULL,
  `totalduration` varchar(15) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `basicsalary` decimal(19,2) NOT NULL,
  `totalallowance` decimal(19,2) NOT NULL,
  `cleaningallowance` decimal(19,2) NOT NULL,
  `nightallowance` decimal(19,2) NOT NULL,
  `dayallowance` decimal(19,2) NOT NULL,
  `doubleshift` decimal(19,2) NOT NULL,
  `latecoming` decimal(19,2) NOT NULL,
  `overtime` decimal(19,2) NOT NULL,
  `daysalary` decimal(19,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daaentry`
--

INSERT INTO `daaentry` (`id`, `date`, `empid`, `presentabsent`, `duty`, `outstationdatefrom`, `outstationdateto`, `shift`, `customername`, `customerid`, `passengername`, `reportingtime`, `intime`, `outtime`, `actualintime`, `actualouttime`, `worktime`, `ottime`, `totalduration`, `remarks`, `basicsalary`, `totalallowance`, `cleaningallowance`, `nightallowance`, `dayallowance`, `doubleshift`, `latecoming`, `overtime`, `daysalary`) VALUES
(248, '2022-01-01', 1, 'DD', '0', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', 'Earlier Closing Time was 12', '0.00', '100.00', '0.00', '0.00', '0.00', '100.00', '0.00', '0.00', '100.00'),
(249, '2022-01-01', 7, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '00:00', '07:30', '00:00', '16:30', '0:00', '16:30', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(250, '2022-01-01', 14, 'PN', NULL, '2022-11-24', '2022-11-24', '', '0', 0, NULL, '', '', '', '', '', '', '0:00', '', 'No Duty', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(251, '2022-01-01', 13, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:00', '16:00', '07:00', '16:00', '09:00', '0:00', '09:00', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(252, '2022-01-01', 12, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:00', '16:00', '07:00', '16:00', '09:00', '0:00', '09:00', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(253, '2022-01-01', 9, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(254, '2022-01-01', 10, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '50.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50.00'),
(256, '2022-11-24', 1, 'PR', 'L', NULL, NULL, 'D', '0', 0, '', '', '07:30', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', '', '500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00'),
(258, '2022-11-25', 1, 'PR', 'L', '0000-00-00', '0000-00-00', 'D', '1', 1, 'smitax', '', '', '16:30', '07:30', '16:30', '09:00', '0:00', '09:00', 'test', '500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00');

-- --------------------------------------------------------

--
-- Table structure for table `emptable`
--

CREATE TABLE `emptable` (
  `ecode` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `shift` varchar(10) NOT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `tottime` varchar(15) NOT NULL,
  `basicsal` decimal(18,2) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `doj` date NOT NULL,
  `inhh` varchar(2) NOT NULL,
  `inmm` varchar(2) NOT NULL,
  `outhh` varchar(2) NOT NULL,
  `outmm` varchar(2) NOT NULL,
  `tothh` varchar(2) NOT NULL,
  `totmm` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emptable`
--

INSERT INTO `emptable` (`ecode`, `name`, `shift`, `intime`, `outtime`, `tottime`, `basicsal`, `designation`, `doj`, `inhh`, `inmm`, `outhh`, `outmm`, `tothh`, `totmm`) VALUES
(1, 'Deepak Patel', 'D', '07:30', '16:30', '09:00', '15000.00', 'Manager', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(5, 'Mr, Vijay Rathod', 'D', '07:40', '16:30', '09:00', '1500.00', '', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(6, 'Vishnu Vandre', 'D', '07:30', '16:30', '09:00', '1500.00', 'drive', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(7, '1', 'D', '07:30', '00:00', '16:30', '1500.00', 'driver', '0000-00-00', '07', '30', '00', '00', '16', '30'),
(8, '21', 'D1', '07:301', '16:301', '09:001', '1500.00', 'driver11', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(9, '3', 'D', '07:30', '16:30', '09:00', '1500.00', 'DRIVER', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(10, '4', 'D', '07:30', '16:30', '09:00', '1500.00', 'driver', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(11, '5', 'D', '07:30', '16:30', '09:00', '1500.00', 'driver', '0000-00-00', '07', '30', '16', '30', '09', '00'),
(12, '7', 'D', '07:00', '16:00', '09:00', '1500.00', 'driver', '0000-00-00', '07', '00', '16', '00', '09', '00'),
(13, '8', 'D', '07:00', '16:00', '09:00', '1500.00', 'driver', '0000-00-00', '07', '00', '16', '00', '09', '00'),
(18, 'zz', 'D', '00:00', '00:00', '00:00', '0.00', 'zzz', '0000-00-00', '00', '00', '00', '00', '00', '00');

-- --------------------------------------------------------

--
-- Table structure for table `paymentregister`
--

CREATE TABLE `paymentregister` (
  `id` int(11) NOT NULL,
  `accode` int(11) NOT NULL,
  `acname` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `openingbalance` decimal(14,2) NOT NULL,
  `amountgiven` decimal(14,2) NOT NULL,
  `amountspend` decimal(14,2) NOT NULL,
  `narration1` varchar(100) NOT NULL,
  `narration2` varchar(100) NOT NULL,
  `amountadjusted` decimal(14,2) NOT NULL,
  `salarymonth` int(11) NOT NULL,
  `salaryyear` int(11) NOT NULL,
  `remarks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentregister`
--

INSERT INTO `paymentregister` (`id`, `accode`, `acname`, `date`, `openingbalance`, `amountgiven`, `amountspend`, `narration1`, `narration2`, `amountadjusted`, `salarymonth`, `salaryyear`, `remarks`) VALUES
(1, 6, '6', '2022-11-26', '500.00', '0.00', '0.00', 'opening balance for vishnu', '', '0.00', 0, 0, ''),
(2, 6, '6', '2022-11-26', '0.00', '1000.00', '0.00', 'petrol for client amin', '', '0.00', 0, 0, ''),
(3, 6, '6', '2022-11-29', '0.00', '0.00', '100.00', 'air in mh-ba-09-4966', '', '0.00', 0, 0, ''),
(4, 6, '6', '2022-11-26', '0.00', '0.00', '600.00', 'petrol for client amin', 'and air in mh-ba-2690', '0.00', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `shifttable`
--

CREATE TABLE `shifttable` (
  `id` int(11) NOT NULL,
  `shift` varchar(15) NOT NULL,
  `intime` varchar(11) NOT NULL,
  `outime` varchar(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `workduration` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shifttable`
--

INSERT INTO `shifttable` (`id`, `shift`, `intime`, `outime`, `description`, `workduration`) VALUES
(1, 'GS', '07:30', '16:30', 'General Shift', '09:00'),
(2, 'DP', '06:30', '15:30', 'Dyanesh', '09:00'),
(3, 'D', '07:00', '16:00', 'Day Time', '09:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `nameofperson` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL,
  `workin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `user_type`, `user_password`, `nameofperson`, `mobile1`, `mobile2`, `workin`) VALUES
(1, 'Deepak', 'ADMIN', 'deepak@1236', 'Deepak Patel', '1', '2', 'DAA'),
(2, 'Jayant', 'ADMIN', 'Jayant@9999', 'Jayant Deshpande.', '11', '21', 'DAA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accodeledger`
--
ALTER TABLE `accodeledger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daaentry`
--
ALTER TABLE `daaentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emptable`
--
ALTER TABLE `emptable`
  ADD UNIQUE KEY `ecode` (`ecode`);

--
-- Indexes for table `paymentregister`
--
ALTER TABLE `paymentregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shifttable`
--
ALTER TABLE `shifttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accodeledger`
--
ALTER TABLE `accodeledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `daaentry`
--
ALTER TABLE `daaentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- AUTO_INCREMENT for table `emptable`
--
ALTER TABLE `emptable`
  MODIFY `ecode` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `paymentregister`
--
ALTER TABLE `paymentregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shifttable`
--
ALTER TABLE `shifttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
