<?php
     $fromdate = $_SESSION['global_fromdate'] ;
     $todate = $_SESSION['global_todate'] ;
?>
<style>
body {
font-family: 'Raleway', sans-serif;
}
.main
{
width: 1015px;
position: absolute;
top: 10%;
left: 20%;
}
#form_head
{
text-align: center;
background-color: #61CAFA;
height: 66px;
margin: 0 0 -29px 0;
padding-top: 35px;
border-radius: 8px 8px 0 0;
color: rgb(255, 255, 255);
}
#content {
position: absolute;
width: 450px;
height: 390px;
border: 2px solid gray;
border-radius: 10px;
}
#form_input
{
margin-left: 110px;
margin-top: 30px;
}
label
{
margin-right: 6px;
font-weight: bold;
}
#pagination{
margin: 40 40 0;
}
.input_text {
display: inline;
margin: 100px;
}
.input_name {
display: inline;
margin: 65px;
}
.input_email {
display: inline;
margin-left: 73px;
}
.input_num {
display: inline;
margin: 36px;
}
.input_country {
display: inline;
margin: 53px;
}
ul.tsc_pagination li a
{
border:solid 1px;
border-radius:3px;
-moz-border-radius:3px;
-webkit-border-radius:3px;
padding:6px 9px 6px 9px;
}
ul.tsc_pagination li
{
padding-bottom:1px;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
color:#FFFFFF;
box-shadow:0px 1px #EDEDED;
-moz-box-shadow:0px 1px #EDEDED;
-webkit-box-shadow:0px 1px #EDEDED;
}
ul.tsc_pagination
{
margin:4px 0;
padding:0px;
height:100%;
overflow:hidden;
font:12px 'Tahoma';
list-style-type:none;
}
ul.tsc_pagination li
{
float:left;
margin:0px;
padding:0px;
margin-left:5px;
}
ul.tsc_pagination li a
{
color:black;
display:block;
text-decoration:none;
padding:7px 10px 7px 10px;
}
ul.tsc_pagination li a img
{
border:none;
}
ul.tsc_pagination li a
{
color:#0A7EC5;
border-color:#8DC5E6;
background:#F8FCFF;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
text-shadow:0px 1px #388DBE;
border-color:#3390CA;
background:#58B0E7;
background:-moz-linear-gradient(top, #B4F6FF 1px, #63D0FE 1px, #58B0E7);
background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #B4F6FF), color-stop(0.02, #63D0FE), color-stop(1, #58B0E7));
}
</style>

<style>
.pagination {
  display: inline-block;
}

.pagination a { /*   float: left; */
  color: black;

  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
span.pag {
    font-size: 22px !important;
        background: #e25817;
        color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext{
    font-size: 22px !important;
        background: #e25817;
        color: white !important;
    padding: 8px 0px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext a{
   
        color: white !important;
    
}
.btn-nexttag a {
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
    background : #f76d2b;
}
span.btn.btn-nexttag {
    padding: 3% 0%;
    color: white !important;
    display: contents;
}
</style>
<div class="main-panel">
<div class="content-wrapper">
        <!--   Table  -->
        <div class="row">
           <div class="col-md-12" style="background-color:white;">
             <div class="table-responsive" style="height: auto;padding:10px;overflow:auto;display:block;">
             <table class="table table-hover" id="dataTable">
               <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Sell Date</th>
                    <th>Sell Name</th>
                    <th>Sell Model/Brand </th>
                    <th>Sell State</th>
                    <th>Sell City</th>
                    <th>Sell Phone</th>

 <!--                   <th>Sell Count</th> -->

                    <th>Sell Email </th>
                    <th>Posted By/Mobile</th>

<!--                 <th>Buy Name </th>
                    <th>Buy Model/Brand </th>
                    <th>Buy Mobile</th>
                    <th>Buy Date </th> -->

                </tr>
              </thead>
            <tbody>
            <?php 
              if(count($sellingLeadsTablepagination))
              {       //           $i=1;
                  foreach($sellingLeadsTablepagination as $tabData)
                  {
                  ?>
                    <tr>
                    <td><?php  echo $i; ?></td>
                    <td><?php echo date('d-m-Y',strtotime($tabData->sell_created))." &nbsp;&nbsp;&nbsp;".date('h:i:s A',strtotime($tabData->sell_created)) ?></td>
                    <?php 
                    $buyc=0;
                    $CI =& get_instance();
                    $CI->load->model('Leaddetails_model');
                    $buyc = $CI->Leaddetails_model->SellingLeadsTable_buy_data_count($fromdate, $todate,$tabData->sell_ad_id)
                    ?>
                    <?php $newsite = base_url() .  "index.php/Leaddetails/sellingLeadsanalysis_for_Particular_sell_ad_id_ctr/" . $tabData->sell_ad_id; ?> 
                    <td> <?php echo $tabData->sell_name . "( " . '<a href="'.  $newsite  .'"' . ' target="_blank" ' . '>' . $tabData->sell_total_views. "(v)" . $buyc . "(L)" . "<a>" . " )" ;?></td>
<!--                <td> <?php echo $tabData->sell_name . "( " . '<a href="'.  $newsite  .'"' . ' target="_blank" ' . '>' . $tabData->sell_total_views. "<a>" . " )" ;?></td> -->
                    <td><?php echo $tabData->sell_brand." ".$tabData->sell_model  ; ?></td>
                    <td><?php echo $tabData->sell_state; ?></td>
                    <td><?php echo $tabData->sell_city; ?></td>
                    <td><?php echo $tabData->sell_phone; ?></td>
                    <td><?php echo $tabData->sell_email; ?></td> 
                    <td><?php echo $tabData->cust_name . " " . $tabData->cust_mobile_no ; ?></td> 
                   </tr>
                   <?php 
                     $i++; 
                   } ?>
              </tr>
             <?php
             }else{
             ?>
            <tr>
            <td colspan="7" align="center"> No Data Found From <?php echo date('d-m-Y',strtotime($fromdate)); ?> To  <?php echo date('d-m-Y',strtotime($todate)); ?></td>
            </tr>
            <?php
            }
             ?>
            </tbody>
     </table>
<!--     <p>   <?php echo $links; ?>  </p> 	 -->
     <p> <div class="pagination"> <?php echo $links; ?> </div> </p> 						
     </div>
   </div>
   </div>
   </div>
  </div>