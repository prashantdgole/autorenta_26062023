-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2021 at 10:30 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyname`
--

CREATE TABLE `companyname` (
  `id` int(11) NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `compad1` varchar(90) NOT NULL,
  `compad2` varchar(90) NOT NULL,
  `compcity` varchar(50) NOT NULL,
  `comppin` varchar(10) NOT NULL,
  `dealwith` varchar(25) NOT NULL,
  `gstnowithdate` varchar(100) NOT NULL,
  `dateofregistration` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `humandiagnosis`
--

CREATE TABLE `humandiagnosis` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateofvisit` date NOT NULL,
  `illness1` varchar(255) NOT NULL,
  `illness2` varchar(255) NOT NULL,
  `dignosis1` varchar(255) NOT NULL,
  `dignosis2` varchar(255) NOT NULL,
  `medicine1` varchar(255) NOT NULL,
  `medicine2` varchar(255) NOT NULL,
  `billamount` double NOT NULL,
  `paidamount` double NOT NULL,
  `nextvisit` date NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `dateofdeath` date NOT NULL,
  `reasonfordeath` varchar(255) NOT NULL,
  `nameofperson` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `humandiagnosis`
--

INSERT INTO `humandiagnosis` (`id`, `userid`, `dateofvisit`, `illness1`, `illness2`, `dignosis1`, `dignosis2`, `medicine1`, `medicine2`, `billamount`, `paidamount`, `nextvisit`, `remarks`, `dateofdeath`, `reasonfordeath`, `nameofperson`) VALUES
(1, 90, '2001-01-01', '4', '4', '4', '4', '4', '4', 4, 4, '0004-04-04', '4', '0004-04-04', '4', 'z4female'),
(2, 94, '2021-12-12', 'carona', 'carona', 'madh ', 'nd', 'medine1', 'mdecine 2', 200, 200, '2021-12-12', 'test', '0000-00-00', '', 'lasttest'),
(5, 90, '2009-09-09', 'm', 'm', 'm', 'm', 'm', 'm', -99, -99, '0000-00-00', '', '0000-00-00', '', 'z4female'),
(6, 90, '2009-09-09', 'm', 'm', 'm', 'm', 'm', 'm', 9, 9, '2009-09-09', 'm', '2009-09-09', 'm', 'z4female');

-- --------------------------------------------------------

--
-- Table structure for table `injectionlist`
--

CREATE TABLE `injectionlist` (
  `id` int(11) NOT NULL,
  `injectionname` varchar(255) NOT NULL,
  `approxprice` decimal(12,2) NOT NULL,
  `usedindisease` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `injectionlist`
--

INSERT INTO `injectionlist` (`id`, `injectionname`, `approxprice`, `usedindisease`, `remarks`) VALUES
(1, 'chlorophorm', '121.00', 'BLOOD PRESSURE', 'new1'),
(2, 'myname', '100.00', 'my disease', 'tested'),
(3, 'myname1', '1200.00', 'throat', 'tested   but risk');

-- --------------------------------------------------------

--
-- Table structure for table `listofdisease`
--

CREATE TABLE `listofdisease` (
  `id` int(11) NOT NULL,
  `diseasename` varchar(255) NOT NULL,
  `seasonspecific` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `injectionlist` varchar(255) NOT NULL,
  `medicine1` varchar(155) NOT NULL,
  `medicine2` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `listofdisease`
--

INSERT INTO `listofdisease` (`id`, `diseasename`, `seasonspecific`, `remarks`, `injectionlist`, `medicine1`, `medicine2`) VALUES
(1, 'cough', 'cold', 'warm clothes', 'sdhd', '', ''),
(2, 'cough', 'heat', 'lot of water', 'clothes', '', ''),
(3, 'test1', 'test1', 'test1', 'aa', 'test1', ''),
(4, 'test2', 'test2', 'test2', 'test2', 'test2.1', 'test2.2'),
(5, 'xx', 'xx', 'xx', 'xx', 'xx', 'xx'),
(6, 'yy', 'yy', 'yyy', 'yy', 'yy', 'yy');

-- --------------------------------------------------------

--
-- Stand-in structure for view `nextvisitdata`
-- (See below for the actual view)
--
CREATE TABLE `nextvisitdata` (
`nextvisit` date
,`petdetid` int(11)
,`petdetailsid` int(11)
,`username` varchar(255)
,`gender` varchar(10)
,`pettype` varchar(90)
,`petname` varchar(255)
,`dateofbirth` date
);

-- --------------------------------------------------------

--
-- Table structure for table `petdiagnosis`
--

CREATE TABLE `petdiagnosis` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `petdetid` int(11) NOT NULL,
  `dateofvisit` date NOT NULL,
  `illness1` varchar(255) NOT NULL,
  `illness2` varchar(255) NOT NULL,
  `dignosis1` varchar(255) NOT NULL,
  `dignosis2` varchar(255) NOT NULL,
  `medicine1` varchar(255) NOT NULL,
  `medicine2` varchar(255) NOT NULL,
  `billamount` double NOT NULL,
  `paidamount` double NOT NULL,
  `nextvisit` date NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `dateofdeath` date NOT NULL,
  `reasonfordeath` varchar(255) NOT NULL,
  `petname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petdiagnosis`
--

INSERT INTO `petdiagnosis` (`id`, `userid`, `petdetid`, `dateofvisit`, `illness1`, `illness2`, `dignosis1`, `dignosis2`, `medicine1`, `medicine2`, `billamount`, `paidamount`, `nextvisit`, `remarks`, `dateofdeath`, `reasonfordeath`, `petname`) VALUES
(1, 30, 19, '2019-02-09', 'ill1', 'ill2', 'dig 1', 'diag 2', 'med 1', 'med 2', 1000, 100, '2019-09-09', 'remarks', '0000-00-00', '', ''),
(2, 30, 19, '0000-00-00', '', '', '', '', 'vf', '', 0, 0, '0000-00-00', '', '0000-00-00', '', ''),
(3, 30, 19, '2019-02-09', 'ill1.3', 'ill 1.3', 'dig 1.3', 'dig 1.4', 'med 1.3', 'med 1.4', 900, 900, '1966-03-25', 'rem', '0000-00-00', '', ''),
(4, 30, 18, '2019-02-09', 'doberman ill1', 'dob ill2', 'doberman dig 1', 'doberman dig 2', 'dob med 1', 'dob med 2', 10, 10, '2019-02-14', 'come with last injection', '0000-00-00', '', ''),
(5, 23, 16, '2019-02-11', 'u1small  cat ill1_1', 'u1 small cat ', 'u1small  cat dig1_1', 'u1small  cat dig', 'u1small  cat med1_1', 'u1small  cat', 900, 900, '2019-04-12', '', '0000-00-00', '', ''),
(6, 23, 17, '2019-02-11', 'cat big cat cat2 ill1', 'cat big cat cat2', 'cat big cat cat2 dig1', 'cat big cat cat2 dig 2', 'cat big cat cat2 med 1', 'cat big cat cat2 ', 100, 100, '2019-03-25', 'check for injectoion', '0000-00-00', '', 'cat big cat cat2 '),
(7, 29, 20, '2019-02-11', 'having cold', '', 'because of cold water', '', 'injection 1', '', 40, 40, '2019-04-26', 'if required', '0000-00-00', '', 'sham  horse'),
(8, 29, 20, '0000-00-00', 'leg injury', '', '', '', 'inno', '', 100, 100, '2019-04-30', '', '0000-00-00', '', 'sham  horse'),
(9, 23, 17, '2019-04-26', 'leg injury', '', '', '', 'qq', '', 0, 0, '2019-04-26', '', '0000-00-00', '', 'cat big cat cat2 ');

-- --------------------------------------------------------

--
-- Table structure for table `petsinformationdetail`
--

CREATE TABLE `petsinformationdetail` (
  `petdetailsid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `contactperson` varchar(90) NOT NULL,
  `totalpendingamount` double NOT NULL,
  `petheadid` int(11) NOT NULL,
  `petid` int(11) NOT NULL,
  `pettype` varchar(90) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `petname` varchar(255) NOT NULL,
  `dateofbirth` date NOT NULL,
  `origin` varchar(100) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `illness1` varchar(255) NOT NULL,
  `illness2` varchar(255) NOT NULL,
  `dignosis1` varchar(255) NOT NULL,
  `dignosis2` varchar(255) NOT NULL,
  `medicine1` varchar(255) NOT NULL,
  `medicine2` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `billamount` double NOT NULL,
  `billdate` date NOT NULL,
  `paidamount` double NOT NULL,
  `nextvisitdate` date NOT NULL,
  `firstvisitdate` date NOT NULL,
  `allergy1` varchar(255) NOT NULL,
  `allergy2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petsinformationdetail`
--

INSERT INTO `petsinformationdetail` (`petdetailsid`, `userid`, `username`, `contactperson`, `totalpendingamount`, `petheadid`, `petid`, `pettype`, `gender`, `petname`, `dateofbirth`, `origin`, `speciality`, `illness1`, `illness2`, `dignosis1`, `dignosis2`, `medicine1`, `medicine2`, `remarks`, `billamount`, `billdate`, `paidamount`, `nextvisitdate`, `firstvisitdate`, `allergy1`, `allergy2`) VALUES
(16, 23, 'u1', '', 10, 23, 1, 'cat', 'MALE', 'cat small cat cat1', '2019-02-01', 'origin', 'speciality', 'ill1', 'ill2', '', '', '', '', 'cat small cat cat 1', 0, '0000-00-00', 0, '0000-00-00', '2019-02-05', 'allergy1', 'allergy2'),
(17, 23, 'u1', '', 0, 23, 27, 'cat  big cat', 'MALE', 'cat big cat cat2 ', '2019-02-01', '', '', '', '', '', '', '', '', 'cat big cat cat 2', 0, '0000-00-00', 0, '0000-00-00', '2019-02-01', '', ''),
(18, 30, 'test', 'test', 0, 30, 2, 'dog  doberman', 'MALE', 'dog doberman rockey', '2018-12-01', 'origin', 'speciality', 'ill1', 'ill2', '', '', '', '', 'doberman rockey with german breed', 0, '0000-00-00', 0, '0000-00-00', '2019-02-08', 'allergy1', 'allergy2'),
(19, 30, 'test', 'test', 0, 30, 29, 'Horse  Arbi Borse', 'FEMALE', 'female horse arbi horse heena', '2018-01-01', '', '', '', '', '', '', '', '', 'heena horse from stud farm', 0, '0000-00-00', 0, '0000-00-00', '2019-02-08', '', ''),
(20, 29, 'sham', 'sham', 0, 29, 29, 'Horse  Arbi Borse', 'MALE', 'sham  horse', '2019-04-01', 'steve jobs horse', 'very honest', '', '', '', '', '', '', 'new dog first time', 0, '0000-00-00', 0, '0000-00-00', '2019-02-11', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `petsinformationhead`
--

CREATE TABLE `petsinformationhead` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `contactperson` varchar(90) NOT NULL,
  `totalpendingamount` double NOT NULL,
  `remarks` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `petsinjections`
--

CREATE TABLE `petsinjections` (
  `id` int(11) NOT NULL,
  `petsdetailsid` int(11) NOT NULL,
  `injectionid` int(11) NOT NULL,
  `injectionname` varchar(255) NOT NULL,
  `dateofinjection` date NOT NULL,
  `whengiven` date NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `petstypelist`
--

CREATE TABLE `petstypelist` (
  `id` int(11) NOT NULL,
  `pettype` varchar(90) NOT NULL,
  `petsubtype` varchar(90) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petstypelist`
--

INSERT INTO `petstypelist` (`id`, `pettype`, `petsubtype`, `speciality`, `remarks`) VALUES
(1, 'cat', 'small cat', 'milk and other animals', 'life upto 15 years'),
(2, 'dog', 'doberman', '', ''),
(27, 'cat', 'big cat', 'jungle', 'very strong'),
(29, 'Horse', 'Arbi Borse', 'Fast Running', 'normal height 6 feet'),
(31, 'dog', 'pomerian', 'very friends', 'lively');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `compid` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  `stockinhand` float(12,2) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `dateofpurchase` date NOT NULL,
  `qtyissue` float(12,2) NOT NULL,
  `lastbilldate` date NOT NULL,
  `lastbillno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `compid`, `description`, `created_at`, `stockinhand`, `unit`, `dateofpurchase`, `qtyissue`, `lastbilldate`, `lastbillno`) VALUES
(1, 0, '14 inch dell ', '0000-00-00', 0.00, '', '0000-00-00', 0.00, '0000-00-00', 0),
(2, 0, 'sony 18\"', '0000-00-00', 0.00, '', '0000-00-00', 0.00, '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchumanstocklist`
--

CREATE TABLE `purchumanstocklist` (
  `id` int(11) NOT NULL,
  `purchasebill` varchar(15) NOT NULL,
  `purchasedate` date NOT NULL,
  `stockid` int(11) NOT NULL,
  `purcqty` float NOT NULL,
  `purrate` float NOT NULL,
  `puramount` float NOT NULL,
  `gstperc` float NOT NULL,
  `vendorid` int(11) NOT NULL,
  `batchcode` varchar(100) NOT NULL,
  `batchdate` date NOT NULL,
  `sgstamount` float NOT NULL,
  `cgstamount` float NOT NULL,
  `qtyissued` float NOT NULL,
  `itemtotal` float NOT NULL,
  `balqty` float NOT NULL,
  `purcqtyreturn` float NOT NULL,
  `salesqtyreturn` float NOT NULL,
  `discperc` float NOT NULL,
  `discountamount` float NOT NULL,
  `total` float NOT NULL,
  `taxtotal` float NOT NULL,
  `sgstperc` float NOT NULL,
  `cgstperc` float NOT NULL,
  `igstperc` float NOT NULL,
  `igstamount` float NOT NULL,
  `stockname` varchar(100) NOT NULL,
  `hsncode` varchar(50) NOT NULL,
  `mrprate` float NOT NULL,
  `roundoffplusminus` float NOT NULL,
  `otherexpenseshead1` varchar(100) NOT NULL,
  `otherexpenses1` float NOT NULL,
  `otherexpenseshead2` varchar(100) NOT NULL,
  `otherexpenses2` float NOT NULL,
  `totaltaxamount` float NOT NULL,
  `unitofmeasurement` varchar(25) NOT NULL,
  `unit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchumanstocklist`
--

INSERT INTO `purchumanstocklist` (`id`, `purchasebill`, `purchasedate`, `stockid`, `purcqty`, `purrate`, `puramount`, `gstperc`, `vendorid`, `batchcode`, `batchdate`, `sgstamount`, `cgstamount`, `qtyissued`, `itemtotal`, `balqty`, `purcqtyreturn`, `salesqtyreturn`, `discperc`, `discountamount`, `total`, `taxtotal`, `sgstperc`, `cgstperc`, `igstperc`, `igstamount`, `stockname`, `hsncode`, `mrprate`, `roundoffplusminus`, `otherexpenseshead1`, `otherexpenses1`, `otherexpenseshead2`, `otherexpenses2`, `totaltaxamount`, `unitofmeasurement`, `unit`) VALUES
(1, '89', '2021-10-29', 4, 87, 0, 0, 0, 2, '', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, '', 0, '', 0, 0, '', ''),
(2, 'inv no 34', '2021-10-02', 4, 44, 24, 0, 0, 2, '', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, '', 0, '', 0, 0, '', ''),
(3, '89', '2021-10-01', 4, 34, 0, 0, 0, 1, '', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'halad', '', 0, 0, '', 0, '', 0, 0, '', 'nos'),
(4, '89', '2021-10-02', 4, 4, 1, 90, 9, 2, 'batch', '0000-00-00', 4, 6, 0, 99, 0, 0, 0, 9, 9, 0, 0, 0, 0, 0, 0, 'halad', 'hsn', 0, 0, '', 0, '', 0, 0, '', 'ltr'),
(5, '89', '2021-10-29', 5, 9, 9, 9, 9, 2, '9', '0000-00-00', 9, 9, 0, 9, 0, 0, 0, 9, 9, 0, 0, 0, 0, 0, 0, 'madh', '9', 0, 0, '', 0, '', 0, 0, '', 'ltr'),
(6, '89', '2021-10-02', 5, 9, 9, 9, 9, 2, '9', '0000-00-00', 9, 9, 0, 9, 0, 0, 0, 9, 9, 0, 0, 0, 0, 0, 0, 'madh', '9', 0, 0, '', 0, '', 0, 0, '', '9'),
(8, '1_inv', '2021-10-01', 6, 1, 1, 1, 1, 3, '1', '2021-10-01', 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, '1', '1', 0, 0, '', 0, '', 0, 0, '', '1'),
(9, '1_inv', '2021-10-01', 7, 2, 2, 2, 2, 3, '2', '2021-10-01', 2, 2, 0, 2, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, '2', '2', 0, 0, '', 0, '', 0, 0, '', '2'),
(10, '1_inv', '2021-10-01', 8, 3, 3, 3, 3, 3, '3', '2021-10-01', 3, 3, 0, 3, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, '3', '3', 0, 0, '', 0, '', 0, 0, '', '3'),
(11, '1_inv', '2021-10-01', 9, 4, 4, 4, 4, 3, '4', '2021-10-01', 4, 4, 0, 4, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0, 0, '4', '4', 0, 0, '', 0, '', 0, 0, '', '4'),
(12, '1_inv', '2021-10-01', 10, 5, 5, 5, 5, 3, '5', '2021-10-01', 5, 5, 0, 5, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, '5', '5', 0, 0, '', 0, '', 0, 0, '', '5'),
(13, '', '0000-00-00', 4, 23, 33, 34, 4, 2, 'ew', '2021-12-09', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'halad', 'dsf', 0, 0, '', 0, '', 0, 0, '', 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `purcreturnhumanstocklist`
--

CREATE TABLE `purcreturnhumanstocklist` (
  `id` int(11) NOT NULL,
  `purchasebill` varchar(25) NOT NULL,
  `purchasedate` date NOT NULL,
  `stockid` int(11) NOT NULL,
  `returnqty` float NOT NULL,
  `remarks1` varchar(100) NOT NULL,
  `remarks2` varchar(100) NOT NULL,
  `rate` float NOT NULL,
  `itemtotal` float NOT NULL,
  `discperc` float NOT NULL,
  `discamt` float NOT NULL,
  `total` float NOT NULL,
  `purcreturndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `saleshumanstocklist`
--

CREATE TABLE `saleshumanstocklist` (
  `id` int(11) NOT NULL,
  `salesbill` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `stockid` int(11) NOT NULL,
  `stockname` varchar(100) NOT NULL,
  `saleqty` float NOT NULL,
  `hsncode` varchar(25) NOT NULL,
  `gstperc` float NOT NULL,
  `sgstamt` float NOT NULL,
  `cgstamt` float NOT NULL,
  `salesrate` float NOT NULL,
  `itemtotal` float NOT NULL,
  `discountperc` float NOT NULL,
  `discountamount` float NOT NULL,
  `total` float NOT NULL,
  `patientid` int(11) NOT NULL,
  `patientname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saleshumanstocklist`
--

INSERT INTO `saleshumanstocklist` (`id`, `salesbill`, `date`, `stockid`, `stockname`, `saleqty`, `hsncode`, `gstperc`, `sgstamt`, `cgstamt`, `salesrate`, `itemtotal`, `discountperc`, `discountamount`, `total`, `patientid`, `patientname`) VALUES
(21, 'bill:/1', '2021-11-12', 4, 'halad', 1, 'haladhsn', 27, 12, 12, 15, 12, 2, 2, 2, 90, 'z4female'),
(22, 'bill:/1', '2021-11-12', 5, 'madh', 2, 'MADHHSN', 18, 2, 2, 100, 2, 2, 2, 2, 90, 'z4female'),
(23, 'bill:/1', '2021-11-12', 6, '1', 3, '3', 3, 3, 3, 1, 3, 3, 3, 3, 90, 'z4female'),
(24, 'bill:/1', '2021-11-12', 7, '2', 4, '2', 4, 4, 4, 4, 4, 4, 4, 4, 90, 'z4female'),
(25, 'bill:/1', '2021-11-12', 8, '3', 5, '3', 5, 5, 5, 5, 5, 5, 5, 5, 90, 'z4female');

-- --------------------------------------------------------

--
-- Table structure for table `salesreturnhumanstocklist`
--

CREATE TABLE `salesreturnhumanstocklist` (
  `id` int(11) NOT NULL,
  `salesid` int(11) NOT NULL,
  `salesbill` varchar(25) NOT NULL,
  `salesbilldate` date NOT NULL,
  `stockid` int(11) NOT NULL,
  `patientid` int(11) NOT NULL,
  `returnqty` float NOT NULL,
  `salesreturndate` date NOT NULL,
  `discountperc` float NOT NULL,
  `discountamount` float NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'jtp', 'jtp');

-- --------------------------------------------------------

--
-- Table structure for table `stocklistofhuman`
--

CREATE TABLE `stocklistofhuman` (
  `id` int(11) NOT NULL,
  `stockshortcode` varchar(25) NOT NULL,
  `stockname` varchar(100) NOT NULL,
  `reorderlevel` float NOT NULL,
  `stockinhand` float NOT NULL,
  `salerate` float NOT NULL,
  `unit` varchar(15) NOT NULL,
  `hsncode` varchar(25) NOT NULL,
  `itemtotal` float NOT NULL,
  `stockbinnumber` varchar(25) NOT NULL,
  `gstperc` float NOT NULL,
  `cgst` float NOT NULL,
  `sgst` float NOT NULL,
  `igst` float NOT NULL,
  `any_information_1` varchar(200) NOT NULL,
  `any_information_2` varchar(200) NOT NULL,
  `schedulestock` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocklistofhuman`
--

INSERT INTO `stocklistofhuman` (`id`, `stockshortcode`, `stockname`, `reorderlevel`, `stockinhand`, `salerate`, `unit`, `hsncode`, `itemtotal`, `stockbinnumber`, `gstperc`, `cgst`, `sgst`, `igst`, `any_information_1`, `any_information_2`, `schedulestock`) VALUES
(4, 'halad', 'halad', 120, 100, 15, '1 gm', 'haladhsn', 0, 'at rack no 5', 27, 9, 9, 9, 'halad from vaidya', 'halad from vaiya1', ''),
(5, 'madh', 'madh', 200, 300, 100, '20 GM', 'MADHHSN', 0, 'RACK NO 12', 18, 9, 9, 0, 'NIL', '', 'NIL'),
(6, '1', '1', 1, 1, 1, '1', '', 0, '', 0, 0, 0, 0, '', '', ''),
(7, '2', '2', 2, 2, 2, '2', '2', 0, '', 0, 0, 0, 0, '', '', ''),
(8, '3', '3', 3, 3, 3, '3', '3', 0, '', 0, 0, 0, 0, '', '', ''),
(9, '4', '4', 4, 4, 4, '4', '4', 0, '4', 0, 0, 0, 0, '', '', ''),
(10, '5', '5', 5, 5, 5, '5', '5', 0, '', 0, 0, 0, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `pethuman` varchar(7) NOT NULL,
  `nameofperson` varchar(100) NOT NULL,
  `ad1` varchar(100) NOT NULL,
  `ad2` varchar(100) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `mobile1` varchar(16) NOT NULL,
  `mobile2` varchar(16) NOT NULL,
  `dateofbirth` date NOT NULL,
  `placeofbirth` varchar(100) NOT NULL,
  `allergyofany` varchar(200) NOT NULL,
  `sleepingtime` varchar(100) NOT NULL,
  `getuptime` varchar(100) NOT NULL,
  `soundsleep` varchar(100) NOT NULL,
  `yoga_exercise` varchar(100) NOT NULL,
  `waterdrinkinghabit` varchar(100) NOT NULL,
  `lunch_dinner_timing` varchar(100) NOT NULL,
  `daily_routine_1` varchar(200) NOT NULL,
  `daily_routine_2` varchar(200) NOT NULL,
  `physical_problem_1` varchar(200) NOT NULL,
  `physical_problem_2` varchar(200) NOT NULL,
  `medicines_list_1` varchar(200) NOT NULL,
  `medicines_list_2` varchar(200) NOT NULL,
  `medicines_list_3` varchar(200) NOT NULL,
  `bad_habit_1` varchar(200) NOT NULL,
  `bad_habit_2` varchar(200) NOT NULL,
  `veg_non_veg_frequency` varchar(200) NOT NULL,
  `about_delivery_1` varchar(200) NOT NULL,
  `about_delivery_2` varchar(200) NOT NULL,
  `bp_diabetics_level` varchar(200) NOT NULL,
  `which_milk_products_1` varchar(200) NOT NULL,
  `which_milk_products_2` varchar(200) NOT NULL,
  `gas_acidity_abdomen_1` varchar(200) NOT NULL,
  `gas_acidity_abdomen_2` varchar(200) NOT NULL,
  `any_information_1` varchar(200) NOT NULL,
  `any_information_2` varchar(200) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `dinner_timing` varchar(100) NOT NULL,
  `diabetic_level` varchar(200) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `whatupno1` varchar(100) NOT NULL,
  `whatupno2` varchar(100) NOT NULL,
  `enquirydetail1` varchar(200) NOT NULL,
  `enquirydetail2` varchar(200) NOT NULL,
  `followup1` varchar(200) NOT NULL,
  `followup2` varchar(200) NOT NULL,
  `hereditarydisease` varchar(200) NOT NULL,
  `registrationdate` date NOT NULL,
  `patientphoto` varchar(255) NOT NULL,
  `weight` varchar(25) NOT NULL,
  `height` varchar(25) NOT NULL,
  `asthma_problem` varchar(200) NOT NULL,
  `other_problem` varchar(200) NOT NULL,
  `nadi_problem` varchar(50) NOT NULL,
  `urine_issue` varchar(100) NOT NULL,
  `duration_disease_1` varchar(200) NOT NULL,
  `duration_disease_2` varchar(200) NOT NULL,
  `duration_disease_3` varchar(200) NOT NULL,
  `duration_disease_4` varchar(200) NOT NULL,
  `any_other_diseases_1` varchar(200) NOT NULL,
  `any_other_diseases_2` varchar(200) NOT NULL,
  `any_surgeries_1` varchar(200) NOT NULL,
  `any_surgeries_2` varchar(200) NOT NULL,
  `any_surgeries_3` varchar(200) NOT NULL,
  `emergency_contact_1` varchar(200) NOT NULL,
  `emergency_contact_2` varchar(200) NOT NULL,
  `family_member_disease_1` varchar(200) NOT NULL,
  `family_member_disease_2` varchar(200) NOT NULL,
  `anyreferencenameno1` varchar(100) NOT NULL,
  `anyreferencenameno2` varchar(100) NOT NULL,
  `anyreferencenameno3` varchar(100) NOT NULL,
  `anyreferencenameno4` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `user_email`, `user_type`, `user_password`, `pethuman`, `nameofperson`, `ad1`, `ad2`, `pincode`, `mobile1`, `mobile2`, `dateofbirth`, `placeofbirth`, `allergyofany`, `sleepingtime`, `getuptime`, `soundsleep`, `yoga_exercise`, `waterdrinkinghabit`, `lunch_dinner_timing`, `daily_routine_1`, `daily_routine_2`, `physical_problem_1`, `physical_problem_2`, `medicines_list_1`, `medicines_list_2`, `medicines_list_3`, `bad_habit_1`, `bad_habit_2`, `veg_non_veg_frequency`, `about_delivery_1`, `about_delivery_2`, `bp_diabetics_level`, `which_milk_products_1`, `which_milk_products_2`, `gas_acidity_abdomen_1`, `gas_acidity_abdomen_2`, `any_information_1`, `any_information_2`, `gender`, `dinner_timing`, `diabetic_level`, `reference`, `occupation`, `whatupno1`, `whatupno2`, `enquirydetail1`, `enquirydetail2`, `followup1`, `followup2`, `hereditarydisease`, `registrationdate`, `patientphoto`, `weight`, `height`, `asthma_problem`, `other_problem`, `nadi_problem`, `urine_issue`, `duration_disease_1`, `duration_disease_2`, `duration_disease_3`, `duration_disease_4`, `any_other_diseases_1`, `any_other_diseases_2`, `any_surgeries_1`, `any_surgeries_2`, `any_surgeries_3`, `emergency_contact_1`, `emergency_contact_2`, `family_member_disease_1`, `family_member_disease_2`, `anyreferencenameno1`, `anyreferencenameno2`, `anyreferencenameno3`, `anyreferencenameno4`) VALUES
(1, 'admin', 'ad@xx.com', 'ADMIN', 'admin', 'HUMAN', 'a', 'b', 'c', 'd', 'e', 'f', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, 'pdg', 'sharprash@yahoo.com', 'USER', 'pdg', 'HUMAN', 'x1', 'x1', 'x1', '91', 'x1', 'xx1', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, 'u1', 'u1@u1.com', 'USER', 'u1', 'PETS', '', '', '', '', '', 'mobile2', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, 'u2', 'u2@u2.com', 'USER', 'u2', 'HUMAN', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, 'u3', 'u3@u3.com', 'ADMIN', 'u3', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, 'u4', 'u4@u4.com', 'ADMIN', 'u4', 'HUMAN', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, 'u5', 'u6@t.com', 'ADMIN', 'u6', 'HUMAN', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, 'xx', 'x@t.com', 'USER', 'U3', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, 'sham', 'sh@g.com', 'USER', 'df', 'PETS', 'sham', 'a', 'b', '5555', '98', '88', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, 'test', 'test@123.com', 'USER', 'test', 'PETS', 'test', 'test ad1', 'test ad2', '400', '1', '2', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, 'admin1', 'a@g.com', 'ADMIN', 'admin', 'PETS', 'a', 'aa', 'aa', 'aa', 'aa', 'aa', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, 'test24', 'tr@g.com', 'USER', 'test24', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, 'test26', 'a@g.com', 'USER', 'test26', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, 'test29', 'tr@g.com', 'USER', 'test29', 'PETS', 'test29', 'a', 's', '4', '1', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, 'test31', 't@t.com', 'USER', 'test31', 'PETS', 'a', 'aa', 's', '4', '1', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, 'test34', 't@t.com', 'USER', 'test34', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, 'test91', 't@t.com', 'USER', 'admin', 'PETS', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(38, 'sonar prakash', 'raje.datta007@gmail.com', 'USER', '9029263748', 'PETS', 'sonar prakash', 'kolsewadi kyn e ', '', '4', '9029263748', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, 'aniket kajale', 'raje.datta007@gmail.com', 'USER', '9594936701', 'PETS', 'aniket kajale', 'badlapur w', '', '4', '9594936701', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(40, 'kadam mangesh', 'raje.datta007@gmail.com', 'USER', '98196777271', 'PETS', 'kadam mangesh', 'bhanushali hall kyn e', '', '4', '9819677271', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(41, 'thakare prakash', 'raje.datta007@gmail.com', 'USER', '9821995456', 'PETS', 'thakare prakash', 'shatri nager kyn e', '', '4', '9821995456', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(42, 'suryanshi ramchandra lahanu', 'raje.datta007@gmail.com', 'USER', '9892013037', 'PETS', 'suryanshi ramchandra lahanu', 'tisgoan road kyn e', '', '4', '9892013037', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, 'ramesh joshi', 'raje.datta007@gmail.com', 'USER', '9821461231', 'PETS', 'ramesh joshi', 'junni dom w', '', '4', '9821461231', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(44, 'prabhu titwala', 'raje.datta007@gmail.com', 'USER', '9664447053', 'PETS', 'prabhu titwala', 'gr patil clg titwala e', '', '4', '964447053', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(45, 'mhatre jayesh', 'raje.datta007@gmail.com', 'USER', '9819844435', 'PETS', 'mhatre jayesh', 'sai gaon manpada dombivali', '', '4', '9819844435', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(46, 'gagli hotel', 'raje.datta007@gmail.com', 'USER', '9223364444', 'PETS', 'gugli hotel', 'desai villege kyn shil road', '', '4', '9223364444', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(47, 'gawali dipak', 'raje.datta007@gmail.com', 'USER', '8976158959', 'PETS', 'gawali dipak', 'gawali chall kyn e', '', '4', '8976158959', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(48, 'kiran', 'raje.datta007@gmail.com', 'USER', '9969376711', 'PETS', 'kiran', 'pisawali kyn e', '', '4', '9969376711', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(49, 'sanap vijay', 'raje.datta007@gmail.com', 'USER', '9702711781', 'PETS', 'sanap vijay', 'sai baba nager kyn e', '', '421306', '8097858158', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, 'chachlani manisha', 'raje.datta007@gmail.com', 'USER', '9867232734', 'PETS', 'chachlani manisha', 'lodha heaven green park bunglo no 107', '', '4', '9867232734', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(51, 'shinganiya anil', 'raje.datta007@gmail.com', 'USER', '9324341111', 'PETS', 'shinghaniya anil', 'gol maidan ulasnager-1', '', '4', '9324311111', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, 'kailash shinde', 'raje.datta007@gmail.com', 'USER', '9821876999', 'PETS', 'kailash shinde', 'tata power kyn e', '', '421306', '9821876999', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(53, 'mahendra lodha', 'raje.datta007@gmail.com', 'USER', '9029633204', 'PETS', 'mahindra lodha', 'chandresen niketen g wing 303 lodha kyn e', '', '421306', '9029633204', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, 'pednekar pravin', 'raje.datta007@gmail.com', 'USER', '9987211374', 'PETS', 'pednekar pravin', 'd-11/8 saydri nager kyn w', '', '4', '9987211374', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(55, 'bhoir prakash', 'raje.datta007@gmail.com', 'USER', '9221528979', 'PETS', 'bhoir prakash', 'manpada [ratna]', '', '4', '9221528979', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(56, 'narode rajendra', 'raje.datta007@gmail.com', 'USER', '9930934399', 'PETS', 'narode rajendra', 'katemanivali kyn -e', '', '4', '9930934399', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, 'pillae balkrishna', 'raje.datta007@gmail.com', 'USER', '9819280390', 'PETS', 'pillage balkrishna', 'sai baba nager kyn e', '', '4', '9819280390', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, 'sing arpit', 'raje.datta007@gmail.com', 'USER', '8976235815', 'PETS', 'sing arpit', 'chinchapada road kyn -e', '', '4', '8976235815', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, 'prabhu gite', 'raje.datta007@gmail.com', 'USER', '9664447053', 'PETS', 'prabhu gite', 'titwala -e gr patil high school', '', '4', '9664447053', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(60, 'gurirya synthetic', 'raje.datta007@gmail.com', 'USER', '9222000887', 'PETS', 'gurirya synthetic', 'phase-1 midc dombivali -e', '', '4', '9222000887', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, 'old age home', 'raje.datta007@gmail.com', 'USER', '9821916422', 'PETS', 'old age home', 'hazi malag r kyn e', '', '421306', '9594839548', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(62, 'mhatre machindra', 'raje.datta007@gmail.com', 'USER', '9819535545', 'PETS', 'mhatre machindra', 'gograwadi dombivali -e', '', '4', '9819195154', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, 'bala bhoir', 'raje.datta007@gmail.com', 'USER', '9967570737', 'PETS', 'bala bhoir', ' gauri pada yogidham', '', '4', '9967570737', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(80, 'patel pratiksha', 'raje.datta007@gmail.com', 'USER', '9224081457', 'PETS', 'patel pratiksha', 'jammi baug  kyn e', '', '4', '9224081457', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(81, 'khare dipa', 'raje.datta007@gmail.com', 'USER', '9820869604', 'PETS', 'khare dipa', 'no', '', '4', '9820869604', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(82, 'yadav pradip', 'raje.datta007@gmail.com', 'USER', '9892130275', 'PETS', 'yadav pradip', 'wavanja road taloja', '', '4', '9892130275', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(83, 'bhoir moreshwar', 'raje.datta007@gmail.com', 'USER', '9930606999', 'PETS', 'bhoir moreshwar', 'pisawali', '', '4', '9930606999', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(84, 'mangesh pisawali', 'raje.datta007@gmail.com', 'USER', '9969376711', 'PETS', 'mangesh pisawali', 'manse offic kyn e', '', '4', '9969376711', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(85, 'zz', 'admin1@g.com', 'USER', 'admin', 'PETS', 'aaa', 'ss', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(86, 'spg', 'sharmili.gole@gmail.com', 'ADMIN', 'spg', 'HUMAN', 'spg', '3/5', 'chand', '400069', '9870512347', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(87, 'pdg1', 'pdg1@gm.com', 'ADMIN', 'pdg1', 'HUMAN', 'pdg1', '3/5', 'chand', '400069', '9870512347', '2', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(88, 'pdg2', 'pdg2@gm.com', 'USER', 'pdg2', 'HUMAN', 'pdg2', '3/5', 'chand', '400069', '9870512347', '2', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(89, 'z1', 'z1@gm.com', 'USER', 'z1', 'HUMAN', 'z1', 'z1', 'z2', 'z3', 'm1', 'm2', '2021-08-01', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MALE', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(90, 'z4female', 'z4r@gm.com', 'USER', 'z4f', 'HUMAN', 'z4female', 'q', '1', '3', 'ss', 'ss', '2021-08-01', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'FEMALE', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(92, 'z12', 'z1@gm.com', 'USER', 'z1', 'HUMAN', 'z12', '9', '9', '9', '9', '9', '2021-08-26', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'ONCE IN BLUE MOON', '', '', '', '', '', '', '', '', '', 'MALE', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(93, 'alle', 'alle@gmail.com', 'USER', 'alle', 'HUMAN', 'alle', '1', '2', '3', '4', '5', '2009-09-09', '10', '27', '16', '15', 'NO', '17', '18', '13', '33', '34', '23', '24', '28', '29', '30', '25', '26', 'IN WEEK LESS THAN 3 TIMES', '31', '32', '11', '19', '20', '21', '22', '35', '36', 'MALE', '14', '12', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(94, 'lasttest', 'admin@3.com', 'USER', 'lasttest', 'HUMAN', 'lasttest', 'j', 'j', 'j', 'j', 'h', '2009-09-09', 'jj', 'kjkl', 'kj', 'kjlk', 'GETUP', 'kjkl', 'kjkl', 'kjlk', 'k', 'klj', 'kj', 'kj', 'kjkl', 'jl', 'kj', 'kjlk', 'kjlk', 'IN WEEK MORE THAN 3 TIMES', 'kj', 'kj', 'j', 'kjk', 'kj', 'kj', 'kj', 'jhkj', 'jhkj', 'MALE', 'kjlk', 'j', 'kj', 'profession', 'jjjjkl', 'kjkl', 'just information', 'jl', 'just information', 'lkkl;', 'lkl;', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'lk;', 'l;k;l', 'lk;l', 'hkj'),
(95, 'adminzz', 'a@r.com', 'USER', 'admin', 'HUMAN', 'hgfhv1', 'gfh 1', 'hg 2', 'hgf 1', '456 2', '565 1', '2021-10-22', 'g 1', 'gf 1', 'yty 2', 'yt 1', 'GETUP 1', 'yt 1', 'yt 1', 'ytry  2', 'gdg  2', 'gf  1', 'rth 2', 'hfh 1', 'gdf 3', 'gf 2 ', 'gfg 1', 'yt 2', 'ytr 1', 'ONCE IN BLUE MOON 1', 'na 2', ' 1', '128  2', 'yt warna 2', 'yt gokul 1', 'yrty new 2', 'ytry 1', 'gdg 2', 'gfd 1', 'gfd 1', 'ytr  1', '4.6   1', 'bgf 1', 'profession', '565 2', '56 1', 'medication', 'hgf 1', 'productv2 2', 'gfdv2v  1', 'ytry 1', '0000-00-00', '', '2', '1', '2', '1', '2', '1', '4', '3', '2', '1', '2', '1', '3', '2', '1', '', '', '2', '1', 'gdfg 4  mmm', 'gdg 3 ', 'h 2 ', 'dfgdfg 1 '),
(97, 'zzz', 'admin@g.com', 'USER', 'zz', 'HUMAN', 'aaa', 'aa', 'aa', '400069', '09869068331', '09869068331', '2021-12-13', 'aa', '', '34', '34', 'GETUP', '43', '', '34', '', '', 'dfg', 'dfg', '', '', '', '', '', 'NO', '', '', 'gdfg', '', '', 'gdf', 'gdfg', '', '', 'MALE', '34', 'df', 'aa', 'job', 'N', 'O', 'camping', 'aa', '', '', '', '2021-12-13', 'Prashant_D_Gole_Photo (3).jpg', '34', '55', 'dfg', 'gdf', 'HEREDITARY', '', '', '', '', '', '', '', '', '', '', '', '', 'ASTHAMA', '', '', '', '', ''),
(98, 'zzz1', 'admin@h.com', 'USER', 'admin', 'HUMAN', '', '', '', '', '', '', '2000-12-12', 'goa', 'my allergy', '', '', 'YES', '', '', '', '', '', '', '', '', '', '', '', '', 'NO', '', '', '', '', '', '', '', '', '', 'MALE', '', '', 'fsf', '', '', '', '', '', '', '', '', '2021-12-13', 'Prashant_D_Gole_Photo.jpg', '', '', '', '', 'VATH', '', '', '', '', '', '', '', '', '', '', '', '', 'ASTHAMA', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_login_clinical_reports`
--

CREATE TABLE `user_login_clinical_reports` (
  `id` int(10) NOT NULL,
  `iduser_login` int(10) NOT NULL,
  `clinical_report_path` varchar(200) NOT NULL,
  `title_of_report` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_login_nextappointment`
--

CREATE TABLE `user_login_nextappointment` (
  `id` int(11) NOT NULL,
  `id_user_login` int(10) NOT NULL,
  `next_apt_date` date NOT NULL,
  `next_apt_time` varchar(20) NOT NULL,
  `any_information_1` varchar(200) NOT NULL,
  `any_information_2` varchar(200) NOT NULL,
  `type_of_apt` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendorlist`
--

CREATE TABLE `vendorlist` (
  `id` int(11) NOT NULL,
  `vendorname` varchar(100) NOT NULL,
  `vendorad1` varchar(100) NOT NULL,
  `vendorad2` varchar(100) NOT NULL,
  `vendorpin` varchar(6) NOT NULL,
  `vendormobile1` varchar(100) NOT NULL,
  `vendormobile2` varchar(100) NOT NULL,
  `contactperson` varchar(100) NOT NULL,
  `gstnumber` varchar(50) NOT NULL,
  `panno` varchar(25) NOT NULL,
  `emailid1` varchar(100) NOT NULL,
  `emailid2` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `any_information_1` varchar(200) NOT NULL,
  `any_information_2` varchar(200) NOT NULL,
  `referred_by` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendorlist`
--

INSERT INTO `vendorlist` (`id`, `vendorname`, `vendorad1`, `vendorad2`, `vendorpin`, `vendormobile1`, `vendormobile2`, `contactperson`, `gstnumber`, `panno`, `emailid1`, `emailid2`, `gender`, `any_information_1`, `any_information_2`, `referred_by`) VALUES
(1, 'abc', 'bgb', 'ff', 'frt', 're', 'r', 'r', 'ret', 'tret', 'zz@d.com', 'zz1@3.com', 'MALE', 'ret', 're', 'tret'),
(2, 'amarshala', 'sanskruti hall , amar bhawan', 'vikhroli thane ', '410098', '8734523789', '', 'mr rajendra 8745623999 sulakshna 2367834111', 'gst', 'aeiyughtye', 'info@amar.com', '', 'MALE', 'good for  shehad , credit terms 100 days', '', 'dr harsh'),
(3, '1', 'BUILDING 3 BLOCK 5', '400069', '400069', '', '', '', '', '', '1@gmail.com', '', 'MALE', '', '', '');

-- --------------------------------------------------------

--
-- Structure for view `nextvisitdata`
--
DROP TABLE IF EXISTS `nextvisitdata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `nextvisitdata`  AS  select `petdiagnosis`.`nextvisit` AS `nextvisit`,`petdiagnosis`.`petdetid` AS `petdetid`,`petsinformationdetail`.`petdetailsid` AS `petdetailsid`,`petsinformationdetail`.`username` AS `username`,`petsinformationdetail`.`gender` AS `gender`,`petsinformationdetail`.`pettype` AS `pettype`,`petsinformationdetail`.`petname` AS `petname`,`petsinformationdetail`.`dateofbirth` AS `dateofbirth` from (`petdiagnosis` join `petsinformationdetail` on((`petdiagnosis`.`petdetid` = `petsinformationdetail`.`petdetailsid`))) where (((month(`petdiagnosis`.`nextvisit`) = month(curdate())) and (year(`petdiagnosis`.`nextvisit`) = year(curdate()))) or (`petdiagnosis`.`nextvisit` = curdate())) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companyname`
--
ALTER TABLE `companyname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `humandiagnosis`
--
ALTER TABLE `humandiagnosis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `injectionlist`
--
ALTER TABLE `injectionlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listofdisease`
--
ALTER TABLE `listofdisease`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petdiagnosis`
--
ALTER TABLE `petdiagnosis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petsinformationdetail`
--
ALTER TABLE `petsinformationdetail`
  ADD PRIMARY KEY (`petdetailsid`);

--
-- Indexes for table `petsinformationhead`
--
ALTER TABLE `petsinformationhead`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petsinjections`
--
ALTER TABLE `petsinjections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petstypelist`
--
ALTER TABLE `petstypelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchumanstocklist`
--
ALTER TABLE `purchumanstocklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purcreturnhumanstocklist`
--
ALTER TABLE `purcreturnhumanstocklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saleshumanstocklist`
--
ALTER TABLE `saleshumanstocklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesreturnhumanstocklist`
--
ALTER TABLE `salesreturnhumanstocklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocklistofhuman`
--
ALTER TABLE `stocklistofhuman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login_clinical_reports`
--
ALTER TABLE `user_login_clinical_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login_nextappointment`
--
ALTER TABLE `user_login_nextappointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendorlist`
--
ALTER TABLE `vendorlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companyname`
--
ALTER TABLE `companyname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `humandiagnosis`
--
ALTER TABLE `humandiagnosis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `injectionlist`
--
ALTER TABLE `injectionlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `listofdisease`
--
ALTER TABLE `listofdisease`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `petdiagnosis`
--
ALTER TABLE `petdiagnosis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `petsinformationdetail`
--
ALTER TABLE `petsinformationdetail`
  MODIFY `petdetailsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `petsinformationhead`
--
ALTER TABLE `petsinformationhead`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `petsinjections`
--
ALTER TABLE `petsinjections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `petstypelist`
--
ALTER TABLE `petstypelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchumanstocklist`
--
ALTER TABLE `purchumanstocklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `purcreturnhumanstocklist`
--
ALTER TABLE `purcreturnhumanstocklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleshumanstocklist`
--
ALTER TABLE `saleshumanstocklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `salesreturnhumanstocklist`
--
ALTER TABLE `salesreturnhumanstocklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stocklistofhuman`
--
ALTER TABLE `stocklistofhuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `user_login_clinical_reports`
--
ALTER TABLE `user_login_clinical_reports`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_login_nextappointment`
--
ALTER TABLE `user_login_nextappointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendorlist`
--
ALTER TABLE `vendorlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
