<?php 
echo '<html>';
echo '<form>';
echo ' <div style="position:relative;width:200px;height:25px;border:0;padding:0;margin:0;">';
echo '  <select style="position:absolute;top:0px;left:0px;width:200px; height:25px;line-height:20px;margin:0;padding:0;"' .
          'onchange="document.getElementById(' . "'displayValue').value=this.options[this.selectedIndex].text; ".
          "document.getElementById('idValue').value=this.options[this.selectedIndex].value;' . '">';
  
   echo ' <option value="one">one</option>';
   echo ' <option value="two">two</option>';
 
 echo ' </select>';
 echo ' <input type="text" name="displayValue" id="displayValue" 
         placeholder="add/select a value" onfocus="this.select()"
         style="position:absolute;top:0px;left:0px;width:183px;width:180px\9;#width:180px;height:23px; height:21px\9;#height:18px;border:1px solid #556;"  > ';
  echo '<input name="idValue" id="idValue" type="hidden">';
echo '</div>';

echo '</form>';
echo '</html>';
?>
