-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2022 at 07:21 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorenta`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `mobile1`, `mobile2`) VALUES
(1, 'Ms Smita Amin', '', ''),
(2, 'David Karkhanis', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `daaentry`
--

CREATE TABLE `daaentry` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `empid` int(10) NOT NULL,
  `presentabsent` varchar(5) NOT NULL,
  `duty` varchar(10) NOT NULL,
  `outstationdatefrom` date NOT NULL,
  `outstationdateto` date NOT NULL,
  `shift` varchar(10) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` int(10) NOT NULL,
  `passengername` varchar(100) NOT NULL,
  `reportingtime` varchar(15) NOT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `actualintime` varchar(15) NOT NULL,
  `actualouttime` varchar(15) NOT NULL,
  `worktime` varchar(15) NOT NULL,
  `ottime` varchar(15) NOT NULL,
  `totalduration` varchar(15) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `basicsalary` decimal(19,2) NOT NULL,
  `totalallowance` decimal(19,2) NOT NULL,
  `cleaningallowance` decimal(19,2) NOT NULL,
  `nightallowance` decimal(19,2) NOT NULL,
  `dayallowance` decimal(19,2) NOT NULL,
  `doubleshift` decimal(19,2) NOT NULL,
  `latecoming` decimal(19,2) NOT NULL,
  `overtime` decimal(19,2) NOT NULL,
  `daysalary` decimal(19,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emptable`
--

CREATE TABLE `emptable` (
  `ecode` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `shift` varchar(10) NOT NULL,
  `intime` varchar(15) NOT NULL,
  `outtime` varchar(15) NOT NULL,
  `tottime` varchar(15) NOT NULL,
  `basicsal` decimal(18,2) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `doj` date NOT NULL,
  `inhh` varchar(2) NOT NULL,
  `inmm` varchar(2) NOT NULL,
  `outhh` varchar(2) NOT NULL,
  `outmm` varchar(2) NOT NULL,
  `tothh` varchar(2) NOT NULL,
  `totmm` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emptable`
--

INSERT INTO `emptable` (`ecode`, `name`, `shift`, `intime`, `outtime`, `tottime`, `basicsal`, `designation`, `doj`, `inhh`, `inmm`, `outhh`, `outmm`, `tothh`, `totmm`) VALUES
(1, 'Deepak Patel', 'D', '07:30', '16:30', '09:00', '15000.00', 'Manager', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(5, 'Mr, Vijay Rathod', '', '', '', '', '0.00', '', '0000-00-00', '0', '0', '0', '0', '0', '0'),
(6, 'Vishnu Vandre', '', '', '', '', '0.00', '', '0000-00-00', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `shifttable`
--

CREATE TABLE `shifttable` (
  `id` int(11) NOT NULL,
  `shift` varchar(15) NOT NULL,
  `intime` varchar(11) NOT NULL,
  `outime` varchar(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `workduration` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shifttable`
--

INSERT INTO `shifttable` (`id`, `shift`, `intime`, `outime`, `description`, `workduration`) VALUES
(1, 'GS', '07:30', '16:30', 'General Shift', '09:00'),
(2, 'DP', '06:30', '15:30', 'Dyanesh', '09:00'),
(3, 'D', '07:00', '16:00', 'Day Time', '09:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `nameofperson` varchar(100) NOT NULL,
  `mobile1` varchar(50) NOT NULL,
  `mobile2` varchar(50) NOT NULL,
  `workin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `user_type`, `user_password`, `nameofperson`, `mobile1`, `mobile2`, `workin`) VALUES
(1, 'Deepak', 'ADMIN', 'deepak@1236', 'Deepak Patel', '', '', 'DAA'),
(2, 'Jayant', 'ADMIN', 'Jayant@9999', 'Jayant Deshpande', '', '', 'DAA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daaentry`
--
ALTER TABLE `daaentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emptable`
--
ALTER TABLE `emptable`
  ADD UNIQUE KEY `ecode` (`ecode`);

--
-- Indexes for table `shifttable`
--
ALTER TABLE `shifttable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `daaentry`
--
ALTER TABLE `daaentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `emptable`
--
ALTER TABLE `emptable`
  MODIFY `ecode` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `shifttable`
--
ALTER TABLE `shifttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
