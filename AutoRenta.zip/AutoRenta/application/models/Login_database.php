<?php  

Class Login_Database extends CI_Model 
{
// Insert registration data in database
public function registration_insert($data)
{
// Query to check whether username already exist or not
//  $condition = "user_name =" . "'" . $data['user_name'] . "'";
  $condition = "user_name =" . "'" . $data['user_name'] . "' AND " . "user_type =" . "'" . $data['user_type']  . "' AND " . "workin =" . "'" . $data['workin'] . "'" ;


// echo $condition;

  $this->db->select('*');
  $this->db->from('user_login');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('user_login', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}


// insert drr data

// Insert registration data in database


public function drr_registration_insert($data)
{
// Query to check whether username already exist or not
//  $condition = "user_name =" . "'" . $data['user_name'] . "'";
//  $condition = "user_name =" . "'" . $data['user_name'] . "' AND " . "user_type =" . "'" . $data['user_type']  . "' AND " . "workin =" . "'" . $data['workin'] . "'" ;

$condition = "date =" . "'" . $data['date'] . "' AND " . "empid =" .  $data['empid']  ; // . "' AND " . "workin =" . "'" . $data['workin'] . "'" ;

//  echo $condition;
if ($data['presentabsent']  == "DD" or  $data['presentabsent']  == "DH"  or  $data['presentabsent']  == "HN" )   //  or $data['presentabsent']  == "PO")
{
      $this->db->insert('daaentry', $data);
      if ($this->db->affected_rows() > 0)
      {
             return true;
      }
      else 
      {
         return false;
      }
}
else
{
 $this->db->select('*');
  $this->db->from('daaentry');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
      $this->db->insert('daaentry', $data);
      if ($this->db->affected_rows() > 0)
      {
             return true;
      }
      else 
      {
         return false;
      }
  }
  else
  {
    return false;
   }
}
}
// oprentry update start
public function oprentry_main_voucher_update($oprentrymaindataupdate)
{ 
$woption = $oprentrymaindataupdate['option' ];
if ($woption == 1)
{
 $wacname = "";
 $wtypeledger = "";
$wacode1 = "";
$wamountgiventotal = 0;
 $sql ="SELECT * FROM accodeledger where id = " .  $oprentrymaindataupdate['accodeid' ]  ; 
 $query1 = $this->db->query($sql);  
  foreach ($query1->result() as $row)
  {  // 3.0
          $wacname = $row->acname ;
          $wtypeledger = $row->typeledger ;
          $wacode1 = $row->accode ;
          $wamountgiventotal = $row->amountgiventotal;
  } 
$wacodecramt = 0;
 $sql ="SELECT * FROM accodeledger where id = " .  $oprentrymaindataupdate['accodecr' ]  ; 
 $query1 = $this->db->query($sql);  
  foreach ($query1->result() as $row)
  {  // 3.0
          $wacodecramt  = $row->amountgiventotal;
  }


$condition = "accodeid=" .  $oprentrymaindataupdate['accodeid' ] . " AND " . "monthledger =" .  $oprentrymaindataupdate['monthofledger' ]  . " AND " . "yearledger  =" .   $oprentrymaindataupdate['yearofledger' ]  ;

 //echo $condition;

 $this->db->select('*');
  $this->db->from('monthyearledger');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
     $newdata= array(
                 'accodeid' =>  $oprentrymaindataupdate['accodeid' ] ,
                 'accode' =>$wacode1 ,           
                  'acname' => $wacname, 
                  'typeledger' =>  $wtypeledger,
                  'openingbalance' =>  0,
                  'amountgiventotal' =>  $oprentrymaindataupdate['amountgiventotal'],
                  'amountspendtotal' => 0,
                 'balanceamount'=>0,
                'monthledger' =>   $oprentrymaindataupdate['monthofledger'],
                  'yearledger'  =>  $oprentrymaindataupdate['yearofledger']
                  );   
      $this->db->insert('monthyearledger',  $newdata);

// update in accodeledger start
         $newdata1 = array(
          'amountgiventotal' =>  $wamountgiventotal +  $oprentrymaindataupdate['amountgiventotal']
         );
            $this->db->where('id',$oprentrymaindataupdate['accodeid' ]);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
          $this->db->update('accodeledger',  $newdata1);


        $newdata2 = array(
          'amountgiventotal' =>   $wacodecramt  +  $oprentrymaindataupdate['amountgiventotal']
         );
           $this->db->where('id',$oprentrymaindataupdate['accodecr' ]);
          $this->db->update('accodeledger',  $newdata2);


// update in accodeledger end

  }
else
{
//echo " in else ";

               $ag= 0;
               $as = 0;
               $ab =0;
//echo $condition;
               $sql ="SELECT * FROM monthyearledger where " . $condition  ; 
               $query1 = $this->db->query($sql);  
               foreach ($query1->result() as $row)
               {  // 3.0
//echo $row->amountgiventotal  . "  from db " ;
//echo $oprentrymaindataupdate['amountgiventotal'] . " from vb " ;
                     $ag = $row->amountgiventotal +  $oprentrymaindataupdate['amountgiventotal'];
                     $as =  $row->amountspendtotal ;
                     $ab = $row->balanceamount ;
               } 

     $newdata= array(
                 'accodeid' =>  $oprentrymaindataupdate['accodeid' ] ,
                 'accode' =>$wacode1 ,           
                  'acname' => $wacname, 
                  'typeledger' =>  $wtypeledger,
                  'openingbalance' =>  0,
                  'amountgiventotal' =>  $ag,
                  'amountspendtotal' => $as,
                 'balanceamount'=>0
                  );   
                $this->db->where('monthledger',$oprentrymaindataupdate['monthofledger']);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
               $this->db->where('yearledger',$oprentrymaindataupdate['yearofledger']); 
                $this->db->update('monthyearledger',  $newdata);
         $newdata1 = array(
          'amountgiventotal' =>  $wamountgiventotal +  $oprentrymaindataupdate['amountgiventotal']
         );
            $this->db->where('id',$oprentrymaindataupdate['accodeid' ]);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
          $this->db->update('accodeledger',  $newdata1);


        $newdata2 = array(
          'amountgiventotal' =>   $wacodecramt  +  $oprentrymaindataupdate['amountgiventotal']
         );
           $this->db->where('id',$oprentrymaindataupdate['accodecr' ]);
          $this->db->update('accodeledger',  $newdata2);
}


} // option 1 of cash deposit over

// option 2 expenses without employee code start

if ($woption == 2 or $woption == 3)
{
 $wacname = "";
 $wtypeledger = "";
$wacode1 = "";
$wamountgiventotal = 0;
 $sql ="SELECT * FROM accodeledger where id = " .  $oprentrymaindataupdate['accodeid' ]  ; 
 $query1 = $this->db->query($sql);  
  foreach ($query1->result() as $row)
  {  // 3.0
          $wacname = $row->acname ;
          $wtypeledger = $row->typeledger ;
          $wacode1 = $row->accode ;
          $wamountgiventotal = 0;
           $wamountspendtotal  = $row->amountspendtotal;
  } 
$wacodedramt = 0;
 $sql ="SELECT * FROM accodeledger where id = " .  $oprentrymaindataupdate['accodedr' ]  ; 
 $query1 = $this->db->query($sql);  
  foreach ($query1->result() as $row)
  {  // 3.0
          $wacodedramt  = $row->amountspendtotal;
  }


$condition = "accodeid=" .  $oprentrymaindataupdate['accodeid' ] . " AND " . "monthledger =" .  $oprentrymaindataupdate['monthofledger' ]  . " AND " . "yearledger  =" .   $oprentrymaindataupdate['yearofledger' ]  ;

 //echo $condition;

 $this->db->select('*');
  $this->db->from('monthyearledger');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
     $newdata= array(
                 'accodeid' =>  $oprentrymaindataupdate['accodeid' ] ,
                 'accode' =>$wacode1 ,           
                  'acname' => $wacname, 
                  'typeledger' =>  $wtypeledger,
                  'openingbalance' =>  0,
                  'amountgiventotal' => 0,  
                  'amountspendtotal' => $oprentrymaindataupdate['amountspendtotal'],
                 'balanceamount'=>0,
                'monthledger' =>   $oprentrymaindataupdate['monthofledger'],
                  'yearledger'  =>  $oprentrymaindataupdate['yearofledger']
                  );   
      $this->db->insert('monthyearledger',  $newdata);

// update in accodeledger start
         $newdata1 = array(
          'amountspendtotal' =>  $wamountspendtotal +  $oprentrymaindataupdate['amountspendtotal']
         );
            $this->db->where('id',$oprentrymaindataupdate['accodeid' ]);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
          $this->db->update('accodeledger',  $newdata1);


        $newdata2 = array(
          'amountspendtotal' =>   $wacodedramt  +  $oprentrymaindataupdate['amountspendtotal']
         );
           $this->db->where('id',$oprentrymaindataupdate['accodedr' ]);
          $this->db->update('accodeledger',  $newdata2);


// update in accodeledger end

  }
else
{
//echo " in else ";

               $ag= 0;
               $as = 0;
               $ab =0;
//echo $condition;
               $sql ="SELECT * FROM monthyearledger where " . $condition  ; 
               $query1 = $this->db->query($sql);  
               foreach ($query1->result() as $row)
               {  // 3.0
//echo $row->amountgiventotal  . "  from db " ;
//echo $oprentrymaindataupdate['amountgiventotal'] . " from vb " ;
                     $ag = $row->amountgiventotal;
                     $as =  $row->amountspendtotal  +  $oprentrymaindataupdate['amountspendtotal'] ;
                     $ab = $row->balanceamount ;
               } 

     $newdata= array(
                 'accodeid' =>  $oprentrymaindataupdate['accodeid' ] ,
                 'accode' =>$wacode1 ,           
                  'acname' => $wacname, 
                  'typeledger' =>  $wtypeledger,
                  'openingbalance' =>  0,
                  'amountgiventotal' =>  $ag,
                  'amountspendtotal' => $as,
                 'balanceamount'=>0
                  );   
                $this->db->where('monthledger',$oprentrymaindataupdate['monthofledger']);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
               $this->db->where('yearledger',$oprentrymaindataupdate['yearofledger']); 
                $this->db->update('monthyearledger',  $newdata);
         $newdata1 = array(
          'amountspendtotal' =>  $wamountspendtotal +  $oprentrymaindataupdate['amountspendtotal']
         );
            $this->db->where('id',$oprentrymaindataupdate['accodeid' ]);     //           'id' =>$oprentrymaindataupdate['accodeid' ],
          $this->db->update('accodeledger',  $newdata1);


        $newdata2 = array(
          'amountspendtotal' =>   $wacodedramt  +  $oprentrymaindataupdate['amountspendtotal']
         );
           $this->db->where('id',$oprentrymaindataupdate['accodedr' ]);
          $this->db->update('accodeledger',  $newdata2);
}


}  



// option 2 expenses without employee code end


}
// oprentry update end
//
// main oprentry insert start

public function oprentry_main_voucher_insert($oprentrymaindata)
{    
        $this->db->insert('paymentregister', $oprentrymaindata);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    else 
    {
       return false;
    }
}
// opr entry insert end


//
// oprentry insert start

public function oprentry_voucher_insert($oprentrydata)
{
        $this->db->insert('paymentregister', $oprentrydata);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    else 
    {
       return false;
    }
}
// opr entry insert end
// insert customer
public function customer_registration_insert($data)
{
// Query to check whether username already exist or not
  $condition = "name =" . "'" . $data['name'] . "'";

//echo $condition;

  $this->db->select('*');
  $this->db->from('customer');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('customer', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}
//

// insert employee
public function emp_registration_insert($data)
{ /*                     emp_registration_insert() */
// Query to check whether username already exist or not
  $condition = "name =" . "'" . $data['name'] . "'";

//echo $condition;

  $this->db->select('*');
  $this->db->from('emptable');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('emptable', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}
//


// insert stock

// insert into stock table

// Insert registration stock data in database
public function registration_stock_insert($data)
{
// Query to check whether username already exist or not
  $condition = "stockname =" . "'" . $data['stockname'] . "'";
  //  medicinename
//echo $condition;

  $this->db->select('*');
  $this->db->from('stocklistofhuman');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('stocklistofhuman', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}

//


// insert into stock table over



// insert stock over

// insert sale bill


 public function human_salebill_insert($data)
 {
        $this->db->insert('saleshumanstocklist', $data);
        if ($this->db->affected_rows() > 0)
        {
 
             return true;
        }
  
        else 
        {
 
          return false;
        }
 }


// insert sale bill over

// insert human patient diagnosis

 public function human_patient_diagnosis_insert($data)
 {

//die("here");
        $this->db->insert('humandiagnosis', $data);
        if ($this->db->affected_rows() > 0)
        {
//die("t");
             return true;
        }
  
        else 
        {
//die("f");
          return false;
        }


 }

// insert human patient diagnosis over

// insert human purchase bill start

 public function human_purchasebill_insert($data)
 {

        $this->db->insert('purchumanstocklist', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
  
        else 
        {
          return false;
        }
 }

// insert human purchase bill end

// insert into vendor table

// Insert registration data in database
public function vendor_registration_insert($data)
{
// Query to check whether username already exist or not
  $condition = "vendorname =" . "'" . $data['vendorname'] . "'";

//echo $condition;

  $this->db->select('*');
  $this->db->from('vendorlist');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('vendorlist', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}

//


// insert into vendor table over

// Insert registration data in petlist database
public function petlist_insert($data)
{
// Query to check whether username already exist or not

//echo  $data;
//print_r($data);
//  echo "   here                insert .............................. " ;
 // $condition = "pettype =" . "'" . $data['username'] .  "' AND " . "petsubtype =" . "'" . $data['email_value'] .  "'";
  $condition = "pettype =" . "'" . $data['pettype'] . "' AND " . "petsubtype =" . "'" . $data['petsubtype'] . "'";



//echo $condition;

  $this->db->select('*');
  $this->db->from('petstypelist');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('petstypelist', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
// echo "error ********************";
       return false;
    }
}

// disease list start

public function diseaselist_insert($data)
{
// Query to check whether username already exist or not

  $condition = "diseasename =" . "'" . $data['diseasename'] . "' AND " . "seasonspecific =" . "'" . $data['seasonspecific'] . "'";


  $this->db->select('*');
  $this->db->from('listofdisease');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('listofdisease', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}

// disease list end


// Insert injection data in database
public function injectionlist_insert($data)
{
// Query to check whether username already exist or not
  $condition = "injectionname =" . "'" . $data['injectionname'] . "' AND " . "usedindisease =" . "'" . $data['usedindisease'] . "'";

//echo $condition;

  $this->db->select('*');
  $this->db->from('injectionlist');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('injectionlist', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}

//




//
// Read data using username and password
public function login($data) 
{
    $condition = "user_name =" . "'" . $data['username'] . "' AND " . "user_password =" . "'" . $data['password'] . "' AND "  . "workin =" . "'" . $data['pethuman']  . "'"  ;
//   $condition = "user_name =" . "'" . $data['username'] . "' AND " . "user_password =" . "'" . $data['password'] . "'  " ;  // . "pethuman =" . "'" . $data['pethuman']  . "'"  ;


//echo $condition;

//die("chk");


    $this->db->select('*');
    $this->db->from('user_login');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1)
    {
        return true;
    }
    else 
    {
       return false;
    }
}
// Read data from database to show data in admin page
public function read_user_information($username) 
{
    $condition = "user_name =" . "'" . $username . "'";
    $this->db->select('*');
    $this->db->from('user_login');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1) 
    {
        return $query->result();
    } 
    else 
    {
       return false;
    }
}
}
?>