<?php


class INJECTIONCRUD extends CI_Model
{


    public function get_itemCRUD()
{
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("injectionlist"); // get("items");
        return $query->result();
    }


    public function insert_item()
    {    
        $data = array(
            'user_email' => $this->input->post('useremail'),
            'user_password' => $this->input->post('password')
        );
        return $this->db->insert('injectionlist', $data);  // items
    }


    public function update_item($id) 
    {
// die (" in update here");
        $data=array(
            'approxprice' => $this->input->post('approxprice'),
            'usedindisease'=> $this->input->post('usedindisease'),
            'remarks'=>$this->input->post('remarks')
        );
        if($id==0){
            return $this->db->insert('injectionlist',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('injectionlist',$data); // items
        }        
    }


    public function find_item($id)
    {
        return $this->db->get_where('injectionlist', array('id' => $id))->row();  // items
    }


    public function delete_item($id)
    {
        return $this->db->delete('injectionlist', array('id' => $id));  // items
    }
}
?>