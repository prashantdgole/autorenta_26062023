<?php
class ItemCRUDModel extends CI_Model
{
    public function get_itemCRUD()
   {
        if(!empty($this->input->get("search")))
       {
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("user_login"); // get("items");
        return $query->result();
   }

 public function get_empname()
   {
        $query = $this->db->query('SELECT * FROM emptable ');
        return $query->result(); 
    }
 public function get_shifttable()
   {
        $query = $this->db->query('SELECT * FROM shifttable ');
        return $query->result(); 
    }
 public function get_customer()
   {
        $query = $this->db->query('SELECT * FROM customer ');
        return $query->result(); 
    }
  public function datewise_daa_list($fdate,$tdate)
  {
    if ($fdate == '')
    {
        $query = $this->db->query("Select * from daaentry ");
        return $query->num_rows(); 
    }
    else
    {
        $query = $this->db->query("Select * from daaentry where date >= " . $fdate . " and date <= " . $tdate);
        return $query->num_rows(); 
    }
   }
 public function daa_emp_list()
  {
        $query = $this->db->query("Select * from emptable" );
        return $query->num_rows(); 
    }
 public function daa_emp_records($limit,$offset)
   {
   // $this->db->limit($limit, $offset);
     $query = $this->db->get("emptable",$limit, $offset);
     return $query->result();
    }
  public function get_daa_records($fdate,$tdate,$limit,$offset)
   {
/*
     $where_array = array( 'pethuman'=>'PETS');
     $query = $this->db->get_where("user_login",$where_array, $limit, $offset);  
*/
     $this->db->limit($limit, $offset);
 //  $where_array = array( 'date >=' , $fdate ,  'date <=', $tdate );
 //   $where_array = 'date >=' , $fdate , ' and ' , 'date <=', $tdate ;
     $this->db->where('date >=', $fdate);
    $this->db->where('date <=', $tdate);
     $query = $this->db->get("daaentry",$limit, $offset);
     return $query->result();
    }

}
// die ("eof item crud");
?>