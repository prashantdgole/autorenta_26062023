<?php
class ItemCRUDModel extends CI_Model
{
    public function get_itemCRUD()
   {
        if(!empty($this->input->get("search")))
       {
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("user_login"); // get("items");
        return $query->result();
   }
  public function find_emp_item($id)
    {
 
        return $this->db->get_where('emptable', array('ecode' => $id))->row();  // items
    }
  public function find_cust_item($id)
    {
        return $this->db->get_where('customer', array('id' => $id))->row();  // items
    }
  public function find_drr_item($id)
    {
 
        return $this->db->get_where('daaentry', array('id' => $id))->row();  // items
    }
  public function find_pay_item($id)
    {
        return $this->db->get_where('paymentregister', array('id' => $id))->row();  // items
    }
   public function find_user_item($id)
    {
//echo "here";
        return $this->db->get_where('user_login', array('id' => $id))->row();  // items
    }
 public function delete_user_item($id)
    {
        return $this->db->delete('user_login', array('id' => $id));  // items
    }
 public function delete_emp_item($id)
    { 
                 return $this->db->delete('emptable', array('ecode' => $id));  // items
    }
 public function delete_cust_item($id)
    { 
                 return $this->db->delete('customer', array('id' => $id));  // items
    }

public function delete_all_drr_item($fdate,$tdate,$eid)
{
/*
        $query = $this->db->query("delete  FROM daaentry where  ( (empid = " . $eid . ") and ( date >= '"  . $fdate . "' and date <= '" . $tdate . "'))" );
   $q = "delete FROM daaentry where  ( (empid = " . $eid . ") and ( date >= '"  . $fdate . "' and date <= '" . $tdate . "'))";
echo $q;
// echo $query->result();
// die("e");
        return $query->result(); 
*/
	$this->db->where('empid', $eid);
                 $this->db->where("date >=  '$fdate'");
                 $this->db->where("date <= '$tdate'");	
	return $this->db->delete('daaentry');

}
 public function delete_drr_item($id)
    { 
                 return $this->db->delete('daaentry', array('id' => $id));  // items
    }
 public function delete_pay_item($id)
    { 
//die("j");
//          $a = readline('Enter a string: ');
 //         if ($a == 'Y' or $a == 'y')
 //       {
                 return $this->db->delete('paymentregister', array('id' => $id));  // items
//        }
    }


public function get_oprentry_details($dt1,$dt2,$wecode,$wexpcode)
{  
//echo " dt 1 " . $dt1 . " dt2 " .  $dt2 . " ec " . $wecode . " exp " .  $wexpcode  ;
      if ($wecode == "0" and $wexpcode == "0")
      {
        $query = $this->db->query("SELECT * FROM paymentregister where (date >= '" . $dt1 . "' and date <= '" . $dt2 . "')    order by date   " );
       }
       if ($wecode <> "0")
       {
        $query = $this->db->query("SELECT * FROM paymentregister where ((date >= '" . $dt1 . "' and date <= '" . $dt2 . "') and accode = " . $wecode   . ") order by date , accode " );
        }
       if ($wexpcode <> "0")
       {
//echo "here";
        $query = $this->db->query("SELECT * FROM paymentregister where ((date >= '" . $dt1 . "' and date <= '" . $dt2 . "') and ( glcodecr = " . $wexpcode . " or glcodedr = " . $wexpcode   . ")) order by date , accode " );
        }
      if ($wecode > "0" and $wexpcode > "0")
      {
        $query = $this->db->query("SELECT * FROM paymentregister where ((date >= '" . $dt1 . "' and date <= '" . $dt2 . "') and accode = " . $wecode . " and ( glcodecr = " . $wexpcode . " or glcodedr = " . $wexpcode . ")"  . ") order by date , accode " );
      }
        return $query->result(); 
}


public function get_oprentry_cash_book_details($dt1,$dt2)
{  
        $query = $this->db->query("SELECT * FROM paymentregister where ((date >= '" . $dt1 .  "'  and date <= '" . $dt2 .  "')  and  ( glcodecr = 1 or glcodedr = 1 ) ) order by date , accode " );
        return $query->result(); 
}


 public function get_empname()
   {
        $query = $this->db->query('SELECT * FROM emptable order by name ');
        return $query->result(); 
    }


public function get_accodeledger()
{
        $query = $this->db->query('SELECT * FROM accodeledger order by typeledger , acname  ');
        return $query->result(); 
}


public function get_monthyearledger()
{
        $query = $this->db->query('SELECT * FROM monthyearledger order by  yearledger , monthledger   ');
        return $query->result(); 
}


public function get_paymentregister()
{
        $query = $this->db->query('SELECT * FROM paymentregister order by  date    ');
        return $query->result(); 
}


public function get_daaentry()
{
        $query = $this->db->query('SELECT * FROM daaentry order by  date  , empid  ');
        return $query->result(); 
}


public function get_ledger_income()
{
        $query = $this->db->query("SELECT * FROM accodeledger where typeledger = 'INC' ");
        return $query->result(); 
}
public function get_ledger_expenses()
{
        $query = $this->db->query("SELECT * FROM accodeledger where typeledger = 'EXP' ");
        return $query->result(); 
}
public function get_ledger_bank()
{
        $query = $this->db->query("SELECT * FROM accodeledger where typeledger = 'BANK' ");
        return $query->result(); 
}

 public function get_drr_details($dt1,$dt2)
   {
        $query = $this->db->query("SELECT * FROM daaentry where date >= '"  . $dt1 . "' and date <= '" . $dt2 . "'" );
        return $query->result(); 
    }

 public function get_drr_details_emp($dt1,$dt2,$eid)
   {
        $query = $this->db->query("SELECT * FROM daaentry where  ( (empid = " . $eid . ") and ( date >= '"  . $dt1 . "' and date <= '" . $dt2 . "'))" );
        return $query->result(); 
    }



 public function get_shifttable()
   {
        $query = $this->db->query('SELECT * FROM shifttable ');
        return $query->result(); 
    }
 public function get_customer()
   {
        $query = $this->db->query('SELECT * FROM customer ');
        return $query->result(); 
    }

   public function update_user_item($id) 
    {
        $data=array(
            'user_password'=> $this->input->post('password'), 
            'nameofperson' => $this->input->post('nameofperson'),
            'mobile1' => $this->input->post('mobile1'),
           'mobile2' => $this->input->post('mobile2')
        );
        if($id==0){
            return $this->db->insert('user_login',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('user_login',$data); // items
        }        
    }

 public function update_drr_item($id) 
    {
// echo  $id . "here";
        $data=array(
              'presentabsent'=> $this->input->post('presentid1'), 
              'duty' => $this->input->post('dutyid1'),
              'outstationdatefrom' => $this->input->post('outdate1_1'),
              'outstationdateto' => $this->input->post('outdate1_2'),
              'shift' => $this->input->post('shiftid1'),
              'passengername' => $this->input->post('pass1'),
              'intime' => $this->input->post('intime11'),
              'outtime' => $this->input->post('outtime1'),
               'actualintime' => $this->input->post('acttime1'),
               'actualouttime' => $this->input->post('actouttime1'),
                'worktime' => $this->input->post('workduration1'),
                'ottime' => $this->input->post('ottime1'),
                'totalduration' => $this->input->post('tottime1'),
                'remarks' => $this->input->post('remarks1'),
                'basicsalary' => $this->input->post('basicsalary'),
                'totalallowance' => $this->input->post('totalallowance'),
                'cleaningallowance' => $this->input->post('cleaningallowance'),
                'nightallowance' => $this->input->post('nightallowance'),
                'dayallowance' => $this->input->post('dayallowance'),
                'doubleshift' => $this->input->post('doubleshift'),
                'latecoming' => $this->input->post('latecoming'),
                'overtime' => $this->input->post('overtime'),
                 'daysalary' => $this->input->post('daysalary')
        );
        if($id==0){
            return $this->db->insert('daaentry',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('daaentry',$data); // items
        }        
    }

//
// payt update start
   public function update_pay_item($id,$glcodedr,$glcodecr) 
    {
//echo "<br>" . "ID " .  $id;
//echo " gl dr " . $glcodedr;
//echo " cr " . $glcodecr;
//die("here");
      $neweid1 =  $this->input->post('newempid1');

       if ($neweid1 == 0)
       {
//echo "stp 1";
        $data=array(
            'date'=>$this->input->post('regdate'), 
            'openingbalance'=> $this->input->post('opbalance'), 
            'amountgiven' => $this->input->post('amountgiven'),
            'amountspend' => $this->input->post('expensesmade'),
            'narration1' => $this->input->post('narration1'),
            'narration2' => $this->input->post('narration2'),
            'amountadjusted' => $this->input->post('amountadjusted'),
            'salarymonth' => $this->input->post('salarymonth'),
            'salaryyear' => $this->input->post('adjyear'),
            'remarks' => $this->input->post('remarks')
        );
       }
       else
       {
//echo "stp 2";
       if ($glcodecr == 0 and $glcodedr == 0 )
       {
//echo "stp 3";
        $data=array(
            'date'=>$this->input->post('regdate'), 
            'openingbalance'=> $this->input->post('opbalance'), 
            'amountgiven' => $this->input->post('amountgiven'),
            'amountspend' => $this->input->post('expensesmade'),
            'narration1' => $this->input->post('narration1'),
            'narration2' => $this->input->post('narration2'),
            'accode' =>  $this->input->post('newempid1'),
            'acname' =>   $this->input->post('newempid1'),
            'amountadjusted' => $this->input->post('amountadjusted'),
            'salarymonth' => $this->input->post('salarymonth'),
            'salaryyear' => $this->input->post('adjyear'),
            'remarks' => $this->input->post('remarks')
        );
        }
        else
        {
//echo "stp 4";
        $data=array(
            'date'=>$this->input->post('regdate'), 
            'openingbalance'=> $this->input->post('opbalance'), 
            'amountgiven' => $this->input->post('amountgiven'),
            'amountspend' => $this->input->post('expensesmade'),
            'narration1' => $this->input->post('narration1'),
            'narration2' => $this->input->post('narration2'),
            'amountadjusted' => $this->input->post('amountadjusted'),
            'salarymonth' => $this->input->post('salarymonth'),
            'salaryyear' => $this->input->post('adjyear'),
            'remarks' => $this->input->post('remarks')
        );
         }
       }
        if($id==0)
       {
            return $this->db->insert('paymentregister',$data);   // items
        }
      else
      {
//echo "stp LAST ";
//die("last");
            $this->db->where('id',$id);
            return $this->db->update('paymentregister',$data); // items
        }        
    }
// cust update end

//
// cust update start
   public function update_cust_item($id) 
    {
        $data=array(
            'name'=> $this->input->post('name'), 
            'mobile1' => $this->input->post('mobile1'),
            'mobile2' => $this->input->post('mobile2')
        );
        if($id==0){
            return $this->db->insert('customer',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('customer',$data); // items
        }        
    }
// cust update end
   public function update_emp_item($id) 
    {
        $data=array(
            'name'=> $this->input->post('name'), 
            'shift' => $this->input->post('shift'),
            'intime' => $this->input->post('intime'),
           'outtime' => $this->input->post('outtime'),
           'tottime' => $this->input->post('tottime'),
           'basicsal' => $this->input->post('basicsal'),
           'designation' => $this->input->post('designation')
        );
        if($id==0){
            return $this->db->insert('emptable',$data);   // items
        }else{
            $this->db->where('ecode',$id);
            return $this->db->update('emptable',$data); // items
        }        
    }
  public function datewise_daa_list($fdate,$tdate)
  {
    if ($fdate == '')
    {
        $query = $this->db->query("Select * from daaentry  order by date , empid,ID ");
        return $query->num_rows(); 
    }
    else
    {
        $query = $this->db->query("Select * from daaentry where date >= '" . $fdate . "' and date <= '" . $tdate . "'  order by date , empid ,ID");
        $q1 = "Select * from daaentry where date >= '" . $fdate . "' and date <= '" . $tdate . "'  order by date , empid,ID ";
//echo $q1;
//die("1");
        return $query->num_rows(); 
    }
   }
  public function empdatewise_payroll_list($fdate,$tdate)
  {
    if ($fdate == '')
    {
        $query = $this->db->query("Select * from daaentry order by empid, date ");
         return $query->result(); 
    }
    else
    {
        $query = $this->db->query("Select * from daaentry where date >= '" . $fdate . "' and date <= '" . $tdate . "' order by empid , date " );
         return $query->result(); 
    }
 
   }
 public function daa_customer_list()
  {
        $query = $this->db->query("Select * from customer" );
        return $query->num_rows(); 
    }
 public function daa_customer_records($limit,$offset)
   {
   // $this->db->limit($limit, $offset);
     $query = $this->db->get("customer",$limit, $offset);
     return $query->result();
    }
 public function daa_emp_list()
  {
        $query = $this->db->query("Select * from emptable" );
        return $query->num_rows(); 
    }
 public function daa_emp_records($limit,$offset)
   {
   // $this->db->limit($limit, $offset);
     $query = $this->db->get("emptable",$limit, $offset);
     return $query->result();
    }
  public function get_daa_records($fdate,$tdate,$limit,$offset)
   {
// die("h");
// echo $_SESSION['start_date'];
echo $limit;
echo $offset;
/*
     $where_array = array( 'pethuman'=>'PETS');
     $query = $this->db->get_where("user_login",$where_array, $limit, $offset);  
*/


 //  $where_array = array( 'date >=' , $fdate ,  'date <=', $tdate );
 //   $where_array = 'date >=' , $fdate , ' and ' , 'date <=', $tdate ;
 //    $this->db->where('date >=', $fdate);
  //  $this->db->where('date <=', $tdate);
 //   $this->db->where("DATE_FORMAT(date,'%Y-%m-%d') >='$first_date'");
 //   $this->db->where("DATE_FORMAT(date,'%Y-%m-%d') <='$second_date'");
/*
    $this->db->select("*");
    $this->db->from('daaentry');
     $this->db->where("date >=  '$fdate'");
    $this->db->where("date <= '$tdate'");
    $this->db->limit($limit , $offset);
     $query = $this->db->get();    // get("daaentry",$limit, $offset); // get();    // get("daaentry",$limit, $offset);
*/
             $fm = $_SESSION['start_date'];
             $to = $_SESSION['end_date'];
              $q= $this->db->query("select * from  daaentry 
                  where  date between '" . $fm . "' and  '" . $to . "' 
                 order by date "); //  limit " . $limit . " offset " . $offset );

	return $q->result();


//     return $query->result();
    }

 public function get_login_details()
   {
        $query = $this->db->query("Select * from user_login where workin = 'DAA' ");
        return $query->result(); 
   }

public function get_payment_details($dt1,$dt2,$ecode)
   {
        $query = $this->db->query("Select * from paymentregister where ((accode = " . $ecode . ")  and (date  >= '" . $dt1 . "' and date <= '" . $dt2 . "' )) order by date , accode" );
        return $query->result(); 
   }


public function get_reverse_payment_details($dt1,$dt2,$ecode)
   {
        $query = $this->db->query("Select * from paymentregister where ( ( glcodedr > 0  and glcodecr > 0 ) and (accode = " . $ecode . ")  and (date  >= '" . $dt1 . "' and date <= '" . $dt2 . "' )) order by date , accode" );
        return $query->result(); 
   }


 public function get_emp_details()
   {
 
        $query = $this->db->query("Select * from emptable ");
        return $query->result(); 
   }

 public function get_cust_details()
   {
 
        $query = $this->db->query("Select * from customer order by name ");
        return $query->result(); 
   }

/*
    public function get_itemCRUD_only_pets()
   {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->query("Select * from user_login where pethuman = 'PETS' ");
        return $query->result(); 
   }
*/

}
// die ("eof item crud");
?>