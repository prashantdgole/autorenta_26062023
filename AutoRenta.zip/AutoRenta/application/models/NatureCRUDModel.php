<?php
class NatureCRUDModel extends CI_Model
{
    public function get_itemCRUD()
   {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("user_login"); // get("items");
        return $query->result();
   }
    public function get_itemCRUD_only_pets()
   {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->query("Select * from user_login where pethuman = 'PETS' ");
        return $query->result(); 
   }
    public function get_itemCRUD_only_human()
   {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->query("Select * from user_login where pethuman = 'HUMAN' ");
        return $query->result(); 
   }
    public function user_count()
    {
       // $query = $this->db->get("user_login");
        $query = $this->db->query("Select * from user_login where pethuman = 'PETS' ");
        return $query->num_rows(); 
   }
    public function human_user_count()
    {
       // $query = $this->db->get("user_login");
        $query = $this->db->query("Select * from user_login where pethuman = 'HUMAN' ");
        return $query->num_rows(); 
   }
    public function get_patientname()
    {
        $query = $this->db->query("Select * from user_login where pethuman = 'HUMAN' and user_type='USER' ");
        return $query->result(); 
   }
   public function get_humandiagnosis()
   {
        $query = $this->db->query("Select distinct userid , nameofperson from humandiagnosis  ");
        return $query->result();  
   }
    public function human_stocklist_count()
    {
       // $query = $this->db->get("stocklistofhuman");
        $query = $this->db->query("Select * from stocklistofhuman ");
        return $query->num_rows(); 
   }
    public function get_vendorlist_only_human()
   {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->query("Select * from vendorlist ");
        return $query->result(); 
   }
    public function human_vendor_count()
    {
       // $query = $this->db->get("vendorlist");
        $query = $this->db->query("Select * from vendorlist ");
        return $query->num_rows(); 
   }   
   public function  get_salesbilllist()
   {
        $query = $this->db->query('SELECT * FROM saleshumanstocklist ');
        return $query->result();
   }
   public function  new_get_salesbilllist()
   {
        $query = $this->db->query("SELECT DISTINCT salesbill, patientid ,patientname FROM  saleshumanstocklist" );
        return $query->result();
   }
    public function get_stocklist()
   {
        $query = $this->db->query('SELECT * FROM stocklistofhuman ');
        return $query->result();
    }
   public function get_itemCRUD_new($limit,$offset)
   {
      $this->db->limit($limit, $offset);
   // original   $query = $this->db->get("user_login");
     $id = 'PETS';
     $where_array = array( 'pethuman'=>'PETS');
     $query = $this->db->get_where("user_login",$where_array, $limit, $offset);   
  //     $query = $this->db->get_where('user_login', array('pethuman' => $id))->row();
   //  return   $query = $this->db->query("Select * from user_login where pethuman = 'PETS' ");
      return $query->result();
    }

   public function get_itemCRUD_new_full()
   {
//      $this->db->limit($limit, $offset);
   // original   $query = $this->db->get("user_login");
     $id = 'PETS';
     $where_array = array( 'pethuman'=>'PETS');
     $query = $this->db->get_where("user_login",$where_array); // , $limit, $offset);   
  //     $query = $this->db->get_where('user_login', array('pethuman' => $id))->row();
   //  return   $query = $this->db->query("Select * from user_login where pethuman = 'PETS' ");
      return $query->result();
    }



   public function get_itemCRUD_human_new($limit,$offset)
   {
     $this->db->limit($limit, $offset);
     $where_array = array( 'pethuman'=>'HUMAN');
     $query = $this->db->get_where("user_login",$where_array, $limit, $offset);
     return $query->result();
    }
   public function get_itemCRUD_vendor_new($limit,$offset)
   {
     $this->db->limit($limit, $offset);
     $query = $this->db->get("vendorlist", $limit, $offset);
     return $query->result();
    }
  public function get_itemCRUD_stocklist_new($limit,$offset)
   {
     $this->db->limit($limit, $offset);
     $query = $this->db->get("stocklistofhuman", $limit, $offset);   
     return $query->result();
    }
    public function get_petCRUD()
    {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("petstypelist"); // get("items");
        return $query->result();
    }
    public function insert_item()
    {    
        $data = array(
            'useremail' => $this->input->post('user_email'),
            'password' => $this->input->post('password')
        );
        return $this->db->insert('user_login', $data);  // items
    }
    public function update_stock_human($id) 
    {
        $data=array(
            'reorderlevel' => $this->input->post('wreorderlevel'),
            'stockinhand'=> $this->input->post('wstockinhand'), 
            'salerate' => $this->input->post('wsalerate'),
            'unit' => $this->input->post('wunit'),
            'hsncode'  => $this->input->post('whsncode'),
            'stockbinnumber' => $this->input->post('wstockbinnumber'),
            'gstperc' => $this->input->post('wgstperc'),
           'any_information_1' => $this->input->post('wany_information_1'),
           'any_information_2' => $this->input->post('wany_information_2')
        );
        if($id==0){
            return $this->db->insert('stocklistofhuman',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('stocklistofhuman',$data); // items
        }        
    }
    public function update_vendor_human($id) 
    {
        $data=array(
            'vendorname' => $this->input->post('vendorname'),
            'vendorad1'=> $this->input->post('vendorad1'), 
            'vendorad2' => $this->input->post('vendorad2'),
            'vendorpin' => $this->input->post('vendorpin'),
            'vendormobile1'  => $this->input->post('vendormobile1'),
            'vendormobile2' => $this->input->post('vendormobile2'),
            'contactperson' => $this->input->post('contactperson'),
            'gstnumber' => $this->input->post('gstnumber'),
            'panno' => $this->input->post('panno'),
            'emailid1' => $this->input->post('emailid1'),
            'emailid2' => $this->input->post('emailid2'),
            'gender' => $this->input->post('gender'),
            'referred_by' => $this->input->post('referred_by'),
           'any_information_1' => $this->input->post('wany_information_1'),
           'any_information_2' => $this->input->post('wany_information_2')
        );
        if($id==0){
            return $this->db->insert('vendorlist',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('vendorlist',$data); // items
        }        
    }
    public function update_item($id) 
    {
        $data=array(
            'user_email' => $this->input->post('useremail'),
            'user_password'=> $this->input->post('password'), 
            'nameofperson' => $this->input->post('nameofperson'),
            'ad1' => $this->input->post('ad1'),
            'ad2'  => $this->input->post('ad2'),
            'pincode' => $this->input->post('pincode'),
            'mobile1' => $this->input->post('mobile1'),
           'mobile2' => $this->input->post('mobile2')
        );
        if($id==0){
            return $this->db->insert('user_login',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('user_login',$data); // items
        }        
    }
    public function update_item_human($id) 
    {
        $data=array(
            'user_email' => $this->input->post('useremail'),
            'user_password'=> $this->input->post('password'), 
            'nameofperson' => $this->input->post('nameofperson'),
            'ad1' => $this->input->post('ad1'),
            'ad2'  => $this->input->post('ad2'),
            'pincode' => $this->input->post('pincode'),
            'mobile1' => $this->input->post('mobile1'),
           'mobile2' => $this->input->post('mobile2'),
           'dateofbirth' => $this->input->post('birthdate'),
           'placeofbirth' => $this->input->post('placeofbirth'),
           'allergyofany' => $this->input->post('allergy'),
           'sleepingtime' => $this->input->post('sleeptime'),
           'getuptime' => $this->input->post('getuptime'),
           'soundsleep' => $this->input->post('soundsleep'),
           'yoga_exercise' =>$this->input->post('yogae'),
           'waterdrinkinghabit' => $this->input->post('waterd'),
           'lunch_dinner_timing' => $this->input->post('lunchd'),
           'daily_routine_1' => $this->input->post('dailyr1'),
           'daily_routine_2' => $this->input->post('dailyr2'),
           'physical_problem_1' => $this->input->post('phy1'),
           'physical_problem_2' => $this->input->post('phy2'),
           'medicines_list_1' => $this->input->post('med1'),
           'medicines_list_2' => $this->input->post('med2'),
           'medicines_list_3' => $this->input->post('med3'),
           'bad_habit_1' => $this->input->post('hab1'),
           'bad_habit_2' => $this->input->post('hab2'),
           'veg_non_veg_frequency' => $this->input->post('vegn'),
           'about_delivery_1' => $this->input->post('delp1'),
           'about_delivery_2' => $this->input->post('delp2'),
           'bp_diabetics_level' => $this->input->post('bp1'),
           'which_milk_products_1' => $this->input->post('mil1'),
           'which_milk_products_2' => $this->input->post('mil2'),
           'gas_acidity_abdomen_1' => $this->input->post('gas1'),
           'gas_acidity_abdomen_2' => $this->input->post('gas2'),
           'any_information_1' => $this->input->post('inf1'),
           'any_information_2' => $this->input->post('inf2'),
           'gender' => $this->input->post('inf2'),
           'dinner_timing' => $this->input->post('d1'),
           'diabetic_level' => $this->input->post('dia1'),
           'reference' => $this->input->post('ref'),
           'whatupno1' => $this->input->post('wa1'),
           'whatupno2' => $this->input->post('wa2'),
           'enquirydetail1' => $this->input->post('enq1'),
           'enquirydetail2' => $this->input->post('enq2'),
           'followup1' => $this->input->post('fol1'),
           'followup2' => $this->input->post('fol2'),
           'hereditarydisease' => $this->input->post('herd1'),
           'weight' => $this->input->post('wei1'),
           'height' => $this->input->post('hei1'),
           'asthma_problem' => $this->input->post('ast1'),
           'other_problem' => $this->input->post('oth1'),
           'nadi_problem' => $this->input->post('nadi1'),
           'urine_issue' => $this->input->post('uri1'),
           'duration_disease_1' => $this->input->post('durdise1'),
           'duration_disease_2' => $this->input->post('durdise2'),
           'duration_disease_3' => $this->input->post('durdise3'),
           'duration_disease_4' => $this->input->post('durdise4'),
           'any_other_diseases_1' => $this->input->post('othdise1'),
           'any_other_diseases_2' => $this->input->post('othdise2'),
           'any_surgeries_1' => $this->input->post('surgery1'),
           'any_surgeries_2' => $this->input->post('surgery2'),
           'any_surgeries_3' => $this->input->post('surgery3'),
           'family_member_disease_1' => $this->input->post('fmly1'),
           'family_member_disease_2' => $this->input->post('fmly2'),
           'anyreferencenameno1' => $this->input->post('ref1'),
           'anyreferencenameno2' => $this->input->post('ref2'),
           'anyreferencenameno3' => $this->input->post('ref3'),
           'anyreferencenameno4' => $this->input->post('ref4')
        );
//echo $id;
// die ("id");
        if($id==0){
            return $this->db->insert('user_login',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('user_login',$data); // items
        }        
    }
//
    public function update_item_human_photo($id) 
    {
        $data=array(
          'patientphoto' => $this->input->post('patientphoto')
        );
        if($id==0){
            return $this->db->insert('user_login',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('user_login',$data); // items
        }        
    }
    public function update_pettype($id) 
    {
// die (" in update here");
        $data=array(
            'speciality' => $this->input->post('speciality'),
            'remarks'=> $this->input->post('remarks')
        );
        if($id==0){
            return $this->db->insert('petstypelist',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('petstypelist',$data); // items
        }        
    }
    public function find_stock($id)
    {
        return $this->db->get_where('stocklistofhuman', array('id' => $id))->row();  // stock find
    }
    public function find_item($id)
    {
        return $this->db->get_where('user_login', array('id' => $id))->row();  // items
    }
    public function find_vendor($id)
    {
        return $this->db->get_where('vendorlist', array('id' => $id))->row();  // vendor list
    }
    public function find_pettype($id)
    {
        return $this->db->get_where('petstypelist', array('id' => $id))->row();  // items
    }
    public function delete_item($id)
    {
        return $this->db->delete('user_login', array('id' => $id));  // items
    }
    public function delete_stock($id)
    {
        return $this->db->delete('stocklistofhuman', array('id' => $id));  // stock
    }
    public function delete_vendor($id)
    {
        return $this->db->delete('vendorlist', array('id' => $id));  // vendor
    }

    public function delete_pettype($id)
    {
        return $this->db->delete('petstypelist', array('id' => $id));  // items
    }
    public function get_suppliername()
   {
        $query = $this->db->query('SELECT * FROM vendorlist ');
        return $query->result(); 
    }
    public function get_Pet_itemCRUD()
   {
//      $query =  $this->db->get_where('user_login', array('pethuman' => 'PETS'))->row_array();  // items
 //     return $query->row_array(); //  $query; // ->result();
         $query = $this->db->query('SELECT * FROM user_login where pethuman="PETS" and user_type ="USER" ');
        return $query->result();
// $query = $this->db->get_where('users', array('username' => $username));
//return $query->result_array(); 
    }
 public function get_Pet_TypeList($id)
   {
       if ($id==0)
       {
           $query = $this->db->query('SELECT * FROM petstypelist ');
       }
       else
       {
           $query = $this->db->query('SELECT * FROM petstypelist  where  id = ' . $id );
       }
        return $query->result();
    }
 public function get_pethead_CRUD()
   {
// die ("here");
       $query = $this->db->query('SELECT * FROM petsinformationhead ');
        return $query->result();
    }
public function get_pet_CRUD()
   {
// die ("here");
       $query = $this->db->query('SELECT * FROM petsinformationhead ');
        return $query->result();
    }
public function get_petdetails_CRUD()
   {
        $query = $this->db->query('SELECT * FROM petsinformationdetail ');
        return $query->result();
    }
public function get_petdetails_utility_CRUD()
   {
        $query = $this->db->query('SELECT distinct userid , username FROM petsinformationdetail ');
// echo "here........................................";
        return $query->result();
    }
public function get_petdetails_next_visit_CRUD()
   {
        $for_user_id = $_SESSION['global_user_id'];
        $query = $this->db->query('SELECT * FROM petsinformationdetail where userid = ' . $for_user_id);
        return $query->result();
    }
public function get_next_visit_data()
   {
        $query = $this->db->query('SELECT petdiagnosis.nextvisit,petdiagnosis.petdetid, petsinformationdetail.petdetailsid  , petsinformationdetail.username,
petsinformationdetail.gender,petsinformationdetail.pettype,petsinformationdetail.petname,petsinformationdetail.dateofbirth,user_login.mobile1 ,user_login.mobile2  FROM   petdiagnosis   
inner JOIN user_login on petdiagnosis.userid = user_login.id 
INNER join petsinformationdetail on petdiagnosis.petdetid = petsinformationdetail.petdetailsid
WHERE  ( (MONTH(petdiagnosis.nextvisit) = MONTH(CURRENT_DATE())) AND YEAR(petdiagnosis.nextvisit) = YEAR(CURRENT_DATE() ) 
    or petdiagnosis.nextvisit = CURRENT_DATE() ) order by nextvisit ');
        return $query->result();
    }
public function get_birth_date_data()
   {
/*
        $query = $this->db->query('SELECT petsinformationdetail.userid,petsinformationdetail.username,petsinformationdetail.dateofbirth ,  
petsinformationdetail.gender , petsinformationdetail.pettype,petsinformationdetail.petname , user_login.mobile1 , user_login.mobile2 
FROM petsinformationdetail
inner join user_login on petsinformationdetail.userid = user_login.id
where (MONTH(dateofbirth) = MONTH(CURRENT_DATE())) AND YEAR(dateofbirth) = YEAR(CURRENT_DATE() )  or
  dateofbirth = CURRENT_DATE()
    order by dateofbirth'); 
*/
  $query = $this->db->query('SELECT petsinformationdetail.userid,petsinformationdetail.username,
           petsinformationdetail.dateofbirth , 
           petsinformationdetail.gender , petsinformationdetail.pettype,petsinformationdetail.petname ,
           user_login.mobile1 , user_login.mobile2 
           FROM petsinformationdetail 
           inner join user_login on petsinformationdetail.userid = user_login.id 
           where 
           (MONTH(petsinformationdetail.dateofbirth) = MONTH(CURRENT_DATE())) AND 
           YEAR(petsinformationdetail.dateofbirth) = YEAR(CURRENT_DATE() ) 
           or petsinformationdetail.dateofbirth = CURRENT_DATE() 
           order by petsinformationdetail.dateofbirth');
        return $query->result();
    }
public function get_pet_Diagnosis()
   {
       $query = $this->db->query('SELECT * FROM  petdiagnosis ');
       return $query->result();
    }
public function get_pet_Diagnosis_for_userid()
   {
       $for_user_id = $_SESSION['global_user_id'];
       $query = $this->db->query('SELECT * FROM  petdiagnosis where  userid =  ' . $for_user_id);
       return $query->result();
    }
public function get_pet_petdetails_for_userid()
   {
       $for_user_id = $_SESSION['global_user_id'];
       $query = $this->db->query('SELECT * FROM  petsinformationdetail where userid =  ' . $for_user_id  );
       return $query->result();
    }
public function get_petdetails_new()
   {
     $id =  $this->input->post('petloginid');
//echo $id;
//exit;
     if ($id > 0)
     {
//echo ("here1");
     $query = $this->db->query('SELECT * FROM petsinformationdetail '); // where petdetailsid = ' . $id);
      }
     else
     {
//echo  ("here2");
     $query = $this->db->query('SELECT * FROM petsinformationdetail ');
     }
     return $query->result();
    }
 public function update_petshead() 
    { // update_petshead($id)
// die (" in update here");
//     $condition = "userid ="  .  $this->input->post('userloginid')    . " "  ;
// echo $condition;
$xuname = $_SESSION['global_user_name'] ;
$xname =  $_SESSION['global_name_of_person'];
$xid = $_SESSION['global_user_id'] ;
//echo 'u name ' .  $xuname ;
//echo ' name ' .  $xname;
//echo ' uid = ' . $xid;
//  die("con");
 // $this->db->select('*');
 // $this->db->from('petsinformationdetail');
 // $this->db->where($condition);
//  $this->db->limit(1);
 // $query = $this->db->get();
//  if ($query->num_rows() == 0)
//  {
    $condition = "id ="  .  $this->input->post('pettypeid')    . " "  ;
    $pname = "Db error";
    $this->db->select('*');
    $this->db->from('petstypelist');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() >= 1)
    {
       $pname =  $query->row('pettype') ;  
       $pname .= '  '; 
       $pname .=  $query->row('petsubtype');
    } //  $this->input->post('pettypename'),
        $data=array(
            'userid' => $xid,  
            'username'=> $xuname , 
            'contactperson' => $xname, 
            'totalpendingamount' => $this->input->post('totalpendingamount'),
            'petheadid' => $xid,
            'petid' =>  $this->input->post('pettypeid'),
            'pettype' => $pname ,
            'gender' => $this->input->post('gender_opt_value'),
            'petname' => $this->input->post('name_of_pet'),
            'dateofbirth' => $this->input->post('birthdate'),
            'origin' => $this->input->post('origindetails'),
            'speciality' => $this->input->post('specialitydetails'),
            'illness1' => $this->input->post('illnessdetails'),
            'illness2' => $this->input->post('illnessdetails2'),
            'allergy1' => $this->input->post('allergydetails1'),
            'allergy2' => $this->input->post('allergydetails2'),
            'remarks' => $this->input->post('petremarks'),
            'firstvisitdate' =>  $this->input->post('visitdate')
        ); // remarks
 //       if($id==0) 
//        {   //                              petsinformationdetail
            return $this->db->insert('petsinformationdetail',$data);   // items
//        }else
//        {
//            $this->db->where('id',$id);
//            return $this->db->update('petsinformationdetails',$data); // items
//        }        
   // }
    }
    public function update_petsdiagnose()
   {
    $xuname = $_SESSION['global_user_name'] ;
    $xname =  $_SESSION['global_name_of_person'];
    $xid = $_SESSION['global_user_id'] ; // userid'),
    $xpetid = $_SESSION['global_pet_id'] ; // petloginid'),
/////////////
    $condition = "petdetailsid ="  .   $xpetid    . " "  ;
    $pname = "Db error";
    $this->db->select('*');
    $this->db->from(' petsinformationdetail');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() >= 1)
    {
       $pname =  $query->row('petname') ;  
     }
//    echo $this->input->post('userloginid');
//die("hi");
    $data=array(
            'userid' => $xid,  
            'petdetid	'=>   $xpetid,
            'dateofvisit' => $this->input->post('entrydate'),
            'illness1' => $this->input->post('illnessdetails'),
            'illness2' => $this->input->post('illnessdetails2'),
            'dignosis1' => $this->input->post('allergydetails1'),
            'dignosis2' => $this->input->post('allergydetails2'),
            'medicine1' => $this->input->post('medicinedetails'),
            'medicine2' => $this->input->post('medicinedetails2'),
            'billamount' => $this->input->post('billamount'),
            'paidamount' => $this->input->post('paidamount'),
            'nextvisit' => $this->input->post('nextvisitdate'),
            'remarks' => $this->input->post('remarks'),
            'dateofdeath' =>  $this->input->post('deathdate'),
            'reasonfordeath' => $this->input->post('deathreason'),
            'petname' => $pname
        ); 
        return $this->db->insert('petdiagnosis',$data);   // items
   }

// nature login insert

public function registration_insert($data)
{
// Query to check whether username already exist or not
  $condition = "user_name =" . "'" . $data['user_name'] . "'";

//echo $condition;

  $this->db->select('*');
  $this->db->from('nature_user_login');
  $this->db->where($condition);
  $this->db->limit(1);
  $query = $this->db->get();
  if ($query->num_rows() == 0)
  {
//     Query to insert data in database
        $this->db->insert('nature_user_login', $data);
        if ($this->db->affected_rows() > 0)
        {
             return true;
        }
    } 
    else 
    {
       return false;
    }
}

//



}
// die ("eof item crud");
?>