<?php


class DisCRUDModel extends CI_Model
{


    public function get_itemCRUD()
{
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("listofdisease"); // get("items");
        return $query->result();
    }


    public function insert_item()
    {    
        $data = array(
            'useremail' => $this->input->post('user_email'),
            'password' => $this->input->post('password')
        );
        return $this->db->insert('listofdisease', $data);  // items
    }


    public function update_item($id) 
    {
// die (" in update here");
        $data=array(
            'seasonspecific' => $this->input->post('seasonspecific'),
            'remarks'=> $this->input->post('remarks'),
            'injectionlist'=> $this->input->post('injectionlist'),
            'medicine1'=> $this->input->post('medicine1'),
            'medicine2'=> $this->input->post('medicine2')
        );
        if($id==0){
            return $this->db->insert('listofdisease',$data);   // items
        }else{
            $this->db->where('id',$id);
            return $this->db->update('listofdisease',$data); // items
        }        
    }


    public function find_item($id)
    {
        return $this->db->get_where('listofdisease', array('id' => $id))->row();  // items
    }


    public function delete_item($id)
    {
        return $this->db->delete('listofdisease', array('id' => $id));  // items
    }
}
?>