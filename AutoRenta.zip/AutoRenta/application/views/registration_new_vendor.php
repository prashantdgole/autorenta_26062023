<?php
//die("here");
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
<script>
function onSelectChange()
{
    var sel = document.getElementById('select');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.occupation.value=strUser;
}

function onEnquiryChange()
{
    var sel = document.getElementById('selectenquiry');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.enquiry1.value=strUser;
}

function onFollowupChange()
{
    var sel = document.getElementById('selectfollowup');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.followup1.value=strUser;
}

</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>
<form method="post" name="regvendor" action="<?php echo base_url().'index.php/Home_Dr_Raje/new_human_vendor_registration';?>">

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_vendor"; ?>'>New Supplier </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_vendor"; ?>'>Existing Supplier</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>
<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <div id="main">
<div id="login"> 
<span style="font-size:20px;cursor:pointer;color="black"> New Vendor Registration Form </span>
<!-- <h2>Registration Form</h2> -->
<hr/>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('Home_Dr_Raje/human_patient_new_vendor'); // new_vendor_registration'); 
echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}
echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
echo form_label('Enter Vendor Name: '); 
echo '</span>';
echo"<br/>";
 
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_input('vendorname'); /* checked */
echo '</span>';
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}

// vendor email id   ..... checked
echo "</div>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Email : '); 
echo '</span>';
echo"<br/>";
$data = array(
'type' => 'email',
'name' => 'email_value'
);
echo form_input($data);
$data2 = array(
'type' => 'email',
'name' => 'email_value2'
);
echo form_input($data2);
echo"<br/>";
echo"<br/>";

// vendor gender   ... checked

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Gender  :</label> </span>';
$options1 = array(
                  'MALE'  => 'MALE',
                  'FEMALE'    => 'FEMALE',
                );  
 echo form_dropdown('vendorgender', $options1, 'MALE');


// vendor address   .... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Address :</label> </span>';
echo form_input('ad1'); 
echo form_input('ad2'); 
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Pin Code :</label> </span>';
echo form_input('pincode'); 


// vendor mobile 1 and mobile 2 .... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Mobile  1 and 2 mention whats up no also :</label> </span>';
echo form_input('mobile1'); 
echo form_input('mobile2');

// please tell about contact person  .... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Contact Person Please :</label> </span>';
echo form_input('contactperson'); 


// please tell about gst number ... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Gst Number Please :</label> </span>';
echo form_input('gstnumber'); 

// please Pan number   ..... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Pan Number :</label> </span>';
echo form_input('panno'); 

// referred by  .... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Referred By .. :</label> </span>';
echo form_input('referred_by'); 

 
// any additional information ..... checked
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Any additional information  :</label> </span>';
echo form_input('any_information_1'); 
echo form_input('any_information_2'); 


echo "<br>";
echo "<br>";
echo form_submit('submit', 'Create Vendor/Supplier');
echo form_close();
?>
<span style="font-size:15px;cursor:pointer;color="black">;
<a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>For Login Click Here</a>
</span>;
<!-- <a href="<?php echo base_url() ?> ">For Login Click Here</a> -->
  </div>
</div> 
</div>
</div>
</form>
</body>
</html>