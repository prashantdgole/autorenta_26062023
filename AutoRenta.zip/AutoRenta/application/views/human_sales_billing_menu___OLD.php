<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
}

 
?>
<?php
 $id = 0;
 $sbill = "";
?>
<!DOCTYPE html>
<html>
<head>
<title>Medicines to Patients sales bill </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function getpetname(form)
{
// alert(" in ");
 var val1 , n , strUser;
var e = document.getElementById("pettypeid");
var strUser = e.options[e.selectedIndex].text;
var sp_lit = strUser.split('-');
document.mypetdetails1.pettypename.value=sp_lit[0];
}
 

function onPatientChange()
{
    var sel = document.getElementById('patientid');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.mypetdetails1.petname.value=strUser;
}


 
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_new_purchase_medicines"; ?>'>Purchase new Medicines </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_approve_purchase_medicines"; ?>'>Approve Purchase for billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_return_medicines"; ?>'>Defective Return - Inspection Note</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reject_medicines"; ?>'>Purchase Return - Rejection Note</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_approved_billing"; ?>'>Payment of Approved Bills</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     



<span style="font-size:20px;cursor:pointer;color="black"> Sales Bills details </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

 
?>
<!-- // original start -->

<font color="black">
<hr>
<h2> Medicines Sold to Patients Form </h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Back</a>


  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   

    <?php

    if ($this->session->flashdata('errors'))
    {
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }
    ?>
    <table>
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Select Patient : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="patientid" id = "patientid" onchange="onPatientChange()" style="width:100px;"> 
                        <option value="0">Patient </option>
                         <?php 
                        foreach ($data1 as $data1) { 
                         echo "<option value=". $data1->id .  ">" .   $data1->nameofperson    . "</option>";
                          }  ?>      </select> </span>
                     <br>
                     <input type="text" name="petname" id="petname" >  
               </td>
              <td> </td>
              <td>   <button type="submit" id="show" name="show" >Show Bills to modify </button>  </td>

         </tr>
      </table>
      <br>
 
       <table>
         <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Select Bills from here </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="salesbillid" id = "salesbillid" style="width:100px;"> 
                        <option value="0">SalesBill </option>
               <?php  
               if (isset($_POST['show'])) 
               {
                  $id = $_POST['patientid'];
                  $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $sid  ;
                  $query = $this->db->query($sql);
                  if ($query->num_rows() > 0)
                  {
                     foreach ($query->result() as $row)  
                     {
                          echo "<option value=". $row->salesbill .  ">" .   $row->patientname . " " .  $row->date . " " . $row->stockname . " " . $row->saleqty  . "</option>";
                    }
                  } 
                }
                  ?>

                  </select> </span>  
               </td>    
              <td> </td>
              <td>   <button type="submit" id="showme" name="showme" >Edit/New Bills </button>  </td>
       
         </tr>
 </table>
 <br>
  <h2> Showing records of sales bill no <?php if (isset($_POST['showme']))  { $sbill = $_POST['salesbillid']; echo $sbill; } ?>
 <table>
    <tr> <td> Sales Bill </td> <td> Date </td> 
         <td> Stock name </td> <td> Qty Sold </td>
         <td> Rate  </td> <td> Amount </td>
         <td> Discount % </td> <td> Discount amount </td>
         <td> Total </td>
    </tr>
    <tr>

    <?php 
       if (isset($_POST['showme']))  
       { 
         $sbill = $_POST['salesbillid'];
         $sql ="SELECT * FROM saleshumanstocklist where salesbill= '" . $sbill . "'"  ;
         $query = $this->db->query($sql);
         if ($query->num_rows() > 0)
         {
         foreach ($query->result() as $row)  
         {
         ?>
          <td>
         
          </td>
          <?php
          }
        }
      }
     ?>        
    </tr>
 </table>
 </form>
  </div>
</div>
</body>
</html>