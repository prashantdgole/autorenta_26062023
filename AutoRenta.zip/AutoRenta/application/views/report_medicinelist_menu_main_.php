<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
 $username = ($this->session->userdata['logged_in']['username']);
 $email = ($this->session->userdata['logged_in']['email']);
 $user_type_value = ($this->session->userdata['logged_in']['user_type']);
 $patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
else 
{
// echo " **************** 0 ";
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";
 
?>
<?php
// if (!empty($_POST['show'])) 
// {
// }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>

<style>
body {
font-family: 'Raleway', sans-serif;
}
.main
{
width: 1015px;
position: absolute;
top: 10%;
left: 20%;
}
#form_head
{
text-align: center;
background-color: #61CAFA;
height: 66px;
margin: 0 0 -29px 0;
padding-top: 35px;
border-radius: 8px 8px 0 0;
color: rgb(255, 255, 255);
}
#content {
position: absolute;
width: 450px;
height: 390px;
border: 2px solid gray;
border-radius: 10px;
}
#form_input
{
margin-left: 110px;
margin-top: 30px;
}
label
{
margin-right: 6px;
font-weight: bold;
}
#pagination{
margin: 40 40 0;
}
.input_text {
display: inline;
margin: 100px;
}
.input_name {
display: inline;
margin: 65px;
}
.input_email {
display: inline;
margin-left: 73px;
}
.input_num {
display: inline;
margin: 36px;
}
.input_country {
display: inline;
margin: 53px;
}
.btn a
{
   background-color:#CCC;
   padding:10px;
}
ul.tsc_pagination li a
{
border:solid 1px;
border-radius:3px;
-moz-border-radius:3px;
-webkit-border-radius:3px;
padding:6px 9px 6px 9px;
}
ul.tsc_pagination li
{
padding-bottom:1px;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
color:#FFFFFF;
box-shadow:0px 1px #EDEDED;
-moz-box-shadow:0px 1px #EDEDED;
-webkit-box-shadow:0px 1px #EDEDED;
}
ul.tsc_pagination
{
margin:4px 0;
padding:0px;
height:100%;
overflow:hidden;
font:12px 'Tahoma';
list-style-type:none;
}
ul.tsc_pagination li
{
float:left;
margin:0px;
padding:0px;
margin-left:5px;
}
ul.tsc_pagination li a
{
color:black;
display:block;
text-decoration:none;
padding:7px 10px 7px 10px;
}
ul.tsc_pagination li a img
{
border:none;
}
ul.tsc_pagination li a
{
color:#0A7EC5;
border-color:#8DC5E6;
background:#F8FCFF;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
text-shadow:0px 1px #388DBE;
border-color:#3390CA;
background:#58B0E7;
background:-moz-linear-gradient(top, #B4F6FF 1px, #63D0FE 1px, #58B0E7);
background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #B4F6FF), color-stop(0.02, #63D0FE), color-stop(1, #58B0E7));
}

</style>

<style>
.pagination {
  display: inline-block;
}

.pagination a { /* float: left; */
  color: black;
  
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
span.pag {
    font-size: 22px !important;
        background: #e25817;
        color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext{
    font-size: 22px !important;
        background: #e25817;
        color: white !important;
    padding: 8px 0px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext a{
   
        color: white !important;
    
}
.btn-nexttag a {
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
    background : #f76d2b;
}
span.btn.btn-nexttag {
    padding: 3% 0%;
    color: white !important;
    display: contents;
}

</style>

    <style type="text/css">
        #lasttext
        {
        	font-family :Verdana;
        	font-size :18px;
        	font-weight:bold;
            position:absolute;
            bottom  :-10px;
            width:100%;
            height:69px;  
            left: 0px;
        }
        .headerbak
        {
            font-size: 11px;
            color: black;
        }
         .headerbak1
        {
           background-image :url("Images\pattern-7hi.png");
        }
          .headerbak3
        {
           background-image :url("Images\pattern-7hi.png");
        }
         .headerbak2
        {
           background-image :url("Images\pattern-7hi.png");
        }
        .style1
        {
            width: 170px;
            height: 59px;
        }
        .style2
        {   
            background-image: url('Images\pattern-7hi.png');
            width: 32px;
        }
        .style3
        {
            background-image: url('Images\pattern-7hi.png');
            width: 171px;
        }
        .style4
        {
            background-image: url('Images\pattern-7hi.png');
            width: 480px;
        }
    </style>


<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>

<?php



if ($patient_class_value == "HUMAN")
{ ?>
<div id="mySidenav" class="sidenav">
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_stock"; ?>'>New Medicine </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_vendor"; ?>'>Existing Medicine</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_medicines_reports_list"; ?>'>Reports</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>

</div>
<?php
}
else
{ ?>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

<?php
} ?>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>




<div class="mainContainer">
<div class="formContainer">     
<table  width="100%" class ="headerbak" border=1 cellpadding=5> 
     <thead>
       <tr>
           <th>Sr.No</th>
           <th>Stock Name</th>
           <th>Short Code</th>
           <th>Reorder Level</th>
           <th>Stock in Hand</th>
           <th>Unit</th>
           <th>Sale Rate</th>
           <th>HSN Code</th>  
           <th>Bin Number</th>  
           <th>Any Information </th>
         </tr>
         </thead>
         <tbody>
         <?php 
            // $i=1;
											
            foreach($userrec as $tabData)
            {
	?>
             <tr>												
              <td><?php echo $i; ?></td>
              <td><?php echo $tabData->stockname; ?></td>
              <td><?php echo $tabData->stockshortcode; ?></td>
              <td><?php echo $tabData->reorderlevel; ?></td>
              <td> <?php echo $tabData->stockinhand;?></td>
              <td><?php echo $tabData->unit ; ?></td>
              <td><?php echo $tabData->salerate; ?></td>
              <td><?php echo $tabData->hsncode; ?></td>
              <td><?php echo $tabData->stockbinnumber; ?></td>
              <td><?php echo $tabData->any_information_1 . "<br>" . $tabData->any_information_2; ?></td>

             </tr>
											
             <?php
											
               $i++; 
             }
										
             ?>
											
            </tbody>
									
     </table>
     <p> <div class="pagination"> <?php echo $links; ?> </div> </p>
</div>
</div>
</body>
</html>