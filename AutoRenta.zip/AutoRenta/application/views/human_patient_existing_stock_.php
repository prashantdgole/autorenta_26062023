<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>
</head>
<body>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_patient"; ?>'>New Patient </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_patient"; ?>'>Existing Patient</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_upload_photo"; ?>'>upload photo</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_details"; ?>'>Patient Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_diagnosis"; ?>'>Patient Diagnosis</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_reports"; ?>'>Clinical Reports upload </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_billing"; ?>'>Billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_nextvisit"; ?>'>Next Visit</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>




<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Update Stock Records Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
/// remove echo form_open('Home_Dr_Raje/new_injection_registration'); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>
<!--   <a href="<?php echo base_url('user_registration_show') ?>"> Create New Item</a> -->
<!--  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>New User Registration</a> -->
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_stock"; ?>'>New Stock Registration</a>



<!-- // original start -->

<font color="black">
<hr>
<table> <!-- class="table table-bordered"> -->


  <thead>
      <tr>
          <th>Stock Name</th>
          <th>Short code </th>
          <th>Reorder Level</th>
          <th>Stock in Hand</th>
          <th> Sale Rate </th>
          <th> Unit </th>
          <th>Action</th>
      </tr>
  </thead>
  <tbody>
   <?php foreach ($data as $item) { ?>      
      <tr>
          <td><?php echo $item->stockname; ?></td>  
          <td><?php echo $item->stockshortcode; ?></td> 
          <td><?php echo $item->reorderlevel; ?></td> 
          <td><?php echo $item->stockinhand; ?></td> 
          <td><?php echo $item->salerate; ?></td>      
          <td><?php echo $item->unit; ?></td>         
      <td>
     <!--   <form method="DELETE" action="<?php echo base_url('itemCRUDdelete/'.$item->id);?>"> -->
     <!--  <a class="btn btn-info" href="<?php echo base_url('itemCRUD/'.$item->id) ?>"> show</a> -->
                <!-- class="btn btn-info" -->
              <!-- class="btn btn-primary" -->
 <!--     <a  href="<?php echo base_url('itemCRUD/edit/'.$item->id) ?>"> Edit</a> -->

            <form method="DELETE" action="<?php echo base_url().'index.php/Home_Dr_Raje/deletehumanstock/'.$item->id;?>">
            <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/showhumanstock/'.$item->id ?> "> Show </a>
            <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/edithumanstock/'.$item->id ?> "> Edit </a>
                      <!-- class="btn btn-danger" --> 
          <button type="submit" > Delete</button>
        </form>
      </td>     
      </tr>
      <?php } ?>
  </tbody>
</table>
<?php
?>
  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>