<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<?php
// if (!empty($_POST['show'])) 
// {
// }
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function uname(form)
{
 // alert("hi");
var val1 , n , strUser;
var e = document.getElementById("userloginid");
var strUser = e.options[e.selectedIndex].text;
var splitname = strUser.split('~');
 // alert(splitname[0]);
document.petdetails.username.value=splitname[0]; // user name
//document.petdetails.ad1.value=splitname[1]; // ad1
//document.petdetails.ad2.value=splitname[2]; // ad2
//document.petdetails.pincode.value=splitname[3]; // pin
//document.petdetails.mobile1.value=splitname[4]; // mob1
//document.petdetails.mobile2.value=splitname[5]; // mob2
//document.petdetails.nameofperson.value=splitname[6]; // mob2
}

function uname1(form)
{
alert("in");
//var val1 , n , strUser;
//var e = document.getElementById("addpetdetails");
//var strUser = e.options[e.selectedIndex].text;
//var splitname = strUser; // .split('~');
// alert(splitname);
//document.petdetails.hiddenname.value=splitname; // user name
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Pets Details Entry  Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Pets Details</h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>




<!-- <form method="post" name="petdetails" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />  -->


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>

    <table>
  <!--  <tr> <td> <?php echo phpversion(); ?> </td> </tr> -->
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Login Id : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="userloginid" id = "userloginid" style="width:100px;"> 
                         <?php 
                          foreach($data as $data) {
                         echo "<option value=". $data->id .  ">" .   $data->user_name  . "~" .  $data->ad1 . "~" . $data->ad2 . "~" . $data->pincode . "~" . $data->mobile1 . "~" . $data->mobile2 . "~" . $data->nameofperson  . "</option>";
                          }?>   onblur="uname(this.form)" </select> </span>
               </td>
               
               <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name : </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="username" name="username" readonly value = ""  onfocus="uname(this.form)"  placeholder="click here for user name"  /> 
                         </span> 
               </td>
         </tr>
         <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Address :1: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="" placeholder="address line1 "> 
                       </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Pin </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="pincode" name="pincode"  readonly value="" placeholder="Pin code"> 
                        </span> </td>
         </tr>
         <tr> 
               <td> <span style="font-size:15px;cursor:pointer;color="black"> Address :2: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="ad2" name="ad2" readonly  value="" placeholder="address line2 "> 
                         </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Mobile :1 : </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="mobile1"  name="mobile1"  readonly  value="" placeholder="Mobile1">  </td>
         <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value="" placeholder="name of person "> 
                         </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> Mobile :2 : </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black">
                      <input type="text" id="mobile2" name="mobile2" readonly  value="" placeholder="Mobile2">
                      </span>
              </td>
         </tr>
        <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Remarks : </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="headremarks"  name="headremarks"   value="" placeholder="Remarks if Any" /> 
                         </span> 
               </td>
        </tr>
 </table>
  <h2> Name and Other Details of Pets   </h2>   
   <table>
   <tr> <td> <span style="font-size:15px;cursor:pointer;color="black"> Select User Name To Add Two Or  More Pets :  </span> </td>
          <td>  <span style="font-size:15px;cursor:pointer;color="black">
            <select id="addpetdetails"  name="addpetdetails" style="width:200px;"> 
              <option value="-9">Not Selected </option>   
                     <?php 
                          foreach($data2 as $data2)
                         {
                        echo "<option value=". $data2->userid .  ">" .   $data2->username  .  "</option>";
                          }
                        ?> onblur="uname(this.form)"  </select>   
                  <button type="show" >Show</button>
                hidden <input type="text" id="hiddenname" name="hiddenname"  /> 
                </span> 
             </td> </tr>
  </table>
  <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name <br> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender  <br> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Birth <br> Next Visit </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Bill Amount <br> Paid Amount </span> </td> 
      </tr>

     <?php
            if (!empty($_POST['show'])) 
            {
   
                echo '<tr><td><span style="font-size:15px;cursor:pointer;color="black">';
     
             }
    ?>
      
  </table>
 
  <table>
       <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Type - subtype :</span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black">
                   <select name="userloginid1"> 
                          <?php 
                          foreach($data1 as $data1)
                          { 
                         echo "<option value=". $data1->id . ">" .  $data1->pettype . "-" . $data1->petsubtype  . "</option>";
                          } ?>
                  </select> 
                  </span>
               </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender & Name  :</span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                     <?php 
                  $genderopt = array(
                  'MALE'  => 'MALE',
                  'FEMALE'    => 'FEMALE',
                   ); 
                   echo form_dropdown('gender_opt_value', $genderopt, 'MALE'); ?> </span> </td>
                 <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="name_of_pet"  id="name_of_pet" value="" placeholder="Name"/> 
                   </span>
                 </td>
        </tr>
       <table> <br>
       <table>
       <tr>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> Birth Date </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="date" id ="birthdate" name="birthdate" value = "" /> </span> </td>
                <td>  <span style="font-size:15px;cursor:pointer;color="black"> Visit Date </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black">   
                       <input type="date" id ="visitdate" name="visitdate" value = "<?php $dt = new DateTime(); echo $dt->format('d-m-y'); ?>" /> </span> </td>

       </tr>
       
      <tr>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> Pending Amount  </span> </td>
                <td style="width:100px;"> <span style="font-size:15px;cursor:pointer;color="black" > 
                       <input type="text" id ="totalpendingamount"   name="totalpendingamount" value = "0" placeholder="0 for first time user" /> </span> </td>
                <td>  <span style="font-size:15px;cursor:pointer;color="black"> Remarks </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id ="petremarks" name="petremarks" value = "" /> </span> </td>

       </tr>
       <tr>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of death </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black">  
                         <input type="date" id="deathdate" name ="deathdate" value=""> </span> </td>
                 <td> <span style="font-size:15px;cursor:pointer;color="black"> Reason </span> </td>
                  <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                           <input type="text" id="deathreason" name="deathreason" value="" placeholder="reason for death" /> </span>
                  </td>
        <tr>
  </table>
   <h2>     Historical Details  </h2>
    <table>
        <tr> 
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Allergy details </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" name= "allergydetails" id="allregydetails" value="" placeholder="allergy details"/> </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Previous illness </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" name="illnessdetails" id="illnessdetails" value="" placeholder="illness details" /> </span> </td>
        </tr>
    </table>
           <!-- class="btn btn-primary" -->
<hr>
<!-- <center>  <button type="submit" >Submit</button> </center>-->

<center> <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/' ?> "> Update </a> </center>


</hr>
<!-- </form>-->

<?php


 
?>

  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>