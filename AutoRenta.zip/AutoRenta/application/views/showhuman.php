<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<script>


patientphoto.onblur = evt => {
  const [file] = patientphoto.files
  if (file) {
    blah.src = URL.createObjectURL(file)
  }
}

</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_patient"; ?>'>New Patient </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_patient"; ?>'>Existing Patient</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_upload_photo"; ?>'>upload photo</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_details"; ?>'>Patient Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_diagnosis"; ?>'>Patient Diagnosis</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_reports"; ?>'>Clinical Reports upload </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_billing"; ?>'>Billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_nextvisit"; ?>'>Next Visit</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>



<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Update Registration Records Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
/// remove echo form_open('Home_Dr_Raje/new_injection_registration'); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>
<!--   <a href="<?php echo base_url('user_registration_show') ?>"> user_registration_show Create New Item</a> -->
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_patient"; ?>'>New User Registration</a>


<!-- // original start -->

<font color="black">
<hr>

   
<!--  <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left"> -->
            <h2> Show Item</h2>
<!--        </div>
        <div class="pull-right">                                                          itemcrudindex   -->
           <a class="btn btn-primary" href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_patient"; ?>'>Back</a>
<!--        </div>
    </div>
</div> -->

<table>
  <tr>
    <td>   <strong>Registration Date :</strong> </td>
     <td>       <?php echo $user_login->registrationdate; ?>   </td>
   </tr>
   <tr>
  <tr>
    <td>   <strong>ID:</strong> </td>
     <td>       <?php echo $user_login->id; ?>   </td>
   </tr>
   <tr>
         <td>     <strong>User Name:</strong> </td>
          <td>     <?php echo $user_login->user_name; ?> </td>
        </div>
    </tr>
<!--  <img src="<?php echo base_url(); ?>images/dr_raje_logo_jpg.jpg"></img>  Prashant_D_Gole_Photo.jpg -->

<tr> <td> <strong> Photo : <?php echo $user_login->patientphoto;?>  </strong> </td>
    <td> <img src="<?php echo base_url(); ?>images/<?php echo $user_login->patientphoto;?>"></img> </td>
</tr>    


   <tr>
         <td>     <strong>Gender:</strong> </td>
          <td>     <?php echo $user_login->gender; ?> </td>
        </div>
    </tr>

    <tr>
        <td>     <strong>User Email:</strong> </td>
         <td>   <?php echo $user_login->user_email; ?> </td>
    </tr>
    <tr>
         <td>  <strong>User Type:</strong> </td>
          <td>  <?php echo $user_login->user_type; ?> </td>
    </tr>
    <tr>
           <td> <strong>User Password:</strong> </td>
           <td>  <?php echo $user_login->user_password; ?> </td>
   </tr>
   <tr>
        <td <strong>Patient Type :</strong> </td>
        <td>    <?php echo $user_login->pethuman; ?> </td>
    </tr>

   <tr>
        <td <strong>Patient Clinical ID :</strong> </td>
        <td>    <?php echo $user_login->clinicalid; ?> </td>
    </tr>


    <tr>
        <td> <strong> Person Name:<strong> </td>
       <td> <input type="text" name="nameofperson" id="nameofperson" readonly value="<?php  echo $user_login->nameofperson; ?>" /> </td>
    </tr>
     <tr>
        <td> <strong>Occupation Please:<strong> </td>
       <td> <input type="text" name="occ" id="occ" readonly value="<?php  echo $user_login->occupation; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>Address :1:<strong> </td>
       <td> <input type="text" name="ad1" id="ad1" readonly value="<?php  echo $user_login->ad1; ?>" /> </td>
    </tr>
    <tr>
        <td> <strong>Address :2:<strong> </td>
       <td> <input type="text" name="ad2" id="ad2" readonly value="<?php  echo $user_login->ad2; ?>" /> </td>
    </tr>
    <tr>
        <td> <strong>Pin Code :<strong> </td>
       <td> <input type="text" name="pincode" id="pincode" readonly value="<?php  echo $user_login->pincode; ?>" /> </td>
    </tr>
    <tr>
        <td> <strong>Mobile 1 and 2 :<strong> </td>
       <td> <input type="text" name="mobile1" id="mobile1" readonly value="<?php  echo $user_login->mobile1; ?>" /> <br> 
               <input type="text" name="mobile2" id="mobile2" readonly value="<?php  echo $user_login->mobile2; ?>" />
      </td>
    </tr>
    <tr>
        <td> <strong>Whatsup No 1 and 2 :<strong> </td>
       <td> <input type="text" name="wa1" id="wa1" readonly value="<?php  echo $user_login->whatupno1; ?>" /> <br> 
            <input type="text" name="wa2" id="wa2" readonly value="<?php  echo $user_login->whatupno2; ?>" />
      </td>
    </tr>

    <tr>
        <td> <strong>Date of Birth and Place :<strong> </td>
       <td> <input type="text" name="birthdate" id="birthdate" readonly value="<?php  echo $user_login->dateofbirth; ?>" /> <br> 
               <input type="text" name="placeofbirth" id="placeofbirth" readonly value="<?php  echo $user_login->placeofbirth; ?>" />
      </td>
    </tr>
    <tr>
        <td> <strong>Allergy if Any :<strong> </td>
       <td> <input type="text" name="allergy" id="allergy" readonly value="<?php  echo $user_login->allergyofany; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>Sleep & Get up Time <br> and Have Sound Sleep :<strong> </td>
       <td> <input type="text" name="sleeptime" id="sleeptime" readonly value="<?php  echo $user_login->sleepingtime; ?>" /> <br> 
               <input type="text" name="getuptime" id="getuptime" readonly value="<?php  echo $user_login->getuptime; ?>" /> <br>
               <input type="text" name="soundsleep" id="soundsleep" readonly value="<?php  echo $user_login->soundsleep; ?>" />
      </td>
    </tr>
    <tr>
        <td> <strong>Yoga Exercise :<strong> </td>
       <td> <input type="text" name="yogae" id="yogae" readonly value="<?php  echo $user_login->yoga_exercise; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>water drinking habit :<strong> </td>
       <td> <input type="text" name="waterd" id="waterd" readonly value="<?php  echo $user_login->waterdrinkinghabit; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>Lunch/ Dinner Timing :<strong> </td>
       <td> <input type="text" name="lunchd" id="lunchd" readonly value="<?php  echo $user_login->lunch_dinner_timing; ?>" />  <br> 
            <input type="text" name="d1" id="d1" readonly value="<?php  echo $user_login->dinner_timing; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>Daily Routine :<strong> </td>
       <td> <input type="text" name="dailyr1" id="dailyr1" readonly value="<?php  echo $user_login->daily_routine_1; ?>" /> <br> 
            <input type="text" name="dailyr2" id="dailyr2" readonly value="<?php  echo $user_login->daily_routine_2; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>Physical Problem if any :<strong> </td>
       <td> <input type="text" name="phy1" id="phy1" readonly value="<?php  echo $user_login->physical_problem_1; ?>" /> <br> 
            <input type="text" name="phy2" id="phy2" readonly value="<?php  echo $user_login->physical_problem_2; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>List of Medicines :<strong> </td>
       <td> <input type="text" name="med1" id="med1" readonly value="<?php  echo $user_login->medicines_list_1; ?>" /> <br> 
            <input type="text" name="med2" id="med2" readonly value="<?php  echo $user_login->medicines_list_2; ?>" /> <br> 
            <input type="text" name="med3" id="med3" readonly value="<?php  echo $user_login->medicines_list_3; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>Habit if any :<strong> </td>
       <td> <input type="text" name="hab1" id="hab1" readonly value="<?php  echo $user_login->bad_habit_1; ?>" /> <br> 
            <input type="text" name="hab2" id="hab2" readonly value="<?php  echo $user_login->bad_habit_2; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>Veg / Non Veg Frequency :<strong> </td>
       <td> <input type="text" name="vegn" id="vegn" readonly value="<?php  echo $user_login->veg_non_veg_frequency; ?>" />   
      </td>
    </tr>
    <tr>
        <td> <strong>Delivery Problem if any :<strong> </td>
       <td> <input type="text" name="delp1" id="delp1" readonly value="<?php  echo $user_login->about_delivery_1; ?>" /> <br> 
            <input type="text" name="delp2" id="delp2" readonly value="<?php  echo $user_login->about_delivery_2; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>Bp and Diabetic Level :<strong> </td>
       <td> <input type="text" name="bp1" id="bp1" readonly value="<?php  echo $user_login->bp_diabetics_level; ?>" /> <br> 
            <input type="text" name="dia1" id="dia1" readonly value="<?php  echo $user_login->diabetic_level; ?>" />  
      </td>
    </tr>
    <tr>
        <td> <strong>Which Milk Products :<strong> </td>
       <td> <input type="text" name="mil1" id="mil1" readonly value="<?php  echo $user_login->which_milk_products_1; ?>" /> <br> 
            <input type="text" name="mil2" id="mil2" readonly value="<?php  echo $user_login->which_milk_products_2; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Gas Acidity Issue if any:<strong> </td>
       <td> <input type="text" name="gas1" id="gas1" readonly value="<?php  echo $user_login->gas_acidity_abdomen_1; ?>" /> <br> 
            <input type="text" name="gas2" id="gas2" readonly value="<?php  echo $user_login->gas_acidity_abdomen_2; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Reference Please:<strong> </td>
       <td> <input type="text" name="ref" id="ref" readonly value="<?php  echo $user_login->reference; ?>" />   
      </td>
    </tr>
     <tr>
        <td> <strong>Enquiry Details :<strong> </td>
       <td> <input type="text" name="enq1" id="enq1" readonly value="<?php  echo $user_login->enquirydetail1; ?>" /> <br> 
            <input type="text" name="enq2" id="enq2" readonly value="<?php  echo $user_login->enquirydetail2 ; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Heridetary Details :<strong> </td>
       <td> <input type="text" name="herd1" id="herd1" readonly value="<?php  echo $user_login->hereditarydisease; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Followup Details :<strong> </td>
       <td> <input type="text" name="fol1" id="fol1" readonly value="<?php  echo $user_login->followup1; ?>" /> <br> 
            <input type="text" name="fol2" id="fol2" readonly value="<?php  echo $user_login->followup2; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Height and Weight :<strong> </td>
       <td> <input type="text" name="wei1" id="wei1" readonly value="<?php  echo $user_login->weight; ?>" /> <br> 
            <input type="text" name="hei1" id="hei1" readonly value="<?php  echo $user_login->height; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Asthama and Other Problem :<strong> </td>
       <td> <input type="text" name="ast1" id="ast1" readonly value="<?php  echo $user_login->asthma_problem; ?>" /> <br> 
            <input type="text" name="oth1" id="oth1" readonly value="<?php  echo $user_login->other_problem; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Nadi Problem and Urine Issue :<strong> </td>
       <td> <input type="text" name="nadi1" id="nadi1" readonly value="<?php  echo $user_login->nadi_problem; ?>" /> <br> 
            <input type="text" name="uri1" id="uri1" readonly value="<?php  echo $user_login->urine_issue; ?>" />  
      </td>
    </tr>
     <tr>
        <td> <strong>Duration of Disease :<strong> </td>
       <td> <input type="text" name="durdise1" id="durdise1" readonly value="<?php  echo $user_login->duration_disease_1; ?>" /> <br> 
            <input type="text" name="durdise2" id="durdise2" readonly value="<?php  echo $user_login->duration_disease_2; ?>" /> <br> 
            <input type="text" name="durdise3" id="durdise3" readonly value="<?php  echo $user_login->duration_disease_3; ?>" /> <br> 
            <input type="text" name="durdise4" id="durdise4" readonly value="<?php  echo $user_login->duration_disease_4; ?>" /> 
       </td>
      </tr>
      <tr>
        <td> <strong>Any Other Disease :<strong> </td>
       <td> <input type="text" name="othdise1" id="othdise1" readonly value="<?php  echo $user_login->any_other_diseases_1; ?>" /> <br> 
            <input type="text" name="othdise2" id="othdise2" readonly value="<?php  echo $user_login->any_other_diseases_2; ?>" />   
       </td>
      </tr>
      </tr>
        <td> <strong>Any Surgeries Done :<strong> </td>
       <td> <input type="text" name="surgery1" id="surgery1" readonly value="<?php  echo $user_login->any_surgeries_1; ?>" /> <br> 
            <input type="text" name="surgery2" id="surgery2" readonly value="<?php  echo $user_login->any_surgeries_2; ?>" /> <br> 
            <input type="text" name="surgery3" id="surgery3" readonly value="<?php  echo $user_login->any_surgeries_3; ?>" />   
       </td>
      </tr>
      </tr>
        <td> <strong>Any Family History / Disease :<strong> </td>
       <td> <input type="text" name="fmly1" id="fmly1" readonly value="<?php  echo $user_login->family_member_disease_1; ?>" /> <br> 
            <input type="text" name="fmly2" id="fmly2" readonly value="<?php  echo $user_login->family_member_disease_2; ?>" />  
       </td>
      </tr>
     <tr>
        <td> <strong>Any Reference Name You can Suggest :<strong> </td>
       <td> <input type="text" name="ref1" id="ref1" readonly value="<?php  echo $user_login->anyreferencenameno1; ?>" /> <br> 
            <input type="text" name="ref2" id="ref2" readonly value="<?php  echo $user_login->anyreferencenameno2; ?>" /> <br> 
            <input type="text" name="ref3" id="ref3" readonly value="<?php  echo $user_login->anyreferencenameno3; ?>" /> <br> 
            <input type="text" name="ref4" id="ref4" readonly value="<?php  echo $user_login->anyreferencenameno4; ?>" /> 
       </td>
      </tr>
     <tr>
        <td> <strong>Any additional Information :<strong> </td>
       <td> <input type="text" name="inf1" id="inf1" readonly value="<?php  echo $user_login->any_information_1; ?>" /> <br> 
            <input type="text" name="inf2" id="inf2" readonly value="<?php  echo $user_login->any_information_2; ?>" />  
      </td>
    </tr>
   

</table>

<?php
?>

  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>