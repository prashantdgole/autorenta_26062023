<?php
// die("here");
$pathphoto="";
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
//  echo " **************** 0 ";
// die("here");
  header("location: login");
}

if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
<script>
function onSelectChange()
{
    var sel = document.getElementById('select');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.occupation.value=strUser;
}

function onEnquiryChange()
{
    var sel = document.getElementById('selectenquiry');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.enquiry1.value=strUser;
}



function onFollowupChange()
{
    var sel = document.getElementById('selectfollowup');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.followup1.value=strUser;
}

</script>

<script>


patientphoto.onchange = evt => {
  const [file] = patientphoto.files
  if (file) {
    blah.src = URL.createObjectURL(file)
  }
}

</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>
<form method="post" runat="server" name="reghuman" action="<?php echo base_url().'index.php/Home_Dr_Raje/new_nature_user_registration';?>">


//


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_Registration"; ?>'>Registration</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_Maintenance"; ?>'>Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_report_upload"; ?>'>Report Upload</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminnature"; ?>'>Admin</a>
</div>



//


<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>


 <div id="main">
<div id="login"> 
<span style="font-size:20px;cursor:pointer;color="black"> Naturopathy Patient Registration Form </span>
<!-- <h2>Registration Form</h2> -->
<hr/>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('Home_Dr_Raje/human_patient_new_patient_nature'); // new_human_user_registration'); 
echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}
echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
echo form_label('Create Username : '); 
echo '</span>';
echo"<br/>";
 
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_input('username'); 
echo '</span>';
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}
echo "</div>";


echo"<br/>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Password : ');
echo '</span>';
echo"<br/>";
echo form_password('password');


// entry date
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Registration Date :</label> </span>';
echo '<input type="date" id ="registrationdate" name="registrationdate" value = "" />';


// CLINIC TYPE
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Clinic Type :</label> </span>';
$options1 = array(
                  'NATURE'    => 'NATUROPATHY PATIENT',
                );  
 echo form_dropdown('pethuman', $options1, 'NATUROPATHY PATIENT');
echo"<br/>";
echo"<br/>";

echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('User Type '); 
echo '</span>';
// echo "<br/>";
echo "&nbsp;&nbsp;";
//echo form_input('user_type_value');

$options = array(
                  'PATIENT'    => 'PATIENT',
                );

//$shirts_on_sale = array('small', 'large');

echo form_dropdown('user_type_value', $options, 'PATIENT');
echo"<br/>";
echo"<br/>";

// patients clinical id number
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Patient Clinical ID :</label> </span>';
echo form_input('clinicalid'); 



// photo image of patient

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Upload Patient Photo :</label> </span>';
echo "<br>";
echo '<input accept="image/*" type="file" id ="patientphoto" name="patientphoto" />';
echo '<img id="blah" src="\images\noimage.jpg" height=100 width=100 alt="your image" />';
echo "<br>";
echo "<br>";
?>
<script>
patientphoto.onchange = evt => {
   const [file] = patientphoto.files
   if (file)
   {
     blah.src = URL.createObjectURL(file)
   }
}

</script>

<?php

// please tell about you are referred by
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Referred by (Self/Dr/Friend/Relative etc name and contact no)  :</label> </span>';
echo form_input('reference'); 


// please tell us about your enquiry type
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Enquiry Type  :</label> </span>';
echo '<select name="" id= "selectenquiry" onchange="onEnquiryChange()">';
      echo '<option value="training">training</option>';
      echo '<option value="treatment">treatment</option>';
      echo '<option value="camping">camping</option>';
      echo '<option value="medication">medication</option>';
      echo '<option value="product">product</option>';
      echo '<option value="just information">just information</option>';
      echo '<option value="other">other</option>';
echo '</select>';
echo '<input type="text" name="enquiry1" id="enquiry1"/>'; 
echo "<br>";
echo '<input type="text" name="enquiry2" id="enquiry2"/>'; 
// enquiry over


// patients name 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Patients Name :</label> </span>';
echo form_input('nameofperson'); 

// patients gender

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Gender  :</label> </span>';
$options1 = array(
                  'MALE'  => 'MALE',
                  'FEMALE'    => 'FEMALE',
                );  
 echo form_dropdown('humangender', $options1, 'MALE');


// patient birth date

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Birth Date :</label> </span>';
echo '<input type="date" id ="birthdate" name="birthdate" value = "" />';

//   patients birth place
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Birth Place :</label> </span>';
echo form_input('placeofbirth');  
echo"<br/>";

// patients address 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Address :</label> </span>';
echo form_input('ad1'); 
echo form_input('ad2'); 
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Pin Code :</label> </span>';
echo form_input('pincode'); 


// please tell us about your occupation

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Occupation  :</label> </span>';
// echo form_input('occupation');

echo '<select name="" id= "select" onchange="onSelectChange()">';
      echo '<option value="student">student</option>';
      echo '<option value="house wife">house wife</option>';
      echo '<option value="job">job</option>';
      echo '<option value="profession">profession</option>';
      echo '<option value="govt. employee">govt. employee</option>';
      echo '<option value="retired">retired</option>';
      echo '<option value="other">other</option>';
echo '</select>';
echo '<input type="text" name="occupation" id="occupation"/>'; 

// occupation over

// patients mobile 1 and mobile 2
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Mobile  1 and 2 :</label> </span>';
echo form_input('mobile1'); 
echo form_input('mobile2');


// whats up nos 2
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Whats up no (if not yours mention name and nos)  :</label> </span>';
echo form_input('whatupno1');
echo form_input('whatupno2');
// whats up nos over


echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Email : '); 
echo '</span>';
echo"<br/>";
$data = array(
'type' => 'email',
'name' => 'email_value'
);
echo form_input($data);
echo "<br>";


// weight and height

echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Weight and Height  :</label> </span>';
echo form_input('patientweight');
echo form_input('patientheight');
// whats up nos over

echo "<br>";
echo "<br>";
echo '<span style="font-size:20px;bold;cursor:pointer"><label>CLINICAL FINDINGS (Health History) </label> </span>';

// please tell about Your exact physical problems 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your Problems (Health History) :</label> </span>';
echo form_input('physical_problems_1'); 
echo form_input('physical_problems_2'); 




//  patients diabetic and sugar level and asthma other problem
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Blood Pressure Level :</label> </span>';
echo form_input('bp_diabetic_level'); 
echo '<span style="font-size:15px;cursor:pointer"><label>Sugar Level :</label> </span>';
echo form_input('diabetic_level'); 
echo '<span style="font-size:15px;cursor:pointer"><label>Asthma Problem :</label> </span>';
echo form_input('asthma_problem'); 
echo '<span style="font-size:15px;cursor:pointer"><label>Any Other Problem :</label> </span>';
echo form_input('other_problem'); 
// please tell about your gas / acidity and abdomen 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about your gas / acidity and abdomen :</label> </span>';
echo form_input('gas_acidity_problem_1'); 
echo form_input('gas_acidity_problem_2'); 


echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Nadi Parikshan  :</label> </span>';
$options1 = array(
                  'VATH'  => 'VATH',
                  'PITH'    => 'PITH',
                  'COUGH'    => 'COUGH',
                  'HEREDITARY'    => 'HEREDITARY',
                  'TEMPERATURE' => 'TEMPERATURE',
                );  
 echo form_dropdown('nadi_problem', $options1, 'VATH');

echo "<br>";
echo "<br>";
echo '<span style="font-size:20px;bold;cursor:pointer"><label>PERSONNEL HABBITS </label> </span>';


//  patients  lunch dinner timings
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Lunch  Timings :</label> </span>';
echo form_input('lunchtimings'); 

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Dinner Timings :</label> </span>';
echo form_input('dinnertimings'); 

// wake up timings
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Morning Wake Up Timings :</label> </span>';
echo form_input('wakeuptimings'); 

// slipping timings
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Slipping Timings :</label> </span>';
echo form_input('sleeptimings'); 

// sound sleep yes or no 

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Are You Getting Sound sleep  :</label> </span>';
$options1 = array(
                  'YES'  => 'YES',
                  'NO'    => 'NO',
                  'GETUP' => 'GETUP',
                );  
 echo form_dropdown('soundsleepoption', $options1, 'YES');

// yoga exercises 

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label> Your Yoga Activities  :</label> </span>';
echo form_input('yogaactivities'); 


// please tell about water drinking habits 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about water drinking habits  :</label> </span>';
echo form_input('waterdrinkinghabits'); 


// please tell about consumption of milk products 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Milk Product Consumption :</label> </span>';
echo form_input('milk_product_consumption_1'); 
echo form_input('milk_product_consumption_2'); 



// are you pure vegeterian yes no 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell  are you veg or non veg :</label> </span>';

echo "<br>";

$options1 = array(
                  'NO'    => 'NO',
                  'IN WEEK LESS THAN 3 TIMES' => 'IN WEEK LESS THAN 3 TIMES',
                  'IN WEEK MORE THAN 3 TIMES' => 'IN WEEK MORE THAN 3 TIMES',  
                  'IN PARTIES' => 'IN PARTIES,BIRTHDAYS ETC',
                  'ONCE IN BLUE MOON' => 'ONCE IN A BLUE MOON',              
                );  
 echo  '<span style="font-size:15px;color:blue;cursor:pointer">' ;
 echo form_dropdown('vegnonveg', $options1, 'NO');
 echo '</span>';
/*
echo form_checkbox('vegnonveg[]', '1', TRUE)."YES";echo "<br>";
echo form_checkbox('vegnonveg[]', '2', FALSE)."NO";echo "<br>";
echo form_checkbox('vegnonveg[]', '3', FALSE).'IN A WEEK LESS THAN 3 TIMES';echo "<br>";
echo form_checkbox('vegnonveg[]', '4', FALSE)."IN A WEEK LESS THAN 3 TIMES";echo "<br>";
*/

// please tell about Your bad habits if any 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your Bad Habits if any :</label> </span>';
echo form_input('bad_habits_1'); 
echo form_input('bad_habits_2'); 


// please tell about Your urine 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about  Urine color , quantity, how many times  :</label> </span>';
echo form_input('urine_issue'); 


// please tell us about heridietery disease if any
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Specify heridietery disease if any (family history)  :</label> </span>';
echo form_input('heridieterydisease');

// heridietery disease over


// please tell about how old are diseases
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about how old are diseases  :</label> </span>';
echo form_input('duration_diseases_1'); 
echo form_input('duration_diseases_2'); 
echo form_input('duration_diseases_3'); 
echo form_input('duration_diseases_4'); 

// please tell about any other diseases
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about any other diseases  :</label> </span>';
echo form_input('any_other_diseases_1'); 
echo form_input('any_other_diseases_2'); 

// please tell about Your delivery time issue 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your Delivery time issue (if any)  :</label> </span>';
echo form_input('about_delivery_1'); 
echo form_input('about_delivery_2'); 


// please tell about Your surgeries if any 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your surgeries if any  :</label> </span>';
echo form_input('any_surgeries_1'); 
echo form_input('any_surgeries_2'); 
echo form_input('any_surgeries_3'); 

// please tell about Your allergery if any 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your allergy related to medicine or any food if any :</label> </span>';
echo form_input('allergyofany'); 

// please tell about Your medicines you are consuming if any 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your medication  :</label> </span>';
echo form_input('medicine_list_1'); 
echo form_input('medicine_list_2'); 
echo form_input('medicine_list_3'); 

// please tell about Your daily routine 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your Daily Routine  :</label> </span>';
echo form_input('daily_routine_1'); 
echo form_input('daily_routine_2'); 

// please tell about emergency contact details with relation 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Please tell about Your Emergency Contact Details with relation  :</label> </span>';
echo form_input('emergency_contact_1'); 
echo form_input('emergency_contact_2'); 


// family member has any of the following issue or any other

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Your family member has any issue as below or any other  :</label> </span>';
$options1 = array(
                  'ASTHAMA'  => 'ASTHAMA',
                  'BP'    => 'BP',
                  'THYROID' => 'THYROID',
                  'DIABETES'  => 'DIBETES',
                  'ANEMIA'    => 'ANEMIA',
                  'ALLERGY' => 'ALLERGY',
                  'ARTHRITIS'  => 'ARTHRITIS',
                  'ACIDITY'    => 'ACIDITY',
                  'DEPRESSION' => 'DEPRESSION',
                  'ALCOHOLISM'  => 'ALCOHOLISM',
                  'BLOOD CLOT'    => 'BLOOD CLOT',
                  'CANCER' => 'CANCER',
                  'GYNECOLOGICAL'  => 'GYNECOLOGICAL',
                  'CHOLESTEROL'    => 'CHOLESTEROL',
                  'SKIN' => 'SKIN',
                  'HEART ATTACK'  => 'HEART ATTACK',
                  'RESPIRATORY'    => 'RESPIRATORY',
                  'STOMACH' => 'STOMACH',
                  'STROKE'  => 'STROKE',
                  'SEXUAL'    => 'SEXUAL',
                  'MIGRAINE' => 'MIGRAINE',
                  'RENAL DISEASE' => 'RENAL DISEASE',
                );  
 echo form_dropdown('familydisease_1', $options1, 'ASTHAMA');
echo form_input('familydisease_2'); 


// please tell us about follow up required on below

echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Do you want follow from us on below  :</label> </span>';
echo '<select name="" id= "selectfollowup" onchange="onFollowupChange()">';
      echo '<option value="training">training</option>';
      echo '<option value="camping">camping</option>';
      echo '<option value="medication">medication</option>';
      echo '<option value="product">product</option>';
      echo '<option value="just information">just information</option>';
      echo '<option value="other">other</option>';
echo '</select>';
echo '<input type="text" name="followup1" id="followup1"/>'; 
echo "<br>";
echo '<input type="text" name="followup2" id="followup2"/>'; 

// follwup over


// please give references below
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>please give references of any friend, relative (name and nos)   :</label> </span>';
echo form_input('anyreferencenameno1');
echo form_input('anyreferencenameno2');
echo form_input('anyreferencenameno3');
echo form_input('anyreferencenameno4');

//any reference name no  over

 
// any additional information 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Any additional information  :</label> </span>';
echo form_input('any_information_1'); 
echo form_input('any_information_2'); 


/*
$data = array(
        'name'          => 'vegnonveg1',
        'id'            => 'vegnonveg2',
        'value'         => 'YES',
        'checked'       => TRUE,
        'style'         => 'margin:10px'
        'name'          => 'vegnonveg2',
        'id'            => 'vegnonveg2',
        'value'         => 'NO',
        'checked'       => FALSE,
        'style'         => 'margin:10px'
);
echo form_checkbox($data); 
*/

echo "<br>";
echo "<br>";
echo form_submit('submit', 'Create USER');
echo form_close();
?>
<span style="font-size:15px;cursor:pointer;color="black">;
<a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>For Login Click Here</a>
</span>;
<!-- <a href="<?php echo base_url() ?> ">For Login Click Here</a> -->
  </div>
</div> 
</div>
</div>
</form>
</body>
</html>