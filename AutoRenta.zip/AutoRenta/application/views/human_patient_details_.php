<?php 
 $this->load->library('session');
$_SESSION['global_user_id']= 0;
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}

 
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_new_sales_medicines"; ?>'>Medicines to Patient (Sales Bill) </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_approve_purchase_medicines"; ?>'>Approve Sales billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_return_medicines"; ?>'>Return By Patient (not required)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reject_medicines"; ?>'>Rejection by Patient (Replacement)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:20px;cursor:pointer;color="black">Patients Diagnosis Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Diagnosis of Patient </h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF'];  ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> SHOW RECORDS    : </span> </td>
               <td> 
                      <span style="font-size:15px;cursor:pointer;color="black">Patient Name  :
                      <select name="patientid" id = "patientid" style="width:100px;">
                      <option value="0">patientname </option>  
                         <?php 
                        foreach ($data1 as $data1) { 
                         echo "<option value=". $data1->id . ">" .   $data1->nameofperson  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br> <button type="submit" id="show" class="button" name="show" >Patient Details </button> 
             </td>
             <td> </td>
          <tr>

 
        <tr>              
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value= "<?php 
                         if (isset($_POST['show'])) 
                         { 
                           $mypatientid = $_POST['patientid']; 
                           $_SESSION['global_patient_id'] = $_POST['patientid'] ; 
                           $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                           $query = $this->db->query($sql);   
                           foreach ($query->result() as $row) 
                           { 
                             $mypatientname = $row->nameofperson; 
                             $_SESSION['global_patient_name']= $row->nameofperson;  
                             echo $row->nameofperson;  
                           }    
                         }  


                         ?>" placeholder="name of person "> 
                        <br>
                        <input type="text" id="personid" name="personid" readonly value="<?php 
                             if (isset($_POST['show'])) 
                             {
                               echo $_POST['patientid'];
                             } 

                         ?>">
                         </span> 
              </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Full Address: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="<?php 
                      if (isset($_POST['show'])) 
                      { 
                         $mypatientid = $_POST['patientid']; 
                         $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                         $query = $this->db->query($sql);   
                         foreach ($query->result() as $row) 
                         { 
                            echo nl2br($row->ad1 . " "  .  $row->ad2  . " " . $row->pincode);   
                         }    
                       }  
                       ?> " placeholder="full address "> 
                       </span> </td>
            
         </tr>
         <tr>
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Message : </span></td>
             <td> <input type="text" name="messageid"  placeholder="Message" id="messageid" value="<?php 
                  if (isset($_POST['show'])) 
                  {
                    $mypatientid = $_POST['patientid'];   
                    $msg = "Showing Records ..";  
                    echo $msg;  
                  }
                  ?>" > </td>
        </tr>
 
 </table>
<br>
<h2> Previous Bills of Patient : <?php if (isset($_POST['show'])) { $mypatientid = $_POST['patientid']; $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; $query = $this->db->query($sql);   foreach ($query->result() as $row) { echo $row->nameofperson;  }    }  ?> </h2>  
 <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Patient name <br> Sales Bill </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date   <br> Stock name</span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> HSN Code<br> Sale Qty </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Rate  <br> Gst% </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Amount <br> Total Amount  </span> </td> 
      </tr>

      <?php 
           if (isset($_POST['show'])) 
           { 
              $mypatientid = $_POST['patientid']; 
              
              $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $mypatientid  ; 
              $query = $this->db->query($sql);   
              foreach ($query->result() as $row)
              { ?>
                <tr>
                <td> <?php echo $row->patientname . "<br>" . $row->salesbill ;  ?> </td>
                <td> <?php echo $row->date . "<br>" . $row->stockname ;  ?> </td>
                <td> <?php echo $row->hsncode . "<br>" . $row->saleqty;  ?> </td>
                <td> <?php echo $row->salesrate . "<br>" . $row->gstperc;  ?> </td>
                <td> <?php echo $row->discountperc . "<br>" . $row->discountamount;  ?> </td>
                <td> <?php echo $row->itemtotal . "<br>" . $row->total;  ?> </td>
                </tr>
              <?php
              }   
            } 

        ?>
        
  </table>

 


<?php //1
if (isset($_POST['show'])) // paid bills
{   // 2
?>
  <br>
  <center>
<br>
<h2> Paid Bills of Patient : <?php if (isset($_POST['show'])) { $mypatientid = $_POST['patientid']; $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; $query = $this->db->query($sql);   foreach ($query->result() as $row) { echo $row->nameofperson;  }    }  ?> </h2>  

 <?php  // 3
  $sql ="SELECT * FROM saleshumanbill where patientid = " . $_SESSION["global_patient_id"] ; // . " and " . " salesbill = '" . $_SESSION["global_sales_billno"] . "'"  ; 
  $query = $this->db->query($sql);  
  $i=0; 
  $_SESSION['global_sales_record'] = 0;
  $txt = '<table border="1">';// 
  echo $txt;
  $txt = '<tr><td>Bill No </td><td>Date  </td><td>Bill Amount <br> Mode of Payment </td><td> Bank Name <br> Branch Address</td><td>Paid Amount  </td><td>Balance Amount    </td> </tr>'; 
  echo $txt;
  foreach ($query->result() as $row)
  {  // 3.1 
     $i++;
     $txt = '<tr><td>'. $row->salesbill . ' <td>'. $row->datepaid .  '</td><td>' . $row->billamount . "<br>" . $row->modeofpayment . '</td><td>'.  $row->bankname  . "<br>" . $row->bankbranch .  '</td><td>'. $row->paidamount .  '</td><td>' . $row->balanceamount .  '</td></tr>';
     echo $txt;
  } // 3.1 
  if ($i == 0 )
  {
     $txt = '<tr><td>Full bill is unpaid </td> </tr>';
     echo $txt;
  }
  $txt = '</table>';// 
  echo $txt;
}
?>

 
<!-- from pet details -->

  <h2> Previous Visit Details   </h2>   
  <table>
       <tr> <td><span style="font-size:15px;cursor:pointer;color="black"> Last Visit Date </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Illness 1 <br> Illness 2 </span> </td> <td><span style="font-size:15px;cursor:pointer;color="black"> Diagnosis 1 <br> Diagnosis 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Medicine1 <br> Medicine 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Bill Amount <br> Paid Amount </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Next Visit <br> Remarks </span> </td> </tr>
     <?php
             if (isset($_POST['show'])) // gole
             {

              $sql ="SELECT * FROM humandiagnosis where  userid = " . $mypatientid  ; 
              $query = $this->db->query($sql);   
              foreach ($query->result() as $row) 
              { 
                   $pvuserid = $_SESSION['global_user_id'];
                  // $pvpetid  =  $_POST['userloginid'];                          echo " <tr>";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->dateofvisit . "</span></td>";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->illness1 . "<br>" . $row->illness2 . "</span></td>";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->dignosis1 . "<br>" . $row->dignosis2 . "</span></td>";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->medicine1 . "<br>" . $row->medicine2 . "</span></td>";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->billamount .  "<br>" . $row->paidamount . "</span></td> ";
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->nextvisit . "<br>" . $row->remarks . "</span></td>";
                   echo "</tr>";
                }
               }
          //   }
         ?>
   <table> 
   <br>
   </form>
  </div>
</div>
</body>
</html>