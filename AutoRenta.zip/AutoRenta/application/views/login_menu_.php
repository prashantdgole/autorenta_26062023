<!DOCTYPE html>
<html lang="en">
<head>
<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>
<meta charset="utf-8">
<title>Login Menu</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>


<script type="text/javascript">
 function validateform()
{ 
   return true;
}
</script>
</head>
<body>

<?php
if (isset($logout_message)) {
echo "<div class='message'>";
echo $logout_message;
echo "</div>";
}
?>
<?php
if (isset($message_display)) {
echo "<div class='message'>";
echo $message_display;
echo "</div>";
}
?>

<div class="header">
  <div class="headerInner">  <!--  logo.png -->
    <div class="logo"><img src="<?php echo base_url(); ?>images/logo_pushpak.jpg" alt="Logo"> </div>
    <!--Logo End here -->
    <div class="topLinks">
      <ul>
        <li style="display:none"><a href="" >Tour</a></li>
        <li><a href="" class="login" >Login</a></li>
      </ul>
    </div>
    <div class="contactInfo">
      <p>: 98205 20 228 &nbsp;<span></span></p>
    </div>
    <!--contactInfo End here -->
  </div>
  <!--topLinks End here -->
  <!--headerInner End here -->
  <div class="clear"></div>
  <div id="smoothmenu1" class="ddsmoothmenu">
    <ul>
      <li><a href="index.php" class="first selected">Home</a></li>

      <li>  <a href="#">Login</a> 
                                  <ul>
			  <li><a href='<?php echo base_url()."index.php/Cntr_Login/login"; ?>'>Log on </a></li>
			  <li><a href='<?php echo base_url()."index.php/Cntr_Login/logout"; ?>'>Log OFF </a></li>
			</ul> 
     </li>  	 
<!--      <li>  <a href='<?php echo base_url()."index.php/Cntr_Login/login"; ?>'>Login</a>   </li>  -->
      <li><a href="#">Online Booking</a></li> 
      <li><a href="#">Tracking </a></li>
      <li><a href=#l">About Us</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
    <br style="clear: left" />
  </div>
  <!--End of Navigation -->
</div>
<!--End of header -->

 <div class="mainContainer">
<!-- <div class="formContainer">     -->

 
 

<!-- <div id="main">
<div id="login"> --> 
<h1>Login Form</h1>
<hr/>
<?php echo form_open('Cntr_Login/user_login_process'); ?>
<?php
echo "<div class='error_msg'>";
if (isset($error_message)) {
echo '<p>'. $error_message;
}
echo  '<p>'.validation_errors();
echo "</div>";
?>
<p> <label>UserName :</label>
<input type="text" name="username" id="username" placeholder="username"/><br /><br />
<label>Password :</label>
<input type="password" name="password" id="password" placeholder="**********"/><br/><br />
<input type="submit" value="Login " name="submit"/><br /><br />
<a href="<?php echo base_url() ?>index.php/Cntr_Login/user_registration_show">To SignUp Click Here</a>
<?php echo form_close(); ?>
</div>
</div>
     




    </div>
    <p>
  
    <p>
    
    </p>
  
 
   </div>
 </div> 
  
<!--mainContainer Div ends here -->
<div class="clear"></div>
<div class="footer">
  <div class="footerInner">
    <p> Unit No 232, Adarsh Industrial Premises, Next to Cigarette Factory, Chakala, Andheri Sahar Road, Mumbai 400 093.</p>
    <div class="contactInfoBtm">
      <p>:98205 20 228 &nbsp; &nbsp;<span></span></p>
    </div>
    <!--contactInfo End here -->
    <p class="tagline">STEP IN @ PUSHPAK <span>and CONSIDER YOU ARE IN SAFE HANDS ... </span></p>
  </div>
</div>
<!--footerInner Div ends here -->
</div>
<!--footer Div ends here -->
</body>
</html>
