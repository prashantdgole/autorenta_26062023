<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>user details show </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">    <!-- payupdate --> 
<form method="post" action="<?php echo base_url().'index.php/Home_AutoRenta/reversepayupdate/'.$paymentregister->id.'/'.$paymentregister->glcodedr.'/'.$paymentregister->glcodecr."/".$paymentregister->accode;?>">  <!-- drrupdate -->


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Update Registration Records Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
// echo form_open('Home_Dr_Raje/updatepaydata); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>
<!--   <a href="<?php echo base_url('user_registration_show') ?>"> Create New Item</a> -->
<!-- <a href='<?php echo base_url()."index.php/Home_AutoRenta/user_registration_show"; ?>'>New User Registration</a> -->

<!-- // original start -->

<font color="black">
<hr>

   
<!--  <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left"> -->
            <h2> Payment Master Reverse Entry</h2>
<!--        </div>
        <div class="pull-right"> -->
           <a class="btn btn-primary" href='<?php echo base_url()."index.php/Home_AutoRenta/reverseentry"; ?>'>Back</a>
<!--        </div>
    </div>
</div> -->
 
   <table width="100%" border="1">  
        <tr>  
           <td><span style="font-size:18px;cursor:pointer;color="black">Enter Date: </td>
          <td> <span style="font-size:18px;cursor:pointer;color="black"><input type="date" name="regdate"  readonly id="regdate" value="<?php echo $paymentregister->date;?>" /> </td>
          </tr>
     </table>
    <table width="100%" border="1">
   
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">    Emp Name  </span></td>
               <td>  <span style="font-size:18px;cursor:pointer;color="black"> 
                   <?php
                             $msql ="SELECT * FROM emptable where ecode = "  .  $paymentregister->accode ; 
                            $query = $this->db->query($msql); 						
                    ?>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                    <?php 
                      $empname = "";
                       foreach ($query->result() as $row)
                      {  // 3.0
                           $empname = $row->name ;
                     } 
                     echo $empname; 
                     ?>
                     </span> 
               </td>

<!-- new emp name start -->
              <td>    <span style="font-size:18px;cursor:pointer;color="black">  New   Emp Name  </span></td>
               <td>
                   <?php
                             $msql1 ="SELECT * FROM emptable "  ; 
                            $query1 = $this->db->query($msql1); 						
                    ?>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                      <select name="newempid1" id = "newempid1" style="width:180px;">
                      <option value="0">Empname </option>  
                         <?php 
                             foreach($query1->result() as  $data2)
                            { 
                                     echo "<option value=". $data2->ecode   . ">" .   $data2->name  . "</option>";
                            }  ?>  
                      </select>  
                     </span> 
               </td>
<!-- new emp name end -->

            </tr>
          </table>
          <br>
        <table width="100%" border="1">  
         <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black"  style="width:100px;">Opening Balance  </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                       <input type="text" name="opbalance"  readonly  id="opbalance" value="<?php if ($paymentregister->openingbalance>0) { echo $paymentregister->openingbalance*-1;}else {echo $paymentregister->openingbalance;}?>" placeholder="Type Opening Balance" />
                     </span> 
               </td>
         </tr>
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black"  style="width:100px;">Amount Given  </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                        <input type="text" name="amountgiven"  readonly  id="amountgiven" value="<?php if ($paymentregister->amountgiven > 0 ) {echo $paymentregister->amountgiven*-1;} else {echo $paymentregister->amountgiven;} ?>" placeholder="Type Amount Given" />
                    </span> 
               </td>
              <td>    <span style="font-size:18px;cursor:pointer;color="black"  style="width:100px;">Expenses Made  </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="expensesmade" readonly  id="expensesmade" value="<?php if ($paymentregister->amountspend>0 ){ echo $paymentregister->amountspend*-1;} else {echo $paymentregister->amountspend;} ?>" placeholder="Specify amount Spend for" />
                     </span> 
               </td>
              <td> &nbsp;&nbsp; </td>
            </tr> 
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">Narration   </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="narration1"    id="narration1" value="<?php echo 'Reverse: '.  $paymentregister->narration1; ?>" placeholder="Type narration 1" /><br>
                      <input type="text" name="narration2"    id="narration2" value="<?php echo 'Reverse: ' . $paymentregister->narration2; ?>" placeholder="Type narration 2" /><br>
                     </span> 
               </td>
              <td> &nbsp;&nbsp; </td>
        </tr>
       </table>
       <br>
        <table width="100%" border="1">  
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">Amount Adjusted Against salary  </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="amountadjusted" readonly   id="amountadjusted" value="<?php echo $paymentregister->amountadjusted; ?>" placeholder="Type Amount adjusted against salary" />
                     </span> 
               </td>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">  </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="salarymonth"    id="salarymonth" placeholder="Adjusted Salary Month" value="<?php echo $paymentregister->salarymonth; ?>" />
                      </span> 
               </td>
               <td> 
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="adjyear"   id="adjyear" value="<?php echo $paymentregister->salaryyear; ?>" placeholder="Adjusted Salary Year" />
                     </span> 
               </td>
              <td> &nbsp;&nbsp; </td>
            </tr> 
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">Remarks   </span></td>           
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="remarks"  id="remarks" value="<?php echo 'Reverse: ' .  $paymentregister->remarks; ?>" placeholder="Type remarks" />
                     </span> 
               </td>
        </tr>
       </table>
<center>
<input type="submit" name="submit" value="Submit"/>
</center>

</form>
  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>