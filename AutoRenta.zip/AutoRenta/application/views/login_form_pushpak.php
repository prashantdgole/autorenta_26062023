<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">
<title>PUSHPAK GROUP</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<div class="header">
  <div class="headerInner">  <!--  logo.png -->
    <div class="logo"><img src="<?php echo base_url(); ?>images/logo_pushpak.jpg" alt="Logo"> </div>
    <!--Logo End here -->
    <div class="topLinks">
      <ul>
        <li style="display:none"><a href="" >Tour</a></li>
        <li><a href="" class="login" >Login</a></li>
      </ul>
    </div>
    <div class="contactInfo">
      <p>: 98205 20 228 &nbsp;<span></span></p>
    </div>
    <!--contactInfo End here -->
  </div>
  <!--topLinks End here -->
  <!--headerInner End here -->
  <div class="clear"></div>
  <div id="smoothmenu1" class="ddsmoothmenu">
    <ul>
      <li><a href="index.php" class="first selected">Home</a></li>	 
      <li>  <a href='<?php echo base_url()."index.php/Cntr_Login/login"; ?>'>Login</a>   </li>  
      <li><a href="#">Online Booking</a></li> 
      <li><a href="#">Tracking </a></li>
      <li><a href=#l">About Us</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
    <br style="clear: left" />
  </div>
  <!--End of Navigation -->
</div>
<!--End of header -->


<div class="mainContainer">
  <div class="contentContainer">  <!-- banner-01.jpg -->
    <div class="adBanner" ><img src="<?php echo base_url(); ?>images/logo_pushpak_big_png.png" alt="" /></div>
     <h1>  
     <?php ?> <!--  $mycomp = $_SESSION['CompanyName']; echo $mycomp ;  ?> --> <!-- // $this->session->userdata['nameofcompany']; -->
     </h1>
    <div class="clear"></div>
	
	<!-- circle here start -->
	 <div class="boxContainerradius">
      <div class="boxContent">
        <a href='<?php echo base_url()."index.php/Cntr_Login/login"; ?>'>   <h2>Login Me<strong></strong></h2> </a>


      </div>
	  </div>
	  <div class="boxContainerradius">
	  <div class="boxContent">
    <a href="#l">   <h2>Book Order<strong></strong></h2> </a>
      </div>
    </div> 
    <div class="boxContainerradius">
	  <div class="boxContent">
    <a href="#l">   <h2>Track<strong>Order</strong></h2> </a>
      </div>
    </div> 

</div>
</div>

  
<div class="clear"></div>
 
  </div>
  <!--features Div ends here -->
</div>
<!--mainContainer Div ends here -->



<div class="footer">
  <div class="footerInner">

    <p>  Unit No 232, Adarsh Industrial Premises, Next to Cigarette Factory, Chakala, Andheri Sahar Road, Mumbai 400 093.</p>
        <div class="contactInfoBtm">
      <p>: 98205 20 228  &nbsp;<span></span></p>
    </div>
    <!--contactInfo End here -->

    <p class="tagline">STEP IN @ PUSHPAK GROUP <span>and CONSIDER YOU ARE IN SAFE HANDS ... </span></p>
  </div>
</div>
<!--footerInner Div ends here -->
</div>
<!--footer Div ends here -->
</body>
</html>

