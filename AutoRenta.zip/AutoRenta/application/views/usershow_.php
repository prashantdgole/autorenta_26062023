<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
if (isset($this->session->userdata['logged_in'])) 
{
   $username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
 
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
else 
{

 header("location: login");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>user details show </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Update Registration Records Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
/// remove echo form_open('Home_Dr_Raje/new_injection_registration'); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>
<!--   <a href="<?php echo base_url('user_registration_show') ?>"> Create New Item</a> -->
 <a href='<?php echo base_url()."index.php/Home_AutoRenta/user_registration_show"; ?>'>New User Registration</a>


<!-- // original start -->

<font color="black">
<hr>

   
<!--  <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left"> -->
            <h2> Show Item</h2>
<!--        </div>
        <div class="pull-right"> -->
           <a class="btn btn-primary" href='<?php echo base_url()."index.php/Home_AutoRenta/loginmaintaince"; ?>'>Back</a>
<!--        </div>
    </div>
</div> -->
 
<table>

  <tr>
    <td>   <strong>ID:</strong> </td>
     <td>       <?php echo $user_login->id; ?>   </td>
   </tr>
   <tr>
         <td>     <strong>User Name:</strong> </td>
          <td>     <?php echo $user_login->user_name; ?> </td>
        </div>
    </tr>
    <tr>
        <td>     <strong>User Type:</strong> </td>
         <td>   <?php echo $user_login->user_type; ?> </td>
    </tr>
    <tr>
           <td> <strong>User Password:</strong> </td>
         <?php
          if ($username=="pdg" || $username ==    $user_login->user_name )
          { ?>
               <td>  <?php echo $user_login->user_password; ?> </td>
           <?php
           }
           else
           {?>
               <td>  <?php echo " -- "; ?> </td>
          <?php
           }?>
   </tr>
   <tr>
        <td <strong>Name of Person :</strong> </td>
        <td>    <?php echo $user_login->nameofperson; ?> </td>
    </tr>
    <tr>
        <td> <strong>Mobile 1 and 2 :<strong> </td>
       <td> <input type="text" name="mobile1" id="mobile1" readonly value="<?php  echo $user_login->mobile1; ?>" /> <br> 
               <input type="text" name="mobile2" id="mobile2" readonly value="<?php  echo $user_login->mobile2; ?>" />
      </td>
    </tr>
   <tr>
        <td <strong>Working In :</strong> </td>
        <td>    <?php echo $user_login->workin; ?> </td>
    </tr>

</table>

<?php
?>

  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>