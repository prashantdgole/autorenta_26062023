<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
 $username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
 $user_type_value = ($this->session->userdata['logged_in']['user_type']);
 $patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
else 
{
// echo " **************** 0 ";
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";
 
?>
<?php
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');
         $eop1 = $this->input->post('op1');
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%; 
}
table
{
 border=1;
}
p {
    font-size: 20px;
}
</style>

<style>
body {
font-family: 'Raleway', sans-serif;
}
.main
{
width: 1015px;
position: absolute;
top: 10%;
left: 20%;
}
#form_head
{
text-align: center;
background-color: #61CAFA;
height: 66px;
margin: 0 0 -29px 0;
padding-top: 35px;
border-radius: 8px 8px 0 0;
color: rgb(255, 255, 255);
}
#content {
position: absolute;
width: 450px;
height: 390px;
border: 2px solid gray;
border-radius: 10px;
}
#form_input
{
margin-left: 110px;
margin-top: 30px;
}
label
{
margin-right: 6px;
font-weight: bold;
}
#pagination{
margin: 40 40 0;
}
.input_text {
display: inline;
margin: 100px;
}
.input_name {
display: inline;
margin: 65px;
}
.input_email {
display: inline;
margin-left: 73px;
}
.input_num {
display: inline;
margin: 36px;
}
.input_country {
display: inline;
margin: 53px;
}
.btn a
{
   background-color:#CCC;
   padding:10px;
}
ul.tsc_pagination li a
{
border:solid 1px;
border-radius:3px;
-moz-border-radius:3px;
-webkit-border-radius:3px;
padding:6px 9px 6px 9px;
}
ul.tsc_pagination li
{
padding-bottom:1px;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
color:#FFFFFF;
box-shadow:0px 1px #EDEDED;
-moz-box-shadow:0px 1px #EDEDED;
-webkit-box-shadow:0px 1px #EDEDED;
}
ul.tsc_pagination
{
margin:4px 0;
padding:0px;
height:100%;
overflow:hidden;
font:12px 'Tahoma';
list-style-type:none;
}
ul.tsc_pagination li
{
float:left;
margin:0px;
padding:0px;
margin-left:5px;
}
ul.tsc_pagination li a
{
color:black;
display:block;
text-decoration:none;
padding:7px 10px 7px 10px;
}
ul.tsc_pagination li a img
{
border:none;
}
ul.tsc_pagination li a
{
color:#0A7EC5;
border-color:#8DC5E6;
background:#F8FCFF;
}
ul.tsc_pagination li a:hover,
ul.tsc_pagination li a.current
{
text-shadow:0px 1px #388DBE;
border-color:#3390CA;
background:#58B0E7;
background:-moz-linear-gradient(top, #B4F6FF 1px, #63D0FE 1px, #58B0E7);
background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #B4F6FF), color-stop(0.02, #63D0FE), color-stop(1, #58B0E7));
}

</style>

<style>
.pagination {
  display: inline-block;
}

.pagination a { /* float: left; */
  color: black;
  
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
span.pag {
    font-size: 22px !important;
        background: #e25817;
        color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext{
    font-size: 22px !important;
        background: #e25817;
        color: white !important;
    padding: 8px 0px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
}

.pagnext a{
   
        color: white !important;
    
}
.btn-nexttag a {
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    transition: background-color .3s;
    border: 1px solid #ddd;
    font-size: 22px;
    background : #f76d2b;
}
span.btn.btn-nexttag {
    padding: 3% 0%;
    color: white !important;
    display: contents;
}

</style>

    <style type="text/css">
        #lasttext
        {
        	font-family :Verdana;
        	font-size :18px;
        	font-weight:bold;
            position:absolute;
            bottom  :-10px;
            width:100%;
            height:69px;  
            left: 0px;
        }
        .headerbak
        {
            font-size: 9px;
            color: black;
        }
         .headerbak1
        {
           background-image :url("Images\pattern-7hi.png");
        }
          .headerbak3
        {
           background-image :url("Images\pattern-7hi.png");
        }
         .headerbak2
        {
           background-image :url("Images\pattern-7hi.png");
        }
        .style1
        {
            width: 170px;
            height: 59px;
        }
        .style2
        {   
            background-image: url('Images\pattern-7hi.png');
            width: 32px;
        }
        .style3
        {
            background-image: url('Images\pattern-7hi.png');
            width: 171px;
        }
        .style4
        {
            background-image: url('Images\pattern-7hi.png');
            width: 480px;
        }
    </style>
<style>
   body{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
   }
   div{
      overflow-x: auto;
   }
   table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid rgb(0, 0, 0);
   }
   th, td {
      text-align: left;
      padding: 8px;
   }
   tr:nth-child(even){background-color: #f2f2f2}
</style>

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<?php
if ($patient_class_value == "DAA")
{ ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>Admin</a>
</div>
<?php
}
else
{ ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>Admin</a>
</div>
<?php
} ?>
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

<div class="mainContainer">
<div class="formContainer">    
           <?php
              if ($eop1 == "0" or $eop1 == "1" or $eop1 == "2")
              { // 0
              ?>
               <?php
                    $newfDate = date("d-m-Y", strtotime($fdate));   
                    $newtDate = date("d-m-Y", strtotime($tdate));   
              ?>
              <table>
                     <tr> <td> </td> <td> Employee Date Wise Daily Attendence Report from <?php echo $newfDate; ?> To  <?php echo $newtDate; ?> </td> </tr>
              </table>
               <br>
              <hr>
                   <table  width="100%" class ="headerbak" border=1 cellpadding=5>  
                   <tr>
                   <td>Sr.No</td>
                   <td> Date </td>  
                   <td> P/A</td>
                   <td>Duty    </td>
                   <td>In time <br> Out Time <br> Out Station </td>
                   <td>Ot Time <br> Total  Duration <br>Date </td> 
                   <td> Customer Name <br> Passenger </td>
                   <td> Remarks </th>
                   </tr>      
                   <?php
                                $i=1;
                                $sql ="SELECT * FROM daaentry where empid  = " . $eid . " and ( date >= '" . $fdate . "' and date <= '" . $tdate . "') order by date,ID "; 
                                $query = $this->db->query($sql);  
                                $xemp = "";
                                foreach ($query->result() as $tabData)
                                {  // 3.0
                                ?>
                                <?php
                                       if ($xemp <> $tabData->empid  )
                                       {
                                                 echo '<tr><td></td><td></td>';
                                                 $xemp = $tabData->empid;
                                                  $empname1= "";
    
                                                  $sql11 ="SELECT * FROM emptable where ecode  = " . $xemp  ; 
                                                  $query11 = $this->db->query($sql11);  
                                                  foreach ($query11->result() as $row11)
                                                  {  // 3.1
                                                       $empname1 = $row11->name ;
                                                   }                                        
                                                  echo '<td>' .    $empname1 .  '</td> </tr>';
                                                  $xemp = $tabData->empid;
                                       }
                                ?>
                                <tr> 										
                                <td><?php echo $i; ?></td>
                               <?php  $newDate = date("d-m-Y", strtotime($tabData->date));   ?>  
                              <?php
                                if ($tabData->presentabsent == 'PO')
                               { ?>
                                           <td><?php  echo $newDate ; ?></td>
                               <?php
                                }
                                else
                                {  $newDate1 = date("d-m-Y", strtotime($tabData->outstationdateto));  
                                    if (  $tabData->outstationdatefrom == $tabData->outstationdateto)
                                    { ?>
                                           <td><?php  echo $newDate ; ?></td>
                                    <?php
                                     }
                                     else
                                     { ?>
                                           <td><?php  echo $newDate . "<br>" . $newDate1 ; ?></td>
                                     <?php
                                      }?>
                               <?php
                                }?>
                                <?php
                                                  $empname= "";
                                                  $daybasic = 0.00;
                                                  $sql1 ="SELECT * FROM emptable where ecode  = " . $tabData->empid  ; 
                                                  $query1 = $this->db->query($sql1);  
                                                  foreach ($query1->result() as $row1)
                                                  {  // 3.1
                                                       $empname = $row1->name ;
                                                   } 
                                ?>

                                <td><?php echo $tabData->presentabsent; ?></td>
                                <td> <?php echo $tabData->duty;?>
                               <?php
                                if ($tabData->presentabsent == 'PO')
                                 { ?>
                                <td> <?php echo $tabData->outstationdatefrom;?> </td>
                               <td> <?php echo $tabData->outstationdateto;?></td>
                                 <?php
                                 } 
                                 else
                                {
                                 ?>
                                <td><?php echo $tabData->actualintime . "<br>" . $tabData->actualouttime ; ?></td>
                                <td><?php echo $tabData->ottime . "<br>" . $tabData->totalduration ; ?></td>
                                <?php
                                 } ?>
                                <?php
                                             $customername="";
                                             $sql2 ="SELECT * FROM customer where id  = " . $tabData->customerid  ; 
                                              $query2 = $this->db->query($sql2);  
                                              foreach ($query2->result() as $row2)
                                              {  // 3.2
                                                   $customername = $row2->name ;
                                             } 
                                ?>
                                <td><?php echo  $customername."<br>".$tabData->passengername ; ?></td> 
                                <td><?php echo $tabData->remarks; ?></td>
                                </tr>										
                               <?php											
                                     $i++; 
                              } // 3.0
                          ?>
                   							
                       </table>
               <?php
               } // 0
               ?>
<!-- 1 or 3 start -->
             <?php
              if ( $eop1 == "1" or $eop1 == "3")
              { //0
              ?>
               <?php
                    $newfDate = date("d-m-Y", strtotime($fdate));   
                    $newtDate = date("d-m-Y", strtotime($tdate));   
              ?>
              <table  width="1025px" class ="headerbak" border=1 cellpadding=5>
                     <tr> <td> </td> <td> Employee Pay Roll Wise  Attendence Report from <?php echo $newfDate; ?> To  <?php echo $newtDate; ?> </td> </tr>
              </table>
               <br>
              <hr>

                  <table  width="1025px" class ="headerbak" border=1 cellpadding=5>      
                      <tr>
                     <td>.No</td>
                     <td> Date </td>

                     <td> P/A</td>
                     <td> Duty </td>
<!--                     <td> Customer Name/ Passenger  </td>  -->
                      <td> Customer  </td> 

<!--                     <td>In time <br> Out Time (O/s Date)</td> -->
<!--                     <td>In </td> -->
<!--                     <td>Ot Time <br> Total  Duration </td>  -->
                     <td>Out </td> 
          <!--           <td> Basic <br> Salary </td> -->
                     <td> Cleaning </td>
                     <td> Night   </td>
<!--                     <td> Daily <br> Alllowance </td> -->
                     <td>Alllowance </td>
<!--                     <td> Deduction <br> Late Coming </td> -->
                     <td> Late   </td>
<!--                    <td> Over <br> Time </td> -->
                    <td> OT </td>
                    <td> Double  </td>
<!--                    <td> Day <br> Salary </td> -->
                    <td>Salary </td>
                    <td> Remarks </td>
                   </tr>
                  <?php 
                        $i=1;
                       $col1 = 0.00;
                       $col2 = 0.00;
                       $col3 = 0.00;
                       $col4 = 0.00;
                       $col5 = 0.00;
                       $col6 = 0.00;
                       $col7 = 0.00;

                       $hr1 = 0.00;
                       $hr2 = 0.00;
                       $hr3 = 0.00;
                       $hr4 = 0.00;
                       $hr5 = 0.00;
                       $hr6 = 0.00;
                       $hr7 = 0.00;

                       $local =0; // pr
                       $outstation = 0; // po
                       $noduty = 0;  // pn
                       $absent = 0 ; // ab
                       $holiday = 0 ; // hl
                       $hn = 0 ; // hn
                       $hd =0 ; // hd
                       $dd = 0; // dd, dh

                       $wothr = 0;
                       $wotmm = 0;
                       $wotmm2 = 0.00;
                       $msql ="SELECT * FROM daaentry where ( empid = " .  $eid  . " and (  date >= '" . $fdate . "' and date <='" . $tdate . "' )  ) order by date , empid,ID "  ; 
                       $query = $this->db->query($msql);  	
                       $xemp = "";							
                       foreach($query->result() as  $tabData)
                       { // 5.0
                       ?>
                       <?php
                                       if ($xemp <> $tabData->empid  )
                                       {
                                                 echo '<tr>';
                                                 $xemp = $tabData->empid;
                                                  $empname1= "";
                                                  $wdaysal = 0.00;
                                                  $sql11 ="SELECT * FROM emptable where ecode  = " . $xemp  ; 
                                                  $query11 = $this->db->query($sql11);  
                                                  foreach ($query11->result() as $row11)
                                                  {  // 3.1
                                                       $empname1 = $row11->name ;
                                                       if ($row11->basicsal > 0 )
                                                       {
                                                           $wdaysal = round($row11->basicsal / 30,2);
                                                       }
                                                  }                                        
                                                  echo '<td></td><td width="350px;">' .    $empname1 . "</td><td> Day  </td><td>" . "(" . $wdaysal . ")"  .  '</td><td>Basic </td><td>' . "(" . $row11->basicsal  . ")" . '</td> </tr>';
                                                  $xemp = $tabData->empid;
                                       }
                       ?>
                          <tr>												
                          <td><?php echo $i; ?></td>

                          <?php  $newDate = date("d-m-Y", strtotime($tabData->date));   ?>   <!-- d-m-Y -->

                            <td width="450px;"><?php  echo $newDate ; ?></td>
                          <?php
                              $empname="";
                              $sql ="SELECT * FROM emptable where ecode  = " . $tabData->empid  ; 
                              $query = $this->db->query($sql);  
                              foreach ($query->result() as $row)
                              {  // 6.0
                                      $empname = $row->name ;
                              }  // 6.0
                          ?>
                         <td><?php echo $tabData->presentabsent; ?></td>
                       <?php
                            if ($tabData->presentabsent=='PR') {   $local ++;  } // pr
                            if ($tabData->presentabsent=='PO') {    $outstation++; }  // po
                            if ($tabData->presentabsent=='PN') {     $noduty++; }  // pn
                            if ($tabData->presentabsent=='AB') {      $absent++ ; } // ab
                            if ($tabData->presentabsent=='HL') {      $holiday++ ; } // hl
                            if ($tabData->presentabsent=='HN') {     $hn++ ;  } // hn
                            if ($tabData->presentabsent=='HD') {     $hd++ ;  } // hd
                            if ($tabData->presentabsent=='DD') {      $dd++;  } // dd, dh
                        ?>
                         <td><?php echo $tabData->duty; ?></td>
                          <?php
                            $customername="";
                            $sql ="SELECT * FROM customer where id  = " . $tabData->customerid  ; 
                            $query = $this->db->query($sql);  
                            foreach ($query->result() as $row)
                            {  // 7.0
                                  $customername = $row->name ;
                            }  // 7.0
                          ?>
                          <td><?php echo  $customername . "<br>" .   $tabData->passengername; ?> </td> 
 <!--                         <td> <?php echo $tabData->passengername ; ?></td>  $tabData->customerid."-". -->
                          <?php
                              if ($tabData->presentabsent == 'PO')  //  if ($tabData->duty == "L")
                              {   // 8.0
                          ?>
<!--                          <td><?php echo $tabData->outstationdatefrom;  ?></td> -->
                          <td><?php echo $tabData->outstationdateto; ?></td>
                          <?php
                              }
                              else
                              { 
                          ?>
<!--                          <td><?php echo $tabData->actualintime . "<br>" . $tabData->actualouttime ; ?></td> -->
                           <td><?php echo $tabData->ottime . "<br>" . $tabData->totalduration ; ?></td>             
                          <?php
                              } // 8.0 
                           ?>
  <!--                        <td>  <?php echo $tabData->basicsalary; ?> </td>   --> 
                          <?php
                                 /*
                                  $ip = "123.456.789.000"; // some IP address
                                  $iparr = split ("\.", $ip); 
                                  print "$iparr[0] <br />";
                                  */
                                  $otpattern = explode(":",$tabData->ottime);
                                  $wothr = $wothr + (int)$otpattern[0];
                                  $wotmm = $wotmm +  (int)$otpattern[1];
//echo " ot hr " . $wothr . " ot mm " . $wotmm ;
                         ?>
                          <td>   <?php if ($tabData->cleaningallowance >0) { $hr1 = $hr1 + 1; } $col1 = $col1 +  $tabData->cleaningallowance; echo $tabData->cleaningallowance; ?> </td>      
                          <td>   <?php if ($tabData->nightallowance  > 0 ) { $hr2 = $hr2 + 1 ; } $col2 = $col2 +  $tabData->nightallowance ; echo $tabData->nightallowance; ?> </td>  
                          <td>   <?php  $col3 = $col3 + $tabData->dayallowance; echo $tabData->dayallowance; ?> </td>     
                          <td>   <?php  if ( $tabData->latecoming > 0 ) { $hr4 = $hr4 +1 ; } $col4 = $col4  +  $tabData->latecoming;  echo $tabData->latecoming; ?> </td>     
                          <td>   <?php $col5 = $col5   + $tabData->overtime; echo $tabData->overtime; ?> </td>     
                         <td>     <?php if ($tabData->doubleshift >0) { $hr6 = $hr6 +1 ;  } $col6 = $col6   + $tabData->doubleshift;  echo $tabData->doubleshift; ?> </td>     
                          <td>   <?php  $col7 = $col7   + $tabData->daysalary; echo $tabData->daysalary; ?> </td>                  
                          <td><?php echo $tabData->remarks; ?></td>
                          </tr>										
                       <?php										
                                 $i++; 
                       } // 5.0									
                  ?>
                 <tr> <td> </td> </tr>
                  <tr>
                     <td> </td>
                     <td>   </td>
                     <td>  </td>
                     <td>  </td>
                     <td>TOTAL </td> 
<!--                     <td></td> -->
                     <td> </td> 
                     <td> <?php echo $col1;?> </td>
                     <td> <?php echo $col2;?></td>
                     <td>  <?php echo $col3;?> </td>
                     <td> <?php echo $col4;?> </td>
                    <td> <?php echo $col5;?> </td>
                    <td>  <?php echo $col6; ?> </td>
                    <td>  <?php echo $col7;?> </td>
                    <td> </td>
                  </tr>																	
                 <tr> <td> </td> </tr>
                <?php
/*
$n = 1.25;
$whole = floor($n);      // 1
$fraction = $n - $whole; // .25
*/
/*
                    if ( $wotmm > 60 )
                    {
                          $wotmm1 = $wotmm / 60;

                    $wothr = $wothr + floor ($wotmm1);
                    $wotmm2 = $wotmm - floor($wotmm1);
                    $wotmm = $wotmm + $wotmm2 ;
                   }
                   else
                  {
                         $wotmm1 = 0;
                  }

                    $wothr = $wothr + floor ($wotmm1);
                    $wotmm2 = $wotmm - floor($wotmm1);
*/
                ?>
                  <tr>
                     <td> </td>
                     <td>   </td>
                     <td>  </td>
                     <td>  </td>
                     <td>Hours/Number </td> 
<!--                     <td></td> -->
                     <td> </td> 
                     <td> <?php echo $hr1;?> </td>
                     <td> <?php echo $hr2;?></td>
                     <td>  </td>
                     <td> <?php echo $hr4;?> </td>
                    <td> <?php echo $wothr . ":" . $wotmm;?> </td>
                    <td>  <?php echo $hr6; ?> </td>
                    <td>    </td>
                    <td> </td>
                  </tr>	
             
                 																
                   </table>
                   <br>
                   <center> <h1> Summary </h1> </center>
                  <br>
                  <table width="100%" class ="headerbak" border=1 cellpadding=5>
                     <tr> <td> </td> <td> Local Duties  PR : </td> <td> <?php echo $local; ?> </td> <td> </td> <td> Out Station Duties PO : </td> <td> <?php echo $outstation; ?> </td> </tr>
                     <tr> <td> </td> <td> No Duty  PN : </td> <td> <?php echo $noduty; ?> </td> <td> </td> <td>Absent AB : </td> <td> <?php echo  $absent; ?> </td> </tr>
                      <tr> <td> </td> <td>Holiday No Duty HL : </td> <td> <?php echo  $holiday; ?> </td>  <td> </td> <td>HNT HN : </td> <td> <?php echo  $hn; ?> </td> </tr>
                      <tr> <td> </td> <td>Holidy Duty HD : </td> <td> <?php echo  $hd; ?> </td>  <td> </td> <td>Double Duty and on <br> Holiday DD.DH: </td> <td> <?php echo  $dd; ?> </td> </tr>
                  </table>
              <?php
              } // 0
              ?>								

<!-- 1 or 3 end  -->

    <?php
    echo "<br>". " Abbrevations : " . " PR : LOCAL , PO : OUTSTATION  , PN: NODUTY , AB: ABSENT  , HL: HOLIDAY NO DUTY , HN : HNT NIGHT DUTY" . "<br>";
    echo " HD : HOLIDAY  DUTY,  WO: WEEKLY OFF NO DUTY , WD: WEEKLY OFF DUTY,  DD: DOUBLE DUTY , DH : DOUBLE DUTY HOLIDAY  ";
  ?>

  <!--    <p> <div class="pagination"> <?php echo $links; ?> </div> </p> -->
</div>
</div>
</body>
</html>