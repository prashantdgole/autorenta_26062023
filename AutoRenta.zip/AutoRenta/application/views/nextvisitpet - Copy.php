<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
 $username = ($this->session->userdata['logged_in']['username']);
 $email = ($this->session->userdata['logged_in']['email']);
 $user_type_value = ($this->session->userdata['logged_in']['user_type']);
 $patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
else 
{
// echo " **************** 0 ";
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";
 
?>
<?php
// if (!empty($_POST['show'])) 
// {
// }
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

 

 
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
 <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";

if ($user_type_value != 'USER')
{
   $this->session->set_flashdata('err_message', 'Not  User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>



 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Pets Next Visit  Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<div class="mainContainer">
<div class="formContainer">     


<font color="black">
<hr>
<h2> Enter Pets Details for Next  Visit </h2>


<!--
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/index.php"; ?>'>Back</a>
-->



 <!-- <form method="post" name="mypetdetails" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />   -->

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    

    <table>
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Pet Detail Id : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="userloginid" id = "userloginid" style="width:100px;">  
                         <?php 
                        foreach ($data3 as $data3) { 
                         echo "<option value=". $data3->petdetailsid . ">" .   $data3->username  . "~" .  $data3->petname . "~" . $data3->pettype   . "~" .  $data3->userid  . "</option>";
                          }  ?>  
                      </select>  
                     </span>  
                       <input type="text" name="petloginid" id="petloginid"  hidden   readonly value= "<?php if (isset($_POST['show'])) { $uid  =  $_POST['userloginid']; $_SESSION['global_pet_id'] = $_POST['userloginid'];   echo $_POST['userloginid']; }?>" />
                       <input type="text" name="uloginid" id="uloginid"  hidden   readonly   value= "<?php if (isset($_POST['show'])) { $uid  =  $_POST['userloginid'];  foreach ($data7 as $data7) { if ($uid ==$data7->petdetailsid) { echo $data7->userid; $_SESSION['global_user_id'] =  $data7->userid; 
                        $myid  =  $data7->userid;    foreach ($data4 as $data4) { if ($data4->id == $myid) {  $_SESSION['global_user_name'] = $data4->user_name; $_SESSION['global_name_of_person'] = $data4->Nameofperson; $fulladdress = $data4->ad1 . " " .   $data4->ad2  .   " Mobile : " .  $data4->mobile1 . " " .  $data4->mobile2; } }
  } }  }?>" />    
                             
               </td>
              <td> </td>
              <td>    <button type="submit" id="show" name="show" >Show Records </button>   </td>

 
          <tr>

 
        <tr>              
               <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name : </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="ulusername" name="ulusername"   readonly  value = "<?php if (isset($_POST['show'])) {  echo $_SESSION['global_user_name'];  } ?>"  placeholder="click here for user name"  /> 
                         </span> 
               </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value= "<?php if (isset($_POST['show'])) {  echo $_SESSION['global_name_of_person']; } ?>" placeholder="name of person "> 
                         </span> </td>
         </tr>
         <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Full Address: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="<?php if (isset($_POST['show'])) {echo $fulladdress; } ?>" placeholder="full address "> 
                       </span> </td>
            
         </tr>
 
 </table>
<br>
<h2>Pet Other Details  </h2>  
 <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name <br> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender  <br> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Birth <br> Origin Details</span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> First Visit Date <br> Speciality </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Prev Illness <br> Allergy </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Remarks  </span> </td> 
      </tr>

     <?php
             if (isset($_POST['show'])) 
             {
              foreach ($data8 as $data8) 
              { 
                 $uid =  $_SESSION['global_user_id'];
                $mypetid  =  $_POST['userloginid'];
// echo $uid;
                 if ($data8->userid == $uid and  $data8->petdetailsid == $mypetid) 
                  {
                
                   echo '<tr>';
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->username . "<br>".$data8->pettype . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->gender . "<br>".$data8->petname . "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->dateofbirth . "<br>".$data8->origin . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->firstvisitdate . "<br>".$data8->speciality . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->illness1 . "<br>".$data8->illness2 . "<br>" . 
                          $data8->allergy1 . "<br>".$data8->allergy2 .  "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->remarks . "</span>";
                   echo '</td>';

                   echo '</tr>';
                 } 
               
               } 
             }
    ?>
      
  </table>

  <h2> Previous Visit Details   </h2>   
  <table>
       <tr> <td><span style="font-size:15px;cursor:pointer;color="black"> Last Visit Date </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Illness 1 <br> Illness 2 </span> </td> <td><span style="font-size:15px;cursor:pointer;color="black"> Diagnosis 1 <br> Diagnosis 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Medicine1 <br> Medicine 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Bill Amount <br> Paid Amount </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Next Visit <br> Remarks </span> </td> </tr>
     <?php
             if (isset($_POST['show'])) 
             {
              foreach ($data9 as $data9) 
              { 
                   $pvuserid = $_SESSION['global_user_id'];
                   $pvpetid  =  $_POST['userloginid'];
                   if ($data9->userid == $pvuserid and $data9->petdetid == $pvpetid )
                   {
                          echo " <tr>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dateofvisit . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->illness1 . "<br>" . $data9->illness2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dignosis1 . "<br>" . $data9->dignosis2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->medicine1 . "<br>" . $data9->medicine2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->billamount .  "<br>" . $data9->paidamount . "</span></td> ";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->nextvisit . "<br>" . $data9->remarks . "</span></td>";
                          echo "</tr>";
                   }
               }
             }
         ?>
   </table> 
   <br>
   </form>


</div>
</div>
</body>
</html>



