<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
$this->load->helper('form');

 
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in']))
{
$username = ($this->session->userdata['logged_in']['username']);
//$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
{
  header("location: login");
}
//echo $patient_class_value;
//die ("h");
if ($patient_class_value == 'DAA')
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
else
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
$wdayallowance = 0;
$wnightallowance = 0;
$wcleaningallowance =0;
$daydiff = 0;
$osrs = 400;
$nightrs = 100;
$cleanrs = 25;
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment  voucher entry Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function chkoutdatefn1()
{
   var od1 =   document.mydaa.outdate1_1.value;
   var od2 =   document.mydaa.outdate1_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}

}

function rtchangefn1()
{
// alert("h");
 var rth1 = document.getElementById("rthh1").value;
var rtm1 = document.getElementById("rtmm1").value;
 document.mydaa.reporttime1.value= rth1+ ":"+rtm1;
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
 
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
 
@media screen and (max-height: 400px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttonsmall {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 9px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
 <style>
   body{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      
   }
   div{
      overflow-x: auto;
   }
   table {
      border-collapse: collapse;
      border-spacing: 0;
      font-size :9px;
      width: 100%;
      border: 1px solid rgb(0, 0, 0);
   }
   th, td {
      text-align: left;
      padding: 8px;
   }
   tr:nth-child(even){background-color: #f2f2f2}
</style>


</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/daareports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>admin</a>


</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:15px;cursor:pointer;color="black">Daily Expenses Register </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
// echo $msg1;
?>


<!-- // original start -->

<font color="black">
<hr>

<!-- <a  href='<?php echo base_url()."index.php/Home_AutoRenta/oprentry"; ?>'>Back</a>   -->
 

<!--   <form  name="mydaa" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> -->
  <?php
/* echo form_open('Home_AutoRenta/new_user_registration');  */

 $attributes = array('id' => 'mydaa' ,'name' =>'mydaa');
echo form_open('Home_AutoRenta/reverse_main_voucher_save', $attributes);   // oprentry_main_voucher_save'



    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    <?php
             $obdate = "";
               $msql ="SELECT * FROM accodeledger  where id = 1 "  ; 
               $query = $this->db->query($msql);  
            $ftime = true;
            foreach($query->result() as  $tabData)
            { 
                $obdate = $tabData->date;
            }
    ?> 
    <table>
    </table>
   <br>
   <table width="100%" border="1">  
        <tr> <td> <input type="date" hidden name="obdate1" id="obdate1" value="<?php echo $obdate;?>" /> </td> </tr>
        <tr>  
           <td><span style="font-size:18px;cursor:pointer;color="black">Enter Date: </td>
          <td> <span style="font-size:18px;cursor:pointer;color="black"><input type="date" name="regdate" id="regdate" value="<?php echo date('Y-m-d');?>" /> </td>
          </tr>
     </table>
    <table width="100%" border="1">
   
          <tr>
             <td> <span style="font-size:18px;cursor:pointer;color="black">  Petty Cash A/C  </span></td>
             <td>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                      <select name="pettycashid1" readonly id = "pettycashid1" style="width:180px;">
                         <?php 
                             foreach($databank as $databank)   /* $query->result() as  $data) */
                            { 
                                     echo "<option value=". $databank->id   . ">" .   $databank->acname  . "</option>";
                            }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">    Emp Name  </span></td>
               <td>
                   <?php
       /*                      $msql ="SELECT * FROM emptable "  ; 
                            $query = $this->db->query($msql); */						
                    ?>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                      <select name="empid1" id = "empid1" style="width:180px;">
                      <option value="0">Empname </option>  
                         <?php 
                             foreach($data as $data)   /* $query->result() as  $data) */
                            { 
                                     echo "<option value=". $data->ecode   . ">" .   $data->name  . "</option>";
                            }  ?>  
                      </select>  
                     </span> 
               </td>
            </tr>

 
          <tr>
             <td> <span style="font-size:18px;cursor:pointer;color="black"> Expense A/C Head </span></td>
             <td>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                      <select name="expid1"   id = "expid1" style="width:180px;">
                      <option value="0">NOSELECTION</option>
                         <?php 
                             foreach($dataexp as $dataexp)   /* $query->result() as  $data) */
                            { 
                                     echo "<option value=". $dataexp->id   . ">" .   $dataexp->acname  . "</option>";
                            }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">Amount in Petty Cash </span></td>
               <td>
                   <?php
                    ?>
                       <span style="font-size:18px;cursor:pointer;color="black"> 
                      <select name="opbalid1" id = "opbalid1" style="width:180px;">
                      <option value="0">NOSELECTION</option>
                         <?php 
                             foreach($datainc as $datainc)   /* $query->result() as  $data) */
                            { 
                                     echo "<option value=". $datainc->id   . ">" .   $datainc->acname  . "</option>";
                            }  ?>  
                      </select>  
                     </span> 
               </td>
            </tr>



 

          </table>
          <br>
        <table width="100%" border="1">  
         <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black"  style="width:100px;">Amount    </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="amountgivenid1" id="amountgivenid1" value="" placeholder="amount in/out petty cash" />
                     </span> 
               </td>
    

              <td>    <span style="font-size:18px;cursor:pointer;color="black">Narration   </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="narration1" id="narration1" value="" placeholder="Type narration 1" /><br>
                      <input type="text" name="narration2" id="narration2" value="" placeholder="Type narration 2" /><br>
                     </span> 
               </td>
              <td>&nbsp;</td>
         </tr>
          <tr>
              <td>    <span style="font-size:18px;cursor:pointer;color="black">Remarks   </span></td>
               <td>
                      <span style="font-size:18px;cursor:pointer;color="black"> 
                      <input type="text" name="remarks" id="remarks" value="" placeholder="Type remarks" />
                     </span> 
               </td>
        </tr>
       </table>
      <br>
<?php

echo form_submit('submit', 'Create Main Payment Voucher  Entry ');
?>
        <br>
      <?php
               $xop = 0;
               $xde = 0;
               $xsp = 0;
               $msql ="SELECT * FROM accodeledger where id = " . 1  ; 
               $query = $this->db->query($msql);  
              foreach($query->result() as  $tabData)
            { 
                  $xop = $tabData->openingbalance;
                  $xde =  $tabData->amountgiventotal;
                  $xsp= $tabData->amountspendtotal;
             }
     ?>
      <table width="100%" border="1">     
           <tr> <td> Opening Balance </td> <td><?php echo $xop; ?></td>  <td> Balance Amount</td> <td><?php echo($xop+$xde)-$xsp; ?></td> </tr>
           <tr> <td> Amount Deposited</td> <td><?php echo $xde; ?></td> </tr>
          <tr> <td> Amount Spend</td> <td><?php echo $xsp; ?></td>     </tr>
      <table>
<?php
echo form_close();
?>
</div>
</div>
</body>
</html>