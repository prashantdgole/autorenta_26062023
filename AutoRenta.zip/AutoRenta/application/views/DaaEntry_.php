<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
$this->load->helper('form');

// echo $data_12;
 
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in']))
{
$username = ($this->session->userdata['logged_in']['username']);
//$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
{
  header("location: login");
}
//echo $patient_class_value;
//die ("h");
if ($patient_class_value == 'DAA')
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
else
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
$wdayallowance = 0;
$wnightallowance = 0;
$wcleaningallowance =0;
$daydiff = 0;
$osrs = 400;
$nightrs = 100;
$cleanrs = 25;
?>

<!DOCTYPE html>
<html>
<head>
<title>daa entry Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function selectsevenhh1()
{
 //  alert("here");
document.getElementById('acthh1').selectedIndex = 8;
}
function empidbasechangefn(sel) 
{
// line 1
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid1_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid1_1").value;
 var emp3 = document.getElementById("empid1_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid1name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid1.value=sp_lit[0];
     document.mydaa.shiftid1.value=sp_lit[1];
       document.mydaa.intime1.value=sp_lit[2];
    document.mydaa.acttime1.value=sp_lit[2]; 
        document.mydaa.outtime1.value=sp_lit[3]; 
    document.mydaa.actouttime1.value=sp_lit[3]; 
 document.mydaa.tottime1.value=sp_lit[4];               
     document.mydaa.workduration1.value=sp_lit[4];  
    document.mydaa.basicsal1.value=sp_lit[5];  
      document.mydaa.ottime1.value = "0:00";
// line 1 over

// line 2
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid2_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid2_1").value;
 var emp3 = document.getElementById("empid2_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid2name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid2.value=sp_lit[0];
     document.mydaa.shiftid2.value=sp_lit[1];
       document.mydaa.intime2.value=sp_lit[2];
    document.mydaa.acttime2.value=sp_lit[2]; 
        document.mydaa.outtime2.value=sp_lit[3]; 
    document.mydaa.actouttime2.value=sp_lit[3]; 
 document.mydaa.tottime2.value=sp_lit[4];               
     document.mydaa.workduration2.value=sp_lit[4];  
    document.mydaa.basicsal2.value=sp_lit[5];  
      document.mydaa.ottime2.value = "0:00";
// line 2 over

// line 3
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid3_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid3_1").value;
 var emp3 = document.getElementById("empid3_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid3name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid3.value=sp_lit[0];
     document.mydaa.shiftid3.value=sp_lit[1];
       document.mydaa.intime3.value=sp_lit[2];
    document.mydaa.acttime3.value=sp_lit[2]; 
        document.mydaa.outtime3.value=sp_lit[3]; 
    document.mydaa.actouttime3.value=sp_lit[3]; 
 document.mydaa.tottime3.value=sp_lit[4];               
     document.mydaa.workduration3.value=sp_lit[4];  
    document.mydaa.basicsal3.value=sp_lit[5];  
      document.mydaa.ottime3.value = "0:00";
// line 3 over

// line 4
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid4_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid4_1").value;
 var emp3 = document.getElementById("empid4_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid4name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid4.value=sp_lit[0];
     document.mydaa.shiftid4.value=sp_lit[1];
       document.mydaa.intime4.value=sp_lit[2];
    document.mydaa.acttime4.value=sp_lit[2]; 
        document.mydaa.outtime4.value=sp_lit[3]; 
    document.mydaa.actouttime4.value=sp_lit[3]; 
 document.mydaa.tottime4.value=sp_lit[4];               
     document.mydaa.workduration4.value=sp_lit[4];  
    document.mydaa.basicsal4.value=sp_lit[5];  
      document.mydaa.ottime4.value = "0:00";
// line 4 over

// line 5
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid5_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid5_1").value;
 var emp3 = document.getElementById("empid5_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid5name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid5.value=sp_lit[0];
     document.mydaa.shiftid5.value=sp_lit[1];
       document.mydaa.intime5.value=sp_lit[2];
    document.mydaa.acttime5.value=sp_lit[2]; 
        document.mydaa.outtime5.value=sp_lit[3]; 
    document.mydaa.actouttime5.value=sp_lit[3]; 
 document.mydaa.tottime5.value=sp_lit[4];               
     document.mydaa.workduration5.value=sp_lit[4];  
    document.mydaa.basicsal5.value=sp_lit[5];  
      document.mydaa.ottime5.value = "0:00";
// line 5 over


// line 6
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid6_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid6_1").value;
 var emp3 = document.getElementById("empid6_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid6name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid6.value=sp_lit[0];
     document.mydaa.shiftid6.value=sp_lit[1];
       document.mydaa.intime6.value=sp_lit[2];
    document.mydaa.acttime6.value=sp_lit[2]; 
        document.mydaa.outtime6.value=sp_lit[3]; 
    document.mydaa.actouttime6.value=sp_lit[3]; 
 document.mydaa.tottime6.value=sp_lit[4];               
     document.mydaa.workduration6.value=sp_lit[4];  
    document.mydaa.basicsal6.value=sp_lit[5];  
      document.mydaa.ottime6.value = "0:00";
// line 6 over



// line 7
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid7_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid7_1").value;
 var emp3 = document.getElementById("empid7_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid7name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid7.value=sp_lit[0];
     document.mydaa.shiftid7.value=sp_lit[1];
       document.mydaa.intime7.value=sp_lit[2];
    document.mydaa.acttime7.value=sp_lit[2]; 
        document.mydaa.outtime7.value=sp_lit[3]; 
    document.mydaa.actouttime7.value=sp_lit[3]; 
 document.mydaa.tottime7.value=sp_lit[4];               
     document.mydaa.workduration7.value=sp_lit[4];  
    document.mydaa.basicsal7.value=sp_lit[5];  
      document.mydaa.ottime7.value = "0:00";
// line 7 over


// line 8
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid8_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid8_1").value;
 var emp3 = document.getElementById("empid8_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid8name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid8.value=sp_lit[0];
     document.mydaa.shiftid8.value=sp_lit[1];
       document.mydaa.intime8.value=sp_lit[2];
    document.mydaa.acttime8.value=sp_lit[2]; 
        document.mydaa.outtime8.value=sp_lit[3]; 
    document.mydaa.actouttime8.value=sp_lit[3]; 
 document.mydaa.tottime8.value=sp_lit[4];               
     document.mydaa.workduration8.value=sp_lit[4];  
    document.mydaa.basicsal8.value=sp_lit[5];  
      document.mydaa.ottime8.value = "0:00";
// line 8 over



// line 9
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid9_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid9_1").value;
 var emp3 = document.getElementById("empid9_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid9name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid9.value=sp_lit[0];
     document.mydaa.shiftid9.value=sp_lit[1];
       document.mydaa.intime9.value=sp_lit[2];
    document.mydaa.acttime9.value=sp_lit[2]; 
        document.mydaa.outtime9.value=sp_lit[3]; 
    document.mydaa.actouttime9.value=sp_lit[3]; 
 document.mydaa.tottime9.value=sp_lit[4];               
     document.mydaa.workduration9.value=sp_lit[4];  
    document.mydaa.basicsal9.value=sp_lit[5];  
      document.mydaa.ottime9.value = "0:00";
// line 9 over


// line 10
  var empbase = document.getElementById("empidbase").value;
// alert(sel.options[sel.selectedIndex].text);
 var empbasesel =  sel.options[sel.selectedIndex].text;   //  value;  // document.getElementById("empid1").selectedIndex;
//alert(empbase);
//alert(empbasesel );
var options = document.getElementById("empid10_1").options;
for (var i = 0; i < options.length; i++) 
{
  if (options[i].text == empbasesel )
 {
    options[i].selected = true;
    break;
  }
}
 var emp2 = document.getElementById("empid10_1").value;
 var emp3 = document.getElementById("empid10_1");
//alert(emp2);
var strUser = emp3.options[emp3.selectedIndex].text;  //getting the selected option's text
//alert(strUser );
  document.mydaa.empid10name.value=strUser;

 var sp_lit = emp2.split('~'); 
//alert(sp_lit[0]); //                     shiftid1
    document.mydaa.empid10.value=sp_lit[0];
     document.mydaa.shiftid10.value=sp_lit[1];
       document.mydaa.intime10.value=sp_lit[2];
    document.mydaa.acttime10.value=sp_lit[2]; 
        document.mydaa.outtime10.value=sp_lit[3]; 
    document.mydaa.actouttime10.value=sp_lit[3]; 
 document.mydaa.tottime10.value=sp_lit[4];               
     document.mydaa.workduration10.value=sp_lit[4];  
    document.mydaa.basicsal10.value=sp_lit[5];  
      document.mydaa.ottime10.value = "0:00";
// line 10 over




}

function regdatechangefn1()
{
   daadate1 = document.mydaa.regdate1.value;
  document.getElementById("outdate1_1").value = daadate1;
  document.getElementById("outdate1_2").value = daadate1;
}


function regdatechangefn2()
{
   daadate1 = document.mydaa.regdate2.value;
  document.getElementById("outdate2_1").value = daadate1;
  document.getElementById("outdate2_2").value = daadate1;
}


function regdatechangefn3()
{
   daadate1 = document.mydaa.regdate3.value;
  document.getElementById("outdate3_1").value = daadate1;
  document.getElementById("outdate3_2").value = daadate1;
}


function regdatechangefn4()
{
   daadate1 = document.mydaa.regdate4.value;
  document.getElementById("outdate4_1").value = daadate1;
  document.getElementById("outdate4_2").value = daadate1;
}


function regdatechangefn5()
{
   daadate1 = document.mydaa.regdate5.value;
  document.getElementById("outdate5_1").value = daadate1;
  document.getElementById("outdate5_2").value = daadate1;
}


function regdatechangefn6()
{
   daadate1 = document.mydaa.regdate6.value;
  document.getElementById("outdate6_1").value = daadate1;
  document.getElementById("outdate6_2").value = daadate1;
}


function regdatechangefn7()
{
   daadate1 = document.mydaa.regdate7.value;
  document.getElementById("outdate7_1").value = daadate1;
  document.getElementById("outdate7_2").value = daadate1;
}


function regdatechangefn8()
{
   daadate1 = document.mydaa.regdate8.value;
  document.getElementById("outdate8_1").value = daadate1;
  document.getElementById("outdate8_2").value = daadate1;
}


function regdatechangefn9()
{
   daadate1 = document.mydaa.regdate9.value;
  document.getElementById("outdate9_1").value = daadate1;
  document.getElementById("outdate9_2").value = daadate1;
}


function regdatechangefn10()
{
   daadate1 = document.mydaa.regdate10.value;
  document.getElementById("outdate10_1").value = daadate1;
  document.getElementById("outdate10_2").value = daadate1;
}

function dtchangefn1()
{
      daadate1 = document.mydaa.regdate.value;

  document.getElementById("outdate1_1").value = daadate1;
  document.getElementById("outdate1_2").value = daadate1;

  document.getElementById("outdate2_1").value = daadate1;
  document.getElementById("outdate2_2").value = daadate1;

  document.getElementById("outdate3_1").value = daadate1;
  document.getElementById("outdate3_2").value = daadate1;

  document.getElementById("outdate4_1").value = daadate1;
  document.getElementById("outdate4_2").value = daadate1;

  document.getElementById("outdate5_1").value = daadate1;
  document.getElementById("outdate5_2").value = daadate1;

  document.getElementById("outdate6_1").value = daadate1;
  document.getElementById("outdate6_2").value = daadate1;

  document.getElementById("outdate7_1").value = daadate1;
  document.getElementById("outdate7_2").value = daadate1;

  document.getElementById("outdate8_1").value = daadate1;
  document.getElementById("outdate8_2").value = daadate1;

  document.getElementById("outdate9_1").value = daadate1;
  document.getElementById("outdate9_2").value = daadate1;

  document.getElementById("outdate10_1").value = daadate1;
  document.getElementById("outdate10_2").value = daadate1;

}

function chkoutdatefn1()
{
   var od1 =   document.mydaa.outdate1_1.value;
   var od2 =   document.mydaa.outdate1_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate1_2").value = od1;
  }
}
function chkoutdatefn2()
{
   var od1 =   document.mydaa.outdate2_1.value;
   var od2 =   document.mydaa.outdate2_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate2_2").value = od1;
  }
}
function chkoutdatefn3()
{
   var od1 =   document.mydaa.outdate3_1.value;
   var od2 =   document.mydaa.outdate3_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate3_2").value = od1;
  }
}
function chkoutdatefn4()
{
   var od1 =   document.mydaa.outdate4_1.value;
   var od2 =   document.mydaa.outdate4_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate4_2").value = od1;
  }
}
function chkoutdatefn5()
{
   var od1 =   document.mydaa.outdate5_1.value;
   var od2 =   document.mydaa.outdate5_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate5_2").value = od1;
  }
}
function chkoutdatefn6()
{
   var od1 =   document.mydaa.outdate6_1.value;
   var od2 =   document.mydaa.outdate6_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate6_2").value = od1;
  }
}
function chkoutdatefn7()
{
   var od1 =   document.mydaa.outdate7_1.value;
   var od2 =   document.mydaa.outdate7_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate7_2").value = od1;
  }
}

// 8 start

function chkoutdatefn8()
{
   var od1 =   document.mydaa.outdate8_1.value;
   var od2 =   document.mydaa.outdate8_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate8_2").value = od1;
  }
}
function chkoutdatefn9()
{
   var od1 =   document.mydaa.outdate9_1.value;
   var od2 =   document.mydaa.outdate9_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate9_2").value = od1;
  }
}
function chkoutdatefn10()
{
   var od1 =   document.mydaa.outdate10_1.value;
   var od2 =   document.mydaa.outdate10_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
     document.getElementById("outdate10_2").value = od1;
  }
}


// 10 over


function dutychangefn1() {

  var duty1 = document.getElementById("dutyid1").value;

  if (duty1 == 'L')
  {

//     document.getElementById("outdate1_1").hidden = true;
//     document.getElementById("outdate1_2").hidden = true;

//      document.getElementById("outdate1_1").disabled = true;
//      document.getElementById("outdate1_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate1_1").disabled = false;
  document.getElementById("outdate1_2").disabled = false;
  document.mydaa.intime1.value='';
  document.mydaa.acttime1.value='';
  document.mydaa.outtime1.value='';
  document.mydaa.actouttime1.value='';
  document.mydaa.tottime1.value='';        
  document.mydaa.workduration1.value='';
  }
}
 
function dutychangefn2() {
  var duty1 = document.getElementById("dutyid2").value;
 
  if (duty1 == 'L')
  {
 // alert('h');
//      document.getElementById("outdate2_1").disabled = true;
//      document.getElementById("outdate2_2").disabled = true;

//      document.getElementById("outdate2_1").disabled = true;
//      document.getElementById("outdate2_2").disabled = true;
  }
  else
  {
// alert('o');
  document.getElementById("outdate2_1").disabled = false;
  document.getElementById("outdate2_2").disabled = false;
  document.mydaa.intime2.value='';
  document.mydaa.acttime2.value='';
  document.mydaa.outtime2.value='';
  document.mydaa.actouttime2.value='';
  document.mydaa.tottime2.value='';        
  document.mydaa.workduration2.value='';
  }
}
 
function dutychangefn3() {
  var duty1 = document.getElementById("dutyid3").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate3_1").disabled = true;
//      document.getElementById("outdate3_2").disabled = true;

//      document.getElementById("outdate3_1").disabled = true;
//      document.getElementById("outdate3_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate3_1").disabled = false;
  document.getElementById("outdate3_2").disabled = false;
  document.mydaa.intime3.value='';
  document.mydaa.acttime3.value='';
  document.mydaa.outtime3.value='';
  document.mydaa.actouttime3.value='';
  document.mydaa.tottime3.value='';        
  document.mydaa.workduration3.value='';
  }
}
 
function dutychangefn4() {
  var duty1 = document.getElementById("dutyid4").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate4_1").disabled = true;
//      document.getElementById("outdate4_2").disabled = true;

//      document.getElementById("outdate4_1").disabled = true;
//      document.getElementById("outdate4_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate4_1").disabled = false;
  document.getElementById("outdate4_2").disabled = false;
  document.mydaa.intime4.value='';
  document.mydaa.acttime4.value='';
  document.mydaa.outtime4.value='';
  document.mydaa.actouttime4.value='';
  document.mydaa.tottime4.value='';        
  document.mydaa.workduration4.value='';
  }
}
 
function dutychangefn5() {
  var duty1 = document.getElementById("dutyid5").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate5_1").disabled = true;
//      document.getElementById("outdate5_2").disabled = true;

//      document.getElementById("outdate5_1").disabled = true;
//      document.getElementById("outdate5_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate5_1").disabled = false;
  document.getElementById("outdate5_2").disabled = false;
  document.mydaa.intime5.value='';
  document.mydaa.acttime5.value='';
  document.mydaa.outtime5.value='';
  document.mydaa.actouttime5.value='';
  document.mydaa.tottime5.value='';        
  document.mydaa.workduration5.value='';
  }
}
 
function dutychangefn6() {
  var duty1 = document.getElementById("dutyid6").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate6_1").disabled = true;
//      document.getElementById("outdate6_2").disabled = true;

//      document.getElementById("outdate6_1").disabled = true;
//      document.getElementById("outdate6_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate6_1").disabled = false;
  document.getElementById("outdate6_2").disabled = false;
  document.mydaa.intime6.value='';
  document.mydaa.acttime6.value='';
  document.mydaa.outtime6.value='';
  document.mydaa.actouttime6.value='';
  document.mydaa.tottime6.value='';        
  document.mydaa.workduration6.value='';
  }
}
 
function dutychangefn7()
 {
  var duty1 = document.getElementById("dutyid7").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate7_1").disabled = true;
//      document.getElementById("outdate7_2").disabled = true;

//      document.getElementById("outdate7_1").disabled = true;
//      document.getElementById("outdate7_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate7_1").disabled = false;
  document.getElementById("outdate7_2").disabled = false;
  document.mydaa.intime7.value='';
  document.mydaa.acttime7.value='';
  document.mydaa.outtime7.value='';
  document.mydaa.actouttime7.value='';
  document.mydaa.tottime7.value='';        
  document.mydaa.workduration7.value='';
  }
}

// 8 start

function dutychangefn8() {
  var duty1 = document.getElementById("dutyid8").value;
 
  if (duty1 == 'L')
  {
// alert('h');
 //     document.getElementById("outdate8_1").disabled = true;
 //     document.getElementById("outdate8_2").disabled = true;

//      document.getElementById("outdate8_1").disabled = true;
//      document.getElementById("outdate8_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate8_1").disabled = false;
  document.getElementById("outdate8_2").disabled = false;
  document.mydaa.intime8.value='';
  document.mydaa.acttime8.value='';
  document.mydaa.outtime8.value='';
  document.mydaa.actouttime8.value='';
  document.mydaa.tottime8.value='';        
  document.mydaa.workduration8.value='';
  }
}
function dutychangefn9() 
{
  var duty1 = document.getElementById("dutyid9").value;
 
  if (duty1 == 'L')
  {
// alert('h');
 //     document.getElementById("outdate9_1").disabled = true;
//      document.getElementById("outdate9_2").disabled = true;

//      document.getElementById("outdate9_1").disabled = true;
  //    document.getElementById("outdate9_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate9_1").disabled = false;
  document.getElementById("outdate9_2").disabled = false;
  document.mydaa.intime9.value='';
  document.mydaa.acttime9.value='';
  document.mydaa.outtime9.value='';
  document.mydaa.actouttime9.value='';
  document.mydaa.tottime9.value='';        
  document.mydaa.workduration9.value='';
  }
}
function dutychangefn10() 
{
  var duty1 = document.getElementById("dutyid10").value;
 
  if (duty1 == 'L')
  {
// alert('h');
//      document.getElementById("outdate10_1").disabled = true;
//      document.getElementById("outdate10_2").disabled = true;

//      document.getElementById("outdate10_1").disabled = true;
//      document.getElementById("outdate10_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate10_1").disabled = false;
  document.getElementById("outdate10_2").disabled = false;
  document.mydaa.intime10.value='';
  document.mydaa.acttime10.value='';
  document.mydaa.outtime10.value='';
  document.mydaa.actouttime10.value='';
  document.mydaa.tottime10.value='';        
  document.mydaa.workduration10.value='';
  }
}



// 10 over

function vehchangefn1()
{
  var veh1 = document.getElementById("vehid1").value;
   var veh2 = document.getElementById("vehid1");
 var strUser = veh2.options[veh2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.vehid1name.value=strUser;
}
function empchangefn1() {
  var emp1 = document.getElementById("empid1").value;
   var emp2 = document.getElementById("empid1");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid1name.value=strUser;
//

//    var sel = document.getElementById('sid1');
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text


//
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid1.value=sp_lit[1];
      document.mydaa.intime1.value=sp_lit[2];
       document.mydaa.acttime1.value=sp_lit[2]; 
       document.mydaa.outtime1.value=sp_lit[3]; 
      document.mydaa.actouttime1.value=sp_lit[3]; 
     document.mydaa.tottime1.value=sp_lit[4];               
      document.mydaa.workduration1.value=sp_lit[4];  
      document.mydaa.basicsal1.value=sp_lit[5];  
      document.mydaa.ottime1.value = "0:00";
}
function empchangefn2() {
  var emp1 = document.getElementById("empid2").value;
   var emp2 = document.getElementById("empid2");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid2name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid2.value=sp_lit[1];
      document.mydaa.intime2.value=sp_lit[2];
       document.mydaa.acttime2.value=sp_lit[2]; 
       document.mydaa.outtime2.value=sp_lit[3]; 
      document.mydaa.actouttime2.value=sp_lit[3]; 
     document.mydaa.tottime2.value=sp_lit[4];               
       document.mydaa.workduration2.value=sp_lit[4];     
      document.mydaa.basicsal2.value=sp_lit[5];     
      document.mydaa.ottime2.value = "0:00";  
}

function empchangefn3() {
  var emp1 = document.getElementById("empid3").value;
   var emp2 = document.getElementById("empid3");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid3name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid3.value=sp_lit[1];
      document.mydaa.intime3.value=sp_lit[2];
       document.mydaa.acttime3.value=sp_lit[2]; 
       document.mydaa.outtime3.value=sp_lit[3]; 
      document.mydaa.actouttime3.value=sp_lit[3]; 
     document.mydaa.tottime3.value=sp_lit[4];               
       document.mydaa.workduration3.value=sp_lit[4];     
      document.mydaa.basicsal3.value=sp_lit[5];   
      document.mydaa.ottime3.value = "0:00";
}
function empchangefn4() {
  var emp1 = document.getElementById("empid4").value;
   var emp2 = document.getElementById("empid4");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid4name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid4.value=sp_lit[1];
      document.mydaa.intime4.value=sp_lit[2];
       document.mydaa.acttime4.value=sp_lit[2]; 
       document.mydaa.outtime4.value=sp_lit[3]; 
      document.mydaa.actouttime4.value=sp_lit[3]; 
     document.mydaa.tottime4.value=sp_lit[4];               
       document.mydaa.workduration4.value=sp_lit[4];     
      document.mydaa.basicsal4.value=sp_lit[5];   
      document.mydaa.ottime4.value = "0:00";
}

function empchangefn5() {
  var emp1 = document.getElementById("empid5").value;
   var emp2 = document.getElementById("empid5");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid5name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid5.value=sp_lit[1];
      document.mydaa.intime5.value=sp_lit[2];
       document.mydaa.acttime5.value=sp_lit[2]; 
       document.mydaa.outtime5.value=sp_lit[3]; 
      document.mydaa.actouttime5.value=sp_lit[3]; 
     document.mydaa.tottime5.value=sp_lit[4];               
       document.mydaa.workduration5.value=sp_lit[4];   
      document.mydaa.basicsal5.value=sp_lit[5];     
      document.mydaa.ottime5.value = "0:00";
}
function empchangefn6() {
  var emp1 = document.getElementById("empid6").value;
   var emp2 = document.getElementById("empid6");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid6name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid6.value=sp_lit[1];
      document.mydaa.intime6.value=sp_lit[2];
       document.mydaa.acttime6.value=sp_lit[2]; 
       document.mydaa.outtime6.value=sp_lit[3]; 
      document.mydaa.actouttime6.value=sp_lit[3]; 
     document.mydaa.tottime6.value=sp_lit[4];               
       document.mydaa.workduration6.value=sp_lit[4];   
      document.mydaa.basicsal6.value=sp_lit[5];     
      document.mydaa.ottime6.value = "0:00";
}
function empchangefn7() 
{
  var emp1 = document.getElementById("empid7").value;
   var emp2 = document.getElementById("empid7");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid7name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid7.value=sp_lit[1];
      document.mydaa.intime7.value=sp_lit[2];
       document.mydaa.acttime7.value=sp_lit[2]; 
       document.mydaa.outtime7.value=sp_lit[3]; 
      document.mydaa.actouttime7.value=sp_lit[3]; 
     document.mydaa.tottime7.value=sp_lit[4];               
       document.mydaa.workduration7.value=sp_lit[4];   
      document.mydaa.basicsal7.value=sp_lit[5];     
      document.mydaa.ottime7.value = "0:00";
} 

// 8 start 

function empchangefn8()
 {
  var emp1 = document.getElementById("empid8").value;
   var emp2 = document.getElementById("empid8");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid8name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid8.value=sp_lit[1];
      document.mydaa.intime8.value=sp_lit[2];
       document.mydaa.acttime8.value=sp_lit[2]; 
       document.mydaa.outtime8.value=sp_lit[3]; 
      document.mydaa.actouttime8.value=sp_lit[3]; 
     document.mydaa.tottime8.value=sp_lit[4];               
     document.mydaa.workduration8.value=sp_lit[4];   
      document.mydaa.basicsal8.value=sp_lit[5];     
      document.mydaa.ottime8.value = "0:00";
} 
function empchangefn9()
 {
  var emp1 = document.getElementById("empid9").value;
   var emp2 = document.getElementById("empid9");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid9name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid9.value=sp_lit[1];
      document.mydaa.intime9.value=sp_lit[2];
       document.mydaa.acttime9.value=sp_lit[2]; 
       document.mydaa.outtime9.value=sp_lit[3]; 
      document.mydaa.actouttime9.value=sp_lit[3]; 
       document.mydaa.tottime9.value=sp_lit[4];               
       document.mydaa.workduration9.value=sp_lit[4];   
      document.mydaa.basicsal9.value=sp_lit[5];     
      document.mydaa.ottime9.value = "0:00";
} 
function empchangefn10() 
{
  var emp1 = document.getElementById("empid10").value;
   var emp2 = document.getElementById("empid10");
 var strUser = emp2.options[emp2.selectedIndex].text;  //getting the selected option's text
  document.mydaa.empid10name.value=strUser;

//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid10.value=sp_lit[1];
      document.mydaa.intime10.value=sp_lit[2];
       document.mydaa.acttime10.value=sp_lit[2]; 
       document.mydaa.outtime10.value=sp_lit[3]; 
      document.mydaa.actouttime10.value=sp_lit[3]; 
     document.mydaa.tottime10.value=sp_lit[4];               
       document.mydaa.workduration10.value=sp_lit[4];   
      document.mydaa.basicsal10.value=sp_lit[5];     
      document.mydaa.ottime10.value = "0:00";
} 


// 10 end 

function presenteefn1()
{
   var pfn1 = document.getElementById("presentid1").value;
  //alert(pfn1);
   if (pfn1 == 'AB')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
      document.mydaa.basicsal1.value='0';
     document.mydaa.latecoming1.value = '0';
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
     document.mydaa.remarks1.value='Absent';        
  }
   if (pfn1 == 'PN')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
     document.mydaa.latecoming1.value = '0';
     document.mydaa.remarks1.value='No Duty';        
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
  }
   if (pfn1 == 'HL')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
     document.mydaa.latecoming1.value = '0';
     document.mydaa.remarks1.value='Holiday No Duty';        
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
  }
   if (pfn1 == 'WO')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
     document.mydaa.latecoming1.value = '0';
     document.mydaa.remarks1.value='Weekly Off No Duty';        
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
  }
   if (pfn1 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid1.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate1_1").hidden = false;
    document.getElementById("outdate1_2").hidden =false;
    document.getElementById("outdate1_1").disabled = false;
    document.getElementById("outdate1_2").disabled = false;
//  document.getElementById("outdate1_1").value = daadate1;
 // document.getElementById("outdate1_2").value = daadate1;

     document.mydaa.remarks1.value='Outstation Duty';        
  }
   if (pfn1 == 'PR' || pfn1 == 'PP')
  {
     document.mydaa.dutyid1.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate1_1").hidden = false;
    document.getElementById("outdate1_2").hidden =false;
    document.getElementById("outdate1_1").disabled = false;  //  true;
    document.getElementById("outdate1_2").disabled = false; //  true;
  }
   if (pfn1 == 'HN')
  {
     document.mydaa.dutyid1.value='L';
    document.getElementById("outdate1_1").disabled = true;
    document.getElementById("outdate1_2").disabled = true;
    document.mydaa.basicsal1.value='0';
    document.mydaa.latecoming1.value = '0';
  }
   if (pfn1 == 'DD'  || pfn1 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks1.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate1_1").disabled = true;
    document.getElementById("outdate1_2").disabled = true;

  }
}
function presenteefn2()
{
   var pfn2 = document.getElementById("presentid2").value;

   if (pfn2 == 'AB')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
      document.mydaa.basicsal2.value='0';
     document.mydaa.latecoming2.value = '0';
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
     document.mydaa.remarks2.value='Absent';       
  }
   if (pfn2 == 'PN')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
     document.mydaa.latecoming2.value = '0';
     document.mydaa.remarks2.value='No Duty';        
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
  }
   if (pfn2 == 'HL')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
     document.mydaa.latecoming2.value = '0';
     document.mydaa.remarks2.value='Holiday No Duty';        
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
  }
   if (pfn2 == 'WO')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
     document.mydaa.latecoming2.value = '0';
     document.mydaa.remarks2.value='Weekly Off No Duty';        
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
  }
   if (pfn2 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid2.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate2_1").hidden = false;
    document.getElementById("outdate2_2").hidden =false;
    document.getElementById("outdate2_1").disabled = false;
    document.getElementById("outdate2_2").disabled = false;
     document.mydaa.remarks2.value='Outstation Duty';        

  }
   if (pfn2 == 'PR'   || pfn2 == 'PP')
  {
     document.mydaa.dutyid2.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate2_1").hidden = false;
    document.getElementById("outdate2_2").hidden =false;
    document.getElementById("outdate2_1").disabled = false; //  true;
    document.getElementById("outdate2_2").disabled = false;  // true;
  }
   if (pfn2 == 'HN')
  {
     document.mydaa.dutyid2.value='L';
    document.getElementById("outdate2_1").disabled = true;
    document.getElementById("outdate2_2").disabled = true;
    document.mydaa.basicsal2.value='0';
    document.mydaa.latecoming2.value = '0';

  }

  if (pfn2 == 'DD'  || pfn2 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks2.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate2_1").disabled = true;
    document.getElementById("outdate2_2").disabled = true;
  }
}
function presenteefn3()
{
   var pfn3 = document.getElementById("presentid3").value;
  //alert(pfn1);
   if (pfn3 == 'AB')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
      document.mydaa.basicsal3.value='0';
     document.mydaa.latecoming3.value = '0';
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
     document.mydaa.remarks3.value='Absent';       
  }

   if (pfn3 == 'PN')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
     document.mydaa.latecoming3.value = '0';
     document.mydaa.remarks3.value='No Duty';        
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
  }
  if (pfn3 == 'HL')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
     document.mydaa.latecoming3.value = '0';
     document.mydaa.remarks3.value='Holiday No Duty';        
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
  }
  if (pfn3 == 'WO')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
     document.mydaa.latecoming3.value = '0';
     document.mydaa.remarks3.value='Weekly Off No Duty';        
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
  }
   if (pfn3 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid3.value='O';

//     document.getElementById("dutyid3").innerHTML="OUTSTATION";
    document.getElementById("outdate3_1").hidden = false;
    document.getElementById("outdate3_2").hidden =false;
    document.getElementById("outdate3_1").disabled = false;
    document.getElementById("outdate3_2").disabled = false;
     document.mydaa.remarks3.value='Outstation Duty';        
  }
   if (pfn3 == 'PR' || pfn3 == 'PP')
  {
     document.mydaa.dutyid3.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate3_1").hidden = false;
    document.getElementById("outdate3_2").hidden =false;
    document.getElementById("outdate3_1").disabled =  false; //  true;
    document.getElementById("outdate3_2").disabled = false; //  true;
  }
   if (pfn3 == 'HN')
  {
     document.mydaa.dutyid3.value='L';
    document.getElementById("outdate3_1").disabled = true;
    document.getElementById("outdate3_2").disabled = true;
    document.mydaa.basicsal3.value='0';
    document.mydaa.latecoming3.value = '0';

  }

  if (pfn3 == 'DD'  || pfn3 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks3.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate3_1").disabled = true;
    document.getElementById("outdate3_2").disabled = true;
  }
}
function presenteefn4()
{
   var pfn4 = document.getElementById("presentid4").value;
  //alert(pfn1);
   if (pfn4 == 'AB')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
      document.mydaa.basicsal4.value='0';
     document.mydaa.latecoming4.value = '0';
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
     document.mydaa.remarks4.value='Absent';       
  }

   if (pfn4 == 'PN')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
     document.mydaa.latecoming4.value = '0';
     document.mydaa.remarks4.value='No Duty';        
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
  }
   if (pfn4 == 'HL')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
     document.mydaa.latecoming4.value = '0';
     document.mydaa.remarks4.value='HoliDay No Duty';        
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
  }
   if (pfn4 == 'WO')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
     document.mydaa.latecoming4.value = '0';
     document.mydaa.remarks4.value='Weekly Off No Duty';        
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
  }
   if (pfn4 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid4.value='O';

//     document.getElementById("dutyid4").innerHTML="OUTSTATION";
    document.getElementById("outdate4_1").hidden = false;
    document.getElementById("outdate4_2").hidden =false;
    document.getElementById("outdate4_1").disabled = false;
    document.getElementById("outdate4_2").disabled = false;
     document.mydaa.remarks4.value='Outstation Duty';        
  }
   if (pfn4 == 'PR' || pfn4 == 'PP')
  {
     document.mydaa.dutyid4.value='L';
//     document.getElementById("dutyid4").innerHTML="LOCAL"; 
    document.getElementById("outdate4_1").hidden = false;
    document.getElementById("outdate4_2").hidden =false;
    document.getElementById("outdate4_1").disabled = false; //  true;
    document.getElementById("outdate4_2").disabled = false; //  true;
  }
   if (pfn4 == 'HN')
  {
     document.mydaa.dutyid4.value='L';
    document.getElementById("outdate4_1").disabled = true;
    document.getElementById("outdate4_2").disabled = true;
    document.mydaa.basicsal4.value='0';
    document.mydaa.latecoming4.value = '0';

  }

  if (pfn4 == 'DD'  || pfn4 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks4.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate4_1").disabled = true;
    document.getElementById("outdate4_2").disabled = true;
  }
}
function presenteefn5()
{
   var pfn5 = document.getElementById("presentid5").value;
  //alert(pfn1);
   if (pfn5 == 'AB')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
      document.mydaa.basicsal5.value='0';
     document.mydaa.latecoming5.value = '0';
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
     document.mydaa.remarks5.value='Absent';       
  }

   if (pfn5 == 'PN')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
     document.mydaa.latecoming5.value = '0';
     document.mydaa.remarks5.value='No Duty';        
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
  }
   if (pfn5 == 'HL')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
     document.mydaa.latecoming5.value = '0';
     document.mydaa.remarks5.value='HoliDay No Duty';        
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
  }
   if (pfn5 == 'WO')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
     document.mydaa.latecoming5.value = '0';
     document.mydaa.remarks5.value='Weekly Off No Duty';        
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
  }
   if (pfn5 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid5.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate5_1").hidden = false;
    document.getElementById("outdate5_2").hidden =false;
    document.getElementById("outdate5_1").disabled = false;
    document.getElementById("outdate5_2").disabled = false;
     document.mydaa.remarks5.value='Outstation Duty';        
  }
   if (pfn5 == 'PR' || pfn5 == 'PP')
  {
     document.mydaa.dutyid5.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate5_1").hidden = false;
    document.getElementById("outdate5_2").hidden =false;
    document.getElementById("outdate5_1").disabled = false; // true;
    document.getElementById("outdate5_2").disabled = false; //  true;
  }
   if (pfn5 == 'HN')
  {
     document.mydaa.dutyid5.value='L';
    document.getElementById("outdate5_1").disabled = true;
    document.getElementById("outdate5_2").disabled = true;
    document.mydaa.basicsal5.value='0';
    document.mydaa.latecoming5.value = '0';

  }

  if (pfn5 == 'DD'  || pfn5 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks5.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate5_1").disabled = true;
    document.getElementById("outdate5_2").disabled = true;
  }
}
function presenteefn6()
{
   var pfn6 = document.getElementById("presentid6").value;
  //alert(pfn1);
   if (pfn6 == 'AB')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
      document.mydaa.basicsal6.value='0';
     document.mydaa.latecoming6.value = '0';
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
     document.mydaa.remarks6.value='Absent';       
  }

   if (pfn6 == 'PN')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
     document.mydaa.latecoming6.value = '0';
     document.mydaa.remarks6.value='No Duty';        
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
  }
   if (pfn6 == 'HL')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
     document.mydaa.latecoming6.value = '0';
     document.mydaa.remarks6.value='Holiday No Duty';        
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
  }
   if (pfn6 == 'WO')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
     document.mydaa.latecoming6.value = '0';
     document.mydaa.remarks6.value='Weekly Off No Duty';        
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
  }
   if (pfn6 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid6.value='O';

//     document.getElementById("dutyid6").innerHTML="OUTSTATION";
    document.getElementById("outdate6_1").hidden = false;
    document.getElementById("outdate6_2").hidden =false;
    document.getElementById("outdate6_1").disabled = false;
    document.getElementById("outdate6_2").disabled = false;
     document.mydaa.remarks6.value='Outstation Duty';        
  }
   if (pfn6 == 'PR'  || pfn6 == 'PP')
  {
     document.mydaa.dutyid6.value='L';
//     document.getElementById("dutyid4").innerHTML="LOCAL"; 
    document.getElementById("outdate6_1").hidden = false;
    document.getElementById("outdate6_2").hidden =false;
    document.getElementById("outdate6_1").disabled = false; // true;
    document.getElementById("outdate6_2").disabled =  false; // true;
  }
   if (pfn6 == 'HN')
  {
     document.mydaa.dutyid6.value='L';
    document.getElementById("outdate6_1").disabled = true;
    document.getElementById("outdate6_2").disabled = true;
    document.mydaa.basicsal6.value='0';
    document.mydaa.latecoming6.value = '0';

  }

  if (pfn6 == 'DD'  || pfn6 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks6.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate6_1").disabled = true;
    document.getElementById("outdate6_2").disabled = true;
  }
}

function presenteefn7()
{
   var pfn7 = document.getElementById("presentid7").value;
  //alert(pfn1);
   if (pfn7 == 'AB')
  {
      document.mydaa.shiftid7.value='';
      document.mydaa.dutyid7.value='';
      document.mydaa.intime7.value='';
       document.mydaa.acttime7.value='';
       document.mydaa.outtime7.value='';
      document.mydaa.actouttime7.value='';
     document.mydaa.tottime7.value='';        
       document.mydaa.workduration7.value='';
      document.mydaa.basicsal7.value='0';
     document.mydaa.latecoming7.value = '0';
    document.getElementById("outdate7_1").hidden = true;
    document.getElementById("outdate7_2").hidden = true;
     document.mydaa.remarks7.value='Absent';       
  }

   if (pfn7 == 'PN')
  {
      document.mydaa.shiftid7.value='';
      document.mydaa.dutyid7.value='';
      document.mydaa.intime7.value='';
       document.mydaa.acttime7.value='';
       document.mydaa.outtime7.value='';
      document.mydaa.actouttime7.value='';
     document.mydaa.tottime7.value='';        
       document.mydaa.workduration7.value='';
     document.mydaa.latecoming7.value = '0';
     document.mydaa.remarks7.value='No Duty';        
    document.getElementById("outdate7_1").hidden = true;
    document.getElementById("outdate7_2").hidden = true;
  }
   if (pfn7 == 'HL')
  {
      document.mydaa.shiftid7.value='';
      document.mydaa.dutyid7.value='';
      document.mydaa.intime7.value='';
       document.mydaa.acttime7.value='';
       document.mydaa.outtime7.value='';
      document.mydaa.actouttime7.value='';
     document.mydaa.tottime7.value='';        
       document.mydaa.workduration7.value='';
     document.mydaa.latecoming7.value = '0';
     document.mydaa.remarks7.value='HoliDay No Duty';        
    document.getElementById("outdate7_1").hidden = true;
    document.getElementById("outdate7_2").hidden = true;
  }
   if (pfn7 == 'WO')
  {
      document.mydaa.shiftid7.value='';
      document.mydaa.dutyid7.value='';
      document.mydaa.intime7.value='';
       document.mydaa.acttime7.value='';
       document.mydaa.outtime7.value='';
      document.mydaa.actouttime7.value='';
     document.mydaa.tottime7.value='';        
       document.mydaa.workduration7.value='';
     document.mydaa.latecoming7.value = '0';
     document.mydaa.remarks7.value='Weekly Off No Duty';        
    document.getElementById("outdate7_1").hidden = true;
    document.getElementById("outdate7_2").hidden = true;
  }
   if (pfn7 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid7.value='O';

//     document.getElementById("dutyid7").innerHTML="OUTSTATION";
    document.getElementById("outdate7_1").hidden = false;
    document.getElementById("outdate7_2").hidden =false;
    document.getElementById("outdate7_1").disabled = false;
    document.getElementById("outdate7_2").disabled = false;
     document.mydaa.remarks7.value='Outstation Duty';        
  }
   if (pfn7== 'PR' || pfn7 == 'PP')
  {
     document.mydaa.dutyid7.value='L';
//     document.getElementById("dutyid7").innerHTML="LOCAL"; 
   document.getElementById("outdate7_1").hidden = false;
    document.getElementById("outdate7_2").hidden =false;
     document.getElementById("outdate7_1").disabled = false; // true;
    document.getElementById("outdate7_2").disabled = false; // true;
  }
   if (pfn7 == 'HN')
  {
     document.mydaa.dutyid7.value='L';
    document.getElementById("outdate7_1").disabled = true;
    document.getElementById("outdate7_2").disabled = true;
    document.mydaa.basicsal7.value='0';
    document.mydaa.latecoming7.value = '0';

  }

  if (pfn7 == 'DD'  || pfn7 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks7.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate7_1").disabled = true;
    document.getElementById("outdate7_2").disabled = true;
  }
}

// 8 start

function presenteefn8()
{
   var pfn8 = document.getElementById("presentid8").value;
  //alert(pfn1);
   if (pfn8 == 'AB')
  {
      document.mydaa.shiftid8.value='';
      document.mydaa.dutyid8.value='';
      document.mydaa.intime8.value='';
       document.mydaa.acttime8.value='';
       document.mydaa.outtime8.value='';
      document.mydaa.actouttime8.value='';
     document.mydaa.tottime8.value='';        
       document.mydaa.workduration8.value='';
      document.mydaa.basicsal8.value='0';
     document.mydaa.latecoming8.value = '0';
    document.getElementById("outdate8_1").hidden = true;
    document.getElementById("outdate8_2").hidden = true;
     document.mydaa.remarks8.value='Absent';       
  }

   if (pfn8 == 'PN')
  {
      document.mydaa.shiftid8.value='';
      document.mydaa.dutyid8.value='';
      document.mydaa.intime8.value='';
       document.mydaa.acttime8.value='';
       document.mydaa.outtime8.value='';
      document.mydaa.actouttime8.value='';
     document.mydaa.tottime8.value='';        
       document.mydaa.workduration8.value='';
     document.mydaa.latecoming8.value = '0';
     document.mydaa.remarks8.value='No Duty';        
    document.getElementById("outdate8_1").hidden = true;
    document.getElementById("outdate8_2").hidden = true;
  }
   if (pfn8 == 'HL')
  {
      document.mydaa.shiftid8.value='';
      document.mydaa.dutyid8.value='';
      document.mydaa.intime8.value='';
       document.mydaa.acttime8.value='';
       document.mydaa.outtime8.value='';
      document.mydaa.actouttime8.value='';
     document.mydaa.tottime8.value='';        
       document.mydaa.workduration8.value='';
     document.mydaa.latecoming8.value = '0';
     document.mydaa.remarks8.value='HoliDay No Duty';        
    document.getElementById("outdate8_1").hidden = true;
    document.getElementById("outdate8_2").hidden = true;
  }
  if (pfn8 == 'WO')
  {
      document.mydaa.shiftid8.value='';
      document.mydaa.dutyid8.value='';
      document.mydaa.intime8.value='';
       document.mydaa.acttime8.value='';
       document.mydaa.outtime8.value='';
      document.mydaa.actouttime8.value='';
     document.mydaa.tottime8.value='';        
       document.mydaa.workduration8.value='';
     document.mydaa.latecoming8.value = '0';
     document.mydaa.remarks8.value='Weekly Off No Duty';        
    document.getElementById("outdate8_1").hidden = true;
    document.getElementById("outdate8_2").hidden = true;
  }
   if (pfn8 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid8.value='O';

//     document.getElementById("dutyid8").innerHTML="OUTSTATION";
    document.getElementById("outdate8_1").hidden = false;
    document.getElementById("outdate8_2").hidden =false;
    document.getElementById("outdate8_1").disabled = false;
    document.getElementById("outdate8_2").disabled = false;
     document.mydaa.remarks8.value='Outstation Duty';        
  }
   if (pfn8 == 'PR' || pfn8 == 'PP' )
  {
     document.mydaa.dutyid8.value='L';
//     document.getElementById("dutyid8").innerHTML="LOCAL"; 
    document.getElementById("outdate8_1").hidden = false;
    document.getElementById("outdate8_2").hidden =false;
    document.getElementById("outdate8_1").disabled =  false;  // true;
    document.getElementById("outdate8_2").disabled =  false;  // true;
  }
   if (pfn8 == 'HN')
  {
     document.mydaa.dutyid8.value='L';
    document.getElementById("outdate8_1").disabled = true;
    document.getElementById("outdate8_2").disabled = true;
    document.mydaa.basicsal8.value='0';
    document.mydaa.latecoming8.value = '0';

  }

  if (pfn8 == 'DD'  || pfn8 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks8.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate8_1").disabled = true;
    document.getElementById("outdate8_2").disabled = true;
  }
}
function presenteefn9()
{
   var pfn9 = document.getElementById("presentid9").value;
  //alert(pfn1);
   if (pfn9 == 'AB')
  {
      document.mydaa.shiftid9.value='';
      document.mydaa.dutyid9.value='';
      document.mydaa.intime9.value='';
       document.mydaa.acttime9.value='';
       document.mydaa.outtime9.value='';
      document.mydaa.actouttime9.value='';
     document.mydaa.tottime9.value='';        
       document.mydaa.workduration9.value='';
      document.mydaa.basicsal9.value='0';
     document.mydaa.latecoming9.value = '0';
    document.getElementById("outdate9_1").hidden = true;
    document.getElementById("outdate9_2").hidden = true;
     document.mydaa.remarks9.value='Absent';       
  }

   if (pfn9 == 'PN')
  {
      document.mydaa.shiftid9.value='';
      document.mydaa.dutyid9.value='';
      document.mydaa.intime9.value='';
       document.mydaa.acttime9.value='';
       document.mydaa.outtime9value='';
      document.mydaa.actouttime9.value='';
     document.mydaa.tottime9.value='';        
       document.mydaa.workduration9.value='';
     document.mydaa.latecoming9.value = '0';
     document.mydaa.remarks9.value='No Duty';        
    document.getElementById("outdate9_1").hidden = true;
    document.getElementById("outdate9_2").hidden = true;
  }

   if (pfn9 == 'HL')
  {
      document.mydaa.shiftid9.value='';
      document.mydaa.dutyid9.value='';
      document.mydaa.intime9.value='';
       document.mydaa.acttime9.value='';
       document.mydaa.outtime9value='';
      document.mydaa.actouttime9.value='';
     document.mydaa.tottime9.value='';        
       document.mydaa.workduration9.value='';
     document.mydaa.latecoming9.value = '0';
     document.mydaa.remarks9.value='HoliDay No Duty';        
    document.getElementById("outdate9_1").hidden = true;
    document.getElementById("outdate9_2").hidden = true;
  }
   if (pfn9 == 'WO')
  {
      document.mydaa.shiftid9.value='';
      document.mydaa.dutyid9.value='';
      document.mydaa.intime9.value='';
       document.mydaa.acttime9.value='';
       document.mydaa.outtime9value='';
      document.mydaa.actouttime9.value='';
     document.mydaa.tottime9.value='';        
       document.mydaa.workduration9.value='';
     document.mydaa.latecoming9.value = '0';
     document.mydaa.remarks9.value='Weekly Off No Duty';        
    document.getElementById("outdate9_1").hidden = true;
    document.getElementById("outdate9_2").hidden = true;
  }
   if (pfn9 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid9.value='O';

//     document.getElementById("dutyid99").innerHTML="OUTSTATION";
    document.getElementById("outdate9_1").hidden = false;
    document.getElementById("outdate9_2").hidden =false;
    document.getElementById("outdate9_1").disabled = false;
    document.getElementById("outdate9_2").disabled = false;
     document.mydaa.remarks9.value='Outstation Duty';        
  }
   if (pfn9== 'PR' || pfn9 == 'PP' )
  {
     document.mydaa.dutyid9.value='L';
//     document.getElementById("dutyid9").innerHTML="LOCAL"; 
    document.getElementById("outdate9_1").hidden = false;
    document.getElementById("outdate9_2").hidden =false;
    document.getElementById("outdate9_1").disabled = false; //  true;
    document.getElementById("outdate9_2").disabled = false; //  true;
  }
   if (pfn9 == 'HN')
  {
     document.mydaa.dutyid9.value='L';
    document.getElementById("outdate9_1").disabled = true;
    document.getElementById("outdate9_2").disabled = true;
    document.mydaa.basicsal9.value='0';
    document.mydaa.latecoming9.value = '0';

  }

  if (pfn9 == 'DD'  || pfn9 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks9.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate9_1").disabled = true;
    document.getElementById("outdate9_2").disabled = true;
  }
}
function presenteefn10()
{
   var pfn10= document.getElementById("presentid10").value;
  //alert(pfn1);
   if (pfn10 == 'AB')
  {
      document.mydaa.shiftid10.value='';
      document.mydaa.dutyid10.value='';
      document.mydaa.intime10.value='';
       document.mydaa.acttime10.value='';
       document.mydaa.outtime10.value='';
      document.mydaa.actouttime10.value='';
     document.mydaa.tottime10.value='';        
       document.mydaa.workduration10.value='';
      document.mydaa.basicsal10.value='0';
     document.mydaa.latecoming10.value = '0';
    document.getElementById("outdate10_1").hidden = true;
    document.getElementById("outdate10_2").hidden = true;
     document.mydaa.remarks10.value='Absent';       
  }

   if (pfn10 == 'PN')
  {
      document.mydaa.shiftid10.value='';
      document.mydaa.dutyid10.value='';
      document.mydaa.intime10.value='';
       document.mydaa.acttime10.value='';
       document.mydaa.outtime10.value='';
      document.mydaa.actouttime10.value='';
     document.mydaa.tottime10.value='';        
       document.mydaa.workduration10.value='';
     document.mydaa.latecoming10.value = '0';
     document.mydaa.remarks10.value='No Duty';        
    document.getElementById("outdate10_1").hidden = true;
    document.getElementById("outdate10_2").hidden = true;
  }
   if (pfn10 == 'HL' )
  {
      document.mydaa.shiftid10.value='';
      document.mydaa.dutyid10.value='';
      document.mydaa.intime10.value='';
       document.mydaa.acttime10.value='';
       document.mydaa.outtime10.value='';
      document.mydaa.actouttime10.value='';
     document.mydaa.tottime10.value='';        
       document.mydaa.workduration10.value='';
     document.mydaa.latecoming10.value = '0';
     document.mydaa.remarks6.value='HoliDay No Duty';        
    document.getElementById("outdate10_1").hidden = true;
    document.getElementById("outdate10_2").hidden = true;
  }
   if (pfn10 == 'WO')
  {
      document.mydaa.shiftid10.value='';
      document.mydaa.dutyid10.value='';
      document.mydaa.intime10.value='';
       document.mydaa.acttime10.value='';
       document.mydaa.outtime10.value='';
      document.mydaa.actouttime10.value='';
     document.mydaa.tottime10.value='';        
       document.mydaa.workduration10.value='';
     document.mydaa.latecoming10.value = '0';
     document.mydaa.remarks10.value='Weekly Off No Duty';        
    document.getElementById("outdate10_1").hidden = true;
    document.getElementById("outdate10_2").hidden = true;
  }
   if (pfn10== 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid10.value='O';

//     document.getElementById("dutyid10").innerHTML="OUTSTATION";
    document.getElementById("outdate10_1").hidden = false;
    document.getElementById("outdate10_2").hidden =false;
    document.getElementById("outdate10_1").disabled = false;
    document.getElementById("outdate10_2").disabled = false;
     document.mydaa.remarks10.value='Outstation Duty';        
  }
   if (pfn10 == 'PR' || pfn10 == 'PP')
  {
     document.mydaa.dutyid10.value='L';
//     document.getElementById("dutyid10").innerHTML="LOCAL"; 
    document.getElementById("outdate10_1").hidden = false;
    document.getElementById("outdate10_2").hidden =false;
    document.getElementById("outdate10_1").disabled = false;  //  true;
    document.getElementById("outdate10_2").disabled =  false;  // true;
  }
   if (pfn10 == 'HN')
  {
     document.mydaa.dutyid10.value='L';
    document.getElementById("outdate10_1").disabled = true;
    document.getElementById("outdate10_2").disabled = true;
    document.mydaa.basicsal10.value='0';
    document.mydaa.latecoming10.value = '0';

  }

  if (pfn10 == 'DD'  || pfn10 == 'DH')
  {
      var closingtime = prompt("Please enter closing time of earlier customer", "");
      if (closingtime!= null) 
     { //  document.getElementById("demo").innerHTML = text;
              document.mydaa.remarks10.value= "Earlier Closing Time was " + closingtime ;
     }
    document.getElementById("outdate10_1").disabled = true;
    document.getElementById("outdate10_2").disabled = true;
  }
}


// 10 end

function actchangefn1()
{ // ="intime1"   "acttime1" 
 var acth1 = document.getElementById("acthh1").value;
var actm1 = document.getElementById("actmm1").value;
 document.mydaa.acttime1.value= acth1+ ":"+actm1;
var schintime1 =  document.getElementById("intime1").value;
var sp_lit = schintime1.split(':'); 
var schintimehh1 = sp_lit[0];
var schintimemm1 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming1.value=0.0;
if ( parseInt(acth1) > parseInt(schintimehh1) )
{
         document.mydaa.latecoming1.value='33';   
}
if ( parseInt(acth1) ==  parseInt(schintimehh1)  && parseInt(actm1) >  parseInt(schintimemm1) )
{
         document.mydaa.latecoming1.value='33';   
}
}
function actchangefn2()
{
 var acth2 = document.getElementById("acthh2").value;
var actm2 = document.getElementById("actmm2").value;
 document.mydaa.acttime2.value= acth2+ ":"+actm2;
var schintime2 =  document.getElementById("intime2").value;
var sp_lit = schintime2.split(':'); 
var schintimehh2 = sp_lit[0];
var schintimemm2 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming2.value=0.0;
if ( parseInt(acth2) > parseInt(schintimehh2) )
{
         document.mydaa.latecoming2.value='33';   
}
if ( parseInt(acth2) ==  parseInt(schintimehh2)  && parseInt(actm2) >  parseInt(schintimemm2) )
{
         document.mydaa.latecoming2.value='33';   
}
}
function actchangefn3()
{
 var acth3 = document.getElementById("acthh3").value;
var actm3 = document.getElementById("actmm3").value;
 document.mydaa.acttime3.value= acth3+ ":"+actm3;
var schintime3 =  document.getElementById("intime3").value;
var sp_lit = schintime3.split(':'); 
var schintimehh3 = sp_lit[0];
var schintimemm3 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming3.value=0.0;
if ( parseInt(acth3) > parseInt(schintimehh3) )
{
         document.mydaa.latecoming3.value='33';   
}
if ( parseInt(acth3) ==  parseInt(schintimehh3)  && parseInt(actm3) >  parseInt(schintimemm3) )
{
         document.mydaa.latecoming3.value='33';   
}
}
function actchangefn4()
{
 var acth4 = document.getElementById("acthh4").value;
var actm4 = document.getElementById("actmm4").value;
 document.mydaa.acttime4.value= acth4+ ":"+actm4;
var schintime3 =  document.getElementById("intime4").value;
var sp_lit = schintime4.split(':'); 
var schintimehh4 = sp_lit[0];
var schintimemm4 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming4.value=0.0;
if ( parseInt(acth4) > parseInt(schintimehh4) )
{
         document.mydaa.latecoming4.value='33';   
}
if ( parseInt(acth4) ==  parseInt(schintimehh4)  && parseInt(actm4) >  parseInt(schintimemm4) )
{
         document.mydaa.latecoming4.value='33';   
}
}
function actchangefn5()
{
 var acth5 = document.getElementById("acthh5").value;
var actm5 = document.getElementById("actmm5").value;
 document.mydaa.acttime5.value= acth5+ ":"+actm5;
var schintime5 =  document.getElementById("intime5").value;
var sp_lit = schintime5.split(':'); 
var schintimehh5 = sp_lit[0];
var schintimemm5 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming5.value=0.0;
if ( parseInt(acth5) > parseInt(schintimehh5) )
{
         document.mydaa.latecoming5.value='33';   
}
if ( parseInt(acth5) ==  parseInt(schintimehh5)  && parseInt(actm5) >  parseInt(schintimemm5) )
{
         document.mydaa.latecoming5.value='33';   
}
}
function actchangefn6()
{
 var acth6 = document.getElementById("acthh6").value;
var actm6 = document.getElementById("actmm6").value;
 document.mydaa.acttime6.value= acth6+ ":"+actm6;
var schintime6 =  document.getElementById("intime6").value;
var sp_lit = schintime6.split(':'); 
var schintimehh6 = sp_lit[0];
var schintimemm6 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming6.value=0.0;
if ( parseInt(acth6) > parseInt(schintimehh6) )
{
         document.mydaa.latecoming6.value='33';   
}
if ( parseInt(acth6) ==  parseInt(schintimehh6)  && parseInt(actm6) >  parseInt(schintimemm6) )
{
         document.mydaa.latecoming6.value='33';   
}
}

function actchangefn7()
{
 var acth7 = document.getElementById("acthh7").value;
var actm7 = document.getElementById("actmm7").value;
 document.mydaa.acttime7.value= acth7+ ":"+actm7;
var schintime7 =  document.getElementById("intime7").value;
var sp_lit = schintime7.split(':'); 
var schintimehh7 = sp_lit[0];
var schintimemm7 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming7.value=0.0;
if ( parseInt(acth7) > parseInt(schintimehh7) )
{
         document.mydaa.latecoming7.value='33';   
}
if ( parseInt(acth7) ==  parseInt(schintimehh7)  && parseInt(actm7) >  parseInt(schintimemurm7) )
{
         document.mydaa.latecoming7.value='33';   
}
}

// 8 start

function actchangefn8()
{
 var acth8 = document.getElementById("acthh8").value;
var actm8 = document.getElementById("actmm8").value;
 document.mydaa.acttime8.value= acth8+ ":"+actm8;
var schintime8 =  document.getElementById("intime8").value;
var sp_lit = schintime8.split(':'); 
var schintimehh8 = sp_lit[0];
var schintimemm8 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming8.value=0.0;
if ( parseInt(acth8) > parseInt(schintimehh8) )
{
         document.mydaa.latecoming8.value='33';   
}
if ( parseInt(acth8) ==  parseInt(schintimehh8)  && parseInt(actm8) >  parseInt(schintimemm8) )
{
         document.mydaa.latecoming8.value='33';   
}
}

function actchangefn9()
{
 var acth9 = document.getElementById("acthh9").value;
var actm9 = document.getElementById("actmm9").value;
 document.mydaa.acttime9.value= acth9+ ":"+actm9;
var schintime9 =  document.getElementById("intime9").value;
var sp_lit = schintime9.split(':'); 
var schintimehh9= sp_lit[0];
var schintimemm9 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming9.value=0.0;
if ( parseInt(acth9) > parseInt(schintimehh9) )
{
         document.mydaa.latecoming9.value='33';   
}
if ( parseInt(acth9) ==  parseInt(schintimehh9)  && parseInt(actm9) >  parseInt(schintimemm9) )
{
         document.mydaa.latecoming9.value='33';   
}
}

function actchangefn10()
{
 var acth10 = document.getElementById("acthh10").value;
var actm10 = document.getElementById("actmm10").value;
 document.mydaa.acttime10.value= acth10+ ":"+actm10;
var schintime10 =  document.getElementById("intime10").value;
var sp_lit = schintime10.split(':'); 
var schintimehh10 = sp_lit[0];
var schintimemm10 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming10.value=0.0;
if ( parseInt(acth10) > parseInt(schintimehh10) )
{
         document.mydaa.latecoming10.value='33';   
}
if ( parseInt(acth10) ==  parseInt(schintimehh10)  && parseInt(actm10) >  parseInt(schintimemm10) )
{
         document.mydaa.latecoming10.value='33';   
}
}





// 10 end

function outchangefn1()
{ //  workduration1 ottime1 tottime1     "acthh1  actmm1"

// alert ("1 ");

   var od1 =   document.mydaa.outdate1_1.value;
   var od2 =   document.mydaa.outdate1_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate1_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

var outh1 = document.getElementById("outhh1").value;
var outm1 = document.getElementById("outmm1").value;
document.mydaa.actouttime1.value= outh1+ ":"+outm1;

var oldwduration1 = document.getElementById("workduration1").value;
var sp_lit1 = oldwduration1.split(':'); 
olddurhh1 = sp_lit1[0];
olddurmm1 = sp_lit1[1];

var wacthh1 = document.getElementById("acthh1").value;
var wactmm1 = document.getElementById("actmm1").value;
totoutmm1 = 0 ;
totactmm1 = 0 ;
//alert(outh1) + "out h1";
//alert(outm1) + "out m1";
//alert(wacthh1) + "act h1";
//alert(wactmm1) + "act m1";
if (wacthh1 == "0"  &&  wactmm1 == "0")
{
}
 else
  {
      if (outh1 == "0"  &&  outm1 == "0" )
     {
      }
    else
    {
      totoutmm1 = (parseInt(outh1) * 60) + parseInt(outm1) ;
      totactmm1 = (parseInt(wacthh1) * 60) + parseInt(wactmm1) ;
//alert (totoutmm1);
//alert(totactmm1);
     tottime = Math.abs(totoutmm1 - totactmm1);
//alert (tottime);
      wodur1 = Math.abs( ( totoutmm1 - totactmm1 )/60);
//alert(outm1);
//alert(wactmm1);
//alert (wodur1);
      wodurhh1  =Math.trunc(wodur1);
      wodurmm1 =  Math.abs(   tottime - (wodurhh1*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
//alert(wodurhh1);
//alert(wodurmm1);  // num.toString();
     document.mydaa.tottime1.value = wodurhh1.toString() +":"+   wodurmm1.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh1 >= olddurhh1  )
     {
              wothh1 = wodurhh1 - olddurhh1;
              wotmm1 = wodurmm1;
             document.mydaa.ottime1.value = wothh1.toString() +":"+   wotmm1.toString();
     }
     else
     {
         document.mydaa.workduration1.value = wodurhh1.toString() +":"+   wodurmm1.toString();
         document.mydaa.ottime1.value = "0:00";
     }
    // alert parseInt(outh1) * 60 ;
 //    alert parseInt(wacthh1) * 60 ;
      }
 }
//alert (totoutmm1);
//alert (totactmm1);
}
if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh1 = document.getElementById("outhh1").value;
var outm1 = document.getElementById("outmm1").value;
document.mydaa.actouttime1.value= outh1+ ":"+outm1;

var oldwduration1 = document.getElementById("workduration1").value;
var sp_lit1 = oldwduration1.split(':'); 
olddurhh1 = sp_lit1[0];
olddurmm1 = sp_lit1[1];

var wacthh1 = document.getElementById("acthh1").value;
var wactmm1 = document.getElementById("actmm1").value;
totoutmm1 = 0 ;
totactmm1 = 0 ;

//alert(outh1) + "out h1";  // 21
//alert(outm1) + "out m1";  // 15
//alert(wacthh1) + "act h1"; // 3
//alert(wactmm1) + "act m1"; // 0
if (wactmm1 == 0)  
{
       totoutmm1 = (parseInt(outh1) * 60) + parseInt(outm1) ;
      totactmm1 = (parseInt((24-wacthh1)) * 60) + parseInt(wactmm1) ;
}
else
{
       totoutmm1 = (parseInt(outh1) * 60) + parseInt(outm1) ;
      totactmm1 = (parseInt((23-wacthh1)) * 60) + parseInt((60-wactmm1)) ;
}
if (ndays >= 2 )
{
totoutmm1 =  totoutmm1 +  ((ndays-1)*24*60);
}
tottime = totoutmm1 + totactmm1;
wodur1 = Math.abs( ( totoutmm1 + totactmm1 )/60);
      wodurhh1  =Math.trunc(wodur1);
      wodurmm1 =  Math.abs(   tottime - (wodurhh1*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime1.value = wodurhh1.toString() +":"+   wodurmm1.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh1 >= olddurhh1  )
     {
              wothh1 = wodurhh1 - olddurhh1;
              wotmm1 = wodurmm1;
             document.mydaa.ottime1.value = wothh1.toString() +":"+   wotmm1.toString();
     }
     else
     {
         document.mydaa.workduration1.value = wodurhh1.toString() +":"+   wodurmm1.toString();
         document.mydaa.ottime1.value = "0:00";
     }

}


//alert ("1 e ");

}
function outchangefn2()
{  //  workduration2 ottime2 tottime2     "acthh2  actmm2"
//alert ("2 ");
   var od1 =   document.mydaa.outdate2_1.value;
   var od2 =   document.mydaa.outdate2_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate2_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal
 var outh2 = document.getElementById("outhh2").value;
var outm2 = document.getElementById("outmm2").value;
 document.mydaa.actouttime2.value= outh2+ ":"+outm2;

var oldwduration2 = document.getElementById("workduration2").value;
var sp_lit1 = oldwduration2.split(':'); 
olddurhh2 = sp_lit1[0];
olddurmm2 = sp_lit1[1];

var wacthh2 = document.getElementById("acthh2").value;
var wactmm2 = document.getElementById("actmm2").value;
totoutmm2 = 0 ;
totactmm2 = 0 ;
 
if (wacthh2 == "0"  &&  wactmm2 == "0")
{
}
 else
  {
      if (outh2 == "0"  &&  outm2 == "0" )
     {
      }
    else
    {
      totoutmm2 = (parseInt(outh2) * 60) + parseInt(outm2) ;
      totactmm2 = (parseInt(wacthh2) * 60) + parseInt(wactmm2) ;
 
     tottime = Math.abs(totoutmm2 - totactmm2);

      wodur2 = ( totoutmm2 - totactmm2 )/60;
 
      wodurhh2  =Math.trunc(wodur2);
      wodurmm2 = Math.abs(   tottime - (wodurhh2*60));    //  Math.abs( outm2 - wactmm2) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime2.value = wodurhh2.toString() +":"+   wodurmm2.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh2 >= olddurhh2  )
     {
              wothh2 = wodurhh2 - olddurhh2;
              wotmm2 = wodurmm2;
             document.mydaa.ottime2.value = wothh2.toString() +":"+   wotmm2.toString();
     }
     else
     {
         document.mydaa.workduration2.value = wodurhh2.toString() +":"+   wodurmm2.toString();
         document.mydaa.ottime2.value = "0:00";
     }

      }
 }
}


if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh2 = document.getElementById("outhh2").value;
var outm2 = document.getElementById("outmm2").value;
document.mydaa.actouttime2.value= outh2+ ":"+outm2;

var oldwduration2 = document.getElementById("workduration2").value;
var sp_lit1 = oldwduration2.split(':'); 
olddurhh2 = sp_lit1[0];
olddurmm2 = sp_lit1[1];

var wacthh2 = document.getElementById("acthh2").value;
var wactmm2 = document.getElementById("actmm2").value;
totoutmm2 = 0 ;
totactmm2 = 0 ;

//alert(outh1) + "out h1";  // 21
//alert(outm1) + "out m1";  // 15
//alert(wacthh1) + "act h1"; // 3
//alert(wactmm1) + "act m1"; // 0
if (wactmm2 == 0)  
{
       totoutmm2 = (parseInt(outh2) * 60) + parseInt(outm2) ;
      totactmm2 = (parseInt((24-wacthh2)) * 60) + parseInt(wactmm2) ;
}
else
{
       totoutmm2 = (parseInt(outh2) * 60) + parseInt(outm2) ;
      totactmm2 = (parseInt((23-wacthh2)) * 60) + parseInt((60-wactmm2)) ;
}
if (ndays >= 2 )
{
totoutmm2 =  totoutmm2 +  ((ndays-1)*24*60);
}
tottime = totoutmm2 + totactmm2;
wodur2 = Math.abs( ( totoutmm2 + totactmm2 )/60);
      wodurhh2  =Math.trunc(wodur2);
      wodurmm2 =  Math.abs(   tottime - (wodurhh2*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime2.value = wodurhh2.toString() +":"+   wodurmm2.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh2 >= olddurhh2  )
     {
              wothh2 = wodurhh2 - olddurhh2;
              wotmm2 = wodurmm2;
             document.mydaa.ottime2.value = wothh2.toString() +":"+   wotmm2.toString();
     }
     else
     {
         document.mydaa.workduration2.value = wodurhh2.toString() +":"+   wodurmm2.toString();
         document.mydaa.ottime2.value = "0:00";
     }

}
//alert ("2 e ");
}
function outchangefn3()
{  //  workduration3 ottime3     tottime3     acthh3      actmm3

//alert ("3 ");
   var od1 =   document.mydaa.outdate3_1.value;
   var od2 =   document.mydaa.outdate3_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate3_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal
 var outh3 = document.getElementById("outhh3").value;
var outm3 = document.getElementById("outmm3").value;
 document.mydaa.actouttime3.value= outh3+ ":"+outm3;


var oldwduration3 = document.getElementById("workduration3").value;
var sp_lit1 = oldwduration3.split(':'); 
olddurhh3 = sp_lit1[0];
olddurmm3 = sp_lit1[1];

var wacthh3 = document.getElementById("acthh3").value;
var wactmm3 = document.getElementById("actmm3").value;
totoutmm3 = 0 ;
totactmm3 = 0 ;
 
if (wacthh3 == "0"  &&  wactmm3 == "0")
{
}
 else
  {
      if (outh3 == "0"  &&  outm3 == "0" )
     {
      }
    else
    {
      totoutmm3 = (parseInt(outh3) * 60) + parseInt(outm3) ;
      totactmm3 = (parseInt(wacthh3) * 60) + parseInt(wactmm3) ;
 
     tottime = Math.abs(totoutmm3 - totactmm3);


      wodur3 = ( totoutmm3 - totactmm3 )/60;
 
      wodurhh3  =Math.trunc(wodur3);
      wodurmm3 =  Math.abs(   tottime - (wodurhh3*60));     // Math.abs( outm3 - wactmm3) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime3.value = wodurhh3.toString() +":"+   wodurmm3.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh3 >= olddurhh3  )
     {
              wothh3 = wodurhh3 - olddurhh3;
              wotmm3 = wodurmm3;
             document.mydaa.ottime3.value = wothh3.toString() +":"+   wotmm3.toString();
     }
     else
     {
         document.mydaa.workduration3.value = wodurhh3.toString() +":"+   wodurmm3.toString();
         document.mydaa.ottime3.value = "0:00";
     }

      }
 }
}


if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh3 = document.getElementById("outhh3").value;
var outm3 = document.getElementById("outmm3").value;
document.mydaa.actouttime3.value= outh3+ ":"+outm3;

var oldwduration3 = document.getElementById("workduration3").value;
var sp_lit1 = oldwduration3.split(':'); 
olddurhh3 = sp_lit1[0];
olddurmm3 = sp_lit1[1];

var wacthh3 = document.getElementById("acthh3").value;
var wactmm3 = document.getElementById("actmm3").value;
totoutmm3 = 0 ;
totactmm3 = 0 ;


if (wactmm3 == 0)  
{
       totoutmm3 = (parseInt(outh3) * 60) + parseInt(outm3) ;
      totactmm3 = (parseInt((24-wacthh3)) * 60) + parseInt(wactmm3) ;
}
else
{
       totoutmm3 = (parseInt(outh3) * 60) + parseInt(outm3) ;
      totactmm3 = (parseInt((23-wacthh3)) * 60) + parseInt((60-wactmm3)) ;
}
if (ndays >= 2 )
{
totoutmm3 =  totoutmm3 +  ((ndays-1)*24*60);
}
tottime = totoutmm3 + totactmm3;
wodur3 = Math.abs( ( totoutmm3 + totactmm3 )/60);
      wodurhh3  =Math.trunc(wodur3);
      wodurmm3 =  Math.abs(   tottime - (wodurhh3*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime3.value = wodurhh3.toString() +":"+   wodurmm3.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh3 >= olddurhh3  )
     {
              wothh3 = wodurhh3 - olddurhh3;
              wotmm3 = wodurmm3;
             document.mydaa.ottime3.value = wothh3.toString() +":"+   wotmm3.toString();
     }
     else
     {
         document.mydaa.workduration3.value = wodurhh3.toString() +":"+   wodurmm3.toString();
         document.mydaa.ottime3.value = "0:00";
     }

}


//alert ("3 e ");
}
function outchangefn4()
{  //  workduration4 ottime4     tottime4     acthh4      actmm4

//alert ("4 ");

   var od1 =   document.mydaa.outdate4_1.value;
   var od2 =   document.mydaa.outdate4_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate4_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal


 var outh4 = document.getElementById("outhh4").value;
var outm4 = document.getElementById("outmm4").value;
 document.mydaa.actouttime4.value= outh4+ ":"+outm4;

var oldwduration4 = document.getElementById("workduration4").value;
var sp_lit1 = oldwduration4.split(':'); 
olddurhh4 = sp_lit1[0];
olddurmm4 = sp_lit1[1];

var wacthh4 = document.getElementById("acthh4").value;
var wactmm4 = document.getElementById("actmm4").value;
totoutmm4 = 0 ;
totactmm4 = 0 ;
 
if (wacthh4 == "0"  &&  wactmm4 == "0")
{
}
 else
  {
      if (outh4 == "0"  &&  outm4 == "0" )
     {
      }
    else
    {
      totoutmm4 = (parseInt(outh4) * 60) + parseInt(outm4) ;
      totactmm4 = (parseInt(wacthh4) * 60) + parseInt(wactmm4) ;

     tottime = Math.abs(totoutmm4 - totactmm4);
 

      wodur4 = ( totoutmm4 - totactmm4 )/60;
 
      wodurhh4  =Math.trunc(wodur4);
      wodurmm4 =  Math.abs(   tottime - (wodurhh4*60));    //   Math.abs( outm4 - wactmm4) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime4.value = wodurhh4.toString() +":"+   wodurmm4.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh4 >= olddurhh4  )
     {
              wothh4 = wodurhh4 - olddurhh4;
              wotmm4 = wodurmm4;
             document.mydaa.ottime4.value = wothh4.toString() +":"+   wotmm4.toString();
     }
     else
     {
         document.mydaa.workduration4.value = wodurhh4.toString() +":"+   wodurmm4.toString();
         document.mydaa.ottime4.value = "0:00";
     }

      }
 }
}

if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh4 = document.getElementById("outhh4").value;
var outm4 = document.getElementById("outmm4").value;
document.mydaa.actouttime4.value= outh4+ ":"+outm4;

var oldwduration4 = document.getElementById("workduration4").value;
var sp_lit1 = oldwduration4.split(':'); 
olddurhh4 = sp_lit1[0];
olddurmm4 = sp_lit1[1];

var wacthh4 = document.getElementById("acthh4").value;
var wactmm4 = document.getElementById("actmm4").value;
totoutmm4 = 0 ;
totactmm4 = 0 ;


if (wactmm4 == 0)  
{
       totoutmm4 = (parseInt(outh4) * 60) + parseInt(outm4) ;
      totactmm4 = (parseInt((24-wacthh4)) * 60) + parseInt(wactmm4) ;
}
else
{
       totoutmm4 = (parseInt(outh4) * 60) + parseInt(outm4) ;
      totactmm4 = (parseInt((23-wacthh4)) * 60) + parseInt((60-wactmm4)) ;
}
if (ndays >= 2 )
{
totoutmm4 =  totoutmm4 +  ((ndays-1)*24*60);
}
tottime = totoutmm4 + totactmm4;
wodur4 = Math.abs( ( totoutmm4 + totactmm4 )/60);
      wodurhh4  =Math.trunc(wodur4);
      wodurmm4 =  Math.abs(   tottime - (wodurhh4*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime4.value = wodurhh4.toString() +":"+   wodurmm4.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh4 >= olddurhh4  )
     {
              wothh4 = wodurhh4 - olddurhh4;
              wotmm4 = wodurmm4;
             document.mydaa.ottime4.value = wothh4.toString() +":"+   wotmm4.toString();
     }
     else
     {
         document.mydaa.workduration4.value = wodurhh4.toString() +":"+   wodurmm4.toString();
         document.mydaa.ottime4.value = "0:00";
     }

}

//alert ("4 e ");

}
function outchangefn5()
{  //  workduration5 ottime5    tottime5     acthh5      actmm5

//alert ("5 ");
   var od1 =   document.mydaa.outdate5_1.value;
   var od2 =   document.mydaa.outdate5_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate5_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

 var outh5 = document.getElementById("outhh5").value;
var outm5 = document.getElementById("outmm5").value;
 document.mydaa.actouttime5.value= outh5+ ":"+outm5;


var oldwduration5 = document.getElementById("workduration5").value;
var sp_lit1 = oldwduration5.split(':'); 
olddurhh5 = sp_lit1[0];
olddurmm5 = sp_lit1[1];

var wacthh5 = document.getElementById("acthh5").value;
var wactmm5 = document.getElementById("actmm5").value;
totoutmm5 = 0 ;
totactmm5 = 0 ;
 
if (wacthh5 == "0"  &&  wactmm5 == "0")
{
}
 else
  {
      if (outh5 == "0"  &&  outm5 == "0" )
     {
      }
    else
    {
      totoutmm5 = (parseInt(outh5) * 60) + parseInt(outm5) ;
      totactmm5 = (parseInt(wacthh5) * 60) + parseInt(wactmm5) ;

     tottime = Math.abs(totoutmm5 - totactmm5);

      wodur5 = ( totoutmm5 - totactmm5 )/60;
 
      wodurhh5  =Math.trunc(wodur5);
      wodurmm5 = Math.abs(   tottime - (wodurhh5*60));  //  Math.abs( outm5 - wactmm5) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime5.value = wodurhh5.toString() +":"+   wodurmm5.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh5 >= olddurhh5  )
     {
              wothh5 = wodurhh5 - olddurhh5;
              wotmm5 = wodurmm5;
             document.mydaa.ottime5.value = wothh5.toString() +":"+   wotmm5.toString();
     }
     else
     {
         document.mydaa.workduration5.value = wodurhh5.toString() +":"+   wodurmm5.toString();
         document.mydaa.ottime5.value = "0:00";
     }

      }
 }

}


if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh5 = document.getElementById("outhh5").value;
var outm5 = document.getElementById("outmm5").value;
document.mydaa.actouttime5.value= outh5+ ":"+outm5;

var oldwduration5 = document.getElementById("workduration5").value;
var sp_lit1 = oldwduration5.split(':'); 
olddurhh5 = sp_lit1[0];
olddurmm5 = sp_lit1[1];

var wacthh5 = document.getElementById("acthh5").value;
var wactmm5 = document.getElementById("actmm5").value;
totoutmm5 = 0 ;
totactmm5 = 0 ;


if (wactmm5 == 0)  
{
       totoutmm5 = (parseInt(outh5) * 60) + parseInt(outm5) ;
      totactmm5 = (parseInt((24-wacthh5)) * 60) + parseInt(wactmm5) ;
}
else
{
       totoutmm5 = (parseInt(outh5) * 60) + parseInt(outm5) ;
      totactmm5 = (parseInt((23-wacthh5)) * 60) + parseInt((60-wactmm5)) ;
}
if (ndays >= 2 )
{
totoutmm5 =  totoutmm5 +  ((ndays-1)*24*60);
}
tottime = totoutmm5 + totactmm5;
wodur5 = Math.abs( ( totoutmm5 + totactmm5 )/60);
      wodurhh5  =Math.trunc(wodur5);
      wodurmm5 =  Math.abs(   tottime - (wodurhh5*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime5.value = wodurhh5.toString() +":"+   wodurmm5.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh5 >= olddurhh5  )
     {
              wothh5 = wodurhh5 - olddurhh5;
              wotmm5 = wodurmm5;
             document.mydaa.ottime5.value = wothh5.toString() +":"+   wotmm5.toString();
     }
     else
     {
         document.mydaa.workduration5.value = wodurhh5.toString() +":"+   wodurmm5.toString();
         document.mydaa.ottime5.value = "0:00";
     }

}

//alert ("5 e ");

}
function outchangefn6()
{   //  workduration6 ottime6    tottime6     acthh6      actmm6

//alert ("6 ");
   var od1 =   document.mydaa.outdate6_1.value;
   var od2 =   document.mydaa.outdate6_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate6_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal
 var outh6 = document.getElementById("outhh6").value;
var outm6 = document.getElementById("outmm6").value;
 document.mydaa.actouttime6.value= outh6+ ":"+outm6;


var oldwduration6 = document.getElementById("workduration6").value;
var sp_lit1 = oldwduration6.split(':'); 
olddurhh6 = sp_lit1[0];
olddurmm6 = sp_lit1[1];

var wacthh6 = document.getElementById("acthh6").value;
var wactmm6 = document.getElementById("actmm6").value;
totoutmm6 = 0 ;
totactmm6 = 0 ;
 
if (wacthh6 == "0"  &&  wactmm6 == "0")
{
}
 else
  {
      if (outh6 == "0"  &&  outm6 == "0" )
     {
      }
    else
    {
      totoutmm6 = (parseInt(outh6) * 60) + parseInt(outm6) ;
      totactmm6 = (parseInt(wacthh6) * 60) + parseInt(wactmm6) ;

      tottime = Math.abs(totoutmm6 - totactmm6);

 
      wodur6 = ( totoutmm6 - totactmm6 )/60;
 
      wodurhh6  =Math.trunc(wodur6);
      wodurmm6 =  Math.abs(   tottime - (wodurhh6*60));  //   Math.abs( outm6 - wactmm6) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime6.value = wodurhh6.toString() +":"+   wodurmm6.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh6 >= olddurhh6  )
     {
              wothh6 = wodurhh6 - olddurhh6;
              wotmm6 = wodurmm6;
             document.mydaa.ottime6.value = wothh6.toString() +":"+   wotmm6.toString();
     }
     else
     {
         document.mydaa.workduration6.value = wodurhh6.toString() +":"+   wodurmm6.toString();
         document.mydaa.ottime6.value = "0:00";
     }

      }
 }
}



if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh6 = document.getElementById("outhh6").value;
var outm6 = document.getElementById("outmm6").value;
document.mydaa.actouttime6.value= outh6+ ":"+outm6;

var oldwduration6 = document.getElementById("workduration6").value;
var sp_lit1 = oldwduration6.split(':'); 
olddurhh6 = sp_lit1[0];
olddurmm6 = sp_lit1[1];

var wacthh6 = document.getElementById("acthh6").value;
var wactmm6 = document.getElementById("actmm6").value;
totoutmm6 = 0 ;
totactmm6 = 0 ;

if (wactmm6 == 0)  
{
       totoutmm6 = (parseInt(outh6) * 60) + parseInt(outm6) ;
      totactmm6 = (parseInt((24-wacthh6)) * 60) + parseInt(wactmm6) ;
}
else
{
       totoutmm6 = (parseInt(outh6) * 60) + parseInt(outm6) ;
      totactmm6 = (parseInt((23-wacthh6)) * 60) + parseInt((60-wactmm6)) ;
}
if (ndays >= 2 )
{
totoutmm6 =  totoutmm6 +  ((ndays-1)*24*60);
}
tottime = totoutmm6 + totactmm6;
wodur6 = Math.abs( ( totoutmm6 + totactmm6 )/60);
      wodurhh6  =Math.trunc(wodur6);
      wodurmm6 =  Math.abs(   tottime - (wodurhh6*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime6.value = wodurhh6.toString() +":"+   wodurmm6.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh6 >= olddurhh6  )
     {
              wothh6 = wodurhh6 - olddurhh6;
              wotmm6 = wodurmm6;
             document.mydaa.ottime6.value = wothh6.toString() +":"+   wotmm6.toString();
     }
     else
     {
         document.mydaa.workduration6.value = wodurhh6.toString() +":"+   wodurmm6.toString();
         document.mydaa.ottime6.value = "0:00";
     }

}


//alert ("6 e ");

}

function outchangefn7()
{   //  workduration6 ottime6    tottime6     acthh6      actmm6

//alert ("7 ");
   var od1 =   document.mydaa.outdate7_1.value;
   var od2 =   document.mydaa.outdate7_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate7_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

 var outh7 = document.getElementById("outhh7").value;
var outm7 = document.getElementById("outmm7").value;
 document.mydaa.actouttime7.value= outh7+ ":"+outm7;


var oldwduration7 = document.getElementById("workduration7").value;
var sp_lit1 = oldwduration7.split(':'); 
olddurhh7 = sp_lit1[0];
olddurmm7 = sp_lit1[1];

var wacthh7 = document.getElementById("acthh7").value;
var wactmm7 = document.getElementById("actmm7").value;
totoutmm7 = 0 ;
totactmm7 = 0 ;
 
if (wacthh7 == "0"  &&  wactmm7 == "0")
{
}
 else
  {
      if (outh7 == "0"  &&  outm7 == "0" )
     {
      }
    else
    {
      totoutmm7 = (parseInt(outh7) * 60) + parseInt(outm7) ;
      totactmm7 = (parseInt(wacthh7) * 60) + parseInt(wactmm7) ;


     tottime = Math.abs(totoutmm7 - totactmm7);
 
      wodur7 = ( totoutmm7 - totactmm7 )/60;
 
      wodurhh7  =Math.trunc(wodur7);
      wodurmm7 =  Math.abs(   tottime - (wodurhh7*60));    // Math.abs( outm7 - wactmm7) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime7.value = wodurhh7.toString() +":"+   wodurmm7.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh7 >= olddurhh7  )
     {
              wothh7 = wodurhh7 - olddurhh7;
              wotmm7 = wodurmm7;
             document.mydaa.ottime7.value = wothh7.toString() +":"+   wotmm7.toString();
     }
     else
     {
         document.mydaa.workduration7.value = wodurhh7.toString() +":"+   wodurmm7.toString();
         document.mydaa.ottime7.value = "0:00";
     }

      }
 }
}


if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh7 = document.getElementById("outhh7").value;
var outm7 = document.getElementById("outmm7").value;
document.mydaa.actouttime7.value= outh7+ ":"+outm7;

var oldwduration7 = document.getElementById("workduration7").value;
var sp_lit1 = oldwduration7.split(':'); 
olddurhh7 = sp_lit1[0];
olddurmm7 = sp_lit1[1];

var wacthh7 = document.getElementById("acthh7").value;
var wactmm7 = document.getElementById("actmm7").value;
totoutmm7 = 0 ;
totactmm7 = 0 ;


if (wactmm7 == 0)  
{
       totoutmm7 = (parseInt(outh7) * 60) + parseInt(outm7) ;
      totactmm7 = (parseInt((24-wacthh7)) * 60) + parseInt(wactmm7) ;
}
else
{
       totoutmm7 = (parseInt(outh7) * 60) + parseInt(outm7) ;
      totactmm7 = (parseInt((23-wacthh7)) * 60) + parseInt((60-wactmm7)) ;
}
if (ndays >= 2 )
{
totoutmm7 =  totoutmm7 +  ((ndays-1)*24*60);
}
tottime = totoutmm7 + totactmm7;
wodur7 = Math.abs( ( totoutmm7 + totactmm7 )/60);
      wodurhh7  =Math.trunc(wodur7);
      wodurmm7 =  Math.abs(   tottime - (wodurhh7*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime7.value = wodurhh7.toString() +":"+   wodurmm7.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh7 >= olddurhh7 )
     {
              wothh7 = wodurhh7 - olddurhh7;
              wotmm7 = wodurmm7;
             document.mydaa.ottime7.value = wothh7.toString() +":"+   wotmm7.toString();
     }
     else
     {
         document.mydaa.workduration7.value = wodurhh7.toString() +":"+   wodurmm7.toString();
         document.mydaa.ottime7.value = "0:00";
     }

}

//alert ("7 e ");

}

// 8 start 

function outchangefn8()
{   //  workduration6 ottime6    tottime6     acthh6      actmm6

//alert ("8 ");

   var od1 =   document.mydaa.outdate8_1.value;
   var od2 =   document.mydaa.outdate8_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate8_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

 var outh8 = document.getElementById("outhh8").value;
var outm8 = document.getElementById("outmm8").value;
 document.mydaa.actouttime8.value= outh8+ ":"+outm8;


var oldwduration8 = document.getElementById("workduration8").value;
var sp_lit1 = oldwduration8.split(':'); 
olddurhh8 = sp_lit1[0];
olddurmm8 = sp_lit1[1];

var wacthh8 = document.getElementById("acthh8").value;
var wactmm8 = document.getElementById("actmm8").value;
totoutmm8 = 0 ;
totactmm8 = 0 ;
 
if (wacthh8 == "0"  &&  wactmm8 == "0")
{
}
 else
  {
      if (outh8 == "0"  &&  outm8 == "0" )
     {
      }
    else
    {
      totoutmm8 = (parseInt(outh8) * 60) + parseInt(outm8) ;
      totactmm8 = (parseInt(wacthh8) * 60) + parseInt(wactmm8) ;
 
       tottime = Math.abs(totoutmm8 - totactmm8);

      wodur8 = ( totoutmm8 - totactmm8 )/60;
 
      wodurhh8  =Math.trunc(wodur8);
      wodurmm8 =   Math.abs(   tottime - (wodurhh8*60));   //  Math.abs( outm8 - wactmm8) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime8.value = wodurhh8.toString() +":"+   wodurmm8.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh8 >= olddurhh8  )
     {
              wothh8 = wodurhh8 - olddurhh8;
              wotmm8 = wodurmm8;
             document.mydaa.ottime8.value = wothh8.toString() +":"+   wotmm8.toString();
     }
     else
     {
         document.mydaa.workduration8.value = wodurhh8.toString() +":"+   wodurmm8.toString();
         document.mydaa.ottime8.value = "0:00";
     }

      }
 }
}


if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh8 = document.getElementById("outhh8").value;
var outm8 = document.getElementById("outmm8").value;
document.mydaa.actouttime8.value= outh8+ ":"+outm8;

var oldwduration8 = document.getElementById("workduration8").value;
var sp_lit1 = oldwduration8.split(':'); 
olddurhh8 = sp_lit1[0];
olddurmm8 = sp_lit1[1];

var wacthh8 = document.getElementById("acthh8").value;
var wactmm8 = document.getElementById("actmm8").value;
totoutmm8 = 0 ;
totactmm8 = 0 ;


if (wactmm8 == 0)  
{
       totoutmm8 = (parseInt(outh8) * 60) + parseInt(outm8) ;
      totactmm8 = (parseInt((24-wacthh8)) * 60) + parseInt(wactmm8) ;
}
else
{
       totoutmm8 = (parseInt(outh8) * 60) + parseInt(outm8) ;
      totactmm8 = (parseInt((23-wacthh8)) * 60) + parseInt((60-wactmm8)) ;
}
if (ndays >= 2 )
{
totoutmm8 =  totoutmm8 +  ((ndays-1)*24*60);
}
tottime = totoutmm8 + totactmm8;
wodur8 = Math.abs( ( totoutmm8 + totactmm8 )/60);
      wodurhh8  =Math.trunc(wodur8);
      wodurmm8 =  Math.abs(   tottime - (wodurhh8*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime8.value = wodurhh8.toString() +":"+   wodurmm8.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh8 >= olddurhh8  )
     {
              wothh8 = wodurhh8 - olddurhh8;
              wotmm8 = wodurmm8;
             document.mydaa.ottime8.value = wothh8.toString() +":"+   wotmm8.toString();
     }
     else
     {
         document.mydaa.workduration8.value = wodurhh8.toString() +":"+   wodurmm8.toString();
         document.mydaa.ottime8.value = "0:00";
     }

}

//alert ("8 e ");

}

function outchangefn9() // to change
{   //  workduration6 ottime6    tottime6     acthh6      actmm6

//alert ("9 ");

   var od1 =   document.mydaa.outdate9_1.value;
   var od2 =   document.mydaa.outdate9_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate9_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

 var outh9 = document.getElementById("outhh9").value;
var outm9 = document.getElementById("outmm9").value;
 document.mydaa.actouttime9.value= outh9+ ":"+outm9;


var oldwduration9 = document.getElementById("workduration9").value;
var sp_lit1 = oldwduration9.split(':'); 
olddurhh9 = sp_lit1[0];
olddurmm9 = sp_lit1[1];

var wacthh9 = document.getElementById("acthh9").value;
var wactmm9= document.getElementById("actmm9").value;
totoutmm9 = 0 ;
totactmm9 = 0 ;
 
if (wacthh9 == "0"  &&  wactmm9 == "0")
{
}
 else
  {
      if (outh9== "0"  &&  outm9 == "0" )
     {
      }
    else
    {
      totoutmm9 = (parseInt(outh9) * 60) + parseInt(outm9) ;
      totactmm9 = (parseInt(wacthh9) * 60) + parseInt(wactmm9) ;

     tottime = Math.abs(totoutmm9 - totactmm9);

 
      wodur9 = ( totoutmm9 - totactmm9 )/60;
 
      wodurhh9 =Math.trunc(wodur9);  // GOLE
      wodurmm9 =  Math.abs(   tottime - (wodurhh9*60));   //  Math.abs( outm9 - wactmm9) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime9.value = wodurhh9.toString() +":"+   wodurmm9.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh9 >= olddurhh9  )
     {
              wothh9 = wodurhh9 - olddurhh9;
              wotmm9 = wodurmm9;
             document.mydaa.ottime9.value = wothh9.toString() +":"+   wotmm9.toString();
     }
     else
     {
         document.mydaa.workduration9.value = wodurhh9.toString() +":"+   wodurmm9.toString();
         document.mydaa.ottime9.value = "0:00";
     }

      }
 }

}
if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh9 = document.getElementById("outhh9").value;
var outm9 = document.getElementById("outmm9").value;
document.mydaa.actouttime9.value= outh9+ ":"+outm9;

var oldwduration9 = document.getElementById("workduration9").value;
var sp_lit1 = oldwduration9.split(':'); 
olddurhh9 = sp_lit1[0];
olddurmm9 = sp_lit1[1];

var wacthh9 = document.getElementById("acthh9").value;
var wactmm9 = document.getElementById("actmm9").value;
totoutmm9 = 0 ;
totactmm9 = 0 ;


if (wactmm9 == 0)  
{
       totoutmm9 = (parseInt(outh9) * 60) + parseInt(outm9) ;
      totactmm9 = (parseInt((24-wacthh9)) * 60) + parseInt(wactmm9) ;
}
else
{
       totoutmm9 = (parseInt(outh9) * 60) + parseInt(outm9) ;
      totactmm9 = (parseInt((23-wacthh9)) * 60) + parseInt((60-wactmm9)) ;
}
if (ndays >= 2 )
{
totoutmm9 =  totoutmm9 +  ((ndays-1)*24*60);
}
tottime = totoutmm9 + totactmm9;
wodur9 = Math.abs( ( totoutmm9 + totactmm9 )/60);
      wodurhh9  =Math.trunc(wodur9);
      wodurmm9 =  Math.abs(   tottime - (wodurhh9*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime9.value = wodurhh9.toString() +":"+   wodurmm9.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh9 >= olddurhh9 )
     {
              wothh9 = wodurhh9 - olddurhh9;
              wotmm9 = wodurmm9;
             document.mydaa.ottime9.value = wothh9.toString() +":"+   wotmm9.toString();
     }
     else
     {
         document.mydaa.workduration9.value = wodurhh9.toString() +":"+   wodurmm9.toString();
         document.mydaa.ottime9.value = "0:00";
     }
}
//alert("9 e");
}


function outchangefn10() // to change
{   //  workduration6 ottime6    tottime6     acthh6      actmm6

//alert("10");
   var od1 =   document.mydaa.outdate10_1.value;
   var od2 =   document.mydaa.outdate10_2.value;
if (od2 <od1 )
{
     document.getElementById("outdate10_2").value = od1;
}

// alert ("here");
var nod1 = new Date(od1);
var nod2 = new Date(od2)
var ndays = parseInt((nod2 - nod1) / (1000 * 60 * 60 * 24), 10); 
//alert (ndays);
if (ndays == 0)
{ // dates are equal

 var outh10 = document.getElementById("outhh10").value;
var outm10 = document.getElementById("outmm10").value;
 document.mydaa.actouttime10.value= outh10+ ":"+outm10;


var oldwduration10 = document.getElementById("workduration10").value;
var sp_lit1 = oldwduration10.split(':'); 
olddurhh10 = sp_lit1[0];
olddurmm10 = sp_lit1[1];

var wacthh10= document.getElementById("acthh10").value;
var wactmm10= document.getElementById("actmm10").value;
totoutmm10 = 0 ;
totactmm10 = 0 ;
 
if (wacthh10 == "0"  &&  wactmm10 == "0")
{
}
 else
  {
      if (outh10== "0"  &&  outm10 == "0" )
     {
      }
    else
    {
      totoutmm10 = (parseInt(outh10) * 60) + parseInt(outm10) ;
      totactmm10 = (parseInt(wacthh10) * 60) + parseInt(wactmm10) ;
 
    tottime = Math.abs(totoutmm10 - totactmm10);


      wodur10 = ( totoutmm10 - totactmm10 )/60;
 
      wodurhh10 =Math.trunc(wodur10);
      wodurmm10 =   Math.abs(   tottime - (wodurhh10*60)); //    Math.abs( outm10 - wactmm10) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime10.value = wodurhh10.toString() +":"+   wodurmm10.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh10 >= olddurhh10  )
     {
              wothh10 = wodurhh10 - olddurhh10;
              wotmm10 = wodurmm10;
             document.mydaa.ottime10.value = wothh10.toString() +":"+   wotmm10.toString();
     }
     else
     {
         document.mydaa.workduration10.value = wodurhh10.toString() +":"+   wodurmm10.toString();
         document.mydaa.ottime10.value = "0:00";
     }

      }
 }
}
if (ndays >= 1 )
{ // days diff is 1 day
  //  alert ("days diff 1 day");

var outh10 = document.getElementById("outhh10").value;
var outm10 = document.getElementById("outmm10").value;
document.mydaa.actouttime10.value= outh10+ ":"+outm10;

var oldwduration10 = document.getElementById("workduration10").value;
var sp_lit1 = oldwduration10.split(':'); 
olddurhh10 = sp_lit1[0];
olddurmm10 = sp_lit1[1];

var wacthh10 = document.getElementById("acthh10").value;
var wactmm10 = document.getElementById("actmm10").value;
totoutmm10 = 0 ;
totactmm10 = 0 ;


if (wactmm10 == 0)  
{
       totoutmm10 = (parseInt(outh10) * 60) + parseInt(outm10) ;
      totactmm10 = (parseInt((24-wacthh10)) * 60) + parseInt(wactmm10) ;
}
else
{
       totoutmm10 = (parseInt(outh10) * 60) + parseInt(outm10) ;
      totactmm10 = (parseInt((23-wacthh10)) * 60) + parseInt((60-wactmm10)) ;
}
if (ndays >= 2 )
{
totoutmm10 =  totoutmm10 +  ((ndays-1)*24*60);
}
tottime = totoutmm10 + totactmm10;
wodur10 = Math.abs( ( totoutmm10 + totactmm10 )/60);
      wodurhh10  =Math.trunc(wodur10);
      wodurmm10 =  Math.abs(   tottime - (wodurhh10*60));     //    Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
     document.mydaa.tottime10.value = wodurhh10.toString() +":"+   wodurmm10.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh10 >= olddurhh10  )
     {
              wothh10 = wodurhh10 - olddurhh10;
              wotmm10 = wodurmm10;
             document.mydaa.ottime10.value = wothh10.toString() +":"+   wotmm10.toString();
     }
     else
     {
         document.mydaa.workduration10.value = wodurhh10.toString() +":"+   wodurmm10.toString();
         document.mydaa.ottime10.value = "0:00";
     }

}
//alert ("10ne");
}






// 10 end


function rtchangefn1()
{
// alert("h");
 var rth1 = document.getElementById("rthh1").value;
var rtm1 = document.getElementById("rtmm1").value;
 document.mydaa.reporttime1.value= rth1+ ":"+rtm1;
}
function rtchangefn2()
{
// alert("h");
 var rth2 = document.getElementById("rthh2").value;
var rtm2 = document.getElementById("rtmm2").value;
 document.mydaa.reporttime2.value= rth2+ ":"+rtm2;
}
function rtchangefn3()
{
// alert("h");
 var rth3 = document.getElementById("rthh3").value;
var rtm3 = document.getElementById("rtmm3").value;
 document.mydaa.reporttime3.value= rth3+ ":"+rtm3;
}
function rtchangefn4()
{
// alert("h");
var rth4 =  document.getElementById("rthh4").value;
var rtm4 = document.getElementById("rtmm4").value;
 document.mydaa.reporttime4.value= rth4+ ":"+rtm4;
}
function rtchangefn5()
{
// alert("h");
var rth5 =  document.getElementById("rthh5").value;
var rtm5 = document.getElementById("rtmm5").value;
 document.mydaa.reporttime5.value= rth5+ ":"+rtm5;
}
function rtchangefn6()
{
// alert("h");
var rth6 =  document.getElementById("rthh6").value;
var rtm6 = document.getElementById("rtmm6").value;
 document.mydaa.reporttime6.value= rth6+ ":"+rtm6;
}

function rtchangefn7()
{
// alert("h");
var rth7 =  document.getElementById("rthh7").value;
var rtm7 = document.getElementById("rtmm7").value;
 document.mydaa.reporttime7.value= rth7+ ":"+rtm7;
}


function rtchangefn8()
{
// alert("h");

var rth8 =  document.getElementById("rthh8").value;
var rtm8 = document.getElementById("rtmm8").value;
 document.mydaa.reporttime8.value= rth8+ ":"+rtm8;
}
function rtchangefn9()
{
// alert("h");
var rth9 =  document.getElementById("rthh9").value;
var rtm9 = document.getElementById("rtmm9").value;
 document.mydaa.reporttime9.value= rth9+ ":"+rtm9;
 
}
function rtchangefn10()
{
// alert("h");
var rth10 =  document.getElementById("rthh10").value;
var rtm10= document.getElementById("rtmm10").value;
 document.mydaa.reporttime10.value= rth10+ ":"+rtm10;
}



</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
 
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
 
@media screen and (max-height: 400px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttonsmall {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 9px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
 <style>
   body{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
   }
   div{
      overflow-x: auto;
   }
   table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid rgb(0, 0, 0);
   }
   th, td {
      text-align: left;
      padding: 8px;
   }
   tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/DaaEntry_delete"; ?>'>Delete Entries on Date/Employee</a> 
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/daareports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>admin</a>


</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:15px;cursor:pointer;color="black">Daily Attendence Register </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>

<a  href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>Back</a>
 

<!--   <form  name="mydaa" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> -->
  <?php
/* echo form_open('Home_AutoRenta/new_user_registration');  */

 $attributes = array('id' => 'mydaa' ,'name' =>'mydaa');
echo form_open('Home_AutoRenta/new_drr_registration/'. $data_12, $attributes);



    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
   <?php
    if  ($data_12=="DATE")
    {
    ?>
     <tr> 
           <td><span style="font-size:14px;cursor:pointer;color="black">Enter Date: </td>
          <td> <span style="font-size:14px;cursor:pointer;color="black"><input type="date" name="regdate" id="regdate" onchange="dtchangefn1()" value="<?php echo date('Y-m-d');?>" /> <br>
                   <?php
                        $sql11 ="SELECT * FROM emptable order by name "  ; 
                       $query11 = $this->db->query($sql11);   
                   ?>
                      <select name="empidbase" id = "empidbase" hidden onchange="empidbasechangefn(this)"  style="width:180px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($query11->result() as $row11) 
                         { 
                         echo "<option value=". $row11->ecode . ">" .   $row11->name  . "</option>";
                          }  ?>  
                      </select> 
          </td>
     </tr>
    <?php
     } 
    else
    {

                 $empname1= "";
                 $sql11 ="SELECT * FROM emptable order by name "  ; 
                 $query11 = $this->db->query($sql11);   
    ?>
     <tr> 
           <td><span style="font-size:14px;cursor:pointer;color="black">Enter Name: </td>
          <td> <span style="font-size:14px;cursor:pointer;color="black">
                      <select name="empidbase" id = "empidbase" onchange="empidbasechangefn(this)"  style="width:180px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($query11->result() as $row11) 
                         { 
                         echo "<option value=". $row11->ecode . ">" .   $row11->name  . "</option>";
                          }  ?>  
                      </select>  <br>
                    <input type="date" name="regdate" hidden id="regdate" onchange="dtchangefn1()" value="<?php echo date('Y-m-d');?>" /> </td>
     </tr>
    <?php
    }
   ?>
   <table>
   <br>
   <table width="100%" border="1">  
        <tr>  
        <?php
               if  ($data_12=="DATE")
              { ?>    
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   Emp Name </td>
               <?php
              }
              else
              { ?>
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   Emp Name  <br> Date </td>
               <?php
               } ?>
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   P/A</td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black">   Duty </td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>  <!-- Shift -->
             <td>  <span style="font-size:12px;cursor:pointer;color="black"> Customer <br> Passenger </td>
 <!--           <td>  <span style="font-size:12px;cursor:pointer;color="black"> Passenger <br> Name</td> -->
        <td >  <span style="font-size:12px;cursor:pointer;width:100px;color="black">   </td>  <!-- reporting time -->
             <td>  <span style="font-size:12px;cursor:pointer;color="black">  In/<br>Actual Time </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  Out/<br>Actual Time </td>
           <td>  <span style="font-size:12px;cursor:pointer;color="black">  work <br>Duration </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  OT Time </td>
         <td>  <span style="font-size:12px;cursor:pointer;color="black"> Total <br> Duration </td>
<!--        <td>  <span style="font-size:12px;cursor:pointer;color="black">  Status </td> -->
        <td>  <span style="font-size:12px;cursor:pointer;color="black"> Remarks </td>
        <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>
       <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>
         </tr>
         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <select name="empid1" id = "empid1" onchange="empchangefn1()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data as $data) { 
                         echo "<option value=". $data->ecode ."~".  $data->shift . "~" .  $data->intime . "~" . $data->outtime . "~" . $data->tottime . "~" . $data->basicsal. ">" .   $data->name  . "</option>";
                          }  ?>  
                      </select> 
                      <?php
                      }
                      else
                       { ?>

                      <select name="empid1_1" id = "empid1_1"  disabled="true" onchange="empchangefn1()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data as $data)
                         { 
                         echo "<option value=". $data->ecode ."~".  $data->shift . "~" .  $data->intime . "~" . $data->outtime . "~" . $data->tottime . "~" . $data->basicsal. ">" .   $data->name  . "</option>";
                          }  ?>  
                      </select> 

                      <br>
                       <input type="text" readonly  hidden name="empid1" id="empid1"   /> 
                      <br>
                       <input type="date" name="regdate1" id="regdate1"   onchange="regdatechangefn1()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                      <br>
                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <input type="text" readonly   name="empid1name" id="empid1name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid1name" id="empid1name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td> 
              <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid1" id = "presentid1"   onchange="presenteefn1()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';             
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                        ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid1" id = "dutyid1" onBlur="dutychangefn1()"  style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate1_1"    id="outdate1_1"  value="<?php echo date('Y-m-d');?>"/> &nbsp; &nbsp;
                      <input type="date" name="outdate1_2"     id="outdate1_2"  onBlur="chkoutdatefn1()" value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td> 


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid1" id = "shiftid1"  hidden  style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid1" id = "custid1" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_1 as $data2_1) { 
                         echo "<option value=". $data2_1->id . ">" .   $data2_1->name  . "</option>";
                          }  ?>  
                      </select>  <br>
                     <input type="text" name="pass1" id="pass1" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass1" id="pass1" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td >
                    <span style="font-size:12px;cursor:pointer;color="black"> 

                     <input type="text"   hidden  name="reporttime1" id="reporttime1"  readonly   value="" style="font-size:12px;width:80px;" >
  
                 <select name="rthh1" id="rthh1" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm1" onchange="rtchangefn1()" id="rtmm1" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                    </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime1" id="intime1" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime1" id="acttime1" readonly  value="" style="font-size:12px;width:80px;" >
                <select name="acthh1"   id="acthh1">   <!--   onfocus onblur  onclick="selectsevenhh1()" -->
                    <option value="0">HH</option> 
                    <?php 
       /*                      for ($x = 0; $x <= 24; $x++) {
                                                 echo "<option value=". $x . ">" .  $x  . "</option>";
                              } */
                     echo '<option value="0">0</option>';
                     echo '<option value="1">1</option>';
                      echo '<option value="2">2</option>';           
                      echo '<option value="3">3</option>';
                      echo '<option value="4">4</option>'; 
                      echo '<option value="5">5</option>'; 

                      echo '<option value="6">6</option>'; 
                      echo '<option value="7">7</option>'; 
                      echo '<option value="8">8</option>'; 
                      echo '<option value="9">9</option>'; 
                      echo '<option value="10">10</option>'; 
                      echo '<option value="11">11</option>'; 
                      echo '<option value="12">12</option>'; 
                      echo '<option value="13">13</option>'; 
                      echo '<option value="14">14</option>'; 
                      echo '<option value="15">15</option>'; 
                      echo '<option value="16">16</option>'; 
                      echo '<option value="17">17</option>'; 
                      echo '<option value="18">18</option>'; 
                      echo '<option value="19">19</option>'; 
                      echo '<option value="20">20</option>'; 
                      echo '<option value="21">21</option>'; 
                      echo '<option value="22">22</option>'; 
                      echo '<option value="23">23</option>'; 
                      echo '<option value="24">24</option>';  

                     ?>
                    </select>
      
                   <select name="actmm1" onchange="actchangefn1()" id="actmm1">
                     <option value="0">MM</option>
                    <?php 
   /*
                              for ($x = 0; $x <= 61; $x=$x+15) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                     echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                        ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime1" id="outtime1" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime1" id="actouttime1" readonly  value="" style="font-size:12px;width:80px;" >
                   <select name="outhh1" id="outhh1">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm1" onchange="outchangefn1()" id="outmm1">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 61; $x=$x+15) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration1" id="workduration1" value="" style="font-size:12px;width:30px;" > 
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime1" id="ottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime1" id="tottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status1" id="status1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks1" id="remarks1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal1" id="basicsal1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="latecoming1"  hidden  id="latecoming1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>

           </tr>
<!-- line 2 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <select name="empid2" id = "empid2" onchange="empchangefn2()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_2 as $data_2) { 
                         echo "<option value=". $data_2->ecode ."~".  $data_2->shift . "~" .  $data_2->intime . "~" . $data_2->outtime . "~" . $data_2->tottime . "~" . $data_2->basicsal. ">" .   $data_2->name  . "</option>";
                          }  ?>  
                      </select> 
                      <?php
                      }
                      else
                       { ?>
                      <select name="empid2_1" id = "empid2_1"  disabled="true"  onchange="empchangefn2()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_2 as $data_2) { 
                         echo "<option value=". $data_2->ecode ."~".  $data_2->shift . "~" .  $data_2->intime . "~" . $data_2->outtime . "~" . $data_2->tottime . "~" . $data_2->basicsal. ">" .   $data_2->name  . "</option>";
                          }  ?>  
                      </select> 
                       <br>
                     <input type="text" readonly  hidden name="empid2" id="empid2"   /> 
                    <br>
                     <input type="date" name="regdate2" id="regdate2"   onchange="regdatechangefn2()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                      <br>
                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <input type="text" readonly name="empid2name"  id="empid2name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" >
                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid2name" id="empid2name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td> 

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid2" id = "presentid2" onchange="presenteefn2()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid2" id = "dutyid2" onchange="dutychangefn2()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate2_1"   id="outdate2_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp;
                      <input type="date" name="outdate2_2"  onBlur="chkoutdatefn2()"  id="outdate2_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>


               <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid2" id = "shiftid2"   hidden  style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid2" id = "custid2" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_2 as $data2_2) { 
                         echo "<option value=". $data2_2->id . ">" .   $data2_2->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass2" id="pass2" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass2" id="pass2" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime2" id="reporttime2" hidden readonly value="" style="font-size:12px;width:80px;" >

                 <select name="rthh2" id="rthh2" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm2" onchange="rtchangefn2()" id="rtmm2" hidden >
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime2" id="intime2" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime2" id="acttime2" value="" readonly style="font-size:12px;width:80px;" >
               <select name="acthh2" id="acthh2">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm2" onchange="actchangefn2()" id="actmm2">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime2" id="outtime2" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime2" id="actouttime2" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh2" id="outhh2">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm2" onchange="outchangefn2()" id="outmm2">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration2" id="workduration2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime2" id="ottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime2" id="tottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status2" id="status2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks2" id="remarks2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal2" id="basicsal2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming2"  id="latecoming2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>
    

<!-- line 3 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                     <?php
                       if ($data_12=="DATE")
                      { ?>

                      <select name="empid3" id = "empid3" onchange="empchangefn3()"   style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_3 as $data_3) 
                       { 
                         echo "<option value=". $data_3->ecode ."~".  $data_3->shift . "~" .  $data_3->intime . "~" . $data_3->outtime . "~" . $data_3->tottime . "~" . $data_3->basicsal. ">" .   $data_3->name  . "</option>";
                          }  ?>  
                      </select> 
                      <?php
                      }
                      else
                       { ?>
 
                      <select name="empid3_1" id = "empid3_1"  disabled="true" onchange="empchangefn3()"   style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_3 as $data_3) 
                       { 
                         echo "<option value=". $data_3->ecode ."~".  $data_3->shift . "~" .  $data_3->intime . "~" . $data_3->outtime . "~" . $data_3->tottime . "~" . $data_3->basicsal. ">" .   $data_3->name  . "</option>";
                          }  ?>  
                      </select> 
                      <br>
                       <input type="text" readonly  hidden name="empid3" id="empid3"   /> 
                      <br>
                       <input type="date" name="regdate3" id="regdate3"   onchange="regdatechangefn3()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>

                      <br>
                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <input type="text" readonly name="empid3name" id="empid3name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"   style="width:150px;" value="" >
                     <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid3name" id="empid3name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid3" id = "presentid3" onchange="presenteefn3()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid3" id = "dutyid3" onchange="dutychangefn3()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate3_1"   id="outdate3_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp;
                      <input type="date" name="outdate3_2" onBlur="chkoutdatefn3()"     id="outdate3_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td> 
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid3" id = "shiftid3"  hidden   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid3" id = "custid3" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_3 as $data2_3) { 
                         echo "<option value=". $data2_3->id . ">" .   $data2_3->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass3" id="pass3" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass3" id="pass3" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime3" id="reporttime3" hidden  readonly value="" style="font-size:12px;width:80px;" >

                 <select name="rthh3" id="rthh3" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm3" onchange="rtchangefn3()" id="rtmm3" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime3" id="intime3" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime3" id="acttime3"  readonly value="" style="font-size:12px;width:80px;" >
                   <select name="acthh3" id="acthh3">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm3" onchange="actchangefn3()" id="actmm3">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime3" id="outtime3" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime3" id="actouttime3" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh3" id="outhh3">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm3" onchange="outchangefn3()" id="outmm3">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration3" id="workduration3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime3" id="ottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime3" id="tottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status3" id="status3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks3" id="remarks3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal3" id="basicsal3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming3" id="latecoming3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>


<!-- line 4 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black">

                      <?php
                       if ($data_12=="DATE")
                      { ?>
 
                      <select name="empid4" id = "empid4"  onchange="empchangefn4()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_4 as $data_4)
                       { 
                         echo "<option value=". $data_4->ecode ."~".  $data_4->shift . "~" .  $data_4->intime . "~" . $data_4->outtime . "~" . $data_4->tottime . "~" . $data_4->basicsal. ">" .   $data_4->name  . "</option>";
                          }  ?>  
                      </select>  

                      <?php
                      }
                      else
                       { ?>

                      <select name="empid4_1" id = "empid4_1"  disabled="true"  onchange="empchangefn4()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_4 as $data_4)
                       { 
                         echo "<option value=". $data_4->ecode ."~".  $data_4->shift . "~" .  $data_4->intime . "~" . $data_4->outtime . "~" . $data_4->tottime . "~" . $data_4->basicsal. ">" .   $data_4->name  . "</option>";
                          }  ?>  
                      </select>  

                      <br>
                       <input type="text" readonly  hidden name="empid4" id="empid4"   /> 

                       <br>
                       <input type="date" name="regdate4" id="regdate4"   onchange="regdatechangefn4()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                      <br>


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <input type="text" readonly name="empid4name" id="empid4name"  style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"   style="width:150px;" value="" >
                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid4name" id="empid4name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid4" id = "presentid4" onchange="presenteefn4()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid4" id = "dutyid4" onchange="dutychangefn4()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate4_1"   id="outdate4_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate4_2"  onBlur="chkoutdatefn4()"   id="outdate4_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid4" id = "shiftid4"   hidden  style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid4" id = "custid4" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_4 as $data2_4) { 
                         echo "<option value=". $data2_4->id . ">" .   $data2_4->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass4" id="pass4" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass4" id="pass4" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime4" id="reporttime4"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh4" id="rthh4" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm4" onchange="rtchangefn4()" id="rtmm4" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime4" id="intime4" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime4" id="acttime4" value="" readonly style="font-size:12px;width:80px;" >
               <select name="acthh4" id="acthh4">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm4" onchange="actchangefn4()" id="actmm4">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime4" id="outtime4" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime4" id="actouttime4" readonly value="" style="font-size:12px;width:80px;" >
                    <select name="outhh4" id="outhh4">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm4" onchange="outchangefn4()" id="outmm4">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration4" id="workduration4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime4" id="ottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime4" id="tottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status4" id="status4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks4" id="remarks4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal4" id="basicsal4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming4" id="latecoming4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 5 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 


                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <select name="empid5" id = "empid5" onchange="empchangefn5()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_5 as $data_5) 
                        { 
                          echo "<option value=". $data_5->ecode ."~".  $data_5->shift . "~" .  $data_5->intime . "~" . $data_5->outtime . "~" . $data_5->tottime . "~" . $data_5->basicsal. ">" .   $data_5->name  . "</option>";
                          }  ?>  
                      </select>  

                      <?php
                      }
                      else
                       { ?>

                      <select name="empid5_1" id = "empid5_1"  disabled="true" onchange="empchangefn5()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_5 as $data_5) 
                        { 
                          echo "<option value=". $data_5->ecode ."~".  $data_5->shift . "~" .  $data_5->intime . "~" . $data_5->outtime . "~" . $data_5->tottime . "~" . $data_5->basicsal. ">" .   $data_5->name  . "</option>";
                          }  ?>  
                      </select>  


                      <br>
                       <input type="text" readonly  hidden name="empid5" id="empid5"   /> 
                      <br>
                       <input type="date" name="regdate5" id="regdate5"   onchange="regdatechangefn5()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>

                      <br>


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <input type="text" readonly name="empid5name" id="empid5name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" >
                     <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid5name" id="empid5name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid5" id = "presentid5" onchange="presenteefn5()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                          echo '<option value="PP">PRESENT</option>';                          
                          echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                          echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid5" id = "dutyid5" onchange="dutychangefn5()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date"  name="outdate5_1"   id="outdate5_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate5_2"  onBlur="chkoutdatefn5()"   id="outdate5_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid5" id = "shiftid5"   hidden   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid5" id = "custid5" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_5 as $data2_5) { 
                         echo "<option value=". $data2_5->id . ">" .   $data2_5->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass5 id="pass5" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass5 id="pass5" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime5" id="reporttime5" hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh5" id="rthh5" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm5" onchange="rtchangefn5()" hidden  id="rtmm5">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime5" id="intime5" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime5" id="acttime5" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="acthh5" id="acthh5">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm5" onchange="actchangefn5()" id="actmm5">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime5" id="outtime5" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime5" id="actouttime5"  readonly value="" style="font-size:12px;width:80px;" >
                    <select name="outhh5" id="outhh5">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm5" onchange="outchangefn5()" id="outmm5">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration5" id="workduration5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime5" id="ottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime5" id="tottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status5" id="status5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks5" id="remarks5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal5" id="basicsal5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming5" id="latecoming5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 6 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 

                     <?php
                       if ($data_12=="DATE")
                      { ?>
 
                      <select name="empid6" id = "empid6" onchange="empchangefn6()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_6 as $data_6) 
                        { 
                         echo "<option value=". $data_6->ecode ."~".  $data_6->shift . "~" .  $data_6->intime . "~" . $data_6->outtime . "~" . $data_6->tottime . "~" . $data_6->basicsal. ">" .   $data_6->name  . "</option>";
                          }  ?>  
                      </select> 


                      <?php
                      }
                      else
                       { ?>
                      <select name="empid6_1" id = "empid6_1"  disabled="true"  onchange="empchangefn6()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_6 as $data_6)    
                        { 
                         echo "<option value=". $data_6->ecode ."~".  $data_6->shift . "~" .  $data_6->intime . "~" . $data_6->outtime . "~" . $data_6->tottime . "~" . $data_6->basicsal. ">" .   $data_6->name  . "</option>";
                          }  ?>  
                      </select> 


                      <br>
                       <input type="text" readonly  hidden name="empid6" id="empid6"   />  
                      <br>
                       <input type="date" name="regdate6" id="regdate6"   onchange="regdatechangefn6()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>

                       <br>


                      <?php
                       if ($data_12=="DATE")
                      { ?>


                      <input type="text" readonly name="empid6name" id="empid6name"    style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" >

                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid6name" id="empid6name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>


                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid6" id = "presentid6" onchange="presenteefn6()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid6" id = "dutyid6" onchange="dutychangefn6()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate6_1"   id="outdate6_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate6_2"   onBlur="chkoutdatefn6()"  id="outdate6_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid6" id = "shiftid6"    hidden  style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid6" id = "custid6" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_6 as $data2_6) { 
                         echo "<option value=". $data2_6->id . ">" .   $data2_6->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass6" id="pass6" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass6" id="pass6" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime6" id="reporttime6"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh6" id="rthh6" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm6" onchange="rtchangefn6()" hidden  id="rtmm6">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime6" id="intime6" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime6" id="acttime6" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh6" id="acthh6">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm6" onchange="actchangefn6()" id="actmm6">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime6" id="outtime6" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime6" id="actouttime6" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh6" id="outhh6">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm6" onchange="outchangefn6()" id="outmm6">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration6" id="workduration6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime6" id="ottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime6" id="tottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status6" id="status6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks6" id="remarks6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal6" id="basicsal6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming6" id="latecoming6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>
<!-- line 6 over -->

<!-- line 7     -->


         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <select name="empid7" id = "empid7" onchange="empchangefn7()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_7 as $data_7)
                        { 
                         echo "<option value=". $data_7->ecode ."~".  $data_7->shift . "~" .  $data_7->intime . "~" . $data_7->outtime . "~" . $data_7->tottime . "~" . $data_7->basicsal. ">" .   $data_7->name  . "</option>";
                          }  ?>  
                      </select>


                      <?php
                      }
                      else
                       { ?>


                      <select name="empid7_1" id = "empid7_1"  disabled="true" onchange="empchangefn7()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_7 as $data_7)
                        { 
                         echo "<option value=". $data_7->ecode ."~".  $data_7->shift . "~" .  $data_7->intime . "~" . $data_7->outtime . "~" . $data_7->tottime . "~" . $data_7->basicsal. ">" .   $data_7->name  . "</option>";
                          }  ?>  
                      </select>


                      <br>
                       <input type="text" readonly  hidden name="empid7" id="empid7"   /> 
                      <br>
                       <input type="date" name="regdate7" id="regdate7"   onchange="regdatechangefn7()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                      <br>


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <input type="text" readonly name="empid7name" id="empid7name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" >

                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid7name" id="empid7name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid7" id = "presentid7" onchange="presenteefn7()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid7" id = "dutyid7" onchange="dutychangefn7()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate7_1"   id="outdate7_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate7_2"   onBlur="chkoutdatefn7()"  id="outdate7_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid7" id = "shiftid7"   hidden   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid7" id = "custid7" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_7 as $data2_7) { 
                         echo "<option value=". $data2_7->id . ">" .   $data2_7->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span>  <br>
                     <input type="text" name="pass7" id="pass7" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass7" id="pass7" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime7" id="reporttime7"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh7" id="rthh7" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm7" onchange="rtchangefn7()" hidden  id="rtmm7">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime7" id="intime7" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime7" id="acttime7" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh7" id="acthh7">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm7" onchange="actchangefn7()" id="actmm7">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime7" id="outtime7" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime7" id="actouttime7" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh7" id="outhh7">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm7" onchange="outchangefn7()" id="outmm7">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration7" id="workduration7" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime7" id="ottime7" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime7" id="tottime7" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status7" id="status7" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks7" id="remarks7" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal7" id="basicsal7" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming7" id="latecoming7" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

 

<!-- line 8  -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <select name="empid8" id = "empid8" onchange="empchangefn8()"  style="width:80px;">
                      <option value="0">Empname</option>  
                         <?php 
                        foreach ($data_8 as $data_8) 
                        { 
                         echo "<option value=". $data_8->ecode ."~".  $data_8->shift . "~" .  $data_8->intime . "~" . $data_8->outtime . "~" . $data_8->tottime . "~" . $data_8->basicsal . ">" .   $data_8->name  . "</option>";
                          }  ?>  
                      </select> 


                      <?php
                      }
                      else
                       { ?>

                      <select name="empid8_1" id = "empid8_1"    disabled="true"  onchange="empchangefn8()"  style="width:80px;">
                      <option value="0">Empname</option>  
                         <?php 
                        foreach ($data_8 as $data_8) 
                        { 
                         echo "<option value=". $data_8->ecode ."~".  $data_8->shift . "~" .  $data_8->intime . "~" . $data_8->outtime . "~" . $data_8->tottime . "~" . $data_8->basicsal . ">" .   $data_8->name  . "</option>";
                          }  ?>  
                      </select> 

                      <br>
                       <input type="text" readonly  hidden name="empid8" id="empid8"   /> 
                      <br>
                       <input type="date" name="regdate8" id="regdate8"   onchange="regdatechangefn8()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>



                       <br>

                      <?php
                       if ($data_12=="DATE")
                      { ?>


                      <input type="text" readonly name="empid8name" id="empid8name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"   style="width:150px;" value="" >  
 
                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid8name" id="empid8name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                    </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid8" id = "presentid8" onchange="presenteefn8()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid8" id = "dutyid8" onchange="dutychangefn8()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate8_1"   id="outdate8_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate8_2"   onBlur="chkoutdatefn8()"  id="outdate8_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid8" id = "shiftid8"   hidden    style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid8" id = "custid8" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_8 as $data2_8) { 
                         echo "<option value=". $data2_8->id . ">" .   $data2_8->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass8" id="pass8" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass8" id="pass8" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime8" id="reporttime8"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh8" id="rthh8" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm8" onchange="rtchangefn8()" hidden  id="rtmm8">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime8" id="intime8" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime8" id="acttime8" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh8" id="acthh8">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm8" onchange="actchangefn8()" id="actmm8">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime8" id="outtime8" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime8" id="actouttime8" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh8" id="outhh8">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm8" onchange="outchangefn8()" id="outmm8">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration8" id="workduration8" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime8" id="ottime8" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime8" id="tottime8" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status8" id="status8" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks8" id="remarks8" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal8" id="basicsal8" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming8" id="latecoming8" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 9  -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <select name="empid9" id = "empid9" onchange="empchangefn9()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_9 as $data_9) 
                         { 
                         echo "<option value=". $data_9->ecode ."~".  $data_9->shift . "~" .  $data_9->intime . "~" . $data_9->outtime . "~" . $data_9->tottime . "~" . $data_9->basicsal. ">" .   $data_9->name  . "</option>";
                          }  ?>  
                      </select>


                      <?php
                      }
                      else
                       { ?>
                     <select name="empid9_1" id = "empid9_1"    disabled="true"  onchange="empchangefn9()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_9 as $data_9) 
                         { 
                         echo "<option value=". $data_9->ecode ."~".  $data_9->shift . "~" .  $data_9->intime . "~" . $data_9->outtime . "~" . $data_9->tottime . "~" . $data_9->basicsal. ">" .   $data_9->name  . "</option>";
                          }  ?>  
                      </select>

                      <br>
                       <input type="text" readonly  hidden name="empid9" id="empid9"   /> 
                      <br>
                       <input type="date" name="regdate9" id="regdate9"   onchange="regdatechangefn9()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                       <br>

                      <?php
                       if ($data_12=="DATE")
                      { ?>
                      <input type="text" readonly name="empid9name" id="empid9name"   style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"   style="width:150px;" value="" >  

                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid9name" id="empid9name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid9" id = "presentid9" onchange="presenteefn9()" style="width:80px;">
                      <option value="0">Presentee </option>  
                         <?php 
                          echo '<option value="PP">PRESENT</option>';                         
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid9" id = "dutyid9" onchange="dutychangefn9()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate9_1"   id="outdate9_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate9_2"   onBlur="chkoutdatefn9()"  id="outdate9_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid9" id = "shiftid9"    hidden   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid9" id = "custid9" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_9 as $data2_9) { 
                         echo "<option value=". $data2_9->id . ">" .   $data2_9->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br>
                     <input type="text" name="pass9" id="pass9" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass9" id="pass9" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime9" id="reporttime9"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh9" id="rthh9" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm9" onchange="rtchangefn9()" hidden  id="rtmm9">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime9" id="intime9" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime9" id="acttime9" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh9" id="acthh9">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm9" onchange="actchangefn9()" id="actmm9">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime9" id="outtime9" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime9" id="actouttime9" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh9" id="outhh9">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm9" onchange="outchangefn9()" id="outmm9">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration9" id="workduration9" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime9" id="ottime9" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime9" id="tottime9" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status9" id="status9" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks9" id="remarks9" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal9" id="basicsal9" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming9" id="latecoming9" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 10  data change in controller remaining -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 


                      <?php
                       if ($data_12=="DATE")
                      { ?>

                      <select name="empid10" id = "empid10" onchange="empchangefn10()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_10 as $data_10) { 
                         echo "<option value=". $data_10->ecode ."~".  $data_10->shift . "~" .  $data_10->intime . "~" . $data_10->outtime . "~" . $data_10->tottime . "~" . $data_10->basicsal. ">" .   $data_10->name  . "</option>";
                          }  ?>  
                      </select> 


                      <?php
                      }
                      else
                       { ?>


                      <select name="empid10_1" id = "empid10_1"  disabled="true" onchange="empchangefn10()"  style="width:80px;">
                      <option value="0">Empname </option>  
                         <?php 
                        foreach ($data_10 as $data_10) { 
                         echo "<option value=". $data_10->ecode ."~".  $data_10->shift . "~" .  $data_10->intime . "~" . $data_10->outtime . "~" . $data_10->tottime . "~" . $data_10->basicsal. ">" .   $data_10->name  . "</option>";
                          }  ?>  
                      </select> 

                      <br>
                       <input type="text" readonly  hidden name="empid10" id="empid10"   /> 
                      <br>
                       <input type="date" name="regdate10" id="regdate10"   onchange="regdatechangefn10()" value="<?php echo date('Y-m-d');?>" /> 
                      <?php
                       } ?>
                      <br>

                      <?php
                       if ($data_12=="DATE")
                      { ?>


                      <input type="text" readonly name="empid10name" id="empid10name"  style="font-size: 14px;background-color:#FCF5D8;color:#AD8C08;"   style="width:150px;" value="" > 

                      <?php
                      }
                      else
                      { ?>
                      <input type="text" readonly hidden name="empid10name" id="empid10name"   style="font-size: 12px;background-color:#FCF5D8;color:#AD8C08;"  style="width:150px;" value="" > 
                      <?php
                     }?>
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid10" id = "presentid10" onchange="presenteefn10()" style="width:80px;">
                      <option value="0">Presentee</option>  
                         <?php 
                         echo '<option value="PP">PRESENT</option>';                          
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid10" id = "dutyid10" onchange="dutychangefn10()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate10_1"   id="outdate10_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate10_2"   onBlur="chkoutdatefn10()"  id="outdate10_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid10" id = "shiftid10"   hidden   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid10" id = "custid10" style="width:80px;">
                      <option value="0">Customer </option>  
                         <?php 
                        foreach ($data2_10 as $data2_10) { 
                         echo "<option value=". $data2_10->id . ">" .   $data2_10->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span>  <br>
                     <input type="text" name="pass10" id="pass10" value="" style="font-size:12px;width:40px;" >
             </td>
<!--
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass10" id="pass10" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime10" id="reporttime10"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh10" id="rthh10" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm10" onchange="rtchangefn10()" hidden  id="rtmm10">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime10" id="intime10" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime10" id="acttime10" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh10" id="acthh10">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm10" onchange="actchangefn10()" id="actmm10">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime10" id="outtime10" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime10" id="actouttime10" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh10" id="outhh10">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 24; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm10" onchange="outchangefn10()" id="outmm10">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration10" id="workduration10" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime10" id="ottime10" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime10" id="tottime10" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status10" id="status10" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks10" id="remarks10" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal10" id="basicsal10" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming10" id="latecoming10" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>



<!-- line 10 over -->

       </table>
       <br>

   
 <!--
<center> <input type="submit"  name="dsmit" id="dsmit" value ="Submit Daily Register" >  </center>
 
<br>
</form>   -->
<?php

echo form_submit('submit', 'Create Daily Attendence Register Entry ');
echo form_close();
?>
</div>
</div>
</body>
</html>