<?php
//die("here");
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
<script>
function onSelectChange()
{
    var sel = document.getElementById('select');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.occupation.value=strUser;
}

function onEnquiryChange()
{
    var sel = document.getElementById('selectenquiry');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.enquiry1.value=strUser;
}

function onFollowupChange()
{
    var sel = document.getElementById('selectfollowup');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.reghuman.followup1.value=strUser;
}

</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>
<form method="post" name="reghuman" action="<?php echo base_url().'index.php/Home_Dr_Raje/new_human_stock_registration';?>">

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_stock"; ?>'>New Medicine </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_stock"; ?>'>Existing Medicine</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>
<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <div id="main">
<div id="login"> 
<span style="font-size:20px;cursor:pointer;color="black">   Registration Form </span>
<!-- <h2>Registration Form</h2> -->
<hr/>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('Home_Dr_Raje/new_human_user_registration'); 
echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}
echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
echo form_label('Create New Medicine : '); 
echo '</span>';
echo"<br/>";
 
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_input('stockname'); 
echo '</span>';
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}
echo "</div>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Medicine Short Code : '); 
echo '</span>';
echo"<br/>";
echo form_input('medicineshortcode');
echo"<br/>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Re-Order Level '); 
echo '</span>';
// echo "<br/>";
echo "&nbsp;&nbsp;";
echo form_input('reorderlevel');
echo"<br/>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Actual Stock In Hand : ');
echo '</span>';
echo"<br/>";
echo form_input('stockinhand');
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>Sales Rate :</label> </span>';
echo form_input('salerate'); 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>Unit of Measurement :</label> </span>';
echo form_input('unit'); 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>Gst HSN CODE:</label> </span>';
echo form_input('hsncode');
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>Stock Bin Number (Location of stock) :</label> </span>';
echo form_input('stockbinnumber'); 
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>GST% :</label> </span>';
echo form_input('gstperc'); 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>CGST SGST IGST % :</label> </span>';
echo form_input('cgst'); 
echo form_input('sgst');
echo form_input('igst');
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer">
<label>Schedule Stock Number :</label> </span>';
echo form_input('schedulestock'); 
// any additional information 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Any additional information  :</label> </span>';
echo form_input('any_information_1'); 
echo form_input('any_information_2'); 
echo "<br>";
echo "<br>";
echo form_submit('submit', 'Create Medicine Stock');
echo form_close();
?>
<span style="font-size:15px;cursor:pointer;color="black">;
<a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>For Login Click Here</a>
</span>;
<!-- <a href="<?php echo base_url() ?> ">For Login Click Here</a> -->
  </div>
</div> 
</div>
</div>
</form>
</body>
</html>