<?php
  
?>
<!DOCTYPE html>
<html>
    <head>
       <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
       <title>Welcome to Deshpandes AutoRenta Pvt Ltd </title>  
   <style type="text/css" media="screen"> 
.ddsmoothmenu{ font-size: 1.3em; font-family:Verdana, Geneva, sans-serif; background: #ff9378;	/*background of menu bar (default state)*/width: 100%;}
.ddsmoothmenu ul{z-index:100; width:980px; margin:0 auto; padding: 0;list-style-type: none;}
/*Top level list items*/
.ddsmoothmenu ul li{position: relative;display: inline;float: left;}
/*Top level menu link items style*/
.ddsmoothmenu ul li a{display: block;background: #ff9378; color: #222; padding: 10px 14px;/*border-right: 1px solid #778;*/	/* Commented Today */;text-decoration: none; font-weight: bold;}
.ddsmoothmenu ul li a.first{background: #ff9378 url(../images/icon-home.png) no-repeat 20px 12px; padding: 10px 14px 10px 44px;/*border-right: 1px solid #778;*/	/* Commented Today */color: #2d2b2b;text-decoration: none;}
* html .ddsmoothmenu ul li a{ /*IE6 hack to get sub menu links to behave correctly*/display: inline-block;}
.ddsmoothmenu ul li a:link, .ddsmoothmenu ul li a:visited{color: #222;}
.ddsmoothmenu ul li a.selected{ /*CSS class that's dynamically added to the currently active menu items' LI A element*/background-color: #A82532; /*background: black; */	/* Commented Today */color: #fff;}
.ddsmoothmenu ul li a:hover{background-color: #A82532;	/*background of menu items during onmouseover (hover state)*/
color: white;}

/*1st sub level menu*/
.ddsmoothmenu ul li ul{position: absolute;left: 0;display: none; /*collapse all sub menus to begin with*/visibility: hidden;}

/*Sub level menu list items (undo style from Top level List Items)*/
.ddsmoothmenu ul li ul {width:170px; /* Width Added on 8th March 2015 By Vivek */}
.ddsmoothmenu ul li ul li{display: list-item;float: none; }
/*All subsequent sub menu levels vertical offset after 1st level sub menu */
.ddsmoothmenu ul li ul li ul{top: 0;}

/* Sub level menu links style */
.ddsmoothmenu ul li ul li a{font: normal 13px Verdana;width: 160px; /*width of sub menus*/padding: 5px;margin: 0;border-top-width: 0;border-bottom: 1px solid gray;}

/* Holly Hack for IE \*/
* html .ddsmoothmenu{height: 1%;} /*Holly Hack for IE7 and below*/

/* ######### CSS classes applied to down and right arrow images  ######### */
.downarrowclass{position: absolute;/*top: 12px;	*/	/* Commented Today */top: 14px;right: 7px;}

.rightarrowclass{position: absolute;top: 6px;right: 5px;}

/* ######### CSS for shadow added to sub menus  ######### */

.ddshadow{ /*shadow for NON CSS3 capable browsers*/position: absolute;left: 0;top: 0;width: 0;height: 0;background: silver;}

.toplevelshadow{ /*shadow opacity for NON CSS3 capable browsers.Doesn't work in IE*/opacity: 0.8;}


/* 	Color pallette 	
		ADD COLOR PALlette Hex colors with proper description here
*/

/* 	Resets default browser settings	reset Styles Start here */
*{ margin:0; padding:0; border:0; outline:0; font-weight:inherit; font-style:inherit; font-size:100%; font-family:inherit; vertical-align:baseline; }
:focus{outline:0;}
a{text-decoration:none;}
a:active{outline:none;}
img{border:none;}
ol,ul{list-style:none;}
table{border-collapse:collapse; border-spacing:0;}
body{font-size:62.5%; font-family: Arial, Helvetica, sans-serif; letter-spacing:0; color:#434343; background:#f6f6f6; position:relative;-webkit-font-smoothing: subpixel-antialiased;}
/* 	Resets default browser settings	reset Styles Start here */
/* Generic classes start here */
.clear{clear:both;}
.fl{float:left}
.fr{float:right}
/* Generic classes start here */

/* Other Styles start here */
.mainContainer {  background:#fff; width: 980px; margin:0 auto; /*border: 1px solid; */ min-height:450px; border: 1px solid #ddd; overflow:auto;}
.mainContainer .lhs{ float:left; width: 245px; padding: 24px 0 0 15px;}
.mainContainer .lhs .lhsNav{ width: 215px; border: 1px solid #b4b4b4; background:url(../images/bg-lhs-nav.jpg) repeat-x 0 top;}
.mainContainer .lhs .lhsNav ul { margin:10px 0 0 0;  min-height: 291px; width: 223px;  }
.mainContainer .lhs .lhsNav ul li {	margin:4.5px 0;	font-size:1.2em; color: #7d7d7d;}
.mainContainer .lhs .lhsNav ul li a { padding:9px; display:block; text-decoration:none;}
.mainContainer .lhs .lhsNav ul li a:hover {  background:url(../images/lhs-nav-sel.png) no-repeat 0 0; display:block;  text-decoration:none;}
.mainContainer .lhs .newsletter{ padding: 15px 0 0 0;}
.mainContainer .lhs .adBanner{ padding: 15px 0;}
.mainContainer .rhs{ float:left; width: 660px;}
.mainContainer .rhs .rhsColumn2 {width: 690px;}
.mainContainer .rhs .rhsColumn2 img { padding: 0 0 0 20px;}
.header{ /*border: 1px solid red;*/}
.headerInner{ background:#fff; width: 980px; margin:0 auto; border: 1px solid #ddd; overflow:auto; }
.logo{ float:left; padding: 14px 0 14px 20px; }
.topLinks{ float:right; padding: 8px 0 0 430px; width: 93px; /*border:1px solid red;*/}
.topLinks ul li { float:left; padding:10px; font-size:1.2em; }
.topLinks ul li a.login{ padding:0 0 5px 23px; font-size:1.2em;   background: url(../images/icon-login.png) no-repeat 0 0; color:#666;}
.topLinks ul li a.login:hover{ text-decoration:underline; color:#333;}
.contactInfo { clear:right; float:right; padding-right:20px;}
.contactInfo p{ float:right; color:#ff562d; font-size:2.4em;  padding: 2px 0 4px 40px; background: url(../images/icon-contactus.png) no-repeat 0 0;}
.contactInfo p span{ color: #666; display: inline-block; float: right; font-size: 0.8em; line-height: 27px;}

.footer{ width:100%; background: #dcdcdc; float:left; min-height:80px; border-top:1px solid #9b9b9b;} /* 150px */
.footerInner { width: 940px; margin:0 auto; /*border: 1px solid; */padding: 10px 10px 0 30px; overflow:auto; min-height: 150px;}
.footerBox{ width:185px;/*border: 1px solid;*/ float:left;} 
.footerInner p{	font-size:1.3em; font-weight:bold; font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }
.footerInner p.tagline{ float:right; color:#12466f; font-size:2.2em; padding:  40px 10px 0 0; font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;}
.footerInner p.tagline span{ color:#3877a5; font-size:1.2em;}

.contactInfoBtm { clear:left; float:left; padding-top:5px; }
.contactInfoBtm p{ float:left; color:#ff562d; font-size:2.4em; font-weight:normal;  padding: 2px 0 4px 40px; background: url(../images/icon-contactus.png) no-repeat 0 0;}
.contactInfoBtm p span{ color: #666; display: inline-block; font-size: 0.8em; line-height: 27px;}

/* Other Styles End here */


/* Homepage classes start here */
.bannerContainer{ width:750px; height:200px; border:1px solid #999; margin:20px; float:left; }
.contentContainer{ float:left; width:980px;}
.boxContainer{ float:left; min-height:284px; width:324px; margin: 34px 0 33px 33px; box-shadow: 1px 1px 4px #ccc;}
.boxFirstMargin{ margin-left: 33px !important; }
.boxContainer h2{ float:left; background:#dcdcdc; color:#2a6a93; font-size: 1.9em; font-family:Verdana, Geneva, sans-serif; line-height: 2em;  height: 43px; width:308px; padding-left:16px; }
.boxContent{float:left; clear:both; background: #f6f6f6 url(../images/bg-box-content.png) repeat-x 0 bottom; min-height: 240px; width:324px; padding-top:20px; }
.boxContent input{ float:left; margin:0 0 18px 22px;; border: 1px solid #a7a7a7; width:127px; height:22px; background:#e8e8e8 url(../images/bg-input.png) repeat-x 0 bottom; font-size:1.2em; box-shadow: 1px 1px 3px #ddd;}
.boxContent li{ background: url(../images/bullet-01.png) no-repeat 20px 4px; width:320px; padding: 0 0 14px 40px; font-size:1.3em; color:#666; font-family:Verdana, Geneva, sans-serif; font-weight:bold; }
.boxContent span { display:block; clear:right}
.boxContent span a{ float:right; display:block; padding:0 20px 15px 9px; font-size:1.1em; font-weight:bold; color: #999;  background: url(../images/bullet-02.png) no-repeat 0 4px;}
.boxContent span a:hover{ text-decoration:underline;  color: #666;}  
.offerBanner{ float:right; width:230px; height:205px; margin: 34px 0; background:#57d958; position:relative; }
.offerBanner img{ position:absolute; top: -37px; right: 0; z-index:10;} 
.offerBanner span a{ float:left; color:#a00; font-size:1.4em; padding:16px 0 3px 20px ; font-weight: bold; font-family:Georgia, "Times New Roman", Times, serif; display:block;} 
.offerBanner h3  a{ float:left; color:#423edc; font-size:1.8em; padding: 20px 10px 10px; font-weight: bold; font-family:Georgia, "Times New Roman", Times, serif;} 
.offerBanner h4  a{ float:left; color:#cf480d; font-size:1.4em; padding: 0 10px 10px 10px; font-weight: bold; font-family: Georgia, "Times New Roman", Times, serif;} 
.adBanner{ margin:11px auto 31px auto; width:660px;}
.adBanner img{ float:left;}
/* Homepage classes Ends here */

/* Enquiry Page classes start here */
.formContainer{ float:left; width:980px; }
.formContainer h2{ font-size:1.6em; padding:20px 10px 10px; width:880px; margin: 0 auto 10px; border-bottom: 1px solid #a82532;  }
.formContainer table{width:900px; margin: 0 auto; }
.formContainer td { font-size:1.4em; padding:10px;}
.formContainer table.enquiryType td.emptyTD{ width:200px;}
.formContainer table.enquiryType {  }
.formContainer table.enquiryType input[checkbox] { margin-left:10px; border: 1px solid #aaa; }
.formContainer table.enquiryType label{ width:215px; padding-left: 10px; font-size:0.9em;   }
.formContainer table.contactForm{ margin:20px auto 30px; }
.formContainer table.contactForm input{ border: 1px solid #aaa; width:400px; height:25px;}
.formContainer table.contactForm input.btn{ width:67px; border:none !important}
.formContainer table.contactForm textarea{ border: 1px solid #aaa; width:400px; height:100px;}
/* Enquiry Page classes End here */
/* 	Color pallette 	
		ADD COLOR PALlette Hex colors with proper description here
*/
/* 	Resets default browser settings	reset Styles Start here */
*{ margin:0; padding:0; border:0; outline:0; font-weight:inherit; font-style:inherit; font-size:100%; font-family:inherit; vertical-align:baseline; }
:focus{outline:0;}
a{text-decoration:none;}
a:active{outline:none;}
img{border:none;}
ol,ul{list-style:none;}
table{border-collapse:collapse; border-spacing:0;}
body{font-size:62.5%; font-family: Arial, Helvetica, sans-serif; letter-spacing:0; color:#434343; background:#f6f6f6; position:relative;-webkit-font-smoothing: subpixel-antialiased;}
/* 	Resets default browser settings	reset Styles Start here */
/* Generic classes start here */
.clear{clear:both;}
.fl{float:left}
.fr{float:right}
/* Generic classes start here */
/* Other Styles start here */
.mainContainer {  background:#fff; width: 980px; margin:0 auto; /*border: 1px solid; */ min-height:450px; border: 1px solid #ddd; overflow:auto;}
.mainContainer .lhs{ float:left; width: 245px; padding: 24px 0 0 15px;}
.mainContainer .lhs .lhsNav{ width: 215px; border: 1px solid #b4b4b4; background:url(../images/bg-lhs-nav.jpg) repeat-x 0 top;}
.mainContainer .lhs .lhsNav ul { margin:10px 0 0 0;  min-height: 291px; width: 223px;  }
.mainContainer .lhs .lhsNav ul li {	margin:4.5px 0;	font-size:1.2em; color: #7d7d7d;}
.mainContainer .lhs .lhsNav ul li a { padding:9px; display:block; text-decoration:none;}
.mainContainer .lhs .lhsNav ul li a:hover {  background:url(../images/lhs-nav-sel.png) no-repeat 0 0; display:block;  text-decoration:none;}
.mainContainer .lhs .newsletter{ padding: 15px 0 0 0;}
.mainContainer .lhs .adBanner{ padding: 15px 0;}
.mainContainer .rhs{ float:left; width: 660px;}
.mainContainer .rhs .rhsColumn2 {width: 690px;}
.mainContainer .rhs .rhsColumn2 img { padding: 0 0 0 20px;}
.header{ /*border: 1px solid red;*/}
.headerInner{ background:#fff; width: 980px; margin:0 auto; border: 1px solid #ddd; overflow:auto; }
.logo{ float:left; padding: 14px 0 14px 20px; }
.topLinks{ float:right; padding: 8px 0 0 430px; width: 93px; /*border:1px solid red;*/}
.topLinks ul li { float:left; padding:10px; font-size:1.2em; }
.topLinks ul li a.login{ padding:0 0 5px 23px; font-size:1.2em;   background: url(../images/icon-login.png) no-repeat 0 0; color:#666;}
.topLinks ul li a.login:hover{ text-decoration:underline; color:#333;}
.contactInfo { clear:right; float:right; padding-right:20px;}
.contactInfo p{ float:right; color:#ff562d; font-size:2.4em;  padding: 2px 0 4px 40px; background: url(../images/icon-contactus.png) no-repeat 0 0;}
.contactInfo p span{ color: #666; display: inline-block; float: right; font-size: 0.8em; line-height: 27px;}
.footer{ width:100%; background: #dcdcdc; float:left; min-height:150px; border-top:1px solid #9b9b9b;}
.footerInner { width: 940px; margin:0 auto; /*border: 1px solid; */padding: 10px 10px 0 30px; overflow:auto; min-height: 150px;}
.footerBox{ width:185px;/*border: 1px solid;*/ float:left;} 
.footerInner p{	font-size:1.3em; font-weight:bold; font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }
.footerInner p.tagline{ float:right; color:#12466f; font-size:2.2em; padding:  40px 10px 0 0; font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;}
.footerInner p.tagline span{ color:#3877a5; font-size:1.2em;}
.contactInfoBtm { clear:left; float:left; padding-top:5px; }
.contactInfoBtm p{ float:left; color:#ff562d; font-size:2.4em; font-weight:normal;  padding: 2px 0 4px 40px; background: url(../images/icon-contactus.png) no-repeat 0 0;}
.contactInfoBtm p span{ color: #666; display: inline-block; font-size: 0.8em; line-height: 27px;}
/* Other Styles End here */
/* Homepage classes start here */
.bannerContainer{ width:750px; height:200px; border:1px solid #999; margin:20px; float:left; }
.contentContainer{ float:left; width:980px;}
.boxContainer{ float:left; min-height:284px; width:324px; margin: 34px 0 33px 33px; box-shadow: 1px 1px 4px #ccc;}
.boxFirstMargin{ margin-left: 33px !important; }
.boxContainer h2{ float:left; background:#dcdcdc; color:#2a6a93; font-size: 1.9em; font-family:Verdana, Geneva, sans-serif; line-height: 2em;  height: 43px; width:308px; padding-left:16px; }
.boxContent{float:left; clear:both; background: #f6f6f6 url(../images/bg-box-content.png) repeat-x 0 bottom; min-height: 240px; width:324px; padding-top:20px; }
.boxContent input{ float:left; margin:0 0 18px 22px;; border: 1px solid #a7a7a7; width:127px; height:22px; background:#e8e8e8 url(../images/bg-input.png) repeat-x 0 bottom; font-size:1.2em; box-shadow: 1px 1px 3px #ddd;}
.boxContent li{ background: url(../images/bullet-01.png) no-repeat 20px 4px; width:320px; padding: 0 0 14px 40px; font-size:1.3em; color:#666; font-family:Verdana, Geneva, sans-serif; font-weight:bold; }
.boxContent span { display:block; clear:right}
.boxContent span a{ float:right; display:block; padding:0 20px 15px 9px; font-size:1.1em; font-weight:bold; color: #999;  background: url(../images/bullet-02.png) no-repeat 0 4px;}
.boxContent span a:hover{ text-decoration:underline;  color: #666;}  
.offerBanner{ float:right; width:230px; height:205px; margin: 34px 0; background:#57d958; position:relative; }
.offerBanner img{ position:absolute; top: -37px; right: 0; z-index:10;} 
.offerBanner span a{ float:left; color:#a00; font-size:1.4em; padding:16px 0 3px 20px ; font-weight: bold; font-family:Georgia, "Times New Roman", Times, serif; display:block;} 
.offerBanner h3  a{ float:left; color:#423edc; font-size:1.8em; padding: 20px 10px 10px; font-weight: bold; font-family:Georgia, "Times New Roman", Times, serif;} 
.offerBanner h4  a{ float:left; color:#cf480d; font-size:1.4em; padding: 0 10px 10px 10px; font-weight: bold; font-family: Georgia, "Times New Roman", Times, serif;} 
.adBanner{ margin:11px auto 31px auto; width:660px;}
.adBanner img{ float:left;}
/* Homepage classes Ends here */
/* Enquiry Page classes start here */
.formContainer{ float:left; width:980px; }
.formContainer h2{ font-size:1.6em; padding:20px 10px 10px; width:880px; margin: 0 auto 10px; border-bottom: 1px solid #a82532;  }
.formContainer table{width:900px; margin: 0 auto; }
.formContainer td { font-size:1.4em; padding:10px;}
.formContainer table.enquiryType td.emptyTD{ width:200px;}
.formContainer table.enquiryType {  }
.formContainer table.enquiryType input[checkbox] { margin-left:10px; border: 1px solid #aaa; }
.formContainer table.enquiryType label{ width:215px; padding-left: 10px; font-size:0.9em;   }
.formContainer table.contactForm{ margin:20px auto 30px; }
.formContainer table.contactForm input{ border: 1px solid #aaa; width:400px; height:25px;}
.formContainer table.contactForm input.btn{ width:67px; border:none !important}
.formContainer table.contactForm textarea{ border: 1px solid #aaa; width:400px; height:100px;}
/* Enquiry Page classes End here */

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>
  </head>
    <body> 
         <div class="clear"></div>
        <div id="smoothmenu1" class="ddsmoothmenu">
<!--       <img src="<?php echo base_url(); ?>images/dr_raje_logo_jpg.jpg"></img> -->
       <?php
         echo   "Welcome Deshpandes AutoRenta Pvt Ltd - Software " ;
      ?>
         
         <ul>
          <li><a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a> </li> 

          <li><a href='<?php echo base_url()."index.php/Home_AutoRenta/PecWithdrawal"; ?>'>Petty Cash Withdrwal </a> </li>
          <li><a href='<?php echo base_url()."index.php/Home_AutoRenta/PecExpenses"; ?>'>Petty Cash Expenses</a></li>
          <li><a href='<?php echo base_url()."index.php/Home_AutoRenta/PecReports"; ?>'>Petty Cash Reports</a></li>
          <li><a href='<?php echo base_url()."index.php/Home_AutoRenta/pecadmin"; ?>'>Admin</a></li>
         </ul>
         <br style="clear: left" />
         </div> 
    </body>
</html>