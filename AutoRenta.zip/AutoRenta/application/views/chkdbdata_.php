<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{

 header("location: login");
}

if ($username  == 'pdg')
{
}
else
{
  return;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

<style>
   body{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      
   }
   div{
      overflow-x: auto;
   }
   table {
      border-collapse: collapse;
      border-spacing: 0;
      font-size :9px;
      width: 100%;
      border: 1px solid rgb(0, 0, 0);
   }
   th, td {
      text-align: left;
      padding: 8px;
   }
   tr:nth-child(even){background-color: #f2f2f2}
</style>

</head>
<body>

<?php
if ($patient_class_value == "DAA")
{ ?>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
<!--
  <a href="#">My Pets Info</a>
  <a href="#">Reports</a>
  <a href="#">Next Visit</a>
  <a href="#">Utility</a>
  <a href="#">Admin</a>
-->
</div>
<?php
}
if ($patient_class_value == "PEC")
{ 
// echo "human"; 
?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
<!--
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_patient"; ?>'>Registration</a>   
  <a href="#">Patient Details</a>
  <a href="#">Pateient Diagnosis</a>
  <a href="#">Report Upload</a>
  <a href="#">Billing</a>
  <a href="#">Next Visit</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
-->
</div>
<?php
}


?>

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>


  <div class="mainContainer">
  <div class="formContainer">     

<?php
if (isset($logout_message)) {
echo "<div class='message'>";
echo $logout_message;
echo "</div>";
}
?>
<?php
if (isset($message_display)) {
echo "<div class='message'>";
echo $message_display;
echo "</div>";
}
?>

<!-- <div id="main">
 <div id="login"> 
 <div id="profile">   --> 

<h1>Check Database Data Page </h1>
<hr/>
<center><h2> Employee Table </h2> </center>
<table border="0">
 
     <?php
      echo "<tr><td>Code</td><td>Name</td><td>Shift</td><td>In <br>Time </td><td>Out <br>Time</td><td>Total <br>Time </td><td>Basic <br>Salary </td><td>Designation</td></tr>";
      foreach ($data as $data)
      { 
            echo "<tr><td>" .  $data->ecode . "</td><td>" . $data->name. "</td><td>" . $data->shift . "</td><td>" . $data->intime . " </td><td>" . $data->outtime . "</td><td>" . $data->tottime . "</td><td>".  $data->basicsal . "</td><td>" . $data->designation . " </td></tr>";
       } 
 
    ?>
</table>
<br>
<center><h2> Customer Table </h2> </center>
<table border="0">
 
     <?php
      echo "<tr><td>ID</td><td>Name</td><td>Mobile1 </td><td>Mobile 2 </td> </tr>";
      foreach ($data2_1 as $data)
      { 
            echo "<tr><td>" .  $data->id . "</td><td>" . $data->name. "</td><td>" . $data->mobile1 . "</td><td>" . $data->mobile2 . " </td> </tr>";
       } 
 
    ?>
</table>

<br>
<center><h2> Accounts Ledger </h2> </center>
<table border="0">
 
     <?php
      echo "<tr><td>ID</td><td>Accounts Code</td><td>Name </td><td>Ledger Type<td>Op Balance </td><td>Dr amount </td><td>Cr  Amount </td> </tr>";
      foreach ($data_2 as $data)
      { 
            echo "<tr><td>" .  $data->id . "</td><td>". $data->accode . "</td><td>" . $data->acname. "</td><td>" . $data->typeledger . "</td><td>" . $data->openingbalance . "</td><td> " . $data->amountgiventotal . "</td><td>". $data->amountspendtotal . "</td> </tr>";
       } 
 
    ?>
</table>


<br>
<center><h2> Month Year Ledger </h2> </center>
<table border="0">
 
     <?php
      echo "<tr><td>Accounts Code</td><td>Name </td><td>Ledger Type<td>Op Balance </td><td>Dr amount </td><td>Cr  Amount </td><td>Month</td><td>Year </td> </tr>";
      foreach ($data2_2 as $data)
      { 
            echo "<tr><td>". $data->accode . "</td><td>" . $data->acname. "</td><td>" . $data->typeledger . "</td><td>" . $data->openingbalance . "</td><td> " . $data->amountgiventotal . "</td><td>". $data->amountspendtotal . "</td><td>" . $data->monthledger . "</td><td>" . $data->yearledger . "</td></tr>";
       } 
 
    ?>
</table>


<br>
<center><h2> Payment Register </h2> </center>
<table border="0">
 
     <?php
      echo "<tr><td>Date</td><td>Dr Account</td><td>Cr. Account<td>Employee Name </td><td>Dr. Amount</td><td>Cr Amount </td><td>Amount Adjusted</td><td>Salary <br>Month</td><td>Salary <br>Year </td><td>Remarks <br> Narration </td> </tr>";
      foreach ($data_3 as $data)
      { 
           $gldr = $data->glcodedr;
           $glcr = $data->glcodecr;
           $empcode = $data->accode;
           $drname = "";
           $crname = "";
           $empname = "";
           if ($gldr > 0 )
           { 
               $msql ="SELECT * FROM accodeledger where id = " . $gldr ; 
               $query = $this->db->query($msql);  							
              foreach($query->result() as  $tabData)
              {
                     $drname = $tabData->acname;
              }
            }
           if ($glcr > 0 )
           { 
               $msql ="SELECT * FROM accodeledger where id = " . $glcr ; 
               $query = $this->db->query($msql);  							
              foreach($query->result() as  $tabData)
              {
                     $crname = $tabData->acname;
              }
            }
           if ($empcode > 0 )
           { 
               $msql ="SELECT * FROM emptable where ecode = " . $empcode ; 
               $query = $this->db->query($msql);  							
              foreach($query->result() as  $tabData)
              {
                     $empname = $tabData->name;
              }
            } 
            echo "<tr><td>". $data->date . "</td><td>" . $drname. "</td><td>" . $crname . "</td><td>" . $empname . "</td><td> " . $data->amountgiven . "</td><td>". $data->amountspend . "</td><td>". $data->amountadjusted . "</td><td>" . $data->salarymonth . "</td><td>" . $data->salaryyear . "</td><td>". $data->remarks . "<br>" . $data->narration1 . "<br>" . $data->narration2 . "</td></tr>";
       } 
 
    ?>
</table>


<br>
<center><h2>Daily Entry </h2> </center>
<table border="0">
 
     <?php
       echo "<tr><td>Date</td><td>Emp Name<br>Presentee</td><td>Duty <br>Shift</td><td>Fm Dt<br>To Dt </td><td>Customer <br>Passenger</td><td>In Time<br>Out Time </td><td>Actual In <br> Actual Out  </td> <td> Work <br> Ot Time </td> <td> Total </td><td>Remarks </td> </tr>";
       echo "<tr><td>Basic Salary</td><td>Total Allow</td><td>Cleaning<td>Night  </td><td>Day Allow</td><td>Double Shift </td><td>Late</td><td>Ot Rs </td><td> Day Salary     </td> </tr>";
      foreach ($data2_3 as $data)
      { 
          $empname = "";
               $msql ="SELECT * FROM emptable where ecode = " . $data->empid ; 
               $query = $this->db->query($msql);  							
              foreach($query->result() as  $tabData)
              {
                     $empname = $tabData->name;
              }
          $custname = "";
               $msql ="SELECT * FROM customer where  id = " . $data->customerid ; 
               $query = $this->db->query($msql);  							
              foreach($query->result() as  $tabData)
              {
                     $custname = $tabData->name;
              }

            echo "<tr><td>". $data->date . "</td><td>" . $empname. "<br>" . $data->presentabsent . "</td><td>" . $data->duty. "<br>" . $data->shift  . "</td><td> " . $data->outstationdatefrom . "<br>" . $data->outstationdateto . "</td><td>". $custname . "<br>" . $data->passengername . "</td><td>" . $data->intime . "<br>" . $data->outtime . "</td><td>" . $data->actualintime . "<br>". $data->actualouttime . "</td><td>". $data->worktime . "<br>" . $data->ottime . "</td><td>" . $data->totalduration . "</td><td>". $data->remarks . "</td></tr>";
            echo "<tr><td>". $data->basicsalary . "</td><td>" . $data->totalallowance . "</td><td>" . $data->cleaningallowance  . "</td><td> " . $data->nightallowance . "</td><td>". $data->dayallowance . "</td><td>" . $data->doubleshift . "</td><td>" . $data->latecoming . "</td><td>". $data->overtime . "</td><td>" . $data->daysalary . "</td></tr>";
       } 
 
    ?>
</table>

<!-- </div> -->

</div>
<!-- </div> -->
</body>
</html>