<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}

 
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function uname(form)
{

alert('test');

}

</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
 
</head>
<body>
 
<span style="font-size:20px;cursor:pointer;color="black">Pets Details Entry  Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Pets Details</h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>




  <form method="post" name="petdetails" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />  

  
    <table>
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Login Id : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> <select name="userloginid" id = "userloginid" style="width:100px;"> 
                         <?php 
                          foreach($data as $data) {
                          echo "<option value=". $data->id . ">" .  $data->user_name ."~" .  $data->user_name . "~" . $data->ad1 . "~" . $data->ad2 . "~" . $data->pincode . "~" . $data->mobile1 . "~" . $data->mobile2 . "</option>";
                          }?>   onblur="uname(this.form)" </select> </span>
               </td>
               
               <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name : </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="username" name="username" value = ""  onfocus="uname(this.form)"  placeholder="click here for user name"  /> 
                         </span> 
               </td>
         </tr>
 
 </table>
 
           <!-- class="btn btn-primary" -->
<hr>
<center>  <button type="submit" >Submit</button> </center>
</hr>
</form>
 
</body>
</html>



