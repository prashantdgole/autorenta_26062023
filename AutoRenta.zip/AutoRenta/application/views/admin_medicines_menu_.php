<?php
// die("end");
defined('BASEPATH') OR exit('No direct script access allowed');

// echo isset($this->session->userdata['logged_in']);

// die("here");

if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
//  echo " **************** 0 ";
// die("here");
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<?php
if ($patient_class_value == "PETS")
{ ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/maintenance_show"; ?>'>All Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseaselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/drdiagnosispet"; ?>'>Diagnosis  </a>

</div>
<?php
}
else
{ ?>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_new_stock"; ?>'>New Medicine </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_patient_existing_stock"; ?>'>Existing Medicine</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_medicines_reports_list"; ?>'>Reports</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>


<?php
} ?>
<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

 <div class="mainContainer">
<div class="formContainer">     


<h2>Deal with Patient Form</h2>
<hr/>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

</div>
</div>
     
</body>
</html>