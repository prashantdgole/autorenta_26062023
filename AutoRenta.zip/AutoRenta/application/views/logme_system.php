<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>
<meta charset="utf-8">
<title>Login Page </title>


<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">


ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>

<div class="header">
  <div class="headerInner">
    <div class="logo"><img src="<?php echo base_url(); ?>images/logo_pushpak.jpg" alt="Logo"> </div>
    <!--Logo End here -->
    <div class="topLinks">
      <ul>
        <li style="display:none"><a href="" >Tour</a></li>
        <li><a href="" class="login" >Login</a></li>
      </ul>
    </div>
    <div class="contactInfo">
      <p>:98205 20 228 &nbsp; <span></span></p>
    </div>
    <!--contactInfo End here -->
  </div>
  <!--topLinks End here -->
  <!--headerInner End here -->
  <div class="clear"></div>

  <div id="smoothmenu1" class="ddsmoothmenu">
    <ul>
      <li><a href="index.php" class="first selected">Home</a></li>
     <li>  <a href='<?php echo base_url()."index.php/Main/logme_system"; ?>'>Login</a>   </li>  
     <li><a href="#">Online Booking</a></li> 
      <li><a href="#">Tracking </a></li>
      <li><a href="#">About Us</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
    <br style="clear: left" />
  </div>
  <!--End of Navigation -->
</div>
<!--End of header -->
  <div class="mainContainer">
<!--  <div class="formContainer">  -->
    <h1> Login </h1>
    <?php  
    echo form_open('Main/login_action');   
    echo form_open('<?php echo base_url();?>Main/login_action');
    echo validation_errors(); 
    echo "<br>"; 
    echo "<p>Username: ";  
    echo form_input('username', $this->input->post('username'));  
    echo "</p>";  
    echo "<br>"; 
    echo "<br>"; 
    echo "<p>Password: ";  
    echo form_password('password');  
    echo "</p>";  
    echo "</p>"; 
    echo "<br>";  
    echo "<br>"; 

/*
    echo "<p>Clinic Type: ";  
    $options = array(
                  'PETS'  => 'PETS',
                  'HUMAN'    => 'HUMAN',
                ); */

//$shirts_on_sale = array('small', 'large');

/*
echo form_dropdown('user_type_value', $options, 'PETS'); 
    echo "</p>";  
    echo "</p>"; 
    echo "<br>";  
    echo "<br>";   */
   ?>
    <p>
   <?php
    echo form_submit('login_submit', 'Login');  
    echo "</p>";   
    echo form_close();  
   
    echo "<br>";  
    echo "<br>"; 
    ?>  
    <p>
    <a href='<?php echo base_url()."index.php/Main/signin"; ?>'>Sign In</a> 
    </p>
  
 
   </div>
<!--   </div> -->
  
<!--mainContainer Div ends here -->
<div class="clear"></div>
<div class="footer">
  <div class="footerInner">
    <p>A-104,Regal Arcade Complex,Opp to Avkar Hotel,Joggers Park Road,Near Punam Sagar Complex,Mira Road (E),Thane-401107</p>
    <div class="contactInfoBtm">
      <p>:9821 30 39 68 , 9664 51 07 18&nbsp;<span></span></p>
    </div>
    <!--contactInfo End here -->
    <p class="tagline">STEP IN @ PUSHPAK <span>and CONSIDER YOU ARE A DANCER ... </span></p>
  </div>
</div>
<!--footerInner Div ends here -->
</div>
<!--footer Div ends here -->
</body>
</html>
