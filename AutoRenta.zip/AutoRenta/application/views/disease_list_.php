<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>
</div>

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


  <div id="main">
<div id="login">  

<span style="font-size:20px;cursor:pointer;color="black">  Disease to Pet List Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('Home_Dr_Raje/new_disease_registration'); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
echo form_label('Disease List  : '); 
echo '</span>';
echo"<br/>";
 
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_input('diseasename'); 
echo '</span>';

echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Occurs in a Season : '); 
echo '</span>';
echo"<br/>";

echo form_input('seasonspecific');
echo"<br/>";
echo"<br/>";

echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Remarks : ');
echo '</span>';
echo"<br/>";
echo form_input('remarks');
echo"<br/>";
echo"<br/>";

echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Injection List '); 
echo '</span>';
echo "<br/>";
echo form_input('injectionlist');
echo"<br/>";
echo"<br/>";

echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Medicine Suggested : 1 :  '); 
echo '</span>';
echo "<br/>";
echo form_input('medicine1');
echo"<br/>";
echo"<br/>";

echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Medicine Suggested : 2 : '); 
echo '</span>';
echo "<br/>";
echo form_input('medicine2');
echo"<br/>";
echo"<br/>";

echo"<br/>";
echo"<br/>";
echo form_submit('submit', 'Save Me');
echo form_close();
?>
<!--<span style="font-size:15px;cursor:pointer;color="black">;
<a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>For Login Click Here</a>
</span>; -->
<!-- <a href="<?php echo base_url() ?> ">For Login Click Here</a> -->
  </div>
</div>  
</div>
</div>
</body>
</html>