<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}

 
?>
<?php
// if (!empty($_POST['show'])) 
// {
// }
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function getpetname(form)
{
// alert(" in ");
 var val1 , n , strUser;
var e = document.getElementById("pettypeid");
var strUser = e.options[e.selectedIndex].text;
var sp_lit = strUser.split('-');
document.mypetdetails1.pettypename.value=sp_lit[0];
}
 

 
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Pets Details Entry  Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Pets Details</h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>




 <!-- <form method="post" name="mypetdetails" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />   -->

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>

    <table>

<!-- $_SESSION['global_user_name'] = '';
$_SESSION['global_user_id'] = 0;
$_SESSION['global_name_of_person'] = ''; -->

  <!--  <tr> <td> <?php echo phpversion(); ?> </td> </tr> -->
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Login Id : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="userloginid" id = "userloginid" style="width:100px;"> 
                         <?php 
                        foreach ($data as $data) { 
                         echo "<option value=". $data->id .  ">" .   $data->user_name  . "~" .  $data->ad1 . "~" . $data->ad2 . "~" . $data->pincode . "~" . $data->mobile1 . "~" . $data->mobile2 . "~" . $data->Nameofperson  . "</option>";
                          }  ?>      </select> </span>  
                       <input type="text" name="uloginid" id="uloginid" hidden value= "<?php if (isset($_POST['show'])) { $uid  =  $_POST['userloginid'];  $_SESSION['global_user_id'] = $_POST['userloginid'];   echo $_POST['userloginid'];  }  ?>"
               </td>
              <td> </td>
              <td>   <button type="submit" id="show" name="show" >Show Records </button>  </td>

<!--            <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/show/'.$item->id ?> "> Show </a> -->
          <tr>
         <tr>              
               <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name : </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id="ulusername" name="ulusername"   readonly  value = "<?php if (isset($_POST['show'])) {$uid  =  $_POST['userloginid'];  foreach ($data4 as $data4) { if ($data4->id == $uid)  {  $_SESSION['global_user_name'] = $data4->user_name; echo $data4->user_name;  $_SESSION['global_name_of_person'] = $data4->nameofperson;  $fulladdress = $data4->ad1 . " " .   $data4->ad2  . " Mobile : " .  $data4->mobile1 . " " .  $data4->mobile2  ;  }  }    }  ?>"  placeholder="click here for user name"  /> 
                         </span> 
               </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value= "<?php if (isset($_POST['show'])) { echo  $_SESSION['global_name_of_person']; } ?>" placeholder="name of person "> 
                         </span> </td>
         </tr>
         <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Full Address: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="<?php if (isset($_POST['show'])) {  echo $fulladdress; } ?>" placeholder="full address "> 
                       </span> </td>
         </tr>
 </table>
<br>
<h2>Pets Details already Registered for Client <?php  if (isset($_POST['show'])) {  $unm = $_SESSION['global_user_name']; echo $unm; } ?>  </h2>  
 <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name <br> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender  <br> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Birth <br> Origin Details</span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> First Visit Date <br> Speciality </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Prev Illness <br> Allergy </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Remarks  </span> </td> 
      </tr>

     <?php
             if (isset($_POST['show'])) 
             {
              foreach ($data3 as $data3) 
              { 
                 $uid =  $_SESSION['global_user_id'];

                 if ($data3->userid == $uid) 
                {

                   echo '<tr>';
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->username . "<br>".$data3->pettype  .   "</span>"; //  . "[". $xname . "]".   "</span>";
                   echo '</td>';

  
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->gender . "<br>".$data3->petname . "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->dateofbirth . "<br>".$data3->origin . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->firstvisitdate . "<br>".$data3->speciality . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->illness1 . "<br>".$data3->illness2 . "<br>" . 
                          $data3->allergy1 . "<br>".$data3->allergy2 .  "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data3->remarks . "</span>";
                   echo '</td>';

                   echo '</tr>';
                 } 
               } 
             }
    ?>
      
  </table>
 </form>
 <form method="post" name="mypetdetails1" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />   

  <h2> Name and Other Details of Pets   </h2>   
  <table>
       <tr>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Type - subtype :</span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black">
                   <select name="pettypeid" id=name="pettypeid"> 
                          <?php 
                          foreach($data1 as $data1)
                          { 
                         echo "<option value=". $data1->id . ">" .  $data1->pettype . "-" . $data1->petsubtype  . "</option>";
                          } ?> 
                  </select>  <input type="text" name="pettypename" id="pettypename" hidden value="<?php if (isset($_POST['submit'])) {  $xpid = $_POST["pettypeid"];  echo $xpid; } ?>"/> 
                  </span>
               </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender & Name  :</span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                     <?php 
                  $genderopt = array(
                  'MALE'  => 'MALE',
                  'FEMALE'    => 'FEMALE',
                   ); 
                   echo form_dropdown('gender_opt_value', $genderopt, 'MALE'); ?> </span> </td>
                 <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="name_of_pet"  id="name_of_pet" value="" placeholder="Name"/> 
                   </span>
                 </td>
        </tr>
       <table> <br>
       <table>
       <tr>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> Birth Date </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="date" id ="birthdate" name="birthdate" value = "" /> </span> </td>
                <td>  <span style="font-size:15px;cursor:pointer;color="black">First Visit Date </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black">   
                       <input type="date" id ="visitdate" name="visitdate" value = "<?php $dt = new DateTime(); echo $dt->format('d-m-y'); ?>" /> </span> </td>

       </tr>
       
      <tr>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> Pending Amount  </span> </td>
                <td style="width:100px;"> <span style="font-size:15px;cursor:pointer;color="black" > 
                       <input type="text" id ="totalpendingamount"   name="totalpendingamount" value = "0" placeholder="0 for first time user" /> </span> </td>
                <td>  <span style="font-size:15px;cursor:pointer;color="black"> Remarks </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" id ="petremarks" name="petremarks" value = "" /> </span> </td>

       </tr>
<!--       <tr>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of death </span> </td>
                <td> <span style="font-size:15px;cursor:pointer;color="black">  
                         <input type="date" id="deathdate" name ="deathdate" value=""> </span> </td>
                 <td> <span style="font-size:15px;cursor:pointer;color="black"> Reason </span> </td>
                  <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                           <input type="text" id="deathreason" name="deathreason" value="" placeholder="reason for death" /> </span>
                  </td>
        <tr> -->
  </table>
   <h2>     Historical Details and Speciality if Any  </h2>
    <table>

        <tr> 
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Origin Details </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" name= "origindetails" id="origindetails" value="" placeholder="origin details"/> </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> speciality </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" name="specialitydetails" id="specialitydetails" value="" placeholder="speciality details" /> </span> </td>
        </tr>
        <tr> 
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Allergy details </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                       <input type="text" name= "allergydetails1" id="allregydetails1" value="" placeholder="allergy details1"/> <br>
                       <input type="text" name= "allergydetails2" id="allregydetails2" value="" placeholder="allergy details2"/>
                       </span> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Previous illness </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" name="illnessdetails" id="illnessdetails" value="" placeholder="illness details" /> <br> 
                      <input type="text" name="illnessdetails2" id="illnessdetails2" value="" placeholder="illness details 2" /> <br> 
                      </span> </td>
        </tr>
    </table>
           <!-- class="btn btn-primary" -->
<hr>
<!--  <center>  <button type="submit" >Submit</button> </center> -->

 <center> <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/' ?> "><button type="submit" name="submit" id="submit" >Update</button> </a> </center> 


</hr>
<!-- </form> -->

<?php
?>
  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>