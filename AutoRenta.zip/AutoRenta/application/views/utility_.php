<?php
// die("1");
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
// echo " **************** 0 ";
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<?php
if ($patient_class_value == "PETS")
{ ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/utilitylist"; ?>'>List of Pets with Owners</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/utilityfulllist"; ?>'>Full List</a>

</div>
<?php
}
else
{ ?>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login*</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/maintenance_show"; ?>'>All Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Patient Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Patient Reports</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/drdiagnosis_human"; ?>'>Diagnosis  </a>

</div>

<?php
} ?>

 

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

 <div class="mainContainer">
<div class="formContainer">     


<h2>Utility Form</h2>
<hr/>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";

if ($user_type_value != 'ADMIN')
{
   $this->session->set_flashdata('err_message', 'Not  User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>
<h2>User having how many Pet  Details  </h2>  
<br> <br>
  <table>
      <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User id </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> No of Pets </span> </td> 
      </tr>
      <?php
              $uid = 0;       
              $kount = 0;
              $kountid = 0;
              $kountpets = 0;
              foreach ($e as $data) 
              { 
                 $kount = 0;
                 $uname =  $data->username;
                 $uid = $data->userid;
                 $kountid+=1;
                 foreach ($all as $data1 )
                 {
                     if ($data1->username == $data->username ) 
                     {
                        $kount = $kount + 1;
                     }
                  } 
              echo '<tr>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $uid . "</span>"; // $uid
              echo '</td>';
              if ($uname == "")
              { }
              else
              {
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $uname . "</span>";
              echo '</td>';
              }
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $kount . "</span>";
              $kountpets = $kountpets + $kount;
              echo '</td>';
              echo '</tr>';
              } 
     ?>
     <tr> <td> </tr>
     <tr> <td> <?php echo $kountid; ?> </td> <td><b>TOTAL</b> </td><td> <?php echo $kountpets; ?> </td> </tr>
  </table>
  <hr>
  <center> <h2> Showing data having next visit today or in the current month </h2> </center>
   <hr>
 <table>
      <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> next visit </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> date of birth </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> mobile1 </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> mobile2 </span> </td> 
      </tr>
      <?php
         foreach ($next as $next) 
         {  
              echo '<tr>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->nextvisit . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->username . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->gender . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->pettype . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->petname . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->dateofbirth . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->mobile1 . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $next->mobile2 . "</span>"; // $uid
              echo '</td>';
              echo '</tr>';
          }
       ?>
    </table>
    <hr>
     <center> <h2> Showing data having Birth date today or in the current month </h2> </center>
    <hr>
    <table>
      <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Birth Date </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Mobile1 </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Moble2 </span> </td> 

      </tr>
      <?php
         foreach ($birth as $birth) 
         {  
              echo '<tr>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->dateofbirth . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->username . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->gender . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->pettype . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->petname . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->mobile1 . "</span>"; // $uid
              echo '</td>';
              echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
              echo $birth->mobile2 . "</span>"; // $uid
              echo '</td>';
              echo '</tr>';
          }
       ?>
    </table>
</div>
</div>
</body>
</html> 