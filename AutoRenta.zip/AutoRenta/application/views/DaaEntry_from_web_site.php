<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
$this->load->helper('form');
 
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in']))
{
$username = ($this->session->userdata['logged_in']['username']);
//$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
{
  header("location: login");
}
//echo $patient_class_value;
//die ("h");
if ($patient_class_value == 'DAA')
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
else
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
$wdayallowance = 0;
$wnightallowance = 0;
$wcleaningallowance =0;
$daydiff = 0;
$osrs = 400;
$nightrs = 100;
$cleanrs = 25;
?>

<!DOCTYPE html>
<html>
<head>
<title>daa entry Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function chkoutdatefn1()
{
   var od1 =   document.mydaa.outdate1_1.value;
   var od2 =   document.mydaa.outdate1_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function chkoutdatefn2()
{
   var od1 =   document.mydaa.outdate2_1.value;
   var od2 =   document.mydaa.outdate2_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function chkoutdatefn3()
{
   var od1 =   document.mydaa.outdate3_1.value;
   var od2 =   document.mydaa.outdate3_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function chkoutdatefn4()
{
   var od1 =   document.mydaa.outdate4_1.value;
   var od2 =   document.mydaa.outdate4_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function chkoutdatefn5()
{
   var od1 =   document.mydaa.outdate5_1.value;
   var od2 =   document.mydaa.outdate5_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function chkoutdatefn6()
{
   var od1 =   document.mydaa.outdate6_1.value;
   var od2 =   document.mydaa.outdate6_2.value;

   if (od2 >= od1 )
  {
  }
  else
  {
     alert(od2 + " To date must be equal or more than from date " + od1 );
  }
}
function dutychangefn1() {

  var duty1 = document.getElementById("dutyid1").value;

  if (duty1 == 'L')
  {

     document.getElementById("outdate1_1").hidden = true;
     document.getElementById("outdate1_2").hidden = true;

      document.getElementById("outdate1_1").disabled = true;
      document.getElementById("outdate1_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate1_1").disabled = false;
  document.getElementById("outdate1_2").disabled = false;
  document.mydaa.intime1.value='';
  document.mydaa.acttime1.value='';
  document.mydaa.outtime1.value='';
  document.mydaa.actouttime1.value='';
  document.mydaa.tottime1.value='';        
  document.mydaa.workduration1.value='';
  }
}
 
function dutychangefn2() {
  var duty1 = document.getElementById("dutyid2").value;
 
  if (duty1 == 'L')
  {
 // alert('h');
      document.getElementById("outdate2_1").disabled = true;
      document.getElementById("outdate2_2").disabled = true;

      document.getElementById("outdate2_1").disabled = true;
      document.getElementById("outdate2_2").disabled = true;
  }
  else
  {
// alert('o');
  document.getElementById("outdate2_1").disabled = false;
  document.getElementById("outdate2_2").disabled = false;
  document.mydaa.intime2.value='';
  document.mydaa.acttime2.value='';
  document.mydaa.outtime2.value='';
  document.mydaa.actouttime2.value='';
  document.mydaa.tottime2.value='';        
  document.mydaa.workduration2.value='';
  }
}
 
function dutychangefn3() {
  var duty1 = document.getElementById("dutyid3").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate3_1").disabled = true;
      document.getElementById("outdate3_2").disabled = true;

      document.getElementById("outdate3_1").disabled = true;
      document.getElementById("outdate3_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate3_1").disabled = false;
  document.getElementById("outdate3_2").disabled = false;
  document.mydaa.intime3.value='';
  document.mydaa.acttime3.value='';
  document.mydaa.outtime3.value='';
  document.mydaa.actouttime3.value='';
  document.mydaa.tottime3.value='';        
  document.mydaa.workduration3.value='';
  }
}
 
function dutychangefn4() {
  var duty1 = document.getElementById("dutyid4").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate4_1").disabled = true;
      document.getElementById("outdate4_2").disabled = true;

      document.getElementById("outdate4_1").disabled = true;
      document.getElementById("outdate4_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate4_1").disabled = false;
  document.getElementById("outdate4_2").disabled = false;
  document.mydaa.intime4.value='';
  document.mydaa.acttime4.value='';
  document.mydaa.outtime4.value='';
  document.mydaa.actouttime4.value='';
  document.mydaa.tottime4.value='';        
  document.mydaa.workduration4.value='';
  }
}
 
function dutychangefn5() {
  var duty1 = document.getElementById("dutyid5").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate5_1").disabled = true;
      document.getElementById("outdate5_2").disabled = true;

      document.getElementById("outdate5_1").disabled = true;
      document.getElementById("outdate5_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate5_1").disabled = false;
  document.getElementById("outdate5_2").disabled = false;
  document.mydaa.intime5.value='';
  document.mydaa.acttime5.value='';
  document.mydaa.outtime5.value='';
  document.mydaa.actouttime5.value='';
  document.mydaa.tottime5.value='';        
  document.mydaa.workduration5.value='';
  }
}
 
function dutychangefn6() {
  var duty1 = document.getElementById("dutyid6").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate6_1").disabled = true;
      document.getElementById("outdate6_2").disabled = true;

      document.getElementById("outdate6_1").disabled = true;
      document.getElementById("outdate6_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate6_1").disabled = false;
  document.getElementById("outdate6_2").disabled = false;
  document.mydaa.intime6.value='';
  document.mydaa.acttime6.value='';
  document.mydaa.outtime6.value='';
  document.mydaa.actouttime6.value='';
  document.mydaa.tottime6.value='';        
  document.mydaa.workduration6.value='';
  }
}
 

function empchangefn1() {
  var emp1 = document.getElementById("empid1").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid1.value=sp_lit[1];
      document.mydaa.intime1.value=sp_lit[2];
       document.mydaa.acttime1.value=sp_lit[2]; 
       document.mydaa.outtime1.value=sp_lit[3]; 
      document.mydaa.actouttime1.value=sp_lit[3]; 
     document.mydaa.tottime1.value=sp_lit[4];               
      document.mydaa.workduration1.value=sp_lit[4];  
      document.mydaa.basicsal1.value=sp_lit[5];  
      document.mydaa.ottime1.value = "0:00";
}
function empchangefn2() {
  var emp1 = document.getElementById("empid2").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid2.value=sp_lit[1];
      document.mydaa.intime2.value=sp_lit[2];
       document.mydaa.acttime2.value=sp_lit[2]; 
       document.mydaa.outtime2.value=sp_lit[3]; 
      document.mydaa.actouttime2.value=sp_lit[3]; 
     document.mydaa.tottime2.value=sp_lit[4];               
       document.mydaa.workduration2.value=sp_lit[4];     
      document.mydaa.basicsal2.value=sp_lit[5];     
      document.mydaa.ottime2.value = "0:00";  
}

function empchangefn3() {
  var emp1 = document.getElementById("empid3").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid3.value=sp_lit[1];
      document.mydaa.intime3.value=sp_lit[2];
       document.mydaa.acttime3.value=sp_lit[2]; 
       document.mydaa.outtime3.value=sp_lit[3]; 
      document.mydaa.actouttime3.value=sp_lit[3]; 
     document.mydaa.tottime3.value=sp_lit[4];               
       document.mydaa.workduration3.value=sp_lit[4];     
      document.mydaa.basicsal3.value=sp_lit[5];   
      document.mydaa.ottime3.value = "0:00";
}
function empchangefn4() {
  var emp1 = document.getElementById("empid4").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid4.value=sp_lit[1];
      document.mydaa.intime4.value=sp_lit[2];
       document.mydaa.acttime4.value=sp_lit[2]; 
       document.mydaa.outtime4.value=sp_lit[3]; 
      document.mydaa.actouttime4.value=sp_lit[3]; 
     document.mydaa.tottime4.value=sp_lit[4];               
       document.mydaa.workduration4.value=sp_lit[4];     
      document.mydaa.basicsal4.value=sp_lit[5];   
      document.mydaa.ottime4.value = "0:00";
}

function empchangefn5() {
  var emp1 = document.getElementById("empid5").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid5.value=sp_lit[1];
      document.mydaa.intime5.value=sp_lit[2];
       document.mydaa.acttime5.value=sp_lit[2]; 
       document.mydaa.outtime5.value=sp_lit[3]; 
      document.mydaa.actouttime5.value=sp_lit[3]; 
     document.mydaa.tottime5.value=sp_lit[4];               
       document.mydaa.workduration5.value=sp_lit[4];   
      document.mydaa.basicsal5.value=sp_lit[5];     
      document.mydaa.ottime5.value = "0:00";
}
function empchangefn6() {
  var emp1 = document.getElementById("empid6").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid6.value=sp_lit[1];
      document.mydaa.intime6.value=sp_lit[2];
       document.mydaa.acttime6.value=sp_lit[2]; 
       document.mydaa.outtime6.value=sp_lit[3]; 
      document.mydaa.actouttime6.value=sp_lit[3]; 
     document.mydaa.tottime6.value=sp_lit[4];               
       document.mydaa.workduration6.value=sp_lit[4];   
      document.mydaa.basicsal6.value=sp_lit[5];     
      document.mydaa.ottime6.value = "0:00";
}
function presenteefn1()
{
   var pfn1 = document.getElementById("presentid1").value;
  //alert(pfn1);
   if (pfn1 == 'AB')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
      document.mydaa.basicsal1.value='0';
     document.mydaa.latecoming1.value = '0';
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
     document.mydaa.remarks1.value='Absent';        
  }
   if (pfn1 == 'PN')
  {
      document.mydaa.shiftid1.value='';
      document.mydaa.dutyid1.value='';
      document.mydaa.intime1.value='';
       document.mydaa.acttime1.value='';
       document.mydaa.outtime1.value='';
      document.mydaa.actouttime1.value='';
     document.mydaa.tottime1.value='';        
       document.mydaa.workduration1.value='';
     document.mydaa.latecoming1.value = '0';
     document.mydaa.remarks1.value='No Duty';        
    document.getElementById("outdate1_1").hidden = true;
    document.getElementById("outdate1_2").hidden = true;
  }
   if (pfn1 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid1.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate1_1").hidden = false;
    document.getElementById("outdate1_2").hidden =false;
    document.getElementById("outdate1_1").disabled = false;
    document.getElementById("outdate1_2").disabled = false;
  }
   if (pfn1 == 'PR')
  {
     document.mydaa.dutyid1.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate1_1").disabled = true;
    document.getElementById("outdate1_2").disabled = true;
  }
}
function presenteefn2()
{
   var pfn2 = document.getElementById("presentid2").value;

   if (pfn2 == 'AB')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
      document.mydaa.basicsal2.value='0';
     document.mydaa.latecoming2.value = '0';
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
     document.mydaa.remarks2.value='Absent';       
  }

   if (pfn2 == 'PN')
  {
      document.mydaa.shiftid2.value='';
      document.mydaa.dutyid2.value='';
      document.mydaa.intime2.value='';
       document.mydaa.acttime2.value='';
       document.mydaa.outtime2.value='';
      document.mydaa.actouttime2.value='';
     document.mydaa.tottime2.value='';        
       document.mydaa.workduration2.value='';
     document.mydaa.latecoming2.value = '0';
     document.mydaa.remarks2.value='No Duty';        
    document.getElementById("outdate2_1").hidden = true;
    document.getElementById("outdate2_2").hidden = true;
  }
   if (pfn2 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid2.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate2_1").hidden = false;
    document.getElementById("outdate2_2").hidden =false;
    document.getElementById("outdate2_1").disabled = false;
    document.getElementById("outdate2_2").disabled = false;
  }
   if (pfn2 == 'PR')
  {
     document.mydaa.dutyid2.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate2_1").disabled = true;
    document.getElementById("outdate2_2").disabled = true;
  }

}
function presenteefn3()
{
   var pfn3 = document.getElementById("presentid3").value;
  //alert(pfn1);
   if (pfn3 == 'AB')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
      document.mydaa.basicsal3.value='0';
     document.mydaa.latecoming3.value = '0';
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
     document.mydaa.remarks3.value='Absent';       
  }

   if (pfn3 == 'PN')
  {
      document.mydaa.shiftid3.value='';
      document.mydaa.dutyid3.value='';
      document.mydaa.intime3.value='';
       document.mydaa.acttime3.value='';
       document.mydaa.outtime3.value='';
      document.mydaa.actouttime3.value='';
     document.mydaa.tottime3.value='';        
       document.mydaa.workduration3.value='';
     document.mydaa.latecoming3.value = '0';
     document.mydaa.remarks3.value='No Duty';        
    document.getElementById("outdate3_1").hidden = true;
    document.getElementById("outdate3_2").hidden = true;
  }
   if (pfn3 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid3.value='O';

//     document.getElementById("dutyid3").innerHTML="OUTSTATION";
    document.getElementById("outdate3_1").hidden = false;
    document.getElementById("outdate3_2").hidden =false;
    document.getElementById("outdate3_1").disabled = false;
    document.getElementById("outdate3_2").disabled = false;
  }
   if (pfn3 == 'PR')
  {
     document.mydaa.dutyid3.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate3_1").disabled = true;
    document.getElementById("outdate3_2").disabled = true;
  }

}
function presenteefn4()
{
   var pfn4 = document.getElementById("presentid4").value;
  //alert(pfn1);
   if (pfn4 == 'AB')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
      document.mydaa.basicsal4.value='0';
     document.mydaa.latecoming4.value = '0';
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
     document.mydaa.remarks4.value='Absent';       
  }

   if (pfn4 == 'PN')
  {
      document.mydaa.shiftid4.value='';
      document.mydaa.dutyid4.value='';
      document.mydaa.intime4.value='';
       document.mydaa.acttime4.value='';
       document.mydaa.outtime4.value='';
      document.mydaa.actouttime4.value='';
     document.mydaa.tottime4.value='';        
       document.mydaa.workduration4.value='';
     document.mydaa.latecoming4.value = '0';
     document.mydaa.remarks4.value='No Duty';        
    document.getElementById("outdate4_1").hidden = true;
    document.getElementById("outdate4_2").hidden = true;
  }
   if (pfn4 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid4.value='O';

//     document.getElementById("dutyid4").innerHTML="OUTSTATION";
    document.getElementById("outdate4_1").hidden = false;
    document.getElementById("outdate4_2").hidden =false;
    document.getElementById("outdate4_1").disabled = false;
    document.getElementById("outdate4_2").disabled = false;
  }
   if (pfn4 == 'PR')
  {
     document.mydaa.dutyid4.value='L';
//     document.getElementById("dutyid4").innerHTML="LOCAL"; 
    document.getElementById("outdate4_1").disabled = true;
    document.getElementById("outdate4_2").disabled = true;
  }

}
function presenteefn5()
{
   var pfn5 = document.getElementById("presentid5").value;
  //alert(pfn1);
   if (pfn5 == 'AB')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
      document.mydaa.basicsal5.value='0';
     document.mydaa.latecoming5.value = '0';
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
     document.mydaa.remarks5.value='Absent';       
  }

   if (pfn5 == 'PN')
  {
      document.mydaa.shiftid5.value='';
      document.mydaa.dutyid5.value='';
      document.mydaa.intime5.value='';
       document.mydaa.acttime5.value='';
       document.mydaa.outtime5.value='';
      document.mydaa.actouttime5.value='';
     document.mydaa.tottime5.value='';        
       document.mydaa.workduration5.value='';
     document.mydaa.latecoming5.value = '0';
     document.mydaa.remarks5.value='No Duty';        
    document.getElementById("outdate5_1").hidden = true;
    document.getElementById("outdate5_2").hidden = true;
  }
   if (pfn5 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid5.value='O';

//     document.getElementById("dutyid1").innerHTML="OUTSTATION";
    document.getElementById("outdate5_1").hidden = false;
    document.getElementById("outdate5_2").hidden =false;
    document.getElementById("outdate5_1").disabled = false;
    document.getElementById("outdate5_2").disabled = false;
  }
   if (pfn5 == 'PR')
  {
     document.mydaa.dutyid5.value='L';
//     document.getElementById("dutyid1").innerHTML="LOCAL"; 
    document.getElementById("outdate5_1").disabled = true;
    document.getElementById("outdate5_2").disabled = true;
  }

}
function presenteefn6()
{
   var pfn6 = document.getElementById("presentid6").value;
  //alert(pfn1);
   if (pfn6 == 'AB')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
      document.mydaa.basicsal6.value='0';
     document.mydaa.latecoming6.value = '0';
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
     document.mydaa.remarks6.value='Absent';       
  }

   if (pfn6 == 'PN')
  {
      document.mydaa.shiftid6.value='';
      document.mydaa.dutyid6.value='';
      document.mydaa.intime6.value='';
       document.mydaa.acttime6.value='';
       document.mydaa.outtime6.value='';
      document.mydaa.actouttime6.value='';
     document.mydaa.tottime6.value='';        
       document.mydaa.workduration6.value='';
     document.mydaa.latecoming6.value = '0';
     document.mydaa.remarks6.value='No Duty';        
    document.getElementById("outdate6_1").hidden = true;
    document.getElementById("outdate6_2").hidden = true;
  }
   if (pfn6 == 'PO')
  {
      daadate1 = document.mydaa.regdate.value;

      document.mydaa.dutyid6.value='O';

//     document.getElementById("dutyid6").innerHTML="OUTSTATION";
    document.getElementById("outdate6_1").hidden = false;
    document.getElementById("outdate6_2").hidden =false;
    document.getElementById("outdate6_1").disabled = false;
    document.getElementById("outdate6_2").disabled = false;
  }
   if (pfn6 == 'PR')
  {
     document.mydaa.dutyid6.value='L';
//     document.getElementById("dutyid4").innerHTML="LOCAL"; 
    document.getElementById("outdate6_1").disabled = true;
    document.getElementById("outdate6_2").disabled = true;
  }

}
function actchangefn1()
{ // ="intime1"   "acttime1" 
 var acth1 = document.getElementById("acthh1").value;
var actm1 = document.getElementById("actmm1").value;
 document.mydaa.acttime1.value= acth1+ ":"+actm1;
var schintime1 =  document.getElementById("intime1").value;
var sp_lit = schintime1.split(':'); 
var schintimehh1 = sp_lit[0];
var schintimemm1 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming1.value=0.0;
if ( parseInt(acth1) > parseInt(schintimehh1) )
{
         document.mydaa.latecoming1.value='33';   
}
if ( parseInt(acth1) ==  parseInt(schintimehh1)  && parseInt(actm1) >  parseInt(schintimemm1) )
{
         document.mydaa.latecoming1.value='33';   
}
}
function actchangefn2()
{
 var acth2 = document.getElementById("acthh2").value;
var actm2 = document.getElementById("actmm2").value;
 document.mydaa.acttime2.value= acth2+ ":"+actm2;
var schintime2 =  document.getElementById("intime2").value;
var sp_lit = schintime2.split(':'); 
var schintimehh2 = sp_lit[0];
var schintimemm2 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming2.value=0.0;
if ( parseInt(acth2) > parseInt(schintimehh2) )
{
         document.mydaa.latecoming2.value='33';   
}
if ( parseInt(acth2) ==  parseInt(schintimehh2)  && parseInt(actm2) >  parseInt(schintimemm2) )
{
         document.mydaa.latecoming2.value='33';   
}
}
function actchangefn3()
{
 var acth3 = document.getElementById("acthh3").value;
var actm3 = document.getElementById("actmm3").value;
 document.mydaa.acttime3.value= acth3+ ":"+actm3;
var schintime3 =  document.getElementById("intime3").value;
var sp_lit = schintime3.split(':'); 
var schintimehh3 = sp_lit[0];
var schintimemm3 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming3.value=0.0;
if ( parseInt(acth3) > parseInt(schintimehh3) )
{
         document.mydaa.latecoming3.value='33';   
}
if ( parseInt(acth3) ==  parseInt(schintimehh3)  && parseInt(actm3) >  parseInt(schintimemm3) )
{
         document.mydaa.latecoming3.value='33';   
}
}
function actchangefn4()
{
 var acth4 = document.getElementById("acthh4").value;
var actm4 = document.getElementById("actmm4").value;
 document.mydaa.acttime4.value= acth4+ ":"+actm4;
var schintime3 =  document.getElementById("intime4").value;
var sp_lit = schintime4.split(':'); 
var schintimehh4 = sp_lit[0];
var schintimemm4 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming4.value=0.0;
if ( parseInt(acth4) > parseInt(schintimehh4) )
{
         document.mydaa.latecoming4.value='33';   
}
if ( parseInt(acth4) ==  parseInt(schintimehh4)  && parseInt(actm4) >  parseInt(schintimemm4) )
{
         document.mydaa.latecoming4.value='33';   
}
}
function actchangefn5()
{
 var acth5 = document.getElementById("acthh5").value;
var actm5 = document.getElementById("actmm5").value;
 document.mydaa.acttime5.value= acth5+ ":"+actm5;
var schintime5 =  document.getElementById("intime5").value;
var sp_lit = schintime5.split(':'); 
var schintimehh5 = sp_lit[0];
var schintimemm5 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming5.value=0.0;
if ( parseInt(acth5) > parseInt(schintimehh5) )
{
         document.mydaa.latecoming5.value='33';   
}
if ( parseInt(acth5) ==  parseInt(schintimehh5)  && parseInt(actm5) >  parseInt(schintimemm5) )
{
         document.mydaa.latecoming5.value='33';   
}
}
function actchangefn6()
{
 var acth6 = document.getElementById("acthh6").value;
var actm6 = document.getElementById("actmm6").value;
 document.mydaa.acttime6.value= acth6+ ":"+actm6;
var schintime6 =  document.getElementById("intime6").value;
var sp_lit = schintime6.split(':'); 
var schintimehh6 = sp_lit[0];
var schintimemm6 = sp_lit[1];
//alert (schintimehh1);
//alert(schintimemm1);
//alert(acth1);
//alert(actm1);
document.mydaa.latecoming6.value=0.0;
if ( parseInt(acth6) > parseInt(schintimehh6) )
{
         document.mydaa.latecoming6.value='33';   
}
if ( parseInt(acth6) ==  parseInt(schintimehh6)  && parseInt(actm6) >  parseInt(schintimemm6) )
{
         document.mydaa.latecoming6.value='33';   
}
}
function outchangefn1()
{ //  workduration1 ottime1 tottime1     "acthh1  actmm1"
var outh1 = document.getElementById("outhh1").value;
var outm1 = document.getElementById("outmm1").value;
document.mydaa.actouttime1.value= outh1+ ":"+outm1;

var oldwduration1 = document.getElementById("workduration1").value;
var sp_lit1 = oldwduration1.split(':'); 
olddurhh1 = sp_lit1[0];
olddurmm1 = sp_lit1[1];

var wacthh1 = document.getElementById("acthh1").value;
var wactmm1 = document.getElementById("actmm1").value;
totoutmm1 = 0 ;
totactmm1 = 0 ;
//alert(outh1) + "out h1";
//alert(outm1) + "out m1";
//alert(wacthh1) + "act h1";
//alert(wactmm1) + "act m1";
if (wacthh1 == "0"  &&  wactmm1 == "0")
{
}
 else
  {
      if (outh1 == "0"  &&  outm1 == "0" )
     {
      }
    else
    {
      totoutmm1 = (parseInt(outh1) * 60) + parseInt(outm1) ;
      totactmm1 = (parseInt(wacthh1) * 60) + parseInt(wactmm1) ;
//alert (totoutmm1);
//alert(totactmm1);
      wodur1 = ( totoutmm1 - totactmm1 )/60;
//alert(outm1);
//alert(wactmm1);
//alert (wodur1);
      wodurhh1  =Math.trunc(wodur1);
      wodurmm1 =Math.abs( outm1 - wactmm1) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
//alert(wodurhh1);
//alert(wodurmm1);  // num.toString();
     document.mydaa.tottime1.value = wodurhh1.toString() +":"+   wodurmm1.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh1 >= olddurhh1  )
     {
              wothh1 = wodurhh1 - olddurhh1;
              wotmm1 = wodurmm1;
             document.mydaa.ottime1.value = wothh1.toString() +":"+   wotmm1.toString();
     }
     else
     {
         document.mydaa.workduration1.value = wodurhh1.toString() +":"+   wodurmm1.toString();
         document.mydaa.ottime1.value = "0:00";
     }
    // alert parseInt(outh1) * 60 ;
 //    alert parseInt(wacthh1) * 60 ;
      }
 }
//alert (totoutmm1);
//alert (totactmm1);


}
function outchangefn2()
{  //  workduration2 ottime2 tottime2     "acthh2  actmm2"
 var outh2 = document.getElementById("outhh2").value;
var outm2 = document.getElementById("outmm2").value;
 document.mydaa.actouttime2.value= outh2+ ":"+outm2;

var oldwduration2 = document.getElementById("workduration2").value;
var sp_lit1 = oldwduration2.split(':'); 
olddurhh2 = sp_lit1[0];
olddurmm2 = sp_lit1[1];

var wacthh2 = document.getElementById("acthh2").value;
var wactmm2 = document.getElementById("actmm2").value;
totoutmm2 = 0 ;
totactmm2 = 0 ;
 
if (wacthh2 == "0"  &&  wactmm2 == "0")
{
}
 else
  {
      if (outh2 == "0"  &&  outm2 == "0" )
     {
      }
    else
    {
      totoutmm2 = (parseInt(outh2) * 60) + parseInt(outm2) ;
      totactmm2 = (parseInt(wacthh2) * 60) + parseInt(wactmm2) ;
 
      wodur2 = ( totoutmm2 - totactmm2 )/60;
 
      wodurhh2  =Math.trunc(wodur2);
      wodurmm2 =Math.abs( outm2 - wactmm2) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime2.value = wodurhh2.toString() +":"+   wodurmm2.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh2 >= olddurhh2  )
     {
              wothh2 = wodurhh2 - olddurhh2;
              wotmm2 = wodurmm2;
             document.mydaa.ottime2.value = wothh2.toString() +":"+   wotmm2.toString();
     }
     else
     {
         document.mydaa.workduration2.value = wodurhh2.toString() +":"+   wodurmm2.toString();
         document.mydaa.ottime2.value = "0:00";
     }

      }
 }




}
function outchangefn3()
{  //  workduration3 ottime3     tottime3     acthh3      actmm3
 var outh3 = document.getElementById("outhh3").value;
var outm3 = document.getElementById("outmm3").value;
 document.mydaa.actouttime3.value= outh3+ ":"+outm3;


var oldwduration3 = document.getElementById("workduration3").value;
var sp_lit1 = oldwduration3.split(':'); 
olddurhh3 = sp_lit1[0];
olddurmm3 = sp_lit1[1];

var wacthh3 = document.getElementById("acthh3").value;
var wactmm3 = document.getElementById("actmm3").value;
totoutmm3 = 0 ;
totactmm3 = 0 ;
 
if (wacthh3 == "0"  &&  wactmm3 == "0")
{
}
 else
  {
      if (outh3 == "0"  &&  outm3 == "0" )
     {
      }
    else
    {
      totoutmm3 = (parseInt(outh3) * 60) + parseInt(outm3) ;
      totactmm3 = (parseInt(wacthh3) * 60) + parseInt(wactmm3) ;
 
      wodur3 = ( totoutmm3 - totactmm3 )/60;
 
      wodurhh3  =Math.trunc(wodur3);
      wodurmm3 =Math.abs( outm3 - wactmm3) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime3.value = wodurhh3.toString() +":"+   wodurmm3.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh3 >= olddurhh3  )
     {
              wothh3 = wodurhh3 - olddurhh3;
              wotmm3 = wodurmm3;
             document.mydaa.ottime3.value = wothh3.toString() +":"+   wotmm3.toString();
     }
     else
     {
         document.mydaa.workduration3.value = wodurhh3.toString() +":"+   wodurmm3.toString();
         document.mydaa.ottime3.value = "0:00";
     }

      }
 }

}
function outchangefn4()
{  //  workduration4 ottime4     tottime4     acthh4      actmm4
 var outh4 = document.getElementById("outhh4").value;
var outm4 = document.getElementById("outmm4").value;
 document.mydaa.actouttime4.value= outh4+ ":"+outm4;

var oldwduration4 = document.getElementById("workduration4").value;
var sp_lit1 = oldwduration4.split(':'); 
olddurhh4 = sp_lit1[0];
olddurmm4 = sp_lit1[1];

var wacthh4 = document.getElementById("acthh4").value;
var wactmm4 = document.getElementById("actmm4").value;
totoutmm4 = 0 ;
totactmm4 = 0 ;
 
if (wacthh4 == "0"  &&  wactmm4 == "0")
{
}
 else
  {
      if (outh4 == "0"  &&  outm4 == "0" )
     {
      }
    else
    {
      totoutmm4 = (parseInt(outh4) * 60) + parseInt(outm4) ;
      totactmm4 = (parseInt(wacthh4) * 60) + parseInt(wactmm4) ;
 
      wodur4 = ( totoutmm4 - totactmm4 )/60;
 
      wodurhh4  =Math.trunc(wodur4);
      wodurmm4 =Math.abs( outm4 - wactmm4) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime4.value = wodurhh4.toString() +":"+   wodurmm4.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh4 >= olddurhh4  )
     {
              wothh4 = wodurhh4 - olddurhh4;
              wotmm4 = wodurmm4;
             document.mydaa.ottime4.value = wothh4.toString() +":"+   wotmm4.toString();
     }
     else
     {
         document.mydaa.workduration4.value = wodurhh4.toString() +":"+   wodurmm4.toString();
         document.mydaa.ottime4.value = "0:00";
     }

      }
 }
}
function outchangefn5()
{  //  workduration5 ottime5    tottime5     acthh5      actmm5
 var outh5 = document.getElementById("outhh5").value;
var outm5 = document.getElementById("outmm5").value;
 document.mydaa.actouttime5.value= outh5+ ":"+outm5;


var oldwduration5 = document.getElementById("workduration5").value;
var sp_lit1 = oldwduration5.split(':'); 
olddurhh5 = sp_lit1[0];
olddurmm5 = sp_lit1[1];

var wacthh5 = document.getElementById("acthh5").value;
var wactmm5 = document.getElementById("actmm5").value;
totoutmm5 = 0 ;
totactmm5 = 0 ;
 
if (wacthh5 == "0"  &&  wactmm5 == "0")
{
}
 else
  {
      if (outh5 == "0"  &&  outm5 == "0" )
     {
      }
    else
    {
      totoutmm5 = (parseInt(outh5) * 60) + parseInt(outm5) ;
      totactmm5 = (parseInt(wacthh5) * 60) + parseInt(wactmm5) ;
 
      wodur5 = ( totoutmm5 - totactmm5 )/60;
 
      wodurhh5  =Math.trunc(wodur5);
      wodurmm5 =Math.abs( outm5 - wactmm5) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime5.value = wodurhh5.toString() +":"+   wodurmm5.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh5 >= olddurhh5  )
     {
              wothh5 = wodurhh5 - olddurhh5;
              wotmm5 = wodurmm5;
             document.mydaa.ottime5.value = wothh5.toString() +":"+   wotmm5.toString();
     }
     else
     {
         document.mydaa.workduration5.value = wodurhh5.toString() +":"+   wodurmm5.toString();
         document.mydaa.ottime5.value = "0:00";
     }

      }
 }



}
function outchangefn6()
{   //  workduration6 ottime6    tottime6     acthh6      actmm6
 var outh6 = document.getElementById("outhh6").value;
var outm6 = document.getElementById("outmm6").value;
 document.mydaa.actouttime6.value= outh6+ ":"+outm6;


var oldwduration6 = document.getElementById("workduration6").value;
var sp_lit1 = oldwduration6.split(':'); 
olddurhh6 = sp_lit1[0];
olddurmm6 = sp_lit1[1];

var wacthh6 = document.getElementById("acthh6").value;
var wactmm6 = document.getElementById("actmm6").value;
totoutmm6 = 0 ;
totactmm6 = 0 ;
 
if (wacthh6 == "0"  &&  wactmm6 == "0")
{
}
 else
  {
      if (outh6 == "0"  &&  outm6 == "0" )
     {
      }
    else
    {
      totoutmm6 = (parseInt(outh6) * 60) + parseInt(outm6) ;
      totactmm6 = (parseInt(wacthh6) * 60) + parseInt(wactmm6) ;
 
      wodur6 = ( totoutmm6 - totactmm6 )/60;
 
      wodurhh6  =Math.trunc(wodur6);
      wodurmm6 =Math.abs( outm6 - wactmm6) ; //   parseFloat( (( totoutmm1 - totactmm1 )/60) - ( Math.trunc(wodur1)) );
 
     document.mydaa.tottime6.value = wodurhh6.toString() +":"+   wodurmm6.toString(); //    str(parseFloat(wodurmm1),2);
     if (  wodurhh6 >= olddurhh6  )
     {
              wothh6 = wodurhh6 - olddurhh6;
              wotmm6 = wodurmm6;
             document.mydaa.ottime6.value = wothh6.toString() +":"+   wotmm6.toString();
     }
     else
     {
         document.mydaa.workduration6.value = wodurhh6.toString() +":"+   wodurmm6.toString();
         document.mydaa.ottime6.value = "0:00";
     }

      }
 }

}
function rtchangefn1()
{
// alert("h");
 var rth1 = document.getElementById("rthh1").value;
var rtm1 = document.getElementById("rtmm1").value;
 document.mydaa.reporttime1.value= rth1+ ":"+rtm1;
}
function rtchangefn2()
{
// alert("h");
 var rth2 = document.getElementById("rthh2").value;
var rtm2 = document.getElementById("rtmm2").value;
 document.mydaa.reporttime2.value= rth2+ ":"+rtm2;
}
function rtchangefn3()
{
// alert("h");
 var rth3 = document.getElementById("rthh3").value;
var rtm3 = document.getElementById("rtmm3").value;
 document.mydaa.reporttime3.value= rth3+ ":"+rtm3;
}
function rtchangefn4()
{
// alert("h");
var rth4 =  document.getElementById("rthh4").value;
var rtm4 = document.getElementById("rtmm4").value;
 document.mydaa.reporttime4.value= rth4+ ":"+rtm4;
}
function rtchangefn5()
{
// alert("h");
var rth5 =  document.getElementById("rthh5").value;
var rtm5 = document.getElementById("rtmm5").value;
 document.mydaa.reporttime5.value= rth5+ ":"+rtm5;
}
function rtchangefn6()
{
// alert("h");
var rth6 =  document.getElementById("rthh6").value;
var rtm6 = document.getElementById("rtmm6").value;
 document.mydaa.reporttime6.value= rth6+ ":"+rtm6;
}
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
 
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
 
@media screen and (max-height: 400px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttonsmall {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 9px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
 
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/daareports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>admin</a>


</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:15px;cursor:pointer;color="black">Daily Attendence Register </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>

<a  href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>Back</a>
 

<!--   <form  name="mydaa" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> -->
  <?php
/* echo form_open('Home_AutoRenta/new_user_registration');  */

 $attributes = array('id' => 'mydaa' ,'name' =>'mydaa');
echo form_open('Home_AutoRenta/new_drr_registration', $attributes);



    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
     <tr> 
           <td><span style="font-size:14px;cursor:pointer;color="black">Enter Date: </td>
          <td> <span style="font-size:14px;cursor:pointer;color="black"><input type="date" name="regdate" id="regdate" value="<?php echo date('Y-m-d');?>" /> </td>
     </tr>
   <table>
   <br>
   <table width="100%" border="1">  
        <tr>  
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   Emp Name </td>
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   P/A</td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black">   Duty </td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black"> Shift </td> 
             <td>  <span style="font-size:12px;cursor:pointer;color="black"> Customer <br> Name</td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black"> Passenger <br> Name</td>
        <td >  <span style="font-size:12px;cursor:pointer;width:100px;color="black">   </td>  <!-- reporting time -->
             <td>  <span style="font-size:12px;cursor:pointer;color="black">  In/<br>Actual Time </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  Out/<br>Actual Time </td>
           <td>  <span style="font-size:12px;cursor:pointer;color="black">  work <br>Duration </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  OT Time </td>
         <td>  <span style="font-size:12px;cursor:pointer;color="black"> Total <br> Duration </td>
<!--        <td>  <span style="font-size:12px;cursor:pointer;color="black">  Status </td> -->
        <td>  <span style="font-size:12px;cursor:pointer;color="black"> Remarks </td>
        <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>
       <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>
         </tr>
         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid1" id = "empid1" onchange="empchangefn1()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data as $data) { 
                         echo "<option value=". $data->ecode ."~".  $data->shift . "~" .  $data->intime . "~" . $data->outtime . "~" . $data->tottime . "~" . $data->basicsal. ">" .   $data->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
               </td>
              <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid1" id = "presentid1"   onchange="presenteefn1()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid1" id = "dutyid1" onBlur="dutychangefn1()"  style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate1_1"    id="outdate1_1"  value="<?php echo date('Y-m-d');?>"/> &nbsp; &nbsp;
                      <input type="date" name="outdate1_2"     id="outdate1_2"  onBlur="chkoutdatefn1()" value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td> 


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid1" id = "shiftid1"   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid1" id = "custid1" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_1 as $data2_1) { 
                         echo "<option value=". $data2_1->id . ">" .   $data2_1->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass1" id="pass1" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td >
                    <span style="font-size:12px;cursor:pointer;color="black"> 

                     <input type="text"   hidden  name="reporttime1" id="reporttime1"  readonly   value="" style="font-size:12px;width:80px;" >
  
                 <select name="rthh1" id="rthh1" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm1" onchange="rtchangefn1()" id="rtmm1" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                    </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime1" id="intime1" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime1" id="acttime1" readonly  value="" style="font-size:12px;width:80px;" >
                <select name="acthh1" id="acthh1">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm1" onchange="actchangefn1()" id="actmm1">
                     <option value="0">MM</option>
                    <?php 
   /*
                              for ($x = 0; $x <= 61; $x=$x+15) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                     echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                        ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime1" id="outtime1" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime1" id="actouttime1" readonly  value="" style="font-size:12px;width:80px;" >
                   <select name="outhh1" id="outhh1">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm1" onchange="outchangefn1()" id="outmm1">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 61; $x=$x+15) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration1" id="workduration1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime1" id="ottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime1" id="tottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status1" id="status1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks1" id="remarks1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal1" id="basicsal1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="latecoming1"  hidden  id="latecoming1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>

           </tr>
   
<!-- line 2 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid2" id = "empid2" onchange="empchangefn2()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_2 as $data_2) { 
                         echo "<option value=". $data_2->ecode ."~".  $data_2->shift . "~" .  $data_2->intime . "~" . $data_2->outtime . "~" . $data_2->tottime . "~" . $data_2->basicsal. ">" .   $data_2->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid2" id = "presentid2" onchange="presenteefn2()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid2" id = "dutyid2" onchange="dutychangefn2()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate2_1"   id="outdate2_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp;
                      <input type="date" name="outdate2_2"  onBlur="chkoutdatefn2()"  id="outdate2_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>


               <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid2" id = "shiftid2" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid2" id = "custid2" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_2 as $data2_2) { 
                         echo "<option value=". $data2_2->id . ">" .   $data2_2->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass2" id="pass2" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime2" id="reporttime2" hidden readonly value="" style="font-size:12px;width:80px;" >

                 <select name="rthh2" id="rthh2" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm2" onchange="rtchangefn2()" id="rtmm2" hidden >
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime2" id="intime2" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime2" id="acttime2" value="" readonly style="font-size:12px;width:80px;" >
               <select name="acthh2" id="acthh2">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm2" onchange="actchangefn2()" id="actmm2">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime2" id="outtime2" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime2" id="actouttime2" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh2" id="outhh2">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm2" onchange="outchangefn2()" id="outmm2">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration2" id="workduration2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime2" id="ottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime2" id="tottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status2" id="status2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks2" id="remarks2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal2" id="basicsal2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming2"  id="latecoming2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>
    

<!-- line 3 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid3" id = "empid3" onchange="empchangefn3()"   style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_3 as $data_3) { 
                         echo "<option value=". $data_3->ecode ."~".  $data_3->shift . "~" .  $data_3->intime . "~" . $data_3->outtime . "~" . $data_3->tottime . "~" . $data_3->basicsal. ">" .   $data_3->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid3" id = "presentid3" onchange="presenteefn3()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid3" id = "dutyid3" onchange="dutychangefn3()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate3_1"   id="outdate3_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp;
                      <input type="date" name="outdate3_2" onBlur="chkoutdatefn3()"     id="outdate3_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td> 
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid3" id = "shiftid3" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid3" id = "custid3" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_3 as $data2_3) { 
                         echo "<option value=". $data2_3->id . ">" .   $data2_3->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass3" id="pass3" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime3" id="reporttime3" hidden  readonly value="" style="font-size:12px;width:80px;" >

                 <select name="rthh3" id="rthh3" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm3" onchange="rtchangefn3()" id="rtmm3" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime3" id="intime3" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime3" id="acttime3"  readonly value="" style="font-size:12px;width:80px;" >
                   <select name="acthh3" id="acthh3">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm3" onchange="actchangefn3()" id="actmm3">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime3" id="outtime3" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime3" id="actouttime3" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh3" id="outhh3">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm3" onchange="outchangefn3()" id="outmm3">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration3" id="workduration3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime3" id="ottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime3" id="tottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status3" id="status3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks3" id="remarks3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal3" id="basicsal3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming3" id="latecoming3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>


<!-- line 4 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid4" id = "empid4"  onchange="empchangefn4()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_4 as $data_4) { 
                         echo "<option value=". $data_4->ecode ."~".  $data_4->shift . "~" .  $data_4->intime . "~" . $data_4->outtime . "~" . $data_4->tottime . "~" . $data_4->basicsal. ">" .   $data_4->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid4" id = "presentid4" onchange="presenteefn4()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid4" id = "dutyid4" onchange="dutychangefn4()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate4_1"   id="outdate4_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate4_2"  onBlur="chkoutdatefn4()"   id="outdate4_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid4" id = "shiftid4" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid4" id = "custid4" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_4 as $data2_4) { 
                         echo "<option value=". $data2_4->id . ">" .   $data2_4->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass4" id="pass4" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime4" id="reporttime4"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh4" id="rthh4" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm4" onchange="rtchangefn4()" id="rtmm4" hidden >
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime4" id="intime4" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime4" id="acttime4" value="" readonly style="font-size:12px;width:80px;" >
               <select name="acthh4" id="acthh4">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm4" onchange="actchangefn4()" id="actmm4">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime4" id="outtime4" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime4" id="actouttime4" readonly value="" style="font-size:12px;width:80px;" >
                    <select name="outhh4" id="outhh4">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm4" onchange="outchangefn4()" id="outmm4">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration4" id="workduration4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime4" id="ottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime4" id="tottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status4" id="status4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks4" id="remarks4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal4" id="basicsal4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming4" id="latecoming4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 5 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid5" id = "empid5" onchange="empchangefn5()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_5 as $data_5) { 
                          echo "<option value=". $data_5->ecode ."~".  $data_5->shift . "~" .  $data_5->intime . "~" . $data_5->outtime . "~" . $data_5->tottime . "~" . $data_5->basicsal. ">" .   $data_5->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid5" id = "presentid5" onchange="presenteefn5()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                        echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid5" id = "dutyid5" onchange="dutychangefn5()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date"  name="outdate5_1"   id="outdate5_1" value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate5_2"  onBlur="chkoutdatefn5()"   id="outdate5_2"  value="<?php echo date('Y-m-d');?>" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid5" id = "shiftid5" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid5" id = "custid5" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_5 as $data2_5) { 
                         echo "<option value=". $data2_5->id . ">" .   $data2_5->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass5 id="pass5" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime5" id="reporttime5" hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh5" id="rthh5" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm5" onchange="rtchangefn5()" hidden  id="rtmm5">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime5" id="intime5" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime5" id="acttime5" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="acthh5" id="acthh5">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm5" onchange="actchangefn5()" id="actmm5">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime5" id="outtime5" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime5" id="actouttime5"  readonly value="" style="font-size:12px;width:80px;" >
                    <select name="outhh5" id="outhh5">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm5" onchange="outchangefn5()" id="outmm5">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration5" id="workduration5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime5" id="ottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime5" id="tottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status5" id="status5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks5" id="remarks5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal5" id="basicsal5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming5" id="latecoming5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 6 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid6" id = "empid6" onchange="empchangefn6()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_6 as $data_6) { 
                         echo "<option value=". $data_6->ecode ."~".  $data_6->shift . "~" .  $data_6->intime . "~" . $data_6->outtime . "~" . $data_6->tottime . "~" . $data_6->basicsal. ">" .   $data_6->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid6" id = "presentid6" onchange="presenteefn6()" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid6" id = "dutyid6" onchange="dutychangefn6()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php                  
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate6_1"   id="outdate6_1"  value="<?php echo date('Y-m-d');?>" /> &nbsp;&nbsp; 
                      <input type="date" name="outdate6_2"   onBlur="chkoutdatefn6()"  id="outdate6_2"  value="<?php echo date('Y-m-d');?>"/>
                     </span> 
               </td>
              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 
                   <input type="text"   name="shiftid6" id = "shiftid6" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid6" id = "custid6" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_6 as $data2_6) { 
                         echo "<option value=". $data2_6->id . ">" .   $data2_6->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass6" id="pass6" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime6" id="reporttime6"  hidden  readonly value="" style="font-size:12px;width:80px;" >
                 <select name="rthh6" id="rthh6" hidden >
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="rtmm6" onchange="rtchangefn6()" hidden  id="rtmm6">
                     <option value="0">MM</option>
                    <?php 
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
 
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime6" id="intime6" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="acttime6" id="acttime6" readonly value="" style="font-size:12px;width:80px;" >
               <select name="acthh6" id="acthh6">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 23; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="actmm6" onchange="actchangefn6()" id="actmm6">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime6" id="outtime6" value="" style="font-size:12px;width:80px;" > <br>
                    <input type="text" name="actouttime6" id="actouttime6" readonly value="" style="font-size:12px;width:80px;" >
                   <select name="outhh6" id="outhh6">
                     <option value="0">HH</option>
                    <?php 
                              for ($x = 0; $x <= 49; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
                     ?>
                    </select>
      
                   <select name="outmm6" onchange="outchangefn6()" id="outmm6">
                     <option value="0">MM</option>
                    <?php 
/*
                              for ($x = 0; $x <= 59; $x++) {
                                          echo "<option value=". $x . ">" .  $x  . "</option>";
                              }
*/
                      echo '<option value="00">00</option>';
                      echo '<option value="15">15</option>';
                      echo '<option value="30">30</option>';           
                      echo '<option value="45">45</option>';
                      echo '<option value="50">50</option>'; 
                      echo '<option value="59">59</option>'; 
                     ?>
                    </select>
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration6" id="workduration6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime6" id="ottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime6" id="tottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status6" id="status6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks6" id="remarks6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal6" id="basicsal6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="latecoming6" id="latecoming6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

       </table>
       <br>

   
 <!--
<center> <input type="submit"  name="dsmit" id="dsmit" value ="Submit Daily Register" >  </center>
 
<br>
</form>   -->
<?php

echo form_submit('submit', 'Create Daily Attendence Register Entry ');
echo form_close();
?>
</div>
</div>
</body>
</html>