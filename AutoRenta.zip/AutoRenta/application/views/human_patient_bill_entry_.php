<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
defined('BASEPATH') OR exit('No direct script access allowed');
//if (isset($this->session->userdata['logged_in'])) 
//{
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
//}
//$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN ";
//$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';
//
if (isset($this->session->userdata['logged_in']))
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
{
  header("location: login");
}
if ($patient_class_value == 'HUMAN')
{
$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN PanchaGavya Clinic ";
$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';
}
else
{
$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN Sai Vets Clinic ";
$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';
}
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
if (isset($_POST['paysubmit'])) 
{

$xpid = $_SESSION["global_patient_id"];
$xpnm = $_SESSION["global_patient_name"];

$xsbcash1 = $_POST["sbcash1"];  // cash details
$xcashpddate = $_POST["cashpddate"];
$xcashpdamt = $_POST["cashpdamt"];
$xcashpdinstru = $_POST["cashpdinstru"];
$xcashpdbanknm = $_POST["cashpdbanknm"];
$xcashpdbankbr = $_POST["cashpdbankbr"];

$xsbcash2 = $_POST["sbcash2"]; // cheque details
$xchequepddate = $_POST["chequepddate"];
$xchequepdamt = $_POST["chequepdamt"];
$xchequepdinstru = $_POST["chequepdinstru"];
$xchequepdbanknm = $_POST["chequepdbanknm"];
$xchequepdbankbr = $_POST["chequepdbankbr"];

$xsbcash3 = $_POST["sbcash3"]; // debit or credit details
$xcardpddate = $_POST["cardpddate"];
$xcardpdamt = $_POST["cardpdamt"];
$xcardpdinstru = $_POST["cardpdinstru"];
$xcardpdbanknm = $_POST["cardpdbanknm"];
$xcardpdbankbr = $_POST["cardpdbankbr"];

$xsbcash4 = $_POST["sbcash4"]; // other mode details
$xothermode = $_POST["othermode"];
$xotherpddate = $_POST["otherpddate"];
$xotherpdamt = $_POST["otherpdamt"];
$xotherpdinstru = $_POST["otherpdinstru"];
$xotherpdbanknm = $_POST["otherpdbanknm"];
$xotherpdbankbr = $_POST["otherpdbankbr"];

$inst = 0;
if ($xcashpdamt > 0  ) // cash
{ 
  $inst = $inst + 1;
}
if ($xchequepdamt > 0 ) // cheque details
{
  $inst = $inst + 1;
}
if ($xcardpdamt > 0 ) // debit or credit details
{
  $inst = $inst + 1;
}
if ($xotherpdamt > 0 ) // other mode details
{
  $inst = $inst + 1;
}

if ($inst == 1 )
{
$xbal = 0.0;
$totamt =0.0;
$totpaid = 0.00;

if ($xcashpdamt > 0 ) // cash details
{
    // echo $xsbcash1;
    // echo $_SESSION["global_patient_id"] ;  // gole
    $sql1 = "Select * from saleshumanstocklist where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash1 . "'";
    $query1 = $this->db->query($sql1);  
    foreach ($query1->result() as $row1)
    {  // 4.1 
       if ($totpaid == 0 )
       {
          $totpaid = $row1->paidamount;
       }
       $totamt = $totamt + $row1->itemtotal;
    }
    $xbal = ($totamt-$totpaid)  - $xcashpdamt;
    $sql = "Insert into saleshumanbill  
            (salesbill,patientid,patientname,billamount,paidamount,balanceamount,datepaid,modeofpayment,bankname,bankbranch) 
            values 
            ('$xsbcash1','$xpid','$xpnm','$totamt','$xcashpdamt','$xbal','$xcashpddate','CASH','N/A','N/A')";
    $query = $this->db->query($sql);
    $sql = "Update saleshumanstocklist set paidamount = paidamount + " . $xcashpdamt . " , balanceamount =  " . $xbal . " where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash1 . "'";
    $query = $this->db->query($sql);
} // cash details over

// echo " chq " .  $xchequepdamt ;
if ($xchequepdamt > 0 ) // cheque details
{
    // echo $xsbcash1;
    // echo $_SESSION["global_patient_id"] ;  // gole
    $sql1 = "Select * from saleshumanstocklist where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash2 . "'";
    $query1 = $this->db->query($sql1);  
    foreach ($query1->result() as $row1)
    {  // 4.1 
       if ($totpaid == 0 )
       {
          $totpaid = $row1->paidamount;
       }
       $totamt = $totamt + $row1->itemtotal;
    }
    $xbal = ($totamt-$totpaid)  - $xchequepdamt;
    $sql = "Insert into saleshumanbill  
            (salesbill,patientid,patientname,billamount,paidamount,balanceamount,datepaid,modeofpayment,bankname,bankbranch) 
            values 
            ('$xsbcash2','$xpid','$xpnm','$totamt','$xchequepdamt','$xbal','$xchequepddate','CHEQUE','$xchequepdbanknm','$xchequepdbankbr')";
    $query = $this->db->query($sql);
    $sql = "Update saleshumanstocklist set paidamount = paidamount + " . $xchequepdamt . " , balanceamount =  " . $xbal . " where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash2 . "'";
    $query = $this->db->query($sql);
} // cheque details over
//echo " card " .  $xcardpdamt ;
if ($xcardpdamt > 0 ) // debit or credit details
{
    // echo $xsbcash1;
    // echo $_SESSION["global_patient_id"] ;  // gole
    $sql1 = "Select * from saleshumanstocklist where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash3 . "'";
    $query1 = $this->db->query($sql1);  
    foreach ($query1->result() as $row1)
    {  // 4.1 
       if ($totpaid == 0 )
       {
          $totpaid = $row1->paidamount;
       }
       $totamt = $totamt + $row1->itemtotal;
    }
    $xbal = ($totamt-$totpaid)  - $xcardpdamt;
    $sql = "Insert into saleshumanbill  
            (salesbill,patientid,patientname,billamount,paidamount,balanceamount,datepaid,modeofpayment,bankname,bankbranch) 
            values 
            ('$xsbcash3','$xpid','$xpnm','$totamt','$xcardpdamt','$xbal','$xcardpddate','DEBIT/CREDIT CARD','$xcardpdbanknm','$xcardpdbankbr')";
    $query = $this->db->query($sql);
    $sql = "Update saleshumanstocklist set paidamount = paidamount + " . $xcardpdamt . " , balanceamount =  " . $xbal . " where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash3 . "'";
    $query = $this->db->query($sql);
} // debit or credit card details over
//echo " o ther " .  $xotherpdamt ;
if ($xotherpdamt > 0 ) // other mode details
{
    // echo $xsbcash1;
    // echo $_SESSION["global_patient_id"] ;  // gole
    $sql1 = "Select * from saleshumanstocklist where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash4 . "'";
    $query1 = $this->db->query($sql1);  
    foreach ($query1->result() as $row1)
    {  // 4.1 
       if ($totpaid == 0 )
       {
          $totpaid = $row1->paidamount;
       }
       $totamt = $totamt + $row1->itemtotal;
    }
    $xbal = ($totamt-$totpaid)  - $xotherpdamt;
    $sql = "Insert into saleshumanbill  
            (salesbill,patientid,patientname,billamount,paidamount,balanceamount,datepaid,modeofpayment,bankname,bankbranch,otherinstrument) 
            values 
            ('$xsbcash4','$xpid','$xpnm','$totamt','$xotherpdamt','$xbal','$xotherpddate','$xothermode','$xotherpdbanknm','$xotherpdbankbr','$xotherpdinstru')";
    $query = $this->db->query($sql);
    $sql = "Update saleshumanstocklist set paidamount = paidamount + " . $xotherpdamt . " , balanceamount =  " . $xbal . " where patientid = " . $_SESSION["global_patient_id"] . " and salesbill = '" . $xsbcash4 . "'";
    $query = $this->db->query($sql);
} // other mode details over


}
else
{
  $msg = " All Cash , Cheque , Credit Card , Other Type can not be selected ";
  echo "<html><body><br><br><br><br><h2> <marquee>" . $msg . "</marquee> </h2> </body> </html>";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})


function onSelectChangeqty1()
{
    var sel = document.getElementById('sid1');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids1.value=sp_lit[0];
    document.mypetdetails1.hsc1.value=sp_lit[1];
    document.mypetdetails1.rate1.value=sp_lit[2];
    document.mypetdetails1.gst1.value=sp_lit[3];
}

function onSelectChangeqty2()
{
    var sel = document.getElementById('sid2');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids2.value=sp_lit[0];
    document.mypetdetails1.hsc2.value=sp_lit[1];
    document.mypetdetails1.rate2.value=sp_lit[2];
    document.mypetdetails1.gst2.value=sp_lit[3];
}

function onSelectChangeqty3()
{
    var sel = document.getElementById('sid3');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids3.value=sp_lit[0];
    document.mypetdetails1.hsc3.value=sp_lit[1];
    document.mypetdetails1.rate3.value=sp_lit[2];
    document.mypetdetails1.gst3.value=sp_lit[3];
}

function onSelectChangeqty4()
{
    var sel = document.getElementById('sid4');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids4.value=sp_lit[0];
    document.mypetdetails1.hsc4.value=sp_lit[1];
    document.mypetdetails1.rate4.value=sp_lit[2];
    document.mypetdetails1.gst4.value=sp_lit[3];
}

function onSelectChangeqty5()
{
    var sel = document.getElementById('sid5');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids5.value=sp_lit[0];
    document.mypetdetails1.hsc5.value=sp_lit[1];
    document.mypetdetails1.rate5.value=sp_lit[2];
    document.mypetdetails1.gst5.value=sp_lit[3];
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_new_sales_medicines"; ?>'>Medicines to Patient (Sales Bill) </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_approve_purchase_medicines"; ?>'>Approve Sales billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_return_medicines"; ?>'>Return By Patient (not required)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reject_medicines"; ?>'>Rejection by Patient (Replacement)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:20px;cursor:pointer;color="black">Patients Sales Bill Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Payment Made By Patient </h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
        <tr>
              <td> 
                      <span style="font-size:15px;cursor:pointer;color="black">Select Patient :
                      <select name="patientid" id = "patientid" style="width:100px;">
                      <option value="0">patientname </option>  
                         <?php 
                        foreach ($data1 as $data1) { 
                         echo "<option value=". $data1->id . ">" .   $data1->nameofperson  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
               </td>
           </tr>
           <tr> 
              <td> 
                      <span style="font-size:15px;cursor:pointer;color="black"> 
    
                       <button type="submit" class="button" id="show1" name="show1" > Paid Bills </button> &nbsp;&nbsp;
                       <button type="submit" class="button" id="show2" name="show2" >Pending Bills </button>  
                      </span>                          
               </td>
          </tr>
       </table>
       <br>
       <table>
          <tr>              
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value= "<?php 

                         if ( (isset($_POST['show1'])) or (isset($_POST['show2'])) )
                         { 
                           $mypatientid = $_POST['patientid']; 
                           $_SESSION['global_patient_id'] = $_POST['patientid'] ; 
                           $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                           $query = $this->db->query($sql);   
                           foreach ($query->result() as $row) 
                           { 
                             $mypatientname = $row->nameofperson; 
                             $_SESSION['global_patient_name']= $row->nameofperson;  
                             echo $row->nameofperson;  
                           }    

                         }  

                         ?>" placeholder="name of person "> 
                        <br>
                        <input type="text" id="personid" name="personid" readonly value="<?php 
                             if ( (isset($_POST['show1'])) or (isset($_POST['show2'])) )
                             {
                               echo $_POST['patientid'];
                             } 

                         ?>">
                         </span> 
              </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Full Address: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="<?php 

                      if  ( (isset($_POST['show1'])) or (isset($_POST['show2'])) )
                      { 
                         $mypatientid = $_POST['patientid']; 
                         $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                         $query = $this->db->query($sql);   
                         foreach ($query->result() as $row) 
                         { 
                            echo nl2br($row->ad1 . " "  .  $row->ad2  . " " . $row->pincode);   
                         }    
                      }  

                       ?> " placeholder="full address "> 
                       </span> </td>
            
         </tr>
         <tr>
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Message : </span></td>
             <td> <input type="text" name="messageid"  placeholder="Message" id="messageid" value="<?php 
                  if ( (isset($_POST['show1'])) or (isset($_POST['show2'])) )
                  {
                       $msg = "Showing Records ..";  
                       echo $msg;  
                  } 
                  ?>" > </td>
        </tr>
 
 </table>
<?php //1
if (isset($_POST['show1'])) // paid bills
{   // 2
?>
  <br>
  <center>
  <h3> Paid Bills : for patient name <?php echo $_SESSION['global_patient_name']; ?> </h3>
<?php  // 3
  $sql ="SELECT * FROM saleshumanbill where patientid = " . $_SESSION["global_patient_id"] ; // . " and " . " salesbill = '" . $_SESSION["global_sales_billno"] . "'"  ; 
  $query = $this->db->query($sql);  
  $i=0; 
  $_SESSION['global_sales_record'] = 0;
  $txt = '<table border="1">';// 
  echo $txt;
  $txt = '<tr><td>Bill No </td><td>Date  </td><td>Bill Amount <br> Mode of Payment </td><td> Bank Name <br> Branch Address</td><td>Paid Amount  </td><td>Balance Amount    </td> </tr>'; 
  echo $txt;
  foreach ($query->result() as $row)
  {  // 3.1 
     $i++;
     $txt = '<tr><td>'. $row->salesbill . ' <td>'. $row->datepaid .  '</td><td>' . $row->billamount . "<br>" . $row->modeofpayment . '</td><td>'.  $row->bankname  . "<br>" . $row->bankbranch .  '</td><td>'. $row->paidamount .  '</td><td>' . $row->balanceamount .  '</td></tr>';
     echo $txt;
  } // 3.1 
  if ($i == 0 )
  {
     $txt = '<tr><td>Full bill is unpaid </td> </tr>';
     echo $txt;
  }
  $txt = '</table>';// 
  echo $txt;
}
if (isset($_POST['show2'])) // pending bills
{ ?>
  <br>
  <center>
  <h3> Full / Partial Pending Bills : for patient name <?php echo $_SESSION['global_patient_name']; ?> </h3>
<?php  // 3
  $gtotal = 0.00;
  $gbalamt = 0.00;
  $sql ="SELECT DISTINCT patientid,patientname,salesbill ,paidamount,balanceamount FROM `saleshumanstocklist` where patientid = " . $_SESSION["global_patient_id"]  . " and " . " ( paidamount = 0 or balanceamount > 0 ) "  ; 
  $query = $this->db->query($sql);  
  $i=0; 
  $_SESSION['global_sales_record'] = 0;
?>
  <table border="1"> 
  <tr> <td> Patient ID </td> <td>Sales Bill </td> <td> Paid Amount </td> <td> Balance Amount </td> <td> Total Bill Amount </td> <td>Paid by Patient </td> </tr>
<?php
  foreach ($query->result() as $row)
  {  // 3.1 
     $totamt = 0.00;
     $sql1 = "Select * from saleshumanstocklist where patientid = " . $row->patientid . " and salesbill = '" . $row->salesbill . "'";
     $query1 = $this->db->query($sql1);  
     foreach ($query1->result() as $row1)
     {  // 4.1 
       $totamt = $totamt + $row1->itemtotal;
       $gtotal = $gtotal + $row1->itemtotal;
     } //  4.1 over
     $i++;
//     $txt = '<tr><td>' . $row->patientid . '</td><td>'. $row->salesbill . '</td><td>' .  $row->paidamount 
 //            . '</td><td>' . $row->balanceamount .  '</td><td>' . $totamt . '</td>
 //            <td> <input type="checkbox" name="selectpayment[]" id="selectpayment[]"> . '</td>
 //            </tr>';
//     echo $txt;

 $txt = '<tr><td>' . $row->patientid . '</td><td>'. $row->salesbill . '</td><td>' .  $row->paidamount 
           . '</td><td>' . $row->balanceamount .  '</td><td>' . $totamt . '</td>' 
           . '<td>' .  ($totamt - $row->paidamount) . '</td></tr>';
      echo $txt;
      $gbalamt = $gbalamt + ($totamt - $row->paidamount);

  } // 3.1 
  
?>
</table>
<br>
<hr>
<h2> Enter Payment details below total bill is rs <?php echo $gbalamt; ?> </h2>
<hr>
<?php
  $sqlsbcash ="SELECT DISTINCT patientid,patientname,salesbill ,paidamount,balanceamount FROM `saleshumanstocklist` where patientid = " . $_SESSION["global_patient_id"]  . " and " . " ( paidamount = 0 or balanceamount > 0 ) "  ; 
  $querysbcash = $this->db->query($sqlsbcash);  

?>
<table border="1">
<tr> <td> Sales Bill </td> <td> Mode of <br> Payment </td> <td> Date when <br> paid </td> <td> Amount paid </td> <td> Instrument no </td><td> Bank Name <br> Bank Branch </tr>
<tr> <td> 
      <select name="sbcash1" id = "sbcash1" style="width:100px;">
      <option value="0">sbcash </option>  
      <?php 
      foreach ($querysbcash->result() as $rowsbcash) 
                          {
                          echo "<option value=". $rowsbcash->salesbill . ">" .   $rowsbcash->salesbill  . "</option>";
                          }  ?>  
                      </select>  
     </td>
     <td> CASH </td> 
     <td> <input type="date" name="cashpddate" id="cashpddate"> </td> 
     <td> <input type="text" name="cashpdamt" id="cashpdamt" value="0"> </td> 
     <td> <input type="text" name="cashpdinstru" id="cashpdinstru" value="" > </td>
     <td> <input type="text" name="cashpdbanknm" id="cashpdbanknm" value="" > <br>
          <input type="text" name="cashpdbankbr" id="cashpdbankbr" value="" >
     </td>

</tr>
<tr> 
      <td> 
      <select name="sbcash2" id = "sbcash2" style="width:100px;">
      <option value="0">sbcash </option>  
      <?php 
      foreach ($querysbcash->result() as $rowsbcash) 
                          {
                          echo "<option value=". $rowsbcash->salesbill . ">" .   $rowsbcash->salesbill  . "</option>";
                          }  ?>  
                      </select>  
     </td>
     <td> CHEQUE </td> 
     <td> <input type="date" name="chequepddate" id="chequepddate"> </td> 
     <td> <input type="text" name="chequepdamt" id="chequepdamt" value="0"> </td> 
     <td> <input type="text" name="chequepdinstru" id="chequepdinstru" value="" > </td>
     <td> <input type="text" name="chequepdbanknm" id="chequepdbanknm" value="" > <br>
          <input type="text" name="chequepdbankbr" id="chequepdbankbr" value="" >
     </td>
</tr>
<tr> 
      <td> 
      <select name="sbcash3" id = "sbcash3" style="width:100px;">
      <option value="0">sbcash </option>  
      <?php 
      foreach ($querysbcash->result() as $rowsbcash) 
                          {
                          echo "<option value=". $rowsbcash->salesbill . ">" .   $rowsbcash->salesbill  . "</option>";
                          }  ?>  
                      </select>  
     </td>
     <td> CREDIT CARD </td> 
     <td> <input type="date" name="cardpddate" id="cardpddate"> </td> 
     <td> <input type="text" name="cardpdamt" id="cardpdamt" value="0"> </td> 
     <td> <input type="text" name="cardpdinstru" id="cardpdinstru" value="" > </td>
     <td> <input type="text" name="cardpdbanknm" id="cardpdbanknm" value="" > <br>
          <input type="text" name="cardpdbankbr" id="cardpdbankbr" value="" >
     </td>
</tr>

<tr> 
      <td> 
      <select name="sbcash4" id = "sbcash4" style="width:100px;">
      <option value="0">sbcash </option>  
      <?php 
      foreach ($querysbcash->result() as $rowsbcash) 
                          {
                          echo "<option value=". $rowsbcash->salesbill . ">" .   $rowsbcash->salesbill  . "</option>";
                          }  ?>  
                      </select>  
     </td>

     <td> <input type="text" name="othermode" id="othermode" placeholder="other mode" value="">  </td> 
     <td> <input type="date" name="otherpddate" id="otherpddate"> </td> 
     <td> <input type="text" name="otherpdamt" id="otherpdamt" value="0"> </td> 
     <td> <input type="text" name="otherpdinstru" id="otherpdinstru" value="" > </td>
     <td> <input type="text" name="otherpdbanknm" id="otherpdbanknm" value="" > <br>
          <input type="text" name="otherpdbankbr" id="otherpdbankbr" value="" >
     </td>
</tr>
</table>
<button type="submit" class="button" name="paysubmit" id="paysubmit" >Update Payment</button> </center>
<?php
}
?>
<br>
</form> <!--              mydetails1 -->
</div>
</div>
</body>
</html>