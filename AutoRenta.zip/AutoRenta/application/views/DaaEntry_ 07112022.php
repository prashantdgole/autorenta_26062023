<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
defined('BASEPATH') OR exit('No direct script access allowed');

if (isset($this->session->userdata['logged_in']))
{
$username = ($this->session->userdata['logged_in']['username']);
//$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
{
  header("location: login");
}
//echo $patient_class_value;
//die ("h");
if ($patient_class_value == 'DAA')
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
else
{
$_SESSION['global_company_name'] = "Deshpandes AutoRenta Pvt Ltd.  ";
$_SESSION['global_company_address'] = 'Triumbak Sadan , Ajmal Road, Vile Parle East Mumbai';
}
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
 
?>
<?php
if (isset($_POST['dsmit'])) 
{
 $correctentry='True';
 $datainsert = 0 ;
  die("submit"); 
 $wregdate = $this->input->post('regdate');  
/* line 1 */
 $wempid1 = $this->input->post('empid1');

 echo $wempid1;
 // die("eid1");

 $wpresentid1= $this->input->post('presentid1');
 $wdutyid1 = $this->input->post('dutyid1'); 
 $wshiftid1 = $this->input->post('shiftid1');
 $wcustid1 = $this->input->post('custid1');
 $wpass1  = $this->input->post('pass1');
 $wreporttime1  = $this->input->post('reporttime1');
 $wintime1 = $this->input->post('intime1');
 $wacttime1 = $this->input->post('acttime1');
 $wouttime1 = $this->input->post('outtime1');
 $wactouttime1 = $this->input->post('actouttime1');
 $wworkduration1 = $this->input->post('workduration1');
 $wottime1 = $this->input->post('ottime1');
 $wtottime1 = $this->input->post('tottime1');
 $wremarks1 = $this->input->post('remarks1');
 $wbasicsal1 = $this->input->post('basicsal1');
 $woutdate1_1 = $this->input->post('outdate1_1');
 $woutdate1_2 = $this->input->post('outdate1_2');
/*  line 2 */
 $wempid2 = $this->input->post('empid2');
 $wpresentid2= $this->input->post('presentid2');
 $wdutyid2 = $this->input->post('dutyid2'); 
 $wshiftid2 = $this->input->post('shiftid2');
 $wcustid2 = $this->input->post('custid2');
 $wpass2  = $this->input->post('pass2');
 $wreporttime2  = $this->input->post('reporttime2');
 $wintime2 = $this->input->post('intime2');
 $wacttime2 = $this->input->post('acttime2');
 $wouttime2 = $this->input->post('outtime2');
 $wactouttime2 = $this->input->post('actouttime2');
 $wworkduration2 = $this->input->post('workduration2');
 $wottime2 = $this->input->post('ottime2');
 $wtottime2 = $this->input->post('tottime2');
 $wremarks2 = $this->input->post('remarks2');
 $wbasicsal2 = $this->input->post('basicsal2');
 $woutdate2_1 = $this->input->post('outdate2_1');
 $woutdate2_2 = $this->input->post('outdate2_2');
/*  line 3 */
 $wempid3 = $this->input->post('empid3');
 $wpresentid3= $this->input->post('presentid3');
 $wdutyid3 = $this->input->post('dutyid3'); 
 $wshiftid3 = $this->input->post('shiftid3');
 $wcustid3 = $this->input->post('custid3');
 $wpass3  = $this->input->post('pass3');
 $wreporttime3 = $this->input->post('reporttime3');
 $wintime3 = $this->input->post('intime3');
 $wacttime3 = $this->input->post('acttime3');
 $wouttime3 = $this->input->post('outtime3');
 $wactouttime3 = $this->input->post('actouttime3');
 $wworkduration3 = $this->input->post('workduration3');
 $wottime3 = $this->input->post('ottime3');
 $wtottime3 = $this->input->post('tottime3');
 $wremarks3 = $this->input->post('remarks3');
 $wbasicsal3 = $this->input->post('basicsal3');
 $woutdate3_1 = $this->input->post('outdate3_1');
 $woutdate3_2 = $this->input->post('outdate3_2');
/*  line 4 */
 $wempid4 = $this->input->post('empid4');
 $wpresentid4= $this->input->post('presentid4');
 $wdutyid4 = $this->input->post('dutyid4'); 
 $wshiftid4 = $this->input->post('shiftid4');
 $wcustid4 = $this->input->post('custid4');
 $wpass4  = $this->input->post('pass4');
 $wreporttime4  = $this->input->post('reporttime4');
 $wintime4 = $this->input->post('intime4');
 $wacttime4 = $this->input->post('acttime4');
 $wouttime4 = $this->input->post('outtime4');
 $wactouttime4 = $this->input->post('actouttime4');
 $wworkduration4 = $this->input->post('workduration4');
 $wottime4 = $this->input->post('ottime4');
 $wtottime4 = $this->input->post('tottime4');
 $wremarks4 = $this->input->post('remarks4');
 $wbasicsal4 = $this->input->post('basicsal4');
 $woutdate4_1 = $this->input->post('outdate4_1');
 $woutdate4_2 = $this->input->post('outdate4_2');
/*  line 5 */
 $wempid5 = $this->input->post('empid5');
 $wpresentid5= $this->input->post('presentid5');
 $wdutyid5 = $this->input->post('dutyid5'); 
 $wshiftid5 = $this->input->post('shiftid5');
 $wcustid5 = $this->input->post('custid5');
 $wpass5= $this->input->post('pass5');
 $wreporttime5  = $this->input->post('reporttime5');
 $wintime5 = $this->input->post('intime5');
 $wacttime5 = $this->input->post('acttime5');
 $wouttime5 = $this->input->post('outtime5');
 $wactouttime5 = $this->input->post('actouttime5');
 $wworkduration5 = $this->input->post('workduration5');
 $wottime5 = $this->input->post('ottime5');
 $wtottime5 = $this->input->post('tottime5');
 $wremarks5 = $this->input->post('remarks5');
 $wbasicsal5 = $this->input->post('basicsal5');
 $woutdate5_1 = $this->input->post('outdate5_1');
 $woutdate5_2 = $this->input->post('outdate5_2');
/*  line 6 */
 $wempid6 = $this->input->post('empid6');
 $wpresentid6= $this->input->post('presentid6');
 $wdutyid6 = $this->input->post('dutyid6'); 
 $wshiftid6 = $this->input->post('shiftid6');
 $wcustid6= $this->input->post('custid6');
 $wpass6  = $this->input->post('pass6');
 $wreporttime6  = $this->input->post('reporttime6');
 $wintime6 = $this->input->post('intime6');
 $wacttime6 = $this->input->post('acttime6');
 $wouttime6 = $this->input->post('outtime6');
 $wactouttime6 = $this->input->post('actouttime6');
 $wworkduration6 = $this->input->post('workduration6');
 $wottime6 = $this->input->post('ottime6');
 $wtottime6 = $this->input->post('tottime6');
 $wremarks6 = $this->input->post('remarks6');
 $wbasicsal6 = $this->input->post('basicsal6');
 $woutdate6_1 = $this->input->post('outdate6_1');
 $woutdate6_2 = $this->input->post('outdate6_2');
/* line_1
 echo $wregdate . ' d '  ;
 echo  $wempid1 .  ' enpid  '  ;
  echo $wpresentid1 . ' pfresen id  ' ;
echo  $wdutyid1 . ' duty1 ' ; 
echo  $wshiftid1  . ' shift ';
 echo $wcustid1 . ' cust ' ;
 echo $wpass1 . ' pass 1'  ;
 echo $wreporttime1 . '  repo1 '  ;
 echo $wintime1  . ' intime ';
 echo $wacttime1  . ' act ti ' ;
echo  $wouttime1  . ' out time ' ;
 echo $wactouttime1 . ' act o time '  ;
 echo $wworkduration1 . ' w dur ' ;
 echo $wottime1 . ' ot ' ;
echo  $wtottime1 . ' tot t ';
 echo $wremarks1  . ' re ';
 echo $wbasicsal1  . ' basic s ';
 echo $woutdate1_1 . ' out date1 ';
 echo $woutdate1_2  . ' out date12 ' ;
*/
echo "here";
die ("h1");
  if ($wempid1 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid1 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid1 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid1 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass1 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime1 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                           $daysal1  = $wbasicsal1 / 30 ;
                            $iparr   = explode('~', $wempid1);
                            $weid1 = $iparr[0];
                          echo $weid1 . " e id 1 " ;
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid1',' $wpresentid1',' $wdutyid1','$woutdate1_1','$woutdate1_2','$wshiftid1',' $wcustid1',' $wcustid1',' $wpass1',
' $wreporttime1',' $wintime1',' $wouttime1',' $wacttime1','$wactouttime1','$wworkduration1', ' $wottime1',' $wtottime1' ,' $wremarks1' ,' $daysal1')";

echo $sql;
die ("h");
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

                 }
              }
           }
       }
    }
  }
/* line 2 insert */
  if ($wempid2 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid2 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid2 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid2 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass2 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime2 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                             $daysal2  = $wbasicsal2 / 30 ;
                            $iparr   = explode('~', $wempid2);
                            $weid2 = $iparr[0];
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid2',' $wpresentid2',' $wdutyid2','$woutdate2_1','$woutdate2_2','$wshiftid2',' $wcustid2',' $wcustid2',' $wpass2',
' $wreporttime2',' $wintime2',' $wouttime2',' $wacttime2','$wactouttime2','$wworkduration2', ' $wottime2',' $wtottime2' ,' $wremarks2' ,' $daysal2')";
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
     /*        echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>'; */

                 }
              }
           }
       }
    }
  }
/* line 2 insert over
  line 3 insert */
  if ($wempid3 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid3 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid3 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid3 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass3 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime3 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                            $daysal3  = $wbasicsal3 / 30 ;
                            $iparr   = explode('~', $wempid3);
                            $weid3 = $iparr[0];
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid3',' $wpresentid3',' $wdutyid3','$woutdate3_1','$woutdate3_2','$wshiftid3',' $wcustid3',' $wcustid3',' $wpass3',
' $wreporttime3',' $wintime3',' $wouttime3',' $wacttime3','$wactouttime3','$wworkduration3', ' $wottime3',' $wtottime3' ,' $wremarks3' ,' $daysal3')";
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
 /*         echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>'; */

                 }
              }
           }
       }
    }
  }
/*  line 3 insert over
  line 4 insert */
  if ($wempid4 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid4 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid4 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid4 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass4 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime4 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                            $daysal4  = $wbasicsal4 / 30 ; 
                            $iparr   = explode('~', $wempid4);
                            $weid4 = $iparr[0];
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid4',' $wpresentid4',' $wdutyid4','$woutdate4_1','$woutdate4_2','$wshiftid4',' $wcustid4',' $wcustid4',' $wpass4',
' $wreporttime4',' $wintime4',' $wouttime4',' $wacttime4','$wactouttime4','$wworkduration4', ' $wottime4',' $wtottime4' ,' $wremarks4' ,' $daysal4')";
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
 /*     echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>'; */

                 }
              }
           }
       }
    }
  }
/* line 4 insert over
  line 5 insert */
  if ($wempid5 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid5 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid5 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid5 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass5 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime5 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                            $daysal5  = $wbasicsal5 / 30 ; 
                            $iparr   = explode('~', $wempid5);
                            $weid5 = $iparr[0];
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid5',' $wpresentid5',' $wdutyid5','$woutdate5_1','$woutdate5_2','$wshiftid5',' $wcustid5',' $wcustid5',' $wpass5',
' $wreporttime5',' $wintime5',' $wouttime5',' $wacttime5','$wactouttime5','$wworkduration5', ' $wottime5',' $wtottime5' ,' $wremarks5' ,' $daysal5')";
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
      /*      echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

                 }
              }
           }
       }
    }
  }
/*  line 5 insert over
  line 6 insert */
  if ($wempid6 == '0')
  {
    $correctentry='False';
   
 
  }
  else
  {
    if  ($wpresentid6 == '0' )
    {
           $correctentry='False';
 
    }
    else
    {
       if ($wdutyid6 == '0' )
       {
            $correctentry='False';
 
       }
       else
       {
           if ($wcustid6 =='0' )
           {
                    $correctentry='False';
 
           }
          else
          {
             if ($wpass6 == '' )
             {
                     $correctentry='False';
 
             }
              else
              {
                 if ( $wreporttime6 == '')
                 {
                     $correctentry='False';
 
                  }
                  else
                 {
                            $daysal6  = $wbasicsal6 / 30 ; 
                            $iparr   = explode('~', $wempid6);
                            $weid6 = $iparr[0];
                            $sql = "Insert into daaentry 
                                       (date,empid,presentabsent,duty,outstationdatefrom,outstationdateto,shift,customername,customerid,passengername ,reportingtime,
intime,outtime,actualintime,actualouttime,worktime,ottime,totalduration,remarks,basicsalary) 
                                       values 
                                     ('$wregdate','$weid6',' $wpresentid6',' $wdutyid6','$woutdate6_1','$woutdate6_2','$wshiftid6',' $wcustid6',' $wcustid6',' $wpass6',
' $wreporttime6',' $wintime6',' $wouttime6',' $wacttime6','$wactouttime6','$wworkduration6', ' $wottime6',' $wtottime6' ,' $wremarks6' ,' $daysal6')";
                            $query = $this->db->query($sql);
                            $datainsert = $datainsert + 1;
  /*             echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

                 }
              }
           }
       }
    }
  }
/* line 6 insert over */


  if ($wregdate == '' )
  {
    $correctentry='False';
  }
  if ( $datainsert==0)
  {
        echo '<html><body><marquee><font size="14" color="red">' .  " Data Not Inserted ... date Not selected or Employee Code is blank" .   '</font> </marquee> </body></html>';

  }
 else
 {
       echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Records Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';  
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function dutychangefn1() {
  var duty1 = document.getElementById("dutyid1").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate1_1").disabled = true;
      document.getElementById("outdate1_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate1_1").disabled = false;
  document.getElementById("outdate1_2").disabled = false;
  }
}
 
function dutychangefn2() {
  var duty1 = document.getElementById("dutyid2").value;
 
  if (duty1 == 'L')
  {
 // alert('h');
      document.getElementById("outdate2_1").disabled = true;
      document.getElementById("outdate2_2").disabled = true;
  }
  else
  {
// alert('o');
  document.getElementById("outdate2_1").disabled = false;
  document.getElementById("outdate2_2").disabled = false;
  }
}
 
function dutychangefn3() {
  var duty1 = document.getElementById("dutyid3").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate3_1").disabled = true;
      document.getElementById("outdate3_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate3_1").disabled = false;
  document.getElementById("outdate3_2").disabled = false;
  }
}
 
function dutychangefn4() {
  var duty1 = document.getElementById("dutyid4").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate4_1").disabled = true;
      document.getElementById("outdate4_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate4_1").disabled = false;
  document.getElementById("outdate4_2").disabled = false;
  }
}
 
function dutychangefn5() {
  var duty1 = document.getElementById("dutyid5").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate5_1").disabled = true;
      document.getElementById("outdate5_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate5_1").disabled = false;
  document.getElementById("outdate5_2").disabled = false;
  }
}
 
function dutychangefn6() {
  var duty1 = document.getElementById("dutyid6").value;
 
  if (duty1 == 'L')
  {
// alert('h');
      document.getElementById("outdate6_1").disabled = true;
      document.getElementById("outdate6_2").disabled = true;
  }
  else
  {
//alert('o');
  document.getElementById("outdate6_1").disabled = false;
  document.getElementById("outdate6_2").disabled = false;
  }
}
 

function empchangefn1() {
  var emp1 = document.getElementById("empid1").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid1.value=sp_lit[1];
      document.mydaa.intime1.value=sp_lit[2];
       document.mydaa.acttime1.value=sp_lit[2]; 
       document.mydaa.outtime1.value=sp_lit[3]; 
      document.mydaa.actouttime1.value=sp_lit[3]; 
     document.mydaa.tottime1.value=sp_lit[4];               
      document.mydaa.workduration1.value=sp_lit[4];  
      document.mydaa.basicsal1.value=sp_lit[5];  
}
function empchangefn2() {
  var emp1 = document.getElementById("empid2").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid2.value=sp_lit[1];
      document.mydaa.intime2.value=sp_lit[2];
       document.mydaa.acttime2.value=sp_lit[2]; 
       document.mydaa.outtime2.value=sp_lit[3]; 
      document.mydaa.actouttime2.value=sp_lit[3]; 
     document.mydaa.tottime2.value=sp_lit[4];               
       document.mydaa.workduration2.value=sp_lit[4];     
      document.mydaa.basicsal2.value=sp_lit[5];       
}

function empchangefn3() {
  var emp1 = document.getElementById("empid3").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid3.value=sp_lit[1];
      document.mydaa.intime3.value=sp_lit[2];
       document.mydaa.acttime3.value=sp_lit[2]; 
       document.mydaa.outtime3.value=sp_lit[3]; 
      document.mydaa.actouttime3.value=sp_lit[3]; 
     document.mydaa.tottime3.value=sp_lit[4];               
       document.mydaa.workduration3.value=sp_lit[4];     
      document.mydaa.basicsal3.value=sp_lit[5];   
}
function empchangefn4() {
  var emp1 = document.getElementById("empid4").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid4.value=sp_lit[1];
      document.mydaa.intime4.value=sp_lit[2];
       document.mydaa.acttime4.value=sp_lit[2]; 
       document.mydaa.outtime4.value=sp_lit[3]; 
      document.mydaa.actouttime4.value=sp_lit[3]; 
     document.mydaa.tottime4.value=sp_lit[4];               
       document.mydaa.workduration4.value=sp_lit[4];     
      document.mydaa.basicsal4.value=sp_lit[5];   
}

function empchangefn5() {
  var emp1 = document.getElementById("empid5").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid5.value=sp_lit[1];
      document.mydaa.intime5.value=sp_lit[2];
       document.mydaa.acttime5.value=sp_lit[2]; 
       document.mydaa.outtime5.value=sp_lit[3]; 
      document.mydaa.actouttime5.value=sp_lit[3]; 
     document.mydaa.tottime5.value=sp_lit[4];               
       document.mydaa.workduration5.value=sp_lit[4];   
      document.mydaa.basicsal5.value=sp_lit[5];     
}
function empchangefn6() {
  var emp1 = document.getElementById("empid6").value;
//    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
//alert(emp1);
  var sp_lit = emp1.split('~'); 
//alert(sp_lit[1]); //                     shiftid1
      document.mydaa.shiftid6.value=sp_lit[1];
      document.mydaa.intime6.value=sp_lit[2];
       document.mydaa.acttime6.value=sp_lit[2]; 
       document.mydaa.outtime6.value=sp_lit[3]; 
      document.mydaa.actouttime6.value=sp_lit[3]; 
     document.mydaa.tottime6.value=sp_lit[4];               
       document.mydaa.workduration6.value=sp_lit[4];   
      document.mydaa.basicsal6.value=sp_lit[5];     
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
 
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
 
@media screen and (max-height: 400px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttonsmall {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 9px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
 
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/daareports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>admin</a>


</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>

 
<span style="font-size:15px;cursor:pointer;color="black">Daily Attendence Register </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>

<a  href='<?php echo base_url()."index.php/Home_AutoRenta/admin"; ?>'>Back</a>
 

  <form  name="mydaa" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <?php
 



    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
     <tr> 
           <td><span style="font-size:14px;cursor:pointer;color="black">Enter Date: </td>
          <td> <span style="font-size:14px;cursor:pointer;color="black"><input type="date" name="regdate" id="regdate" value="" /> </td>
     </tr>
   <table>
   <br>
   <table border="1">  
        <tr>  
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   Emp Name </td>
              <td>  <span style="font-size:12px;cursor:pointer;color="black">   P/A</td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black">   Duty </td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black"> Shift </td> 
             <td>  <span style="font-size:12px;cursor:pointer;color="black"> Customer <br> Name</td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black"> Passenger <br> Name</td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  Reporting <br> Time </td>
             <td>  <span style="font-size:12px;cursor:pointer;color="black">  In/<br>Actual Time </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  Out/<br>Actual Time </td>
           <td>  <span style="font-size:12px;cursor:pointer;color="black">  work <br>Duration </td>
            <td>  <span style="font-size:12px;cursor:pointer;color="black">  OT Time </td>
         <td>  <span style="font-size:12px;cursor:pointer;color="black"> Total <br> Duration </td>
<!--        <td>  <span style="font-size:12px;cursor:pointer;color="black">  Status </td> -->
        <td>  <span style="font-size:12px;cursor:pointer;color="black"> Remarks </td>
        <td>  <span style="font-size:12px;cursor:pointer;color="black">  </td>
         </tr>
         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid1" id = "empid1" onchange="empchangefn1()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data as $data) { 
                         echo "<option value=". $data->ecode ."~".  $data->shift . "~" .  $data->intime . "~" . $data->outtime . "~" . $data->tottime . "~" . $data->basicsal. ">" .   $data->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
               </td>
              <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid1" id = "presentid1" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid1" id = "dutyid1" onchange="dutychangefn1()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate1_1"   id="outdate1_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate1_2"   id="outdate1_2" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid1" id = "shiftid1"   style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid1" id = "custid1" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_1 as $data2_1) { 
                         echo "<option value=". $data2_1->id . ">" .   $data2_1->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass1" id="pass1" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime1" id="reporttime1" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime1" id="intime1" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime1" id="acttime1" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime1" id="outtime1" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime1" id="actouttime1" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration1" id="workduration1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime1" id="ottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime1" id="tottime1" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status1" id="status1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks1" id="remarks1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal1" id="basicsal1" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>
   
<!-- line 2 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid2" id = "empid2" onchange="empchangefn2()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_2 as $data_2) { 
                         echo "<option value=". $data_2->ecode ."~".  $data_2->shift . "~" .  $data_2->intime . "~" . $data_2->outtime . "~" . $data_2->tottime . "~" . $data_2->basicsal. ">" .   $data_2->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid2" id = "presentid2" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid2" id = "dutyid2" onchange="dutychangefn2()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate2_1"   id="outdate2_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate2_2"   id="outdate2_2" />
                     </span> 
               </td>


               <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid2" id = "shiftid2" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid2" id = "custid2" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_2 as $data2_2) { 
                         echo "<option value=". $data2_2->id . ">" .   $data2_2->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass2" id="pass2" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime2" id="reporttime2" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime2" id="intime2" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime2" id="acttime2" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime2" id="outtime2" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime2" id="actouttime2" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration2" id="workduration2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime2" id="ottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime2" id="tottime2" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status2" id="status2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
-->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks2" id="remarks2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal2" id="basicsal2" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>
    

<!-- line 3 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid3" id = "empid3" onchange="empchangefn3()"   style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_3 as $data_3) { 
                         echo "<option value=". $data_3->ecode ."~".  $data_3->shift . "~" .  $data_3->intime . "~" . $data_3->outtime . "~" . $data_3->tottime . "~" . $data_3->basicsal. ">" .   $data_3->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid3" id = "presentid3" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid3" id = "dutyid3" onchange="dutychangefn3()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate3_1"   id="outdate3_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate3_2"   id="outdate3_2" />
                     </span> 
               </td>




              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid3" id = "shiftid3" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid3" id = "custid3" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_3 as $data2_3) { 
                         echo "<option value=". $data2_3->id . ">" .   $data2_3->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass3" id="pass3" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime3" id="reporttime3" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime3" id="intime3" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime3" id="acttime3" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime3" id="outtime3" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime3" id="actouttime3" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration3" id="workduration3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime3" id="ottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime3" id="tottime3" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
<!--            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status3" id="status3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks3" id="remarks3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal3" id="basicsal3" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>


<!-- line 4 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid4" id = "empid4"  onchange="empchangefn4()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_4 as $data_4) { 
                         echo "<option value=". $data_4->ecode ."~".  $data_4->shift . "~" .  $data_4->intime . "~" . $data_4->outtime . "~" . $data_4->tottime . "~" . $data_4->basicsal. ">" .   $data_4->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid4" id = "presentid4" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid4" id = "dutyid4" onchange="dutychangefn4()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate4_1"   id="outdate4_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate4_2"   id="outdate4_2" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid4" id = "shiftid4" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid4" id = "custid4" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_4 as $data2_4) { 
                         echo "<option value=". $data2_4->id . ">" .   $data2_4->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass4" id="pass4" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime4" id="reporttime4" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime4" id="intime4" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime4" id="acttime4" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime4" id="outtime4" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime4" id="actouttime4" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration4" id="workduration4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime4" id="ottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime4" id="tottime4" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status4" id="status4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks4" id="remarks4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal4" id="basicsal4" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 5 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid5" id = "empid5" onchange="empchangefn5()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_5 as $data_5) { 
                          echo "<option value=". $data_5->ecode ."~".  $data_5->shift . "~" .  $data_5->intime . "~" . $data_5->outtime . "~" . $data_5->tottime . "~" . $data_5->basicsal. ">" .   $data_5->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid5" id = "presentid5" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid5" id = "dutyid5" onchange="dutychangefn5()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date"  name="outdate5_1"   id="outdate5_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate5_2"   id="outdate5_2" />
                     </span> 
               </td>


              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid5" id = "shiftid5" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid5" id = "custid5" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_5 as $data2_5) { 
                         echo "<option value=". $data2_5->id . ">" .   $data2_5->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass5 id="pass5" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime5" id="reporttime5" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime5" id="intime5" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime5" id="acttime5" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime5" id="outtime5" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime5" id="actouttime5" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration5" id="workduration5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime5" id="ottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime5" id="tottime5" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status5" id="status5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks5" id="remarks5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal5" id="basicsal5" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

<!-- line 6 -->

         <tr>   
               <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="empid6" id = "empid6" onchange="empchangefn6()"  style="width:80px;">
                      <option value="0">empname </option>  
                         <?php 
                        foreach ($data_6 as $data_6) { 
                         echo "<option value=". $data_6->ecode ."~".  $data_6->shift . "~" .  $data_6->intime . "~" . $data_6->outtime . "~" . $data_6->tottime . "~" . $data_6->basicsal. ">" .   $data_6->name  . "</option>";

                          }  ?>  
                      </select>  
                     </span> 
               </td>

             <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="presentid6" id = "presentid6" style="width:80px;">
                      <option value="0">presentee </option>  
                         <?php 
             
                         echo '<option value="P">Present</option>';
                        echo '<option value="A">ABSENT</option>';
                           ?>  
                      </select>  
                     </span> 
               </td>

    <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="dutyid6" id = "dutyid6" onchange="dutychangefn6()" style="width:80px;">
                      <option value="0">Duty </option>  
                         <?php 
                     
                         echo '<option value="L">LOCAL</option>';
                        echo '<option value="O">OUTSTATION</option>';
                           ?>  
                      </select>  
                     <br>
                     <input type="date" name="outdate6_1"   id="outdate6_1" /> &nbsp To : &nbsp 
                      <input type="date" name="outdate6_2"   id="outdate6_2" />
                     </span> 
               </td>




              <td>
                    <span style="font-size:12px;cursor:pointer; width:40px;color="black"> 

                   <input type="text"   name="shiftid6" id = "shiftid6" style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                      <select name="custid6" id = "custid6" style="width:80px;">
                      <option value="0">customer </option>  
                         <?php 
                        foreach ($data2_6 as $data2_6) { 
                         echo "<option value=". $data2_6->id . ">" .   $data2_6->name  . "</option>";
                          }  ?>  
                      </select>  
                     </span> 
             </td>
              <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="pass6" id="pass6" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="reporttime6" id="reporttime6" value="" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="intime6" id="intime6" value="" style="font-size:12px;width:40px;" > <br>
                    <input type="text" name="acttime6" id="acttime6" value="" style="font-size:12px;width:40px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="outtime6" id="outtime6" value="" style="font-size:12px;width:30px;" > <br>
                    <input type="text" name="actouttime6" id="actouttime6" value="" style="font-size:12px;width:30px;" >
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="workduration6" id="workduration6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="ottime6" id="ottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="tottime6" id="tottime6" value="" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
 <!--           <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="status6" id="status6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td> -->
            <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="text" name="remarks6" id="remarks6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
          <td>
                    <span style="font-size:12px;cursor:pointer;color="black"> 
                     <input type="hidden" name="basicsal6" id="basicsal6" value="" style="font-size:12px;width:40px;" >  
                     </span>  
             </td>
           </tr>

       </table>
       <br>

   
 
<center> <input type="submit"  name="dsmit" id="dsmit" value ="Submit Daily Register" >  </center>
 
<br>
</form>  
</div>
</div>
</body>
</html>