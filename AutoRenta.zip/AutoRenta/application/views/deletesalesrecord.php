<?php
 $this->load->library('session');
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}

 
?>
<?php
    $delid =  $_GET['var1'];
    echo $delid;
die("here");

?>