<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
  
}

 
?>
<?php
$sid = 0;
$sname="";
$ino=0;
$idate="";
$i =0;
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

function getpetname(form)
{
// alert(" in ");
 var val1 , n , strUser;
var e = document.getElementById("pettypeid");
var strUser = e.options[e.selectedIndex].text;
var sp_lit = strUser.split('-');
document.mypetdetails1.pettypename.value=sp_lit[0];
}
 

function onSelectChange()
{
    var sel = document.getElementById('supplierid');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.mypetdetails.suppliername.value=strUser;
}

 
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_new_purchase_medicines"; ?>'>Purchase new Medicines </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_approve_purchase_medicines"; ?>'>Approve Purchase for billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_return_medicines"; ?>'>Defective Return - Inspection Note</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reject_medicines"; ?>'>Purchase Return - Rejection Note</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_approved_billing"; ?>'>Payment of Approved Bills</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>

 
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Enter Purchase Medicines and Material details </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Purchase Medicines and other Entry Form </h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Back</a>




 <!-- <form method="post" name="mypetdetails" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />   -->

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>

    <table>

<!-- $_SESSION['global_user_name'] = '';
$_SESSION['global_user_id'] = 0;
$_SESSION['global_name_of_person'] = ''; -->

  <!--  <tr> <td> <?php echo phpversion(); ?> </td> </tr> -->
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Supplier : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="supplierid" id = "supplierid" onchange="onSelectChange()" style="width:100px;"> 
                         <option value="select supplier"> select supplier </option>
                         <?php 
                        foreach ($data as $data) { 
                         echo "<option value=". $data->id .  ">" .   $data->vendorname . "</option>";
                          }  ?>      </select> 
                        <input type="text" name="suppliername"  id="suppliername" value="" >
                      </span>  
               </td>
              
              <td> <span style="font-size:15px;cursor:pointer;color="black">Invoice No. : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="invoiceno" id="invoiceno" value=""> </span>
              </td>
              <td> </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black">Invoice Dt. : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="date" name="invoicedate" id="invoicedate" value=""> </span>
              </td>
              <td> </td>

              <td>   <button type="submit" id="show" name="show" >Show</button>  </td>

          <tr>
 </table>
 <br>
 <hr>
 
<center><span style="font-size:20px;cursor:pointer;color="blue">Invoice Details For Supplier id <?php if (isset($_POST['show'])) {$sid=$_POST["supplierid"]; echo "[" . $sid . "]"; $sname=$_POST["suppliername"];echo $sname; echo " inv no : "; $ino = $_POST["invoiceno"]; echo $_POST["invoiceno"]; echo " dt "; $idate= $_POST["invoicedate"]; echo $_POST["invoicedate"]; } ?> </span> </center>
 <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Description <br> Pur Qty </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Rate <br> Amount</span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Gst % <br> Gst Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Item Total  <br> Invoice Total</span> </td> 
      </tr>
      <tr>
     <?php
         $sql ="SELECT * FROM purchumanstocklist where vendorid = " . $sid . " and purchasebill = '" . $ino . "'" ;
         $query = $this->db->query($sql);

         if ($query->num_rows() > 0)
         {
         foreach ($query->result() as $row) 
         {?>
          <td> <?php 
                echo $row->stockname;?> <br> <?php echo $row->purcqty;?>
          </td>  
          <td> 
                <?php 
                echo $row->purrate;?> <br> <?php echo $row->puramount;?>
          </td>  
          <td> 
                <?php 
                echo $row->gstperc;?> <br> <?php echo $row->taxtotal;?>
          </td>  

         <?php 
         }
         }
    ?>
     </tr> 
  </table>
 </form>
 <form method="post" name="mypetdetails1" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/'?>" />   
  <hr>
  <center><span style="font-size:18px;cursor:pointer;color="blue"> Add some more details of invoice No <?php echo $ino; ?>  </span>   </center>

    
    <table border="1">
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Description <br> Pur Qty <br> Unit  </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> MRP Rate <br> Purchase Rate</span> </td> 

             <td> <span style="font-size:15px;cursor:pointer;color="black"> HSN Code <br> Batch No <br> Batch Date </span> </td> 

             <td> <span style="font-size:15px;cursor:pointer;color="black"> GST % <br> Taxable Amount</span> </td> 
    
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Sgst % <br> Sgst Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Cgst % <br> Cgst Amount </span> </td>
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Igst % <br> Igst Amount </span> </td>  

             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> 

             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Item Total  <br> Invoice Total <br> Tax Total</span> </td> 
      </tr>
<!-- 1 st row --->
      <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  <select name="wstockid1" id = "wstockid1"> 
                  <option value="0"> select stock</option>';
                        <?php  
                        foreach ($data1 as $data1) 
                        { 
                         echo "<option value=". $data1->id .  ">" .   $data1->stockname . "</option>";
                        }  
                        ?>
                </select> <br>    
                <input type="text" name="wpurcqty1"  id="wpurcqty1"> <br>
                <input type="text" name="wunitofmeasurement1" id="wunitofmeasurement1" /> 
                </span>  
               
              </td> 
           
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="wmrprate1" id="wmrprate1"> <br>
                   <input type="text" name="wpurrate1" id="wpurrate1"> <br>
                   </span>
              
              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="whsncode1" id="whsncode1"> <br>
                    <input type="text" name="wbatchcode1" id="wbatchcode1" > <br>
                    <input type="date" name="wbatchdate1" id="wbatchdate1" /> 
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="wgstperc1" id="wgstperc1"> <br>
                    <input type="text" name="wpuramount1" id="wpuramount1" >  
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wsgstperc1" id="wsgstperc1" /> <br>
                    <input type="text" name="wsgstamount1" id="wsgstamount1" />  
                    </span> 
              </td> 
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wcgstperc1" id="wcgstperc1" /> <br>
                    <input type="text" name="wcgstamount1" id="wcgstamount1" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wigstperc1" id="wigstperc1" /> <br>
                    <input type="text" name="wigstamount1" id="wigstamount1" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wdiscperc1" id="wdiscperc1" > <br>
                    <input type="text" name="wdiscountamount1" id="wdiscountamount1" > 
                    </span>
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="witemtotal1" id="witemtotal1" />  <br> 
                    <input type="text" name="wtotal1" id="wtotal1" /> <br>
                    <input type="text" name="wtaxtotal1" id="wtaxtotal1" />
                    </span>
              </td> 

      </tr>
<!-- 2 nd  row --->
      <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  <select name="wstockid2" id = "wstockid2"> 
                  <option value="0"> select stock</option>';
                        <?php  
                        foreach ($data2 as $data2) 
                        { 
                         echo "<option value=". $data2->id .  ">" .   $data2->stockname . "</option>";
                        }  
                        ?>
                </select> <br>    
                <input type="text" name="wpurcqty2"  id="wpurcqty2"> <br>
                <input type="text" name="wunitofmeasurement2" id="wunitofmeasurement2" /> 
                </span>  
               
              </td> 
           
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="wmrprate2" id="wmrprate2"> <br>
                   <input type="text" name="wpurrate2" id="wpurrate2"> <br>
                   </span>
              
              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="whsncode2" id="whsncode2"> <br>
                    <input type="text" name="wbatchcode2" id="wbatchcode2" > <br>
                    <input type="date" name="wbatchdate2" id="wbatchdate2" /> 
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="wgstperc2" id="wgstperc2"> <br>
                    <input type="text" name="wpuramount2" id="wpuramount2" >  
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wsgstperc2" id="wsgstperc2" /> <br>
                    <input type="text" name="wsgstamount2" id="wsgstamount2" />  
                    </span> 
              </td> 
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wcgstperc2" id="wcgstperc2" /> <br>
                    <input type="text" name="wcgstamount2" id="wcgstamount2" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wigstperc2" id="wigstperc2" /> <br>
                    <input type="text" name="wigstamount2" id="wigstamount2" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wdiscperc2" id="wdiscperc2" > <br>
                    <input type="text" name="wdiscountamount2" id="wdiscountamount2" > 
                    </span>
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="witemtotal2" id="witemtotal2" />  <br> 
                    <input type="text" name="wtotal2" id="wtotal2" /> <br>
                    <input type="text" name="wtaxtotal2" id="wtaxtotal2" />
                    </span>
              </td> 

      </tr>
<!-- 3 rd  row --->
      <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  <select name="wstockid3" id = "wstockid3"> 
                  <option value="0"> select stock</option>';
                        <?php  
                        foreach ($data3 as $data3) 
                        { 
                         echo "<option value=". $data3->id .  ">" .   $data3->stockname . "</option>";
                        }  
                        ?>
                </select> <br>    
                <input type="text" name="wpurcqty3"  id="wpurcqty3"> <br>
                <input type="text" name="wunitofmeasurement3" id="wunitofmeasurement3" /> 
                </span>  
               
              </td> 
           
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="wmrprate3" id="wmrprate3"> <br>
                   <input type="text" name="wpurrate3" id="wpurrate3"> <br>
                   </span>
              
              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="whsncode3" id="whsncode3"> <br>
                    <input type="text" name="wbatchcode3" id="wbatchcode3" > <br>
                    <input type="date" name="wbatchdate3" id="wbatchdate3" /> 
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="wgstperc3" id="wgstperc3"> <br>
                    <input type="text" name="wpuramount3" id="wpuramount3" >  
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wsgstperc3" id="wsgstperc3" /> <br>
                    <input type="text" name="wsgstamount3" id="wsgstamount3" />  
                    </span> 
              </td> 
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wcgstperc3" id="wcgstperc3" /> <br>
                    <input type="text" name="wcgstamount3" id="wcgstamount3" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wigstperc3" id="wigstperc3" /> <br>
                    <input type="text" name="wigstamount3" id="wigstamount3" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wdiscperc3" id="wdiscperc3" > <br>
                    <input type="text" name="wdiscountamount3" id="wdiscountamount3" > 
                    </span>
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="witemtotal3" id="witemtotal3" />  <br> 
                    <input type="text" name="wtotal3" id="wtotal3" /> <br>
                    <input type="text" name="wtaxtotal3" id="wtaxtotal3" />
                    </span>
              </td> 

      </tr>
<!-- 4 th  row -->
      <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  <select name="wstockid4" id = "wstockid4"> 
                  <option value="0"> select stock</option>';
                        <?php  
                        foreach ($data4 as $data4) 
                        { 
                         echo "<option value=". $data4->id .  ">" .   $data4->stockname . "</option>";
                        }  
                        ?>
                </select> <br>    
                <input type="text" name="wpurcqty4"  id="wpurcqty4"> <br>
                <input type="text" name="wunitofmeasurement4" id="wunitofmeasurement4" /> 
                </span>  
               
              </td> 
           
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="wmrprate4" id="wmrprate4"> <br>
                   <input type="text" name="wpurrate4" id="wpurrate4"> <br>
                   </span>
              
              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="whsncode4" id="whsncode4"> <br>
                    <input type="text" name="wbatchcode4" id="wbatchcode4" > <br>
                    <input type="date" name="wbatchdate4" id="wbatchdate4" /> 
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="wgstperc4" id="wgstperc4"> <br>
                    <input type="text" name="wpuramount4" id="wpuramount4" >  
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wsgstperc4" id="wsgstperc4" /> <br>
                    <input type="text" name="wsgstamount4" id="wsgstamount4" />  
                    </span> 
              </td> 
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wcgstperc4" id="wcgstperc4" /> <br>
                    <input type="text" name="wcgstamount4" id="wcgstamount4" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wigstperc4" id="wigstperc4" /> <br>
                    <input type="text" name="wigstamount4" id="wigstamount4" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wdiscperc4" id="wdiscperc4" > <br>
                    <input type="text" name="wdiscountamount4" id="wdiscountamount4" > 
                    </span>
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="witemtotal4" id="witemtotal4" />  <br> 
                    <input type="text" name="wtotal4" id="wtotal4" /> <br>
                    <input type="text" name="wtaxtotal4" id="wtaxtotal4" />
                    </span>
              </td> 

      </tr>
<!-- 5 th row -->

      <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  <select name="wstockid5" id = "wstockid5"> 
                  <option value="0"> select stock</option>';
                        <?php  
                        foreach ($data5 as $data5) 
                        { 
                         echo "<option value=". $data5->id .  ">" .   $data5->stockname . "</option>";
                        }  
                        ?>
                </select> <br>    
                <input type="text" name="wpurcqty5"  id="wpurcqty5"> <br>
                <input type="text" name="wunitofmeasurement5" id="wunitofmeasurement5" /> 
                </span>  
               
              </td> 
           
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                   <input type="text" name="wmrprate5" id="wmrprate5"> <br>
                   <input type="text" name="wpurrate5" id="wpurrate5"> <br>
                   </span>
              
              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="whsncode5" id="whsncode5"> <br>
                    <input type="text" name="wbatchcode5" id="wbatchcode5" > <br>
                    <input type="date" name="wbatchdate5" id="wbatchdate5" /> 
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black">
                    <input type="text" name="wgstperc5" id="wgstperc5"> <br>
                    <input type="text" name="wpuramount5" id="wpuramount5" >  
                    </span> 
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wsgstperc5" id="wsgstperc5" /> <br>
                    <input type="text" name="wsgstamount5" id="wsgstamount5" />  
                    </span> 
              </td> 
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wcgstperc5" id="wcgstperc5" /> <br>
                    <input type="text" name="wcgstamount5" id="wcgstamount5" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wigstperc5" id="wigstperc5" /> <br>
                    <input type="text" name="wigstamount5" id="wigstamount5" />   
                    </span> 
              </td>

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="wdiscperc5" id="wdiscperc5" > <br>
                    <input type="text" name="wdiscountamount5" id="wdiscountamount5" > 
                    </span>
              </td> 

              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                    <input type="text" name="witemtotal5" id="witemtotal5" />  <br> 
                    <input type="text" name="wtotal5" id="wtotal5" /> <br>
                    <input type="text" name="wtaxtotal5" id="wtaxtotal5" />
                    </span>
              </td> 

      </tr>




    </table>
<hr>

 <center> <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsinfo/' ?> "><button type="submit" name="submit" id="submit" >Update</button> </a> </center> 


</hr>
<!-- </form> -->

<?php
?>
  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>