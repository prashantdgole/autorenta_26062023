<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
$clinicname = "";
$wdateofapp = "";
$wClinicName = "";
$wClinicName2 = "";
$clinicname2 = "";

?>
<?php
if (isset($_POST['appsubmit'])) 
{
      $wPetsNewPatient = $this->input->post('PetsNewPatient');  
      $wpetspatientname = $this->input->post('PetsPatientname');
// echo "new " . $wPetsNewPatient;
//echo " pat name " . $wpetspatientname;
// die("here");

      $wdateofappointment = $this->input->post('dateofapp3');
      $wclinictype = $this->input->post('cname2');
        $wstrpos = strpos($wPetsNewPatient, "~");
        $arr1 = explode("~",$wPetsNewPatient);
        $arr = explode("~", $wpetspatientname);

        if ( $wstrpos == false )  
        {
          $wpatientname = $arr1[0];
          $wpetsname = "";
echo " wpatientname1 " . $wpatientname;
        }
        else
        {
          $wpatientname = $arr1[0];
          $wpetsname = $arr1[1];
echo " wpatientname2 " . $wpatientname;
        }

      if ($wpetspatientname == "0" or $wPetsNewPatient== "" or $wpetspatientname == "" or $wpetspatientname == "New Patient" or $wpatientname == "" )
//        if ( $wPetsNewPatient== "" or $wpetspatientname == "" or $wpetspatientname == "New Patient"  )
        {
           $wpatientid = "0";
           $wpetid = "0"; 
        }
        else
        {
           $wpatientid = $arr[0];
           $wpetid = $arr[1];
       }
       if ($wclinictype == 'HUMAN')
       {
       $wHumanNewPatient= $this->input->post('HumanNewPatient');
       $wpatientname = $this->input->post('HumanNewPatient');
       }

      if ($wclinictype == '0' )
      {
        echo '<html><body><marquee><font size="12" color="red">' .   $wclinictype . ' clinic type not selected  </font> </marquee> </body></html>';
      }
      else // rest insert programme
      {
        $wDoctorName = $this->input->post('DoctorName');
        $wadr1 = $this->input->post('adr1');
        $wadr2 = $this->input->post('adr2'); 
        $wadr3 = $this->input->post('adr3');
        $wpincode = $this->input->post('pincode');
        $wmobilephone = $this->input->post('mobilephone');
        $wmobileno = $this->input->post('mobileno');
        $wfromtime = $this->input->post('fromtime');
        $whomevisittime = $this->input->post('homevisittime');
        $wclinichome = $this->input->post('ClinicHome');
        $sql = "Insert into appointment_pets 
        (dateofappointment,clinictype,dr_assigned,adr1,adr2,adr3,pincode,mobilephone,patientid,petid,patientname,petsname,mobileno,time_from_to,time_homevisit,clinichomevisit) 
        values 
        ('$wdateofappointment','$wclinictype','$wDoctorName','$wadr1','$wadr2','$wadr3','$wpincode','$wmobilephone','$wpatientid','$wpetid','$wpatientname','$wpetsname','$wmobileno','$wfromtime','$whomevisittime','$wclinichome')";
        $query = $this->db->query($sql);
//echo "added";
        }
      
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">
ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
function getpetname(form)
{
// alert(" in ");
 var val1 , n , strUser;
var e = document.getElementById("pettypeid");
var strUser = e.options[e.selectedIndex].text;
var sp_lit = strUser.split('-');
document.mypetdetails1.pettypename.value=sp_lit[0];
}
function onPetsPatientChange()
{
    var sel = document.getElementById('PetsPatientname');
//alert (sel);
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
// alert(strUser);
    document.mypetdetails.PetsNewPatient.value=strUser; // PetsNewPatient
}
function onHumanPatientChange()
{
    var sel = document.getElementById('HumanPatientname');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    document.mypetdetails.HumanNewPatient.value=strUser;
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
<style>
body {
    font-family: "Lato", sans-serif;
}
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}
.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}
.sidenav a:hover {
    color: #f1f1f1;
}
.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<body>
<form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>
</div>
<p>
<span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
<div class="mainContainer">
<div class="formContainer">     
<h2>Doctor Appointment for PETS / HUMAN Entry  Form </h2>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}
?>
<!-- // original start -->
<font color="black">
<?php
    if ($this->session->flashdata('errors'))
    {
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }
?>
<hr>
<br>
<h2> New Appointment Details for Clients (PETS / HUMAN ) for Clinic / Home Visit  </h2>  
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>
<table>
<tr>     <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Appointment : </span> </td>
    <td> <span style="font-size:15px;cursor:pointer;color="black"> 
         <input type="date"  name="dateofappointment" id="dateofappointment" value=""> </span>
         <br>
         <input type="date" readonly hidden name="dateofapp2" id = "dateofapp2" value="<?php if (isset($_POST['show'])) { $wdateofapp = $_POST["dateofappointment"]; echo $wdateofapp; }  ?>" >
    </td>
</tr>
<tr>
<td> <span style="font-size:15px;cursor:pointer;color="black"> Clinic Name : </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="ClinicName" required>
       <option value="PETS">Sai Vets Clinic </option>
       <option value="HUMAN">Panchgavya Clinic </option>
     </select> </span> 
     <br>
     <input type="text" readonly hidden name="cname1" id="cname1" value="<?php if (isset($_POST['show'])) { $wClinicName = $_POST["ClinicName"]; echo $wClinicName; }  ?>" >
     </td>
    <td> <button type="submit" class="button" name="show" id="show" >Show Appointments (ALL) </button>  
    </td> 
</tr>
</table>
<hr>


<br>
<h2> Existing Appointment Details of Client (Pets / Human) (Clinic / Home Visit)  </h2>  
 <table>
       <tr>   
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Time <br> Clinic/Home Visit <br> Full Address <br> Dr Name</span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Owners Name  <br> Pet Name <br> Mobile / Phone no <br> Clinic Name </span> </td>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Time <br> Clinic/Home Visit <br> Full Address <br> Dr Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Owners Name  <br> Pet Name <br> Mobile / Phone no <br> Clinic Name </span> </td> 
      </tr>
     <?php
             if (isset($_POST['show'])) 
             {
                  $clinicdate = $_POST['dateofappointment'];
//echo "clic " . $clinicdate;

                 
// echo "<br>" . " y " . $yr;
                  if (($clinicdate) == '' )
                  {
                       $clincdate = date('m/d/Y');
                       $mdate =  date('m/d/Y');   
                       $sql ="SELECT * FROM appointment_pets where dateofappointment = '" . $mdate . "'"  ;
                  }
                  else
                  {
                  $sql ="SELECT * FROM appointment_pets where dateofappointment = '" . $clinicdate . "'"  ;
                  }
// echo $sql;
                  $i=0;
                  $query = $this->db->query($sql);
                  if ($query->num_rows() > 0)
                  {
                     foreach ($query->result() as $row)  
                     {
                          if ($i==0 )
                          {
                          echo "<tr>";                         
                          echo '<td>'. $row->time_from_to . " - " . $row->time_homevisit . "<br>" . $row->clinichomevisit . "<br>" . $row->adr1 . " " . $row->adr2 . " ". $row->adr3 . $row->pincode . "<br>" . $row->dr_assigned . '</td>' ;
                          echo '<td>'. $row->patientname . " - " . $row->petsname . "<br>" . $row->mobileno . "<br>". $row->clinictype . '</td>' ;
                          $i++;
                          }
                          else
                          {
                          echo '<td>'. $row->time_from_to . " - " . $row->time_homevisit . "<br>" . $row->clinichomevisit . "<br>" . $row->adr1 . " " . $row->adr2 . " ". $row->adr3 . $row->pincode . "<br>" . $row->dr_assigned  . '</td>' ;
                          echo '<td>'. $row->patientname . " - " . $row->petsname . "<br>" . $row->mobileno . "<br>" . $row->clinictype .  '</td>' ;                          $i=0;
                          echo "</tr>";
                          }
                     }
                   } 

              }
    ?> 
  </table>
<form  name="mypetdetails1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   

<br>
<h2> New Appointment Details of Clinic  </h2>  
  <table>
<tr>     <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Appointment : </span> </td>
    <td> <span style="font-size:15px;cursor:pointer;color="black"> 
         <input type="date"  name="dateofappointment2" id="dateofappointment2" value=""> <br>
         <input type="date" readonly  name="dateofapp3" id = "dateofapp3" value="<?php if (isset($_POST['show1'])) { $wdateofapp3 = $_POST["dateofappointment2"]; echo $wdateofapp3; }  ?>" >
 
         </span>
    </td>

<td> <span style="font-size:15px;cursor:pointer;color="black"> Clinic Name : </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="ClinicName2" id ="ClinicName2" required>
       <option value="PETS">Sai Vets Clinic </option>
       <option value="HUMAN">Panchgavya Clinic </option>
     </select> <br>
     <input type="text" readonly  name="cname2" id="cname2" value="<?php if (isset($_POST['show1'])) { $clinicname = $_POST["ClinicName2"]; $wClinicName2 = $_POST["ClinicName2"]; echo $wClinicName2; }  ?>" >

</span> 
</td>
    <td> <button type="submit" class="button" name="show1" id="show1" >Select </button>  
    </td> 


  </tr>
  <tr>
      <?php
      if ($clinicname == "PETS")
      { ?>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Clinic Visit / Home Visit: </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="ClinicHome">
     <?php
      if (isset($_POST['show1'])) 
      {
       echo '<option value="Clinic">Clinic Visit </option>';
       echo '<option value="Home">Home Visit </option>';
      }
     ?>
     </select> </span>
     </td>
     <?php
     } 

      if ($clinicname == "HUMAN")
      { ?>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Clinic Visit / Home Visit: </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="ClinicHome">
     <?php
      if (isset($_POST['show1'])) 
      {
       echo '<option value="Clinic">Clinic Visit </option>';
      }
     ?>
     </select> </span>
     </td>
     <?php
     } 
     ?>
      <?php
      if ($clinicname == "PETS")
      { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> Patient Name : </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="PetsPatientname" id ="PetsPatientname"  onchange="onPetsPatientChange()">
       <option value="0">New Patient </option>
     <?php
         if (isset($_POST['show1'])) 
         {
                 // $clinicdate = $_POST['dateofappointment'];
                  $sql1 ="SELECT * FROM petsinformationdetail ";
                  $query1 = $this->db->query($sql1);
                  if ($query1->num_rows() > 0)
                  {
                     foreach ($query1->result() as $row1)  
                     {
                          echo "<option value=". $row1->userid . "~". $row1->petid .  ">" .   $row1->username . "~" . $row1->petname . "~" . $row1->userid . "~". $row1->petid . "</option>";
                     }
                   } 
         }
     ?>
     </select> 
     <br>
     <input type="text" name="PetsNewPatient" id = "PetsNewPatient" value="">
     </span> 
     </td> 
     <?php
     }
     if ($clinicname == "HUMAN")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> Patient Name : </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="HumanPatientname" id="HumanPatientname" onchange="onHumanPatientChange()">
       <option value="0">New Patient </option>
     <?php
         if (isset($_POST['show1'])) 
         {
                  $clinicdate = $_POST['dateofappointment'];
                  $sql1 ='SELECT * FROM `user_login` WHERE  pethuman = "HUMAN" and user_type = "USER" ';
                  $query1 = $this->db->query($sql1);
                  if ($query1->num_rows() > 0)
                  {
                     foreach ($query1->result() as $row1)  
                     {
                          echo "<option value=". $row1->id . ">" .   $row1->nameofperson  . "</option>";
                     }
                   } 
         }
     ?>
     </select> 
     <br>
     <input type="text" name="HumanNewPatient" id = "HumanNewPatient" value="">
     </span> 
     </td> 
     <?php
     }
     ?>
   </tr>
   <tr>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Mobile No : </span> </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
          <input type="text" name="mobileno" id="mobileno" value="">
     </td>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> From Time/To Time : </span> </td>
     <?php
     if ($clinicname == "PETS")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
          <select name="fromtime">
            <option value = "0">Home visit </option>
            <option value="09.00 am - 09.30 am"> 09.00 am to 09.30 am  </option>
            <option value="09.30 am - 10.00 am"> 09.30 am to 10.00 am  </option>
            <option value="10.00 am - 10.30 am"> 10.00 am to 10.30 am  </option>
            <option value="10.30 am - 11.00 am"> 10.30 am to 11.00 am  </option>
            <option value="11.00 am - 11.30 am"> 11.00 am to 11.30 am  </option>
            <option value="11.30 am - 12.00 pm"> 11.30 am to 12.00 pm  </option>
            <option value="12.00 pm - 12.30 pm"> 12.00 pm to 12.30 pm  </option>
            <option value="12.30 pm - 01.00 pm"> 12.30 pm to 01.00 pm  </option>
            <option value="01.00 pm - 01.30 pm"> 01.00 pm to 01.30 pm  </option>
            <option value="01.30 pm - 02.00 pm"> 01.30 pm to 02.00 pm  </option>
          </select>
          <br>
          <input type="text" name="homevisittime" id="homevisittime" value="">
     </td>
     <?php
      } ?>
     <?php
     if ($clinicname == "HUMAN")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
          <select name="fromtime">
            <option value="09.00 am - 09.30 am"> 09.00 am to 09.30 am  </option>
            <option value="09.30 am - 10.00 am"> 09.30 am to 10.00 am  </option>
            <option value="10.00 am - 10.30 am"> 10.00 am to 10.30 am  </option>
            <option value="10.30 am - 11.00 am"> 10.30 am to 11.00 am  </option>
            <option value="11.00 am - 11.30 am"> 11.00 am to 11.30 am  </option>
            <option value="11.30 am - 12.00 pm"> 11.30 am to 12.00 pm  </option>
            <option value="12.00 pm - 12.30 pm"> 12.00 pm to 12.30 pm  </option>
            <option value="12.30 pm - 01.00 pm"> 12.30 pm to 01.00 pm  </option>
            <option value="01.00 pm - 01.30 pm"> 01.00 pm to 01.30 pm  </option>
            <option value="01.30 pm - 02.00 pm"> 01.30 pm to 02.00 pm  </option>

            <option value="06.00 pm - 06.30 pm"> 06.00 pm to 06.30 pm  </option>
            <option value="06.30 pm - 07.00 pm"> 06.30 pm to 07.00 pm  </option>
            <option value="07.00 pm - 07.30 pm"> 07.00 pm to 07.30 pm  </option>
            <option value="07.30 pm - 08.00 pm"> 07.30 pm to 08.00 pm  </option>
            <option value="08.00 pm - 08.30 pm"> 08.00 pm to 08.30 pm  </option>
            <option value="08.30 pm - 09.00 pm"> 08.30 pm to 09.00 pm  </option>
            <option value="09.00 pm - 09.30 pm"> 09.00 pm to 09.30 pm  </option>
            <option value="09.30 pm - 10.00 pm"> 09.30 pm to 10.00 pm  </option>
          </select>
          <br>
          <input type="text" hidden name="homevisittime" id="homevisittime" value="">
     </td>
     <?php
      } ?>
   </tr>
   <tr>
   <td> <span style="font-size:15px;cursor:pointer;color="black"> Doctor Name : </span> </td>
     <?php
     if ($clinicname == "PETS")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="DoctorName">
       <option value="DrAniket">Dr. Aniket </option>
       <option value="Dr. Raje">Dr. Raje </option>
     </select> </span> 
     </td>
     <?php
     } ?>
     <?php
     if ($clinicname == "HUMAN")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
     <select name="DoctorName">
       <option value="Dr. Raje">Dr. Raje </option>
     </select> </span> 
     </td>
     <?php
     } ?>
   <td> <span style="font-size:15px;cursor:pointer;color="black"> Home Visit Address : </span> </td>
     <?php
     if ($clinicname == "PETS")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
        <input type="text" name="adr1" id="adr1" value=""> <br>
        <input type="text" name="adr2" id="adr2" value=""> <br>
        <input type="text" name="adr3" id="adr3" value=""> <br>
        Pin code : <input type="text" name="pincode" id="pincode" value=""> <br>
        Mobile/Phone : <input type="text" name="mobilephone" id="mobilephone" value="">
     </span> 
     </td>
     <?php
     } ?>
     <?php
     if ($clinicname == "HUMAN")
     { ?>
     <td> <span style="font-size:15px;cursor:pointer;color="black"> 
        <input type="text" name="adr1" id="adr1" value=""> <br>
        <input type="text" name="adr2" id="adr2" value=""> <br>
        <input type="text" name="adr3" id="adr3" value=""> <br>
        Pin code : <input type="text" name="pincode" id="pincode" value=""> <br>
        Mobile/Phone : <input type="text" name="mobilephone" id="mobilephone" value="">
     </span> 
     </td>
     <?php
     } ?>
  </tr>
  </table>
 <center> <!-- <a  href="<?php echo base_url().'index.php/Home_Dr_Raje/updatepetsappointments/' ?> "><button type="button" class="button" name="appsubmit" id="appsubmit" >Update</button> </a> </center> --> 
 <button type="submit" class="button" name="appsubmit" id="appsubmit" >Update</button>  
</center> 
<hr>
</div>
</div>
</form>
</body>
</html>