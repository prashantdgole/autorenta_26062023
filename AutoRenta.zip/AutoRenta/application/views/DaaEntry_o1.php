<?php
if (isset($_POST['paysubmit'])) 
{
die("1");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>

<!-- <form  name="mydaa"           method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> -->
<form  name="mydaa" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   

<button type="submit" class="button" name="paysubmit" id="paysubmit" >Update Payment</button>  

<!-- <center> <input type="submit"  name="dsmit" id="dsmit" value ="Submit Daily Register" >  </center> -->
 
<br>
</form>  
</body>
</html>