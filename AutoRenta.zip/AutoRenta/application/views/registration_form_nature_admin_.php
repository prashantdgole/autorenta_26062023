<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// die("here");

if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
//  echo " **************** 0 ";
// die("here");
  header("location: login");
}



if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Registration Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

//

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_Registration"; ?>'>Registration</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_Maintenance"; ?>'>Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/Nature_report_upload"; ?>'>Report Upload</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminnature"; ?>'>Admin</a>
</div>


//


<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>



 <div id="main">
<div id="login"> 
<span style="font-size:20px;cursor:pointer;color="black"> Naturopathy Admin  Registration Form </span>
<!-- <h2>Registration Form</h2> -->
<hr/>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('Home_Dr_Raje/new_user_registration_nature'); 
echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}
echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
echo form_label('Create Username : '); 
echo '</span>';
echo"<br/>";
 
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_input('username'); 
echo '</span>';
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}
echo "</div>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Email : '); 
echo '</span>';
echo"<br/>";
$data = array(
'type' => 'email',
'name' => 'email_value'
);
echo form_input($data);
echo"<br/>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('User Type '); 
echo '</span>';
// echo "<br/>";
echo "&nbsp;&nbsp;";
//echo form_input('user_type_value');

$options = array(
                  'ADMIN'  => 'ADMIN',
                );

//$shirts_on_sale = array('small', 'large');

echo form_dropdown('user_type_value', $options, 'ADMIN');
echo"<br/>";
echo"<br/>";
echo '<span style="font-size:15px;cursor:pointer;color="black">';
echo form_label('Password : ');
echo '</span>';
echo"<br/>";
echo form_password('password');

// CLINIC TYPE
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Clinic Type :</label> </span>';
$options1 = array(
                  'NATURE'  => 'NATURE',
                );  
 echo form_dropdown('pethuman', $options1, 'NATURE');

// PETS owner or patients name 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Persons Name :</label> </span>';
echo form_input('nameofperson'); 


// PETS owner or patients address 
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Address :</label> </span>';
echo form_input('ad1'); 
echo form_input('ad2'); 
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Pin Code :</label> </span>';
echo form_input('pincode'); 


// PETS owner or patients mobile 1 and mobile 2
echo "<br>";
echo "<br>";
echo '<span style="font-size:15px;cursor:pointer"><label>Mobile  1 and 2 :</label> </span>';
echo form_input('mobile1'); 
echo form_input('mobile2'); 


echo"<br/>";
echo"<br/>";
echo form_submit('submit', 'Create USER');
echo form_close();
?>
<span style="font-size:15px;cursor:pointer;color="black">;
<a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>For Login Click Here</a>
</span>;
<!-- <a href="<?php echo base_url() ?> ">For Login Click Here</a> -->
  </div>
</div> 
</div>
</div>
</body>
</html>