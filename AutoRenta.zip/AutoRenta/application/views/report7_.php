<?php
$msg = "";
$this->load->library('session');
$this->load->helper('file');
$this->load->helper('form');
 
defined('BASEPATH') OR exit('No direct script access allowed');


// echo isset($this->session->userdata['logged_in']);

// die("here");

if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
//  echo " **************** 0 ";
// die("here");
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttonsmall {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 9px;
  margin: 4px 2px;
  cursor: pointer;
}

.btnBack{
      background: #3498db;
      border: solid 1px;
      border-color: #3498db;
      background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
      background-image: -moz-linear-gradient(top, #3498db, #2980b9);
      background-image: -ms-linear-gradient(top, #3498db, #2980b9);
      background-image: -o-linear-gradient(top, #3498db, #2980b9);
      background-image: linear-gradient(to bottom, #3498db, #2980b9);
      -webkit-border-radius: 5;
      -moz-border-radius: 5;
      border-radius: 5px;
      color: #ffffff;
      font-size: 15px;
      padding: 5px;
      width: 250px;
      text-decoration: none;
    vertical-align: middle;
    }

</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
}
table
{
  border=1;
}
p {
    font-size: 20px;
}
</style>

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<?php
if ($patient_class_value == "DAA")
{ ?>
<div id="mySidenav" class="sidenav">
<span style="font-size:10px;cursor:pointer" >
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>LogOff</a>
 <!-- <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log Off</a> -->
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/report1"; ?>'>On Date </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/report2"; ?>'>On Employee  </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/report3"; ?>'> On Customer  </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/report4"; ?>'>Payroll  Page</a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/report5"; ?>'>Employee Payroll</a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/report6"; ?>'>Late Comers  </a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/report7"; ?>'> Out Station  </a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/report8"; ?>'> Employee List </a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/report9"; ?>'> Customer List </a>
</div>
<?php
}
else
{ ?>

<div id="mySidenav" class="sidenav">
<span style="font-size:10px;cursor:pointer" >
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>LogOut</a>
<!--  <a href='<?php echo base_url()."index.php/Home_AutoRenta/logout"; ?>'>Log off</a> -->
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/bank_registration_show"; ?>'>Bank Name</a>
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/maintenance_show"; ?>'>All Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/PetEntry"; ?>'>Petty Cash Entry</a> 
  <a href ='<?php echo base_url()."index.php/Home_AutoRenta/PetReports"; ?>'>Petty Cash Reports  </a>
  <a href='<?php echo base_url()."index.php/Home_AutoRenta/PetAdmin"; ?>'> Petty Cash Admin</a>
</span>
</div>
<?php
} ?>
<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

 <div class="mainContainer">
<div class="formContainer">     
<?php
 $attributes = array('id' => 'repo1' ,'name' =>'repo1');  // report 2
echo form_open('Home_AutoRenta/report7_report') ; // , $attributes);
?>

<h2>Report Form</h2>
<hr/>
              
     <table border="0">
        <tr> </tr> <tr>  </tr>
         <tr> <td> From Date : </td> <td> </td> <td> <input type="date" name="datefrom" id="datefrom" value="<?php echo date('Y-m-d');?>" /> </td> 
                <td> To Date : </td> <td> </td> <td> <input type="date" name="dateto" id="dateto" value="<?php echo date('Y-m-d');?>" /> </td> </tr>
      <tr> <td>   Employee Name:      </td> <td> </td> <td>    
                       <select name="empid1" id = "empid1"  style="width:120px;">
                      <option value="0">empname </option>  
                        <?php   
                                     $sql ="SELECT * FROM emptable  order by name "  ; 
                                    $query = $this->db->query($sql);  
                                   foreach ($query->result() as $row)
                                   {  // 3.0
                                             echo "<option value=". $row->ecode  . ">" .   $row->name  . "</option>";
                                    } 
                          ?>
                      </select>  
                </td>  
       <td>                       
                     <select name="presentid1" id = "presentid1"   style="width:180px;">
                       <option value="0">NO SELECTION</option>
                         <?php            
                         echo '<option value="PR">LOCAL</option>';
                          echo '<option value="PO">OUTSTATION</option>';
                          echo '<option value="PN">NODUTY</option>';
                         echo '<option value="AB">ABSENT</option>';
                         echo '<option value="HL">HOLIDAY NO DUTY</option>';
                         echo '<option value="HD">HOLIDAY  DUTY</option>';
                          echo '<option value="WO">WEEKLY OFF NO DUTY</option>';
                         echo '<option value="WD">WEEKLY OFF DUTY</option>';
                         echo '<option value="DD">DOUBLE DUTY LOCAL</option>';  
                         echo '<option value="DH">DOUBLE DUTY HOLIDAY</option>';  
                          echo '<option value="HN">HNT NIGHT DUTY</option>';  
                        ?>  
                      </select>  
                </td>
       </tr>
     </table>
   
 
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";
// die("here");
if ($user_type_value != 'ADMIN')
{
// echo $user_type_value . "  1  ------ ";
// die("eee");
   $this->session->set_flashdata('err_message', 'Not a Admin User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>
   <?php
 $attributes = array('class' => 'buttonsmall' );
/*echo form_submit('submit', 'Generate Date Wise Report ');*/
echo '<center>' . form_submit('submit', 'Generate Emp / Date Wise Report',"class='btnBack'"). '</center>';
echo form_close();
?>

</div>
</div>

</body>
</html>