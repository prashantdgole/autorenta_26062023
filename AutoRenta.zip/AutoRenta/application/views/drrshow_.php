<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
if (isset($this->session->userdata['logged_in'])) 
{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>user details show </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->

<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ="#">All Maintenance</a>
 <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
  <a href ="#">Pets Injections</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
 <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseselist"; ?>'> Disease List </a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>


</div>

<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
 

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 <!-- <div id="main">
<div id="login"> --> <!-- display logic start from here  -->

<span style="font-size:20px;cursor:pointer;color="black">Update Registration Records Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
/// remove echo form_open('Home_Dr_Raje/new_injection_registration'); 

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>
<!--   <a href="<?php echo base_url('user_registration_show') ?>"> Create New Item</a> -->
<!-- <a href='<?php echo base_url()."index.php/Home_AutoRenta/user_registration_show"; ?>'>New User Registration</a> -->

<!-- // original start -->

<font color="black">
<hr>

   
<!--  <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left"> -->
            <h2> Show Daily Register Entry</h2>
<!--        </div>
        <div class="pull-right"> -->
           <a class="btn btn-primary" href='<?php echo base_url()."index.php/Home_AutoRenta/drrmaintain"; ?>'>Back</a>
<!--        </div>
    </div>
</div> -->
 
<table>

         <tr>   
               <td>
                <?php
                  $xempid = $daaentry->empid;
                  $empname="";
                  $sql ="SELECT * FROM emptable where ecode  = " . $xempid  ; 
                  $query1 = $this->db->query($sql);  
                  foreach ($query1->result() as $row)
                  {  // 3.0
                     $empname = $row->name ;
                  } 
                 ?>
                  <span style="font-size:14px;cursor:pointer;color="black"> 
                  <?php echo  "Emp Name:" . "<br>". $empname ;  ?> 
                     </span> 
                  </td>
              <td>
                      <span style="font-size:12px;cursor:pointer;color="black"> 
                     Presentee <br>
                      <input type="text" name="presentid1" readonly id = "presentid1"  style="width:80px;" value="<?php echo $daaentry->presentabsent;?>">
                     </span> 
               </td>
               <td>
                      <span style="font-size:14px;cursor:pointer;color="black"> 
                      Duty <br>
                      <input typ="text" name="dutyid1" id = "dutyid1" readonly  value="<?php echo $daaentry->duty;?>" style="width:80px;">
                     <br>
                     <input type="date" name="outdate1_1"  readonly   id="outdate1_1"  value="<?php echo $daaentry->outstationdatefrom;?>"/> &nbsp; &nbsp;
                      <input type="date" name="outdate1_2"  readonly   id="outdate1_2"   value="<?php echo $daaentry->outstationdateto;;?>" />
                     </span> 
               </td> 
              <td>
                    <span style="font-size:14px;cursor:pointer; width:40px;color="black"> 
                  Shift <br>
                   <input type="text"   name="shiftid1" id = "shiftid1" readonly  value="<?php echo $daaentry->shift;?>"  style="font-size:12px;width:40px;" />
                     </span> 
             </td>
             <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
               <?php
                  $xcustid = $daaentry->customerid;
                  $custname="";
                  $sql ="SELECT * FROM customer where id = " . $xcustid  ; 
                  $query1 = $this->db->query($sql);  
                  foreach ($query1->result() as $row)
                  {  // 3.0
                     $custname = $row->name ;
                  } 
                 ?>
                  <span style="font-size:14px;cursor:pointer;color="black"> 
                  <?php echo  "Customer :"  .  "<br>" . $custname ;  ?> 
                     </span> 
             </td>
              <td>
                    <span style="font-size:14px;cursor:pointer;color="black">
                    Passenger <br> 
                     <input type="text" name="pass1" id="pass1"  readonly value="<?php echo $daaentry->passengername; ?>" style="font-size:12px;width:40px;" >
                     </span> 
             </td>
        </tr>
        <tr>
            <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                    In Time <br>
                     <input type="text" name="intime1" id="intime1" value="<?php echo $daaentry->intime; ?>" style="font-size:12px;width:80px;" > <br>
                    Actual In <br>
                    <input type="text" name="acttime1" id="acttime1" readonly  value="<?php echo $daaentry->actualintime; ?>" style="font-size:12px;width:80px;" >
             </td>
            <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                    Out Time <br>
                     <input type="text" name="outtime1" id="outtime1"  readonly value="<?php echo $daaentry->outtime; ?>" style="font-size:12px;width:80px;" > <br>
                      Actual Out Time <br>
                    <input type="text" name="actouttime1" id="actouttime1" readonly  value="<?php echo $daaentry->actualouttime; ?>" style="font-size:12px;width:80px;" >
                     </span>   
             </td>
            <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                     work Duration <br>
                     <input type="text" name="workduration1"  readonly id="workduration1" value="<?php echo $daaentry->worktime; ?>" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
            <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                   Over Time <br>
                     <input type="text" name="ottime1" id="ottime1" value="<?php echo $daaentry->ottime; ?>" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
             <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                    Total Time <br>
                     <input type="text" name="tottime1" id="tottime1" value="<?php echo $daaentry->totalduration; ?>" style="font-size:12px;width:30px;" >  
                     </span>  
             </td>
       </tr>
       <tr>
            <td>
                    <span style="font-size:14px;cursor:pointer;color="black"> 
                     Remaks : 
                     <input type="text" name="remarks1" id="remarks1" value="<?php echo $daaentry->remarks; ?>" style="font-size:12px;width:140px;" >  
                     </span>  
             </td>
           </tr>
           <tr> <td> Finance Part </td> </tr>
           <tr>
                <td> Basic Salary <br>
                  <input type="text" name="basicsalary" id="basicsalary"   readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->basicsalary; ?>"/>
               </td>
                <td> Total Allowance <br>
                  <input type="text" name="totalallowance" id="totalallowance"   readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->totalallowance; ?>"/>
               </td>
                <td> Cleaning <br>
                  <input type="text" name="cleaningallowance" id="cleaningallowance"  readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->cleaningallowance; ?>"/>
               </td>
                <td> Night Allowance <br>
                  <input type="text" name="nightallowance" id="nightallowance"  readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->nightallowance; ?>"/>
               </td>
          </tr>
         <tr>
                <td> Day Allowance <br>
                  <input type="text" name="dayallowance" id="dayallowance"  readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->dayallowance; ?>"/>
               </td>
                <td> Double shift <br>
                  <input type="text" name="doubleshift" id="doubleshift"  readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->doubleshift; ?>"/>
               </td>
                <td> Over Time<br>
                  <input type="text" name="overtime" id="overtime"  readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->overtime; ?>"/>
               </td>
                 <td> Less <br> Late Coming
                  <input type="text" name="latecoming" id="latecoming"  readonly style="font-size:12px;width:140px;" value="<?php echo $daaentry->latecoming; ?>"/>
               </td>
                <td> Day Salary<br>
                  <input type="text" name="daysalary" id="daysalary" readonly  style="font-size:12px;width:140px;" value="<?php echo $daaentry->daysalary; ?>"/>
               </td>
        </tr>
</table> 

<?php
?>

  </div>
<!-- </div> main and logic  
</div> -->
</div>
</body>
</html>