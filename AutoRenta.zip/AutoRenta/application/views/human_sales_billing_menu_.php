<?php
$this->load->library('session');
$this->load->helper('file');
defined('BASEPATH') OR exit('No direct script access allowed');
//if (isset($this->session->userdata['logged_in'])) 
//{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
//}
//$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN ";
//$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';


//

if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}


if ($patient_class_value == 'HUMAN')
{
$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN PanchaGavya Clinic ";
$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';
}
else
{
$_SESSION['global_company_name'] = "Dr Raje's PARTH PRATISTHAN Sai Vets Clinic ";
$_SESSION['global_company_address'] = 'Glass Bunglow, Patri Pool, Kalyan.East (Mobile) 9820998016';
}



//
 
?>
<?php
$mypatientid=0;
$mypatientname='';
$mysalesbillid = "";
$mypatientname = "";
$mysalesbillno = "";
$explodesalesbill = "";
$myidarray = []; 
?>
<?php //1
if (isset($_POST['Print_me'])) 
{   // 2
   $totdiscount = 0.00;
   $totbill = 0.00;
   $tottax = 0.00;
   $totitem=0;
// echo $_SESSION["global_sales_billno"] . " For Patient Id Name : " . $_SESSION["global_patient_id"]  . " nm " . $_SESSION["global_patient_name"] ;       
// die("here"); 
  $txt=  base_url() ;
  $filename =    $_SESSION["global_patient_id"]. "_". $_SESSION["global_patient_name"] .'.html';
//  echo $filename;
  $myfile = fopen($filename, "w") or die("Unable to open file!");
  $txt = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">'. '<br>' ;
  fwrite($myfile, $txt);
  $txt = '<html>';
  fwrite($myfile, $txt);
  $txt = '<head>' . '<br>'. '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
  fwrite($myfile,$txt);
  $txt = '<style type="text/css" media="print, handheld">';
  fwrite($myfile,$txt);
  $txt = 'h1 { background-color: #6495ed; }';
  fwrite($myfile,$txt);
  $txt = 'p { background-color: #e0ffff; }';
  fwrite($myfile,$txt);
  $txt = 'div {     background-color: #b0c4de; }';
  fwrite($myfile,$txt);
  $txt = '.footer { bottom: 0; left: 0; background-color: white; width: 100%; font-size:.3em;  font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }';
  fwrite($myfile,$txt);
  $txt ='.footerInner p{     font-size:1.3em; font-weight:bold; font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }';
  fwrite($myfile,$txt);
  $txt = '</style>';
  fwrite ($myfile,$txt);
  $txt='</head>';
  fwrite($myfile,$txt);
  $txt = '<body bgcolor="#E6E6FA">';
  fwrite($myfile, $txt);
  $txt = '<font face="Verdana"><font size=2>';
  fwrite($myfile, $txt);
  $txt = '<center>';
  fwrite($myfile,$txt);
  $txt = '<table border="0">';  // with border line border="1"
  fwrite($myfile, $txt);
  $txt = '<tr><td> SALES INVOICE </td> </tr> <tr> </tr> ';
  fwrite($myfile,$txt);
  $txt = '<tr> <td>' . $_SESSION["global_company_name"] . '</td> </tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td>' . $_SESSION["global_company_address"] . '</td> </tr>';
  fwrite($myfile,$txt);
  $txt = '</table>';
  fwrite($myfile,$txt);
  $txt = "<br>";
  fwrite($myfile,$txt);
 
  $fulladdress="";
  $sql ="SELECT * FROM user_login where id = " . $_SESSION["global_patient_id"] ; 
  $query = $this->db->query($sql);  
  foreach ($query->result() as $row)
  {  // 3.0
    $fulladdress = $row->ad1 . " ". $row->ad2 . " ". $row->pincode ;
  } 
 
  $txt = '<table border="0">';  // with border line border="1"
  fwrite($myfile, $txt);
  $txt = '<tr> <td> Bill No : </td> <td>'.  $_SESSION["global_sales_billno"] . ' </td> <td> Patient Name : </td> <td>' . $_SESSION["global_patient_name"] . ' </td> </tr> ';   
  fwrite($myfile, $txt);
 
  $txt = '<tr> <td> '. $fulladdress . '</td> </tr></table>';
  fwrite($myfile,$txt);  
  $txt = "<br>";
  fwrite($myfile,$txt);
  $txt = '<table border="1">';  // with border line border="1"
  fwrite($myfile, $txt);
  $txt = '<tr>';
  fwrite($myfile, $txt);
  $txt = '<td>  <span style="font-size:15px;cursor:pointer;color="black"> ID </td>';
  fwrite($myfile, $txt);  
  $txt = '<td> <span style="font-size:15px;cursor:pointer;color="black"> Date   <br> Stock name</span> </td> ';
  fwrite($myfile, $txt);             
  $txt = '<td> <span style="font-size:15px;cursor:pointer;color="black"> HSN Code <br> Sale Qty </span> </td> ';
  fwrite($myfile, $txt);
  $txt = '<td>  <span style="font-size:15px;cursor:pointer;color="black"> Rate  <br> Gst% </span> </td> ';
  fwrite($myfile, $txt);
  $txt = '<td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> ';
  fwrite($myfile, $txt);
  $txt ='<td>  <span style="font-size:15px;cursor:pointer;color="black"> Amount <br> Total Amount  </span> </td>';
  fwrite($myfile, $txt);
  $txt = '</tr>';
  fwrite($myfile,$txt);
  $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $_SESSION["global_patient_id"] . " and " . " salesbill = '" . $_SESSION["global_sales_billno"] . "'"  ; 
  $query = $this->db->query($sql);  
  $i=0; 
  $_SESSION['global_sales_record'] = 0;
  foreach ($query->result() as $row)
  {  // 3
     $totitem++;
     $txt = '<tr>';
     fwrite($myfile,$txt);
     $myidarray[$i] = $row->id;  
     $txt = '<td> <span style="font-size:15px;cursor:pointer;color="black">' .  $row->id . ' </td>';
     fwrite($myfile,$txt);
     $txt ='<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->date . "<br>" . $row->stockname . '</td>';
     fwrite($myfile,$txt);
     $txt ='<td><span style="font-size:15px;cursor:pointer;color="black">' .  $row->hsncode . "<br>" . $row->saleqty . ' </td>';
     fwrite($myfile,$txt);
     $txt = '<td><span style="font-size:15px;cursor:pointer;color="black">' . $row->salesrate . "<br>" . $row->gstperc . ' </td>';
     fwrite($myfile,$txt);
     $txt = '<td><span style="font-size:15px;cursor:pointer;color="black">' .  $row->discountperc . "<br>" . $row->discountamount . ' </td>';
     $totdiscount = $totdiscount + $row->discountamount;
     fwrite($myfile,$txt);
     $txt = '<td><span style="font-size:15px;cursor:pointer;color="black">' .  $row->itemtotal . "<br>" . $row->total . ' </td>';
     $totbill = $totbill + $row->itemtotal;
     fwrite($myfile,$txt);
     $txt = '</tr>';
     fwrite($myfile,$txt);
   }; // 3 over
  $txt = '<tr> <td></td> <td></td> <td></td> <td></td> <td>Total Items </td> <td> ' . $totitem . ' </td> </tr>';
  fwrite($myfile,$txt);
  $txt = '<tr> <td></td> <td></td> <td></td> <td></td> <td>Total Discount </td> <td>' .  $totdiscount . ' </td> </tr>';
  fwrite($myfile,$txt);
  $txt = '<tr> <td></td> <td></td> <td></td> <td></td> <td>Total Bill Amount </td> <td>' .  $totbill . ' </td> </tr>';
  fwrite($myfile,$txt);
  $txt = '</table>';
  fwrite($myfile, $txt);

// paid amount logic

  $sql ="SELECT * FROM saleshumanbill where patientid = " . $_SESSION["global_patient_id"] . " and " . " salesbill = '" . $_SESSION["global_sales_billno"] . "'"  ; 
  $query = $this->db->query($sql);  
  $i=0; 
  $_SESSION['global_sales_record'] = 0;
  $txt = "<br>";
  fwrite($myfile,$txt);
  $txt = '<table border="1">';
  fwrite($myfile,$txt);
  $txt = '<tr><td>Date</td><td>Bill Amount </td><td>Discount</td><td>Paid Amount</td><td>Balance Amount </td> </tr>';
  fwrite($myfile,$txt);
  foreach ($query->result() as $row)
  {  // 3.1 
     $i++;
     $txt = '<tr><td>'. $row->datepaid . '</td><td>' . $row->billamount . '</td><td>'. $row->discountbill . '</td><td>'. $row->paidamount . '</td><td>' . $row->balanceamount . '</td></tr>';
     fwrite($myfile,$txt);
  } // 3.1 
  if ($i == 0 )
  {
     $txt = '<tr><td>This Bill is not paid </td> </tr>';
     fwrite($myfile,$txt);
  }
// paid amount logic
  $txt ='</table>';
  fwrite($myfile,$txt);
  $txt = "</body></html>";
  fwrite($myfile, $txt);
  fclose($myfile);
  $txt = base_url($filename);
  ?> // 1.1 over
   <a href='<?php echo $txt; ?>' target="_blank">  Open Invoice .. (<?php echo $txt ?>)  </a>  <br><br>
  <?php
}
?>




<?php
if (isset($_POST['Del_me'])) 
{
   if(!empty($_POST['delme']))
   {



     $j=0;

     foreach($_POST['delme'] as $selected) 
     {
//        if (isset($_POST['delme']))
//        {
         $id=$selected;
/*
        $tables = array('saleshumanstocklist');
        $this->db->where('id', $id);
        $this->db->delete($tables);
        $sql =   " Delete record " . $id ; */
        $sql = "Delete FROM saleshumanstocklist where  id = " . $id  ; 
        $query = $this->db->query($sql);
//        echo $sql;
//       }
     }
   }
 

}
?>
<!DOCTYPE html>
<html>
<head>
<title>Pet Type List Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />


<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})


function onSelectChangeqty1()
{
    var sel = document.getElementById('sid1');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids1.value=sp_lit[0];
    document.mypetdetails1.hsc1.value=sp_lit[1];
    document.mypetdetails1.rate1.value=sp_lit[2];
    document.mypetdetails1.gst1.value=sp_lit[3];
}

function onSelectChangeqty2()
{
    var sel = document.getElementById('sid2');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids2.value=sp_lit[0];
    document.mypetdetails1.hsc2.value=sp_lit[1];
    document.mypetdetails1.rate2.value=sp_lit[2];
    document.mypetdetails1.gst2.value=sp_lit[3];
}

function onSelectChangeqty3()
{
    var sel = document.getElementById('sid3');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids3.value=sp_lit[0];
    document.mypetdetails1.hsc3.value=sp_lit[1];
    document.mypetdetails1.rate3.value=sp_lit[2];
    document.mypetdetails1.gst3.value=sp_lit[3];
}

function onSelectChangeqty4()
{
    var sel = document.getElementById('sid4');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids4.value=sp_lit[0];
    document.mypetdetails1.hsc4.value=sp_lit[1];
    document.mypetdetails1.rate4.value=sp_lit[2];
    document.mypetdetails1.gst4.value=sp_lit[3];
}

function onSelectChangeqty5()
{
    var sel = document.getElementById('sid5');
    var strUser = sel.options[sel.selectedIndex].text;  //getting the selected option's text
    var sp_lit = strUser.split('~');  
    document.mypetdetails1.ids5.value=sp_lit[0];
    document.mypetdetails1.hsc5.value=sp_lit[1];
    document.mypetdetails1.rate5.value=sp_lit[2];
    document.mypetdetails1.gst5.value=sp_lit[3];
}

</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<!-- <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'> -->
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


</style>

</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log off</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_new_sales_medicines"; ?>'>Medicines to Patient (Sales Bill) </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_approve_purchase_medicines"; ?>'>Approve Sales billing</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_return_medicines"; ?>'>Return By Patient (not required)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reject_medicines"; ?>'>Rejection by Patient (Replacement)</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/human_purchase_reports"; ?>'>Reports print </a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/adminhuman"; ?>'>Admin</a>
</div>

 <p>
  <span style="font-size:30px;color="BLACK";cursor:pointer"  onclick="openNav()">&#9776; open</span>  
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
 

 <div class="mainContainer">
  <div class="formContainer">     


 
<span style="font-size:20px;cursor:pointer;color="black">Patients Sales Bill Form </span>

<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";

echo "<div class='error_msg'>";
if (isset($message_display)) 
{
echo $message_display;
echo"<br/>";
echo "</div>";
}

// echo '<span style="font-size:15px;cursor:pointer;color="black">';
 
?>


<!-- // original start -->

<font color="black">
<hr>
<h2> Enter Medicines for Patient </h2>
<a  href='<?php echo base_url()."index.php/Home_Dr_Raje/admin"; ?>'>Back</a>

  <form  name="mypetdetails" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">   


    <?php


    if ($this->session->flashdata('errors')){
        // echo '<div class="alert alert-danger">'; --
        echo $this->session->flashdata('errors');
        // echo "</div>";
    }


    ?>
    
 
    <table>
        <tr>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Existing Patient Bills   : </span> </td>
              <td>  <span style="font-size:15px;cursor:pointer;color="black"> 
                      <select name="salesbillid" id = "salesbillid" style="width:100px;">
                      <option value="0">Sales Bill </option>  
                         <?php 
                        foreach ($data3 as $data3) { 
                         echo "<option value=" . $data3->salesbill .  ">" .   $data3->salesbill  . "~"  . $data3->patientname       . "</option>";
                          }  ?>  
                      </select> </span> <br> <button type="submit" class="button" id="show1" name="show1" >Show Records </button> 
                       
                             
               </td>
              <td> 
                      <span style="font-size:15px;cursor:pointer;color="black">New Patient Name  :
                      <select name="patientid" id = "patientid" style="width:100px;">
                      <option value="0">patientname </option>  
                         <?php 
                        foreach ($data1 as $data1) { 
                         echo "<option value=". $data1->id . ">" .   $data1->nameofperson  . "</option>";
                          }  ?>  
                      </select>  
                     </span> <br> <button type="submit" id="show" class="button" name="show" >New Bill </button> 
             </td>
             <td> </td>
          <tr>

 
        <tr>              
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Name of Person: </span> </td>
               <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                        <input type="text" id="nameofperson" name="nameofperson" readonly  value= "<?php 
                         if (isset($_POST['show'])) 
                         { 
                           $mypatientid = $_POST['patientid']; 
                           $_SESSION['global_patient_id'] = $_POST['patientid'] ; 
                           $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                           $query = $this->db->query($sql);   
                           foreach ($query->result() as $row) 
                           { 
                             $mypatientname = $row->nameofperson; 
                             $_SESSION['global_patient_name']= $row->nameofperson;  
                             echo $row->nameofperson;  
                           }    
                         }  

                         if (isset($_POST['show1'])) 
                         { 
                           $mysalesbillno = $_POST['salesbillid'];
                           $_SESSION['global_sales_billno'] = $_POST['salesbillid'];
                           $sql ="SELECT * FROM saleshumanstocklist where  salesbill = '" . $mysalesbillno . "'"  ; 
                           $query = $this->db->query($sql);   
                           foreach ($query->result() as $row) 
                           { 
                             $mypatientid = $row->patientid;  
                             $_SESSION['global_patient_id'] = $row->patientid;; //  $_POST['patientid'] ;                           
                           }    

                            
                           $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                           $query = $this->db->query($sql);   
                           foreach ($query->result() as $row) 
                           { 
                             $mypatientname = $row->nameofperson; 
                             $_SESSION['global_patient_name']= $row->nameofperson;  
                             echo $row->nameofperson;  
                           }    
                         }  

                         ?>" placeholder="name of person "> 
                        <br>
                        <input type="text" id="personid" name="personid" readonly value="<?php 
                             if (isset($_POST['show'])) 
                             {
                               echo $_POST['patientid'];
                             } 
                             if (isset($_POST['show1'])) 
                             {
                                 $i=0;
                                 $mysalesbillno = $_POST['salesbillid'];
                                 $sql ="SELECT * FROM saleshumanstocklist where  salesbill = '" . $mysalesbillno . "'"  ; 
                                 $query = $this->db->query($sql);   
                                 foreach ($query->result() as $row) 
                                 { 
                                   if ($i==0 )
                                   {
                                   echo $row->patientid; 
                                   }
                                   $i++; 
                                 }    
                             } 

                         ?>">
                         </span> 
              </td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> Full Address: </span></td>
              <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                      <input type="text" id="ad1" name="ad1" readonly  value="<?php 
                      if (isset($_POST['show'])) 
                      { 
                         $mypatientid = $_POST['patientid']; 
                         $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                         $query = $this->db->query($sql);   
                         foreach ($query->result() as $row) 
                         { 
                            echo nl2br($row->ad1 . " "  .  $row->ad2  . " " . $row->pincode);   
                         }    
                       }  

                      if (isset($_POST['show1'])) 
                      { 
                         $mysalesbillno = $_POST['salesbillid'];   
                         $_SESSION['global_sales_billno'] = $_POST['salesbillid'] ;

                         $sql ="SELECT * FROM saleshumanstocklist where  salesbill = '" . $mysalesbillno . "'"  ; 
                         $query = $this->db->query($sql);   
                         foreach ($query->result() as $row) 
                         { 
                                   $mypatientid= $row->patientid;  
                                   $_SESSION['global_patient_id']  =  $row->patientid ;
                         }    
                         $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; 
                         $query = $this->db->query($sql);   
                         foreach ($query->result() as $row) 
                         { 
                            echo nl2br($row->ad1 . " "  .  $row->ad2  . " " . $row->pincode); 
                            $_SESSION['global_patient_name'] = $row->nameofperson;
  
                         }    
                       }  

                       ?> " placeholder="full address "> 
                       </span> </td>
            
         </tr>
         <tr>
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Message : </span></td>
             <td> <input type="text" name="messageid"  placeholder="Message" id="messageid" value="<?php 
                  if (isset($_POST['show'])) 
                  {
                    $mypatientid = $_POST['patientid'];   
                    $mysalesbillid=  $_POST['salesbillid']; 
                    if ( ($mysalesbillid >0 && $mypatientid) >0 ) 
                    {
                       $msg="Both Sales Bills and patient name cannot be clicked";   
                    }  
                    else  
                    { 
                       $msg = "Showing Records ..";  
                    } 
                    echo $msg;  
                  }
                  if (isset($_POST['show1'])) 
                  {
                       $msg = "Showing Records ..";  
                       echo $msg;  
                  } 
                  ?>" > </td>
        </tr>
 
 </table>
<br>
<h2>Other Bills of Patient : <?php if (isset($_POST['show'])) { $mypatientid = $_POST['patientid']; $sql ="SELECT * FROM user_login where  id = " . $mypatientid  ; $query = $this->db->query($sql);   foreach ($query->result() as $row) { echo $row->nameofperson;  }    }  ?> </h2>  
 <table>
       <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Patient name <br> Sales Bill </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date   <br> Stock name</span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> HSN Code<br> Sale Qty </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Rate  <br> Gst% </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Amount <br> Total Amount  </span> </td> 
      </tr>

      <?php 
           if (isset($_POST['show'])) 
           { 
              $mypatientid = $_POST['patientid']; 
              
              $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $mypatientid  ; 
              $query = $this->db->query($sql);   
              foreach ($query->result() as $row)
              { ?>
                <tr>
                <td> <?php echo $row->patientname . "<br>" . $row->salesbill ;  ?> </td>
                <td> <?php echo $row->date . "<br>" . $row->stockname ;  ?> </td>
                <td> <?php echo $row->hsncode . "<br>" . $row->saleqty;  ?> </td>
                <td> <?php echo $row->salesrate . "<br>" . $row->gstperc;  ?> </td>
                <td> <?php echo $row->discountperc . "<br>" . $row->discountamount;  ?> </td>
                <td> <?php echo $row->itemtotal . "<br>" . $row->total;  ?> </td>
                </tr>
              <?php
              }   
            } 

           if (isset($_POST['show1'])) 
           { 
              $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $mypatientid  ; 
              $query = $this->db->query($sql);   
              foreach ($query->result() as $row)
              { ?>
                <tr>
                <td> <?php echo $row->patientname . "<br>" . $row->salesbill ;  ?> </td>
                <td> <?php echo $row->date . "<br>" . $row->stockname ;  ?> </td>
                <td> <?php echo $row->hsncode . "<br>" . $row->saleqty;  ?> </td>
                <td> <?php echo $row->salesrate . "<br>" . $row->gstperc;  ?> </td>
                <td> <?php echo $row->discountperc . "<br>" . $row->discountamount;  ?> </td>
                <td> <?php echo $row->itemtotal . "<br>" . $row->total;  ?> </td>
                </tr>
              <?php
              }   
           }
        ?>
        
  </table>

  <h2> Current Bills Details of bill no : 
  <?php 
  if (isset($_POST['show1'])) 
  { 
     echo $mysalesbillno . " For Patient Name : " . $mypatientname ; 
  } ?>   </h2>   
 <table>
       <tr>
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> ID </td>
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Patient name <br> Sales Bill </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date   <br> Stock name</span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> HSN Code <br> Sale Qty </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Rate  <br> Gst% </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Discount % <br> Discount Amount </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Amount <br> Total Amount  </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black">  Click <br> To Delete Me  </td> 
      </tr>
      <?php 
           if (isset($_POST['show1'])) 
           { 
              $sql ="SELECT * FROM saleshumanstocklist where patientid = " . $mypatientid . " and " . " salesbill = '" . $mysalesbillno . "'"  ; 
              $query = $this->db->query($sql);  
            //  $myidarray = []; 
              $i=0; 
              $_SESSION['global_sales_record'] = 0;
              foreach ($query->result() as $row)
              { ?>
                <tr>
                <?php $myidarray[$i] = $row->id; ?>
                <td> <?php echo $row->id  ;  ?><input type="text" hidden name="delid" id="delid" value="<?php echo $row->id  ;  ?>"> </td>
                <td> <?php echo $row->patientname . "<br>" . $row->salesbill ;  ?> </td>
                <td> <?php echo $row->date . "<br>" . $row->stockname ;  ?> </td>
                <td> <?php echo $row->hsncode . "<br>" . $row->saleqty;  ?> </td>
                <td> <?php echo $row->salesrate . "<br>" . $row->gstperc;  ?> </td>
                <td> <?php echo $row->discountperc . "<br>" . $row->discountamount;  ?> </td>
                <td> <?php echo $row->itemtotal . "<br>" . $row->total;  ?> </td>
                <td> <input type="checkbox" name="delme[]" value="<?php echo $row->id; ?>"> </td>

                </tr>
              <?php
              }   
            }  
        ?>


  </table>
  <center> <button type="submit" id="Del_me" class="button"  name="Del_me" >Delete  </button>   
           &nbsp;&nbsp;
           <button type="submit" id="Print_me" class="button"  name="Print_me" >Print Bill  </button>
  </center> 


   <br>

     </form> <!--              mydetails1 -->
     <form method="post" name="mypetdetails1" action="<?php echo base_url().'index.php/Home_Dr_Raje/updatehumansalesbill/'?>" />   


 

   <h2>   New Sales Bill Entry </h2>
         <table> 
         <tr>
         <td> <span style="font-size:15px;cursor:pointer;color="black"> Sales Bill No  </span> </td>
          <td> <span style="font-size:15px;cursor:pointer;color="black" style="width:100px;"> 
               <input type="text" name="sb1"  id="sb1" value=""> </span> </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">  Date </span> </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                <?php $xdt =  date("Y/m/d") ; // date("d/m/Y",strtotime(today()); ?>
              <input type="date" name="dt1" id="dt1" value="<? echo $xdt; ?>"> </span>
         </td>
         </tr>
    <table>
    <tr>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Stock id <br> Item Description </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black">  Qty Sold <br> Hsn code </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Gst % </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Sgst Amount </span> </td> 
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Cgst Amount </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Rate  </span> </td> 
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Amount </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black">  Discount %  </span> </td> 
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Discount Amount  </span> </td>
      <td> <span style="font-size:15px;cursor:pointer;color="black"> Total </span>  </td>
    </tr>
<!--  first line -->
    <tr> 
         <td> <span style="font-size:15px;cursor:pointer;color="black">  
              <select name="sid1" id="sid1" onchange="onSelectChangeqty1()" style="width:100px;"> 
                 <option value="0">stockname </option>  
                 <?php 
                        foreach ($data2_1 as $data2_1) 
                        { 
                         echo "<option value=". $data2_1->id . ">" .   $data2_1->stockname . "~" . $data2_1->hsncode . "~" . $data2_1->salerate . "~" . $data2_1->gstperc   . "</option>";
                        }  
                 ?>  
                </select>
              <input type="text" name="ids1" id="ids1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="qs1" id="qs1" value=""> <br>
              <input type="text" name="hsc1" id="hsc1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="gst1" id="gst1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="sgamt1" id="sgamt1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="cgamt1" id="cgamt1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="rate1" id="rate1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="amount1" id="amount1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discperc1" id="discperc1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discamt1" id="discamt1" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="total1" id="total1" value=""> </span>
         </td>
       <tr>
 <!-- first line over -->

<!--  second line -->
    <tr> 
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <select name="sid2" id="sid2" onchange="onSelectChangeqty2()" style="width:100px;"> 
                 <option value="0">stockname </option>  
                 <?php 
                        foreach ($data2_2 as $data2_2) 
                        { 
                         echo "<option value=". $data2_2->id . ">" .   $data2_2->stockname . "~" . $data2_2->hsncode . "~" . $data2_2->salerate . "~" . $data2_2->gstperc  . "</option>";
                        }  
                 ?>  
                </select>
              <input type="text" name="ids2" id="ids2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="qs2" id="qs2" value=""> <br>
              <input type="text" name="hsc2" id="hsc2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="gst2" id="gst2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="sgamt2" id="sgamt2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="cgamt2" id="cgamt2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="rate2" id="rate2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="amount2" id="amount2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discperc2" id="discperc2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discamt2" id="discamt2" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="total2" id="total2" value=""> </span>
         </td>
       <tr>
 <!-- second line over -->


<!--  third line -->
    <tr> 
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <select name="sid3" id="sid3" onchange="onSelectChangeqty3()" style="width:100px;"> 
                 <option value="0">stockname </option>  
                 <?php 
                        foreach ($data2_3 as $data2_3) 
                        { 
                         echo "<option value=". $data2_3->id . ">" .   $data2_3->stockname . "~" . $data2_3->hsncode . "~" . $data2_3->salerate . "~" . $data2_3->gstperc  . "</option>";
                        }  
                 ?>  
                </select>
              <input type="text" name="ids3" id="ids3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="qs3" id="qs3" value=""> <br>
              <input type="text" name="hsc3" id="hsc3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="gst3" id="gst3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="sgamt3" id="sgamt3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="cgamt3" id="cgamt3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="rate3" id="rate3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="amount3" id="amount3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discperc3" id="discperc3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discamt3" id="discamt3" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="total3" id="total3" value=""> </span>
         </td>
       <tr>
 <!-- third ine over -->

<!--  fourth line -->
    <tr> 
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <select name="sid4" id="sid4" onchange="onSelectChangeqty4()" style="width:100px;"> 
                 <option value="0">stockname </option>  
                 <?php 
                        foreach ($data2_4 as $data2_4) 
                        { 
                         echo "<option value=". $data2_4->id . ">" .   $data2_4->stockname . "~" . $data2_4->hsncode . "~" . $data2_4->salerate . "~" . $data2_4->gstperc  . "</option>";
                        }  
                 ?>  
                </select>
              <input type="text" name="ids4" id="ids4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="qs4" id="qs4" value=""> <br>
              <input type="text" name="hsc4" id="hsc4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="gst4" id="gst4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="sgamt4" id="sgamt4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="cgamt4" id="cgamt4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="rate4" id="rate4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="amount4" id="amount4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discperc4" id="discperc4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discamt4" id="discamt4" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="total4" id="total4" value=""> </span>
         </td>
       <tr>
 <!-- fourth ine over -->

<!--  fifth line -->
    <tr> 
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <select name="sid5" id="sid5" onchange="onSelectChangeqty5()" style="width:100px;"> 
                 <option value="0">stockname </option>  
                 <?php 
                        foreach ($data2_5 as $data2_5) 
                        { 
                         echo "<option value=". $data2_5->id . ">" .   $data2_5->stockname   . "~" . $data2_5->hsncode . "~" . $data2_5->salerate . "~" . $data2_5->gstperc. "</option>";
                        }  
                 ?>  
                </select>
              <input type="text" name="ids5" id="ids5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="qs5" id="qs5" value=""> <br>
              <input type="text" name="hsc5" id="hsc5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="gst5" id="gst5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="sgamt5" id="sgamt5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="cgamt5" id="cgamt5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="rate5" id="rate5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="amount5" id="amount5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discperc5" id="discperc5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="discamt5" id="discamt5" value=""> </span>
         </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black">
              <input type="text" name="total5" id="total5" value=""> </span>
         </td>
       <tr>
 <!-- fifth ine over -->



    </table>
           <!-- class="btn btn-primary" -->
<hr>
<!--  <center>  <button type="submit" class="button" >Submit</button> </center> -->

 <center>  <button type="submit" class="button" >Update</button>  </center> 


</hr>
</form> 



  </div>

</div>
</body>
</html>