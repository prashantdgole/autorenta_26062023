<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in'])) 
{
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else 
{
// echo " **************** 0 ";
  header("location: login");
}
 // echo $user_type_value . " -1  ------ ";

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<style>
p.small {
    line-height: 0.9;
    font-size: 16px;
    color: red;
}
h1 {
    font-size: 40px;
    color: red;
    left : 50%;
    
}
p {
    font-size: 20px;
}
</style>

<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
</head>
<body>
<?php
if ($patient_class_value == "PETS")
{ ?>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
//  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
//  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/maintenance_show"; ?>'>All Maintenance</a>
//  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Pets Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Pets Reports</a>
//  <a href ="#">Pets Injections</a>
//  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/petlist"; ?>'>Pet List</a>
//  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/diseaselist"; ?>'> Disease List </a>
//  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/injectionlist"; ?>'>Injections List  </a>
//  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/drdiagnosispet"; ?>'>Diagnosis  </a>

</div>
<?php
}
else
{ ?>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/login"; ?>'>Login</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/logout"; ?>'>Log Off</a> 
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/user_registration_show"; ?>'>Registration</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/maintenance_show"; ?>'>All Maintenance</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsdetails"; ?>'>Patient Details</a>
  <a href='<?php echo base_url()."index.php/Home_Dr_Raje/petsreports"; ?>'>Patient Reports</a>
  <a href ='<?php echo base_url()."index.php/Home_Dr_Raje/drdiagnosis_human"; ?>'>Diagnosis  </a>

</div>

<?php
} ?>
<!-- <h2>Right-sided Navigation</h2>
<p>Click on the element below to open the right-sided navigation menu.</p> -->
 <p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>

 <div class="mainContainer">
<div class="formContainer">     


<h2>User Info Form</h2>
<hr/>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
} 
else
 {

  header("location: login");
}
// echo $user_type_value . "  1  ------ ";

if ($user_type_value != 'USER')
{
   $this->session->set_flashdata('err_message', 'Not  User !');
 //   echo $this->session->flashdata('err_message');
   header("location: login");
}

?>
<h2>Pet Other Details  </h2>  
<table>
   <tr> 
          <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  User Information For : <?php echo $_SESSION['global_user_name']; ?>
          </td>
         <td> <span style="font-size:15px;cursor:pointer;color="black"> 
                  Contact Person  : <?php echo $_SESSION['global_name_of_person']; ?>
          </td>
   <tr>
</table>
<br> <br>
  <table>
      <tr> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> User Name <br> Pet Type </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Gender  <br> Pet Name </span> </td> 
             <td> <span style="font-size:15px;cursor:pointer;color="black"> Date of Birth <br> Origin Details</span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> First Visit Date <br> Speciality </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Prev Illness <br> Allergy </span> </td> 
             <td>  <span style="font-size:15px;cursor:pointer;color="black"> Remarks  </span> </td> 
      </tr>
     <?php
             $mypetid = " ";       
              foreach ($data8 as $data8) 
              { 
                 $uid =  $_SESSION['global_user_id'];
                 if ($data8->userid == $uid ) 
                 {
                   $mypetid = $data8->petdetailsid ;
                   echo '<tr>';
                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->username . "<br>".$data8->pettype . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->gender . "<br>".$data8->petname . "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->dateofbirth . "<br>".$data8->origin . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->firstvisitdate . "<br>".$data8->speciality . "</span>";
                   echo '</td>';

                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->illness1 . "<br>".$data8->illness2 . "<br>" . 
                          $data8->allergy1 . "<br>".$data8->allergy2 .  "</span>";
                   echo '</td>';


                   echo '<td><span style="font-size:15px;cursor:pointer;color="black">';   
                   echo $data8->remarks . "</span>";
                   echo '</td>';

                   echo '</tr>';
        ?> 
<!-- 
       <tr> <td> <h2> Previous Visit Details   </h2>   </td> </tr>
       <tr> <td><span style="font-size:15px;cursor:pointer;color="black"> Last Visit Date <br> Pet Name  </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Illness 1 <br> Illness 2 </span> </td> <td><span style="font-size:15px;cursor:pointer;color="black"> Diagnosis 1 <br> Diagnosis 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Medicine1 <br> Medicine 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Bill Amount <br> Paid Amount </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Next Visit <br> Remarks </span> </td> </tr> 
 -->
      <?php

/*
              foreach ($data9 as $data9) 
              { 
                   $pvuserid = $_SESSION['global_user_id'];
                   $pvpetid  = $data8->petdetailsid ; //  $mypetid ; // $_POST['userloginid'];
                   if ($data9->petdetid == $pvpetid ) // ($data9->userid == $pvuserid and 
                   {
                          echo " <tr>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dateofvisit . "<br>" . $data9->petname . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->illness1 . "<br>" . $data9->illness2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dignosis1 . "<br>" . $data9->dignosis2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->medicine1 . "<br>" . $data9->medicine2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->billamount .  "<br>" . $data9->paidamount . "</span></td> ";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->nextvisit . "<br>" . $data9->remarks . "</span></td>";
                          echo "</tr>";
                   }
               } */
            } 
            } 


    ?>
  </table>

<!--
    <h2> Previous Visit Details   </h2>   
   <table>
      
       <tr> <td><span style="font-size:15px;cursor:pointer;color="black"> Last Visit Date <br> Pet Name </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Illness 1 <br> Illness 2 </span> </td> <td><span style="font-size:15px;cursor:pointer;color="black"> Diagnosis 1 <br> Diagnosis 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Medicine1 <br> Medicine 2 </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Bill Amount <br> Paid Amount </span> </td> <td> <span style="font-size:15px;cursor:pointer;color="black">Next Visit <br> Remarks </span> </td> </tr> 
      <?php
             $totalbillamount = 0;
             $totalpaidamount = 0;
             foreach ($data9 as $data9) 
              { 
                   $pvuserid = $_SESSION['global_user_id'];
//                   $pvpetid  = $data8->petdetailsid ; //  $mypetid ; // $_POST['userloginid'];
                   if ( $data9->userid == $pvuserid ) // and  $data9->petdetid == $pvpetid ) //
                   {
                          $totalbillamount = $totalbillamount + $data9->billamount;
                          $totalpaidamount = $totalpaidamount +  $data9->paidamount;
                          echo " <tr>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dateofvisit . "<br>" . $data9->petname . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->illness1 . "<br>" . $data9->illness2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->dignosis1 . "<br>" . $data9->dignosis2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->medicine1 . "<br>" . $data9->medicine2 . "</span></td>";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->billamount .  "<br>" . $data9->paidamount . "</span></td> ";
                          echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $data9->nextvisit . "<br>" . $data9->remarks . "</span></td>";
                          echo "</tr>";
                   }
               } 
                echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . " T O T A L " . "</span></td>";
                echo '<td>  </td>';
                echo '<td>  </td>';
                echo '<td>  </td>';
                echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . $totalbillamount .  "<br>" . $totalpaidamount . "</span></td> ";
                echo '<td><span style="font-size:15px;cursor:pointer;color="black">' . " Balance : " .  ( $totalbillamount-$totalpaidamount) . ' </td>';
                echo "</tr>";
      ?>
     </table> 
-->
</div>
</div>
</body>
</html>