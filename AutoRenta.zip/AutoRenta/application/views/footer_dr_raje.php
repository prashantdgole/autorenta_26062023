<?php
$this->load->library('session');
$this->load->helper('file');
defined('BASEPATH') OR exit('No direct script access allowed');
$_SESSION['global_company_name'] = "Deshpandes Auto Renta Pvt. Ltd ";
$_SESSION['global_company_address'] = 'Trimbak Sadan Ajmal Road Vile Parle East,Mumbai';

// die("footer 1");
//if (isset($this->session->userdata['logged_in'])) 
//{
  
// header("location: http://localhost/dr_raje/index.php/Home_Dr_Raje/user_login_process");
//}
  
if (isset($this->session->userdata['logged_in']))
 {
$username = ($this->session->userdata['logged_in']['username']);
// $email = ($this->session->userdata['logged_in']['email']);
$user_type_value = ($this->session->userdata['logged_in']['user_type']);
$patient_class_value = ($this->session->userdata['logged_in']['patient_type']);
if ($patient_class_value == 'DAA')
{
$_SESSION['global_company_name'] = "Deshpandes Auto Renta Pvt Ltd";
$_SESSION['global_company_address'] = 'Trimbak Sadan Ajmal Road Vile Parle East Mumbai';
}
else
{  

$_SESSION['global_company_name'] = "Deshpandes Auto Renta Pvt Ltd";
$_SESSION['global_company_address'] = 'Trimbak Sadan Ajmal Road Vile Parle East Mumbai';
} 

} 
else
 {
 
/* header("location: login");*/
}
 


 
 
?>


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#footer1 {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:#6cf;
}
</style>


<link rel="stylesheet" href="<?php echo base_url(); ?>css/global.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ddsmoothmenu.css" />
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>

</head>
<body>
<div class="mainContainer">
<div class="formContainer">     

</div>
</div>
<div class="footer1">
  <div class="footerInner"> 
<!--    <p> Dr. Raje's Pets Clinic . Sai vets Radhe krishna temple shree malang Road netivali kalyan.East </p> -->
<!-- <p>  Dr. Raje's Pets Clinic . Sai vets Radhe krishna temple shree malang Road netivali kalyan.East (m) 9820998016 ,  9421274966 </p> -->

<!-- <p>  Dr. Raje's Pets Clinic . Sai vets, Near Regency/Shiv Sena Office, Chakki Naka, Kalyan.East (m) 9820998016 ,  9421274966 </p> -->

<!-- <p>  Dr. Raje's Pets Clinic . Glass Bunglow, Patri Pool,, Kalyan.East (Mobile) 9820998016  </p> -->
<?php // die ("footer "); ?>
  <p> <?php echo $_SESSION["global_company_name"] . "<br>" . $_SESSION["global_company_address"]; ?> </p>

    <div class="contactInfoBtm">
 <!--      <p>:  &nbsp; &nbsp;<span></span></p> -->
    </div>
    <!--contactInfo End here -->
   <p class="tagline">STEP IN @Auto Renta <span>and CONSIDER  YOUR  IN THE SAFE HANDS ... </span></p>  
 <!--     STEP IN @Raje's Clinic <span>and CONSIDER  YOUR PET IS IN THE SAFE HANDS ... </span>  -->
 </div>
</div>
<!--footerInner Div ends here -->
</div>
<!--footer Div ends here -->
</body>
</html>