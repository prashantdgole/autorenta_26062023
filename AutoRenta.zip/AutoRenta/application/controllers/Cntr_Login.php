<?php  
// session_start();
global $User;
global $CompanyID;
global $CompanyName;
global $fy;
global $worderid;
global $global_db_host ; 
global $global_db_username ; 
global $global_db_pass; 
global $global_db_name ; 
global $global_xid;
global $global_user_type;
global $global_modify_form;
global $lbltxt;
global $global_orderid;
ini_set('session.name','SID');
$_SESSION['User'] = '' ;
$_SESSION['my_url'] = "http://localhost/avenir/";
$_SESSION['CompanyID'] = '' ;
$_SESSION['CompanyName'] = '' ;
$_SESSION['fy'] = '';
$_SESSION['worderid'] = 0;
$_SESSION['global_orderid']=0;
$_SESSION['global_db_host'] = "localhost"; 
$_SESSION['global_db_username'] = "root"; 
$_SESSION['global_db_pass'] = ""; // "admin@123"; 
$_SESSION['global_db_name'] = "pushpakct"; 
$_SESSION['global_xid'] = 0;
$_SESSION['global_user_type'] = '';
$_SESSION['global_modify_form'] = '';
defined('BASEPATH') OR exit('No direct script access allowed');  

class Cntr_Login  extends CI_Controller 
{  

public function __construct() 
{
parent::__construct();

// Load form helper library
$this->load->helper('form');

$this->load->helper('url');
$this->load->helper('security');
$this->load->database();

// Load form validation library
 $this->load->library('form_validation');

// Load session library
 $this->load->library('session');

// Load database
  $this->load->model('login_database');
  
}
    public function index()  
    {  
        $this->load->view('mainmenu_');
    }  
    public function login()  
    {  
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->view('login_menu_');  
    } 
     public function logme_system()  
    {  
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');  
        $this->load->view('logme_system');  
    }  
    public function signin()  
    {  
        $this->load->view('signin');  
    }  
    public function data()  
    {  
        if ($this->session->userdata('currently_logged_in'))   
        {  
              $this->load->view('login_view');   //  $this->load->view('data');  
        } else {  
           // remove  redirect('Main/invalid');  
        }  
    }  
    public function invalid()  
    {  
        $this->load->view('invalid');  
    }  

    public function new_user_registration() 
    {

// Check validation for user input in SignUp form
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
$this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) {
$this->load->view('registration_form');
} else {
$data = array(
'user_name' => $this->input->post('username'),
'user_email' => $this->input->post('email_value'),
'user_password' => $this->input->post('password')
);
$result = $this->login_database->registration_insert($data);
if ($result == TRUE) {
$data['message_display'] = 'Registration Successfully !';
$this->load->view('login_form', $data);
} else {
$data['message_display'] = 'Username already exist!';
$this->load->view('registration_form', $data);
}
}
}

// Check for user login process
public function user_login_process() 
{  // 0
//  echo 'here ... 0 ';
   $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
   $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
   if ($this->form_validation->run() == FALSE) 
   {   // 1
// echo '0.4';
        if(isset($this->session->userdata['logged_in']))
        {
              $this->load->view('admin_page_');
        }
        else
         {   
// echo '0.5';          
             $this->load->view('login_menu_');   //  $this->load->view('login_form');
         }
    } 
    else 
    { // 1
// echo 'here ... 1';
        $data = array(
                   'username' => $this->input->post('username'),
                   'password' => $this->input->post('password')
                    );
        $result = $this->login_database->login($data);
        if ($result == TRUE)
        { // 3
             $username = $this->input->post('username');
             $result = $this->login_database->read_user_information($username);
             if ($result != false) 
             {
                $session_data = array(
                   'username' => $result[0]->user_name,
                   'email' => $result[0]->user_email,
                 );
// Add user data in session
                $this->session->set_userdata('logged_in', $session_data);
                $this->load->view('admin_page_');
             }
       }
       else 
       { // 3
             $data = array(
                   'error_message' => 'Invalid Username or Password'
             );
             $this->load->view('login_menu_', $data);
       } // 3 over
   } // 1 over
} // 0 over

  
    public function login_action()  
    {  
        $this->load->helper('security');  
        $this->load->library('form_validation');  
        $this->form_validation->set_rules('username', 'Username:', 'required|trim|xss_clean|callback_validation');  
        $this->form_validation->set_rules('password', 'Password:', 'required|trim');  
        if ($this->form_validation->run())   
        {  
            $data = array(  
                'username' => $this->input->post('username'),  
                'currently_logged_in' => 1  ,
          //      'nameofcompany' => $this->$data('nameofcompany');
                );    
                $this->session->set_userdata($data);  
                redirect('Main/data');  
        }   
        else {  
            $this->load->view('login_view');  
        }  
    }  
  
    public function signin_validation()  
    {  
        $this->load->library('form_validation');  
  
        $this->form_validation->set_rules('username', 'Username', 'trim|xss_clean|is_unique[signup.username]');  
  
        $this->form_validation->set_rules('password', 'Password', 'required|trim');  
  
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|trim|matches[password]');  
  
        $this->form_validation->set_message('is_unique', 'username already exists');  
  
    if ($this->form_validation->run())  
        {  
            echo "Welcome, you are logged in.";  
         }   
            else {  
              
            $this->load->view('signin');  
        }  
    }   
    public function validation()  
    {  
        $this->load->model('login_model');  
  
        if ($this->login_model->log_in_correctly())  
        {  
            return true;  
        } else {  
            $this->form_validation->set_message('validation', 'Incorrect username/password.');  
            return false;  
        }  
    }  
    public function logout()  
    {  
        $this->session->sess_destroy();  
        redirect ('Cntr_Login/login'); // ('Main/login');  
    }  
  
}  
?>  