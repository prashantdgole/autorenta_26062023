<?php 
// @ob_start();
// session_start(); 
//die("in home");
// if(session_status()!=PHP_SESSION_ACTIVE) session_start();
// session_start(); web site work started on 21 may 2020 
global $User; // task 1 make all field in data base small case 
global $CompanyID;  // and make them in all php files
global $CompanyName;
global $fy;           // task 2 upload newly structre on web site
global $worderid;
global $global_db_host ;   // task 3 upload data on web  and programme
global $global_db_username ; 
global $global_db_pass; 
global $global_db_type;
global $global_db_name ; 
global $global_xid;
global $global_user_type;
global $global_modify_form;
global $lbltxt;
global $global_orderid;
global $itemCRUD;
global $global_user_name;
global $global_user_id;
global $global_name_of_person;
global $global_pet_id;
global $global_ivalue;
global $global_clinic_type;
global $global_patient_id;
global $global_patient_name;
global $global_sales_record;
global $global_sales_billno;
global $global_company_name;
global $global_company_address;
global  $global_dayallowancers ;
global  $global_nightallowancers ;
global  $global_cleaningallowancers ;
global  $global_otrs;
global $start_date;
global $end_date;
ini_set('session.name','SID');
// common
$_SESSION['global_user_name'] = '';
$_SESSION['global_user_id'] = 0;
$_SESSION['global_name_of_person'] = '';
$_SESSION['global_pet_id'] = 0;
$_SESSION['global_ivalue']=1;
$_SESSION['global_clinic_type']='';
$_SESSION['global_patient_id']=0;
$_SESSION['global_patient_name']='';
$_SESSION['global_sales_record']=0;
$_SESSION['global_sales_billno']=0;
$_SESSION['global_company_name'] = "Deshpande AutoRenta";
$_SESSION['global_company_address'] = 'Trimbak Sadan Ajmal Road Vile Parle East Mumbai';
$_SESSION['global_dayallowancers'] = 400 ;
$_SESSION['global_nightallowancers'] = 100 ;
$_SESSION['global_cleaningallowancers'] = 25 ;
$_SESSION['global_otrs'] = 50 ;
$_SESSION['start_date']='';
$_SESSION['end_date']='';
//  echo $_SESSION['global_company_name'] ; $_SESSION['global_ivalue'];
//  echo $_SESSION['global_company_address'];

//  die ("test");

// common end
// server setting
/*
$_SESSION['User'] = '' ;
$_SESSION['my_url'] = "www.autorenta.gungoos.com/autorenta"; //  "http://localhost/dr_raje/";
$_SESSION['CompanyID'] = '' ;
$_SESSION['CompanyName'] = '' ;
$_SESSION['fy'] = '';
$_SESSION['worderid'] = 0;
$_SESSION['global_orderid']=0;
$_SESSION['global_db_host'] = "sql313.gungoos.com"; //  "localhost"; 
$_SESSION['global_db_username'] = "gungo_23120970"; //  ; //  "root"; 
$_SESSION['global_db_pass'] =  "drraje1234"; //    "drraje@1234"; //  ""; // "admin@123"; 
$_SESSION['global_db_name'] = "gungo_23120970_demo"; //   "demo"; //  "pushpakct"; 
$_SESSION['global_xid'] = 0;
$_SESSION['global_user_type'] = '';
$_SESSION['global_modify_form'] = '';
defined('BASEPATH') OR exit('No direct script access allowed');  
*/
//$_SESSION['User'] = '' ;
//$_SESSION['my_url'] = "http://localhost:90/AutoRenta";
//$_SESSION['CompanyID'] = '' ;
//$_SESSION['CompanyName'] = '' ;
//$_SESSION['fy'] = '';
//$_SESSION['worderid'] = 0;
//$_SESSION['global_orderid']=0;
//$_SESSION['global_db_host'] = "localhost:90"; 
//$_SESSION['global_db_username'] = "root"; 
//$_SESSION['global_db_pass'] = ""; // "admin@123"; 
//$_SESSION['global_db_name'] = "AutoRenta"; //  "pushpakct"; 
//$_SESSION['global_xid'] = 0;
//$_SESSION['global_user_type'] = '';
//$_SESSION['global_modify_form'] = '';
// defined('BASEPATH') OR exit('No direct script access allowed');  
class Home_AutoRenta  extends CI_Controller 
{  
   public function __construct() 
   {
parent::__construct();
// Load form helper library
$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('security');
//die("h0");
$this->load->database();
//die("h1");
// Load form validation library
 $this->load->library('form_validation');
// Load session library
 $this->load->library('session');
// Load database
  $this->load->model('login_database');
// item crud start in construct
      $this->load->model('ItemCRUDModel');
      $this->itemCRUD = new ItemCRUDModel;
      $this->load->model('INJECTIONCRUD');
      $this->injectionCRUD = new INJECTIONCRUD;
      $this->load->model('DisCRUDModel');
      $this->disCRUD = new DisCRUDModel;
      $this->load->model('NatureCRUDModel');
      $this->NatureModel = new NatureCRUDModel;
// die("h");
// item crud end in construct
    }
    public function index()  
    { 

// die("index");
        $_SESSION['global_user_name'] = ''; 
        $this->load->helper('url');
// echo 'login';
        $this->load->view('header_dr_raje_main_view');
        $this->load->view('home_view_dr_raje');
       $this->load->view('footer_dr_raje');
// die("index end");
    } 
  public function admin()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('admin_menu_main_');  
         $this->load->view('footer_dr_raje');
    }  

  public function checkdbdetails()
  {

        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');

       $data['data']  = $this->itemCRUD->get_empname();
       $data2_1['data2_1']  = $this->itemCRUD->get_customer();

      $data_2['data_2']  = $this->itemCRUD->get_accodeledger();
      $data2_2['data2_2']  = $this->itemCRUD->get_monthyearledger();

       $data_3['data_3']  = $this->itemCRUD->get_paymentregister();
       $data2_3['data2_3']  = $this->itemCRUD->get_daaentry();



        $this->load->view('header_dr_raje'); // $data5,$data6

        $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3 ) ;  

        $this->load->view('chkdbdata_',$datamerge);  
        $this->load->view('footer_dr_raje');
  }


  public function oprentry()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_menu_main_');  
         $this->load->view('footer_dr_raje');
    } 

  public function oprentry_voucher()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['msg']='';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_voucher_',$data);  
         $this->load->view('footer_dr_raje');
    } 
  public function oprentry_main_voucher()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
    } 

public function reverse_main_voucher()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $this->load->view('header_dr_raje');
         $this->load->view('reverse_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
    } 
 public function Daareports()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('DaaReports_menu_main_');  
         $this->load->view('footer_dr_raje');
    }  
  public function adminhuman()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_menu_main_');  
         $this->load->view('footer_dr_raje');
    }  
 public function DaaEntry()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('daaentry_menu_main_');   /* admin_menu_main_ */
         $this->load->view('footer_dr_raje');
}
// delete daa entry based on date start

public function DaaEntry_delete()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('daadelete_menu_main_');   /* admin_menu_main_ */
         $this->load->view('footer_dr_raje');
}
// delete daa entry based on date end 

public function drrdeleteall()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');
//       echo $fdate . " " . $tdate . " " . $eid ;
// die ("in last ");
    if ( $this->itemCRUD->delete_all_drr_item($fdate,$tdate,$eid) )
    {
    redirect( base_url('index.php/Home_AutoRenta/DaaEntry_delete'));
     }
     else
     {
    redirect( base_url('index.php/Home_AutoRenta/DaaEntry_delete'));
     }
}

    public function daadelete_data()
    {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');
         $data['data'] =   $this->itemCRUD->get_drr_details_emp($fdate,$tdate,$eid); // get_login_details();   
   
  

         $this->load->view('header_dr_raje');


         $this->load->view('delete_daa_data_menu_',$data) ; // $fdate  , $tdate , $eid);
         $this->load->view('footer_dr_raje');   
    }


//
  public function DaaEntry_staff()
  {

        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');

       $data['data']  = $this->itemCRUD->get_empname();
      /*  $data1['data1']    = $this->itemCRUD->get_shifttable(); */
       $data2_1['data2_1']  = $this->itemCRUD->get_customer();

      $data_2['data_2']  = $this->itemCRUD->get_empname();
    /*   $data1_2['data1_2']    = $this->itemCRUD->get_shifttable(); */
       $data2_2['data2_2']  = $this->itemCRUD->get_customer();

       $data_3['data_3']  = $this->itemCRUD->get_empname();
/*       $data1_3['data1_3']    = $this->itemCRUD->get_shifttable(); */
       $data2_3['data2_3']  = $this->itemCRUD->get_customer();

       $data_4['data_4']  = $this->itemCRUD->get_empname();
    /*    $data1_4['data1_4']    = $this->itemCRUD->get_shifttable(); */
       $data2_4['data2_4']  = $this->itemCRUD->get_customer();

       $data_5['data_5']  = $this->itemCRUD->get_empname();
   /*    $data1_5['data1_5']    = $this->itemCRUD->get_shifttable(); */
       $data2_5['data2_5']  = $this->itemCRUD->get_customer();

       $data_6['data_6']  = $this->itemCRUD->get_empname();
/*       $data1_6['data1_6']    = $this->itemCRUD->get_shifttable(); */
       $data2_6['data2_6']  = $this->itemCRUD->get_customer();

       $data_7['data_7']  = $this->itemCRUD->get_empname();
       $data2_7['data2_7']  = $this->itemCRUD->get_customer();

       $data_8['data_8']  = $this->itemCRUD->get_empname();
       $data2_8['data2_8']  = $this->itemCRUD->get_customer();

       $data_9['data_9']  = $this->itemCRUD->get_empname();
       $data2_9['data2_9']  = $this->itemCRUD->get_customer();

       $data_10['data_10']  = $this->itemCRUD->get_empname();
       $data2_10['data2_10']  = $this->itemCRUD->get_customer();

       $data_11['data_11']  = $this->itemCRUD->get_empname();
       $data2_11['data2_11']  = $this->itemCRUD->get_customer();
     
       $data_12['data_12'] = "STAFF";

/*  echo "her1 "; */

        $this->load->view('header_dr_raje'); // $data5,$data6
    /*    $datamerge = array_merge($data, $data1,$data2_1,   $data_2, $data1_2,$data2_2,    $data_3, $data1_3,$data2_3,  $data_4, $data1_4,$data2_4,  $data_5, $data1_5,$data2_5,  $data_6, $data1_6,$data2_6 ) ;  */ 
         $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3,  $data_4, $data2_4,  $data_5,$data2_5,  $data_6, $data2_6,$data_7,$data2_7,$data_8,$data2_8,$data_9,$data2_9,$data_10,$data2_10, $data_11,$data2_11,$data_12 ) ;  
       $this->load->view('DaaEntry_',$datamerge);  
        $this->load->view('footer_dr_raje');
  }



//
  public function DaaEntry_date()
  {

        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');

       $data['data']  = $this->itemCRUD->get_empname();
      /*  $data1['data1']    = $this->itemCRUD->get_shifttable(); */
       $data2_1['data2_1']  = $this->itemCRUD->get_customer();

      $data_2['data_2']  = $this->itemCRUD->get_empname();
    /*   $data1_2['data1_2']    = $this->itemCRUD->get_shifttable(); */
       $data2_2['data2_2']  = $this->itemCRUD->get_customer();

       $data_3['data_3']  = $this->itemCRUD->get_empname();
/*       $data1_3['data1_3']    = $this->itemCRUD->get_shifttable(); */
       $data2_3['data2_3']  = $this->itemCRUD->get_customer();

       $data_4['data_4']  = $this->itemCRUD->get_empname();
    /*    $data1_4['data1_4']    = $this->itemCRUD->get_shifttable(); */
       $data2_4['data2_4']  = $this->itemCRUD->get_customer();

       $data_5['data_5']  = $this->itemCRUD->get_empname();
   /*    $data1_5['data1_5']    = $this->itemCRUD->get_shifttable(); */
       $data2_5['data2_5']  = $this->itemCRUD->get_customer();

       $data_6['data_6']  = $this->itemCRUD->get_empname();
/*       $data1_6['data1_6']    = $this->itemCRUD->get_shifttable(); */
       $data2_6['data2_6']  = $this->itemCRUD->get_customer();

       $data_7['data_7']  = $this->itemCRUD->get_empname();
       $data2_7['data2_7']  = $this->itemCRUD->get_customer();

       $data_8['data_8']  = $this->itemCRUD->get_empname();
       $data2_8['data2_8']  = $this->itemCRUD->get_customer();

       $data_9['data_9']  = $this->itemCRUD->get_empname();
       $data2_9['data2_9']  = $this->itemCRUD->get_customer();

       $data_10['data_10']  = $this->itemCRUD->get_empname();
       $data2_10['data2_10']  = $this->itemCRUD->get_customer();

       $data_11['data_11']  = $this->itemCRUD->get_empname();
       $data2_11['data2_11']  = $this->itemCRUD->get_customer();
     
       $data_12['data_12'] = "DATE";

/*  echo "her1 "; */

        $this->load->view('header_dr_raje'); // $data5,$data6
    /*    $datamerge = array_merge($data, $data1,$data2_1,   $data_2, $data1_2,$data2_2,    $data_3, $data1_3,$data2_3,  $data_4, $data1_4,$data2_4,  $data_5, $data1_5,$data2_5,  $data_6, $data1_6,$data2_6 ) ;  */ 
         $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3,  $data_4, $data2_4,  $data_5,$data2_5,  $data_6, $data2_6,$data_7,$data2_7,$data_8,$data2_8,$data_9,$data2_9,$data_10,$data2_10, $data_11,$data2_11,$data_12 ) ;  
       $this->load->view('DaaEntry_',$datamerge);  
        $this->load->view('footer_dr_raje');
  }

/*
  public function adminnature()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_nature');
         $this->load->view('admin_page_nature_');  
         $this->load->view('footer_dr_raje');
    }  
*/
  public function report1()
  { /* on date daa report */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('report1_');  
         $this->load->view('footer_dr_raje');
}

  public function report2()
  { /* on employee , date  daa report */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
// die("here");
         $this->load->view('report2_');  
         $this->load->view('footer_dr_raje');
}

  public function report3()
  { /* on customer , date  daa report */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
// die("here");
         $this->load->view('report3_');  
         $this->load->view('footer_dr_raje');
}
  public function report4()
  { /* Daa Payroll Page*/

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('report4_');  
         $this->load->view('footer_dr_raje');
}

 public function report5()
  { /*Employee one page  Payroll  */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('report5_');  
         $this->load->view('footer_dr_raje');
}
  public function report6()
  { /* on late comers , date  daa report */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
// die("here");
         $this->load->view('report6_');  
         $this->load->view('footer_dr_raje');
}
  public function report7()
  { /* on any duty , date  daa report */

         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
// die("here");
         $this->load->view('report7_');  
         $this->load->view('footer_dr_raje');
}
 public function report9()
 { /* customer list */

        $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->daa_customer_list();   /* human_vendor_count(); */
         $config["total_rows"] = $this->itemCRUD->daa_customer_list();  /* human_vendor_count(); */
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_AutoRenta/report9';   /*  human_vendor_reports_list'; */
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;  
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->daa_customer_records($config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_daa_customer_menu_',$datamerge);  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
}

    public function report8()
    { /* employee list */

         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->daa_emp_list();   /* human_vendor_count(); */
         $config["total_rows"] = $this->itemCRUD->daa_emp_list();  /* human_vendor_count(); */
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_AutoRenta/report8';   /*  human_vendor_reports_list'; */
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;  
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->daa_emp_records($config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_daa_emp_menu_',$datamerge);  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }

// report2_report

    public function report2_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');
         $eop1 = $this->input->post('op1');

         $_SESSION['start_date']=$this->input->post('datefrom');
         $_SESSION['end_date']=$this->input->post('dateto');

         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('report_emp_daa_menu_',$fdate  , $tdate , $eid , $eop1 );  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }
// report2_report

// report 3

// report3_report

    public function report3_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $cid = $this->input->post('custid1');
         $passname1 = $this->input->post('passname');

         $_SESSION['start_date']=$this->input->post('datefrom');
         $_SESSION['end_date']=$this->input->post('dateto');

         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('report_cust_daa_menu_',$fdate  , $tdate , $cid , $passname1 );  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }

// report 7
    public function report7_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');
         $pr1 = $this->input->post('presentid1');

         $_SESSION['start_date']=$this->input->post('datefrom');
         $_SESSION['end_date']=$this->input->post('dateto');

         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('report_duty_daa_menu_',$fdate  , $tdate , $eid , $pr1 );  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }
// report 7


// report 6 
    public function report6_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $eid = $this->input->post('empid1');

         $_SESSION['start_date']=$this->input->post('datefrom');
         $_SESSION['end_date']=$this->input->post('dateto');

         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('report_late_daa_menu_',$fdate  , $tdate , $eid );  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }

// report6

// report3_report



// report 3

    public function report1_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
         $_SESSION['start_date']=$this->input->post('datefrom');
         $_SESSION['end_date']=$this->input->post('dateto');
// echo $_SESSION['start_date'];
         $fecode = $this->input->post('ecodefrom');
         $tecode = $this->input->post('ecodeto');
         $fccode = $this->input->post('ccodefrom');
         $tccode = $this->input->post('ccodeto');
// echo $chk_user_id . " fd " . $fdate . " t d " . $tdate;
//die("l");
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->datewise_daa_list($fdate,$tdate);   /* human_vendor_count(); */
// echo $trec;
// die("rec");
         $config["total_rows"] = $this->itemCRUD->datewise_daa_list($fdate,$tdate);  /* human_vendor_count(); */
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_AutoRenta/report1_report';   /*  human_vendor_reports_list'; */
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;  
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         $data["fdate"] = $this->input->post('datefrom');
         $data["tdate"] =  $tdate =$this->input->post('dateto');
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
//         $data['userrec']=$this->itemCRUD->get_daa_records($fdate,$tdate,$config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */
//echo $data["fdate"];
//echo $data["tdate"];
         $data['userrec']=$this->itemCRUD->get_daa_records($_SESSION['start_date'], $_SESSION['end_date'],$config["per_page"],$skprec); 
   /// $data["fdate"],$data["tdate"],$config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */
         if ($skprec == 0 ) 
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_daa_menu_',$datamerge);  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }

//  report4_report

    public function report4_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
 
 
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $data['userrec']= $this->itemCRUD->empdatewise_payroll_list($fdate,$tdate);
//         $data['userrec']=$this->itemCRUD->get_daa_records($fdate,$tdate,$config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */

         $this->load->view('header_dr_raje');
         $datamerge = array_merge($data);
         $this->load->view('report_payroll_menu_',$fdate,$tdate); // $datamerge);  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }



// report4_report

//  report5_report

    public function report5_report()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         $fdate =$this->input->post('datefrom');
         $tdate =$this->input->post('dateto');
 
 
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $data['userrec']= $this->itemCRUD->empdatewise_payroll_list($fdate,$tdate);
//         $data['userrec']=$this->itemCRUD->get_daa_records($fdate,$tdate,$config["per_page"],$skprec);   /*    get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20 */

         $this->load->view('header_dr_raje');
         $datamerge = array_merge($data);
         $this->load->view('report_emp_payroll_menu_',$fdate,$tdate); // $datamerge);  /* 'report_vendorlist_menu_main_',$datamerge);  */
         $this->load->view('footer_dr_raje');   
    }



// report5_report

//
  public function drappointmentpets()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('drappointment_pets_');  
         $this->load->view('footer_dr_raje');
    }  



// new human vendor menu 05 09 2021 
 public function human_vendor_menu()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_vendor_menu_');  
         $this->load->view('footer_dr_raje');
    }

    public function human_vendor_reports_list()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_Dr_Raje/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->human_vendor_count();
         $config["total_rows"] = $this->itemCRUD->human_vendor_count();
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_Dr_Raje/human_vendor_reports_list';
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->get_itemCRUD_vendor_new($config["per_page"],$skprec); // 20
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_vendorlist_menu_main_',$datamerge);  
         $this->load->view('footer_dr_raje');   
    }
// new human medicines menu 18 09 2021 
 public function human_medicines_menu()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_medicines_menu_');  
         $this->load->view('footer_dr_raje');
    }

   public function human_medicines_reports_list()
   {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('reports_human_medicines');  
         $this->load->view('footer_dr_raje');

   }


    public function human_medicines_list()
    {

         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_Dr_Raje/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->human_stocklist_count();
         $config["total_rows"] = $this->itemCRUD->human_stocklist_count();
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_Dr_Raje/human_medicines_list';
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->get_itemCRUD_stocklist_new($config["per_page"],$skprec); // 20
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_medicinelist_menu_main_',$datamerge);  
         $this->load->view('footer_dr_raje');   
    }
// vendor list new vendor
   public function human_patient_new_vendor()
   {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('registration_new_vendor');  
         $this->load->view('footer_dr_raje');
   }
   public function human_patient_existing_vendor() // pdgole
   {
         $this->load->helper('url'); // vendorlist
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data'] = $this->itemCRUD->get_vendorlist_only_human();
         $this->load->view('header_dr_raje_human');
         $this->load->view('existing_vendor_human_form',$data);  
         $this->load->view('footer_dr_raje');
   }
   public function human_patient_report_vendor()
   {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('reports_human_vendor');  
         $this->load->view('footer_dr_raje');
   }

// new vendor over 

// new human patient menu 30 08 2021 
 public function human_patient_menu()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_patient_menu_');  
         $this->load->view('footer_dr_raje');
    } 
// new patient clicked

 public function human_patient_new_patient()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('registration_form_human');  
         $this->load->view('footer_dr_raje');
    } 

// existing patient clicked

 public function human_patient_existing_patient()  
    { 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data'] = $this->itemCRUD->get_itemCRUD_only_human();
         $this->load->view('header_dr_raje_human');
         $this->load->view('existing_patient_human_form',$data);  
         $this->load->view('footer_dr_raje');
    } 

  public function human_patient_upload_photo()
  {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->library('table');
         $data['data'] = $this->itemCRUD->get_itemCRUD_only_human();

         $this->load->view('header_dr_raje_human');
         $this->load->view('existing_patient_upload_photo_form',$data);  
         $this->load->view('footer_dr_raje');

  }

//
  public function human_patient_bill_entry()
  {

        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_suppliername();
        $data1['data1']    = $this->itemCRUD->get_patientname();
        $data2_1['data2_1']  = $this->itemCRUD->get_stocklist();
        $data2_2['data2_2']  = $this->itemCRUD->get_stocklist();
        $data2_3['data2_3']  = $this->itemCRUD->get_stocklist();
        $data2_4['data2_4']  = $this->itemCRUD->get_stocklist();
        $data2_5['data2_5']  = $this->itemCRUD->get_stocklist();
        $data3['data3'] = $this->itemCRUD->new_get_salesbilllist();
        $this->load->view('header_dr_raje_human'); // $data5,$data6
        $datamerge = array_merge($data, $data1,$data2_1,$data2_2,$data2_3,$data2_4,$data2_5,$data3) ; // ,$data3,$data4,$data7);
        $this->load->view('human_patient_bill_entry_',$datamerge);  
        $this->load->view('footer_dr_raje');
  }
// human patient details

  public function human_patient_details()
  {
/*
         $this->load->view('human_patient_nextvisit_view_',$datamerge);  
         $this->load->view('footer_dr_raje');
*/
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_suppliername();
        $data1['data1']    = $this->itemCRUD->get_patientname();
        $data3['data3'] = $this->itemCRUD->get_humandiagnosis(); 
        $data2_1['data2_1']  = $this->itemCRUD->get_stocklist();
        $data2_2['data2_2']  = $this->itemCRUD->get_stocklist();
        $data2_3['data2_3']  = $this->itemCRUD->get_stocklist();
        $data2_4['data2_4']  = $this->itemCRUD->get_stocklist();
        $data2_5['data2_5']  = $this->itemCRUD->get_stocklist();
        $data3['data3'] = $this->itemCRUD->new_get_salesbilllist();
        $this->load->view('header_dr_raje_human'); // $data5,$data6
        $datamerge = array_merge($data, $data1,$data3,$data2_1,$data2_2,$data2_3,$data2_4,$data2_5,$data3) ; // ,$data3,$data4,$data7);
        $this->load->view('human_patient_details_',$datamerge);  
        $this->load->view('footer_dr_raje');
  }
// human patient details over
// human patient next date
  public function human_patient_next_visit() // golepd
  {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data']    = $this->itemCRUD->get_suppliername();
         $data1['data1']    = $this->itemCRUD->get_patientname();
         $data3['data3'] = $this->itemCRUD->get_humandiagnosis(); 
         $datamerge = array_merge($data, $data1,$data3) ;
         $this->load->view('header_dr_raje_human');
         $this->load->view('human_patient_nextvisit_view_',$datamerge);  
         $this->load->view('footer_dr_raje');
  }
// human patient next date
// human patient reports
   public function human_patient_reports()
    {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('reports_admin_form_human');  
         $this->load->view('footer_dr_raje');
    }
    public function human_patient_reports_list()
    {
// die("here");
         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_Dr_Raje/logout'); 
         }
//         $this->load->helper('url');
//         $this->load->helper('security');  
//         $this->load->library('form_validation');
//         $this->load->view('header_dr_raje_human');
//         $this->load->view('reports_admin_form_human');  
//         $this->load->view('footer_dr_raje');

// here
// die("out");
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->human_user_count();
         $config["total_rows"] = $this->itemCRUD->human_user_count();
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_Dr_Raje/human_patient_reports_list';
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->get_itemCRUD_human_new($config["per_page"],$skprec); // 20
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_menu_main_',$datamerge);  
         $this->load->view('footer_dr_raje');

// here end
   
    }

// sales billing start

public function deletesalesrecord($rec)
{
         // $rec = $this->session->userdata('global_sales_record');
//echo $rec;
//die("dd");
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('deletesalesrecord?var1='.$rec);  
         $this->load->view('footer_dr_raje');
 
}

 public function human_patient_sales_billing()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_patient_sales_billing_menu_');  
         $this->load->view('footer_dr_raje');
    } 
 public function human_new_sales_medicines()  
    {  
        
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_suppliername();
        $data1['data1']    = $this->itemCRUD->get_patientname();
        $data2_1['data2_1']  = $this->itemCRUD->get_stocklist();
        $data2_2['data2_2']  = $this->itemCRUD->get_stocklist();
        $data2_3['data2_3']  = $this->itemCRUD->get_stocklist();
        $data2_4['data2_4']  = $this->itemCRUD->get_stocklist();
        $data2_5['data2_5']  = $this->itemCRUD->get_stocklist();
        $data3['data3'] = $this->itemCRUD->new_get_salesbilllist();
        $this->load->view('header_dr_raje_human'); // $data5,$data6
        $datamerge = array_merge($data, $data1,$data2_1,$data2_2,$data2_3,$data2_4,$data2_5,$data3) ; // ,$data3,$data4,$data7);
        $this->load->view('human_sales_billing_menu_',$datamerge);  
        $this->load->view('footer_dr_raje');
    } 
public function updatehumansalesbill()
 { // 1
    $pid = 0;
    $pnm = '';
    $recsave =0;
    if ( $this->input->post('qs1') > 0  and $this->input->post('amount1') > 0 )
    { // 2
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'salesbill' => $this->input->post('sb1') ,
          'date' => $this->input->post('dt1'),    
          'stockid'  => $this->input->post('sid1'),
          'stockname' => $this->input->post('ids1'),
          'saleqty' => $this->input->post('qs1'),
          'hsncode' => $this->input->post('hsc1'),
          'gstperc' => $this->input->post('gst1'),
          'sgstamt'  => $this->input->post('sgamt1'),
          'cgstamt' => $this->input->post('cgamt1'),
          'salesrate' => $this->input->post('rate1'),
          'itemtotal' => $this->input->post('amount1'), /* new added */
          'discountperc' => $this->input->post('discperc1'),
          'discountamount' => $this->input->post('discamt1'),
          'total' => $this->input->post('total1'),
          'patientid' => $pid, //  $this->input->post('personid') ,
          'patientname' => $pnm //   $this->input->post('nameofperson')
          ); 
          $result = $this->login_database->human_salebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Sales Bill Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Sales Bill Not Saved Successfully!';
           } // 3 over
    } // 2
// 2nd line
    if ( $this->input->post('qs2') > 0  and $this->input->post('amount2') > 0 )
    { // 2
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'salesbill' => $this->input->post('sb1') ,
          'date' => $this->input->post('dt1'),    
          'stockid'  => $this->input->post('sid2'),
          'stockname' => $this->input->post('ids2'),
          'saleqty' => $this->input->post('qs2'),
          'hsncode' => $this->input->post('hsc2'),
          'gstperc' => $this->input->post('gst2'),
          'sgstamt'  => $this->input->post('sgamt2'),
          'cgstamt' => $this->input->post('cgamt2'),
          'salesrate' => $this->input->post('rate2'),
          'itemtotal' => $this->input->post('amount2'), /* new added */
          'discountperc' => $this->input->post('discperc2'),
          'discountamount' => $this->input->post('discamt2'),
          'total' => $this->input->post('total2'),
          'patientid' => $pid, //  $this->input->post('personid') ,
          'patientname' => $pnm //   $this->input->post('nameofperson')
          ); 
          $result = $this->login_database->human_salebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Sales Bill Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Sales Bill Not Saved Successfully!';
           } // 3 over
    } // 2

// 3rd line
    if ( $this->input->post('qs3') > 0  and $this->input->post('amount3') > 0 )
    { // 2
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'salesbill' => $this->input->post('sb1') ,
          'date' => $this->input->post('dt1'),    
          'stockid'  => $this->input->post('sid3'),
          'stockname' => $this->input->post('ids3'),
          'saleqty' => $this->input->post('qs3'),
          'hsncode' => $this->input->post('hsc3'),
          'gstperc' => $this->input->post('gst3'),
          'sgstamt'  => $this->input->post('sgamt3'),
          'cgstamt' => $this->input->post('cgamt3'),
          'salesrate' => $this->input->post('rate3'),
          'itemtotal' => $this->input->post('amount3'), /* new added */
          'discountperc' => $this->input->post('discperc3'),
          'discountamount' => $this->input->post('discamt3'),
          'total' => $this->input->post('total3'),
          'patientid' => $pid, //  $this->input->post('personid') ,
          'patientname' => $pnm //   $this->input->post('nameofperson')
          ); 
          $result = $this->login_database->human_salebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Sales Bill Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Sales Bill Not Saved Successfully!';
           } // 3 over
    } // 2


// 4th line
    if ( $this->input->post('qs4') > 0  and $this->input->post('amount4') > 0 )
    { // 2
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'salesbill' => $this->input->post('sb1') ,
          'date' => $this->input->post('dt1'),    
          'stockid'  => $this->input->post('sid4'),
          'stockname' => $this->input->post('ids4'),
          'saleqty' => $this->input->post('qs4'),
          'hsncode' => $this->input->post('hsc4'),
          'gstperc' => $this->input->post('gst4'),
          'sgstamt'  => $this->input->post('sgamt4'),
          'cgstamt' => $this->input->post('cgamt4'),
          'salesrate' => $this->input->post('rate4'),
          'itemtotal' => $this->input->post('amount4'), /* new added */
          'discountperc' => $this->input->post('discperc4'),
          'discountamount' => $this->input->post('discamt4'),
          'total' => $this->input->post('total4'),
          'patientid' => $pid, //  $this->input->post('personid') ,
          'patientname' => $pnm //   $this->input->post('nameofperson')
          ); 
          $result = $this->login_database->human_salebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Sales Bill Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Sales Bill Not Saved Successfully!';
           } // 3 over
    } // 2

// 5th line
    if ( $this->input->post('qs5') > 0  and $this->input->post('amount5') > 0 )
    { // 2
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'salesbill' => $this->input->post('sb1') ,
          'date' => $this->input->post('dt1'),    
          'stockid'  => $this->input->post('sid5'),
          'stockname' => $this->input->post('ids5'),
          'saleqty' => $this->input->post('qs5'),
          'hsncode' => $this->input->post('hsc5'),
          'gstperc' => $this->input->post('gst5'),
          'sgstamt'  => $this->input->post('sgamt5'),
          'cgstamt' => $this->input->post('cgamt5'),
          'salesrate' => $this->input->post('rate5'),
          'itemtotal' => $this->input->post('amount5'), /* new added */
          'discountperc' => $this->input->post('discperc5'),
          'discountamount' => $this->input->post('discamt5'),
          'total' => $this->input->post('total5'),
          'patientid' => $pid, //  $this->input->post('personid') ,
          'patientname' => $pnm //   $this->input->post('nameofperson')
          ); 
          $result = $this->login_database->human_salebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Sales Bill Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Sales Bill Not Saved Successfully!';
           } // 3 over
    } // 2
    $this->load->view('header_dr_raje');
    redirect('Home_Dr_Raje/human_new_sales_medicines'); 
    $this->load->view('footer_dr_raje');
 } // 1 




// sales billing end

// purchase billing


// new human patient purchase stock 19 09 2021 
 public function human_patient_purchase_billing()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('admin_patient_purchase_billing_menu_');  
         $this->load->view('footer_dr_raje');
    } 

 public function human_new_purchase_medicines()  
    {  
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_suppliername();
        $data1['data1']  = $this->itemCRUD->get_stocklist();
        $data2['data2']  = $this->itemCRUD->get_stocklist();
        $data3['data3']  = $this->itemCRUD->get_stocklist();
        $data4['data4']  = $this->itemCRUD->get_stocklist();
        $data5['data5']  = $this->itemCRUD->get_stocklist();

       // $data3['data3']  = $this->itemCRUD->get_petdetails_CRUD();
       // $data4['data4']    = $this->itemCRUD->get_Pet_itemCRUD();
       // $data7['data7']    = $this->itemCRUD->get_Pet_TypeList(0);
        $this->load->view('header_dr_raje_human'); // $data5,$data6
        $datamerge = array_merge($data, $data1,$data2,$data3,$data4,$data5) ; // ,$data3,$data4,$data7);
        $this->load->view('human_purchase_billing_menu_',$datamerge);  
        $this->load->view('footer_dr_raje');
    } 

   public function updatehumanpurchaseinfo()  
   {  // 1

    if ( $this->input->post('wpurcqty1') > 0  and $this->input->post('wstockid1') > 0 )
    { // 2
          $data = array(
          'purchasebill' => $this->input->post('dinvoiceno') ,
          'purchasedate' => $this->input->post('dinvoicedate'),    
          'stockid'  => $this->input->post('wstockid1'),
          'purcqty' => $this->input->post('wpurcqty1'),
          'purrate' => $this->input->post('wpurrate1'),
          'puramount' => $this->input->post('wpuramount1'),
          'gstperc' => $this->input->post('wgstperc1'),
          'vendorid'  => $this->input->post('dsupplierid'),
          'batchcode' => $this->input->post('wbatchcode1'),
          'batchdate' => $this->input->post('wbatchdate1'),
          'sgstamount' => $this->input->post('wsgstamount1'), /* new added */
          'cgstamount' => $this->input->post('wcgstamount1'),
          'itemtotal' => $this->input->post('witemtotal1'),
          'discperc' => $this->input->post('wdiscperc1'),

          'hsncode' => $this->input->post('whsncode1'),
          'stockname' =>  $this->input->post('wstockname1'),
          'unit' =>  $this->input->post('wunitofmeasurement1'),

          'discountamount' => $this->input->post('wdiscountamount1')
          );
          $result = $this->login_database->human_purchasebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Purchase Record Saved Successfully !';
             $this->load->view('header_dr_raje');
             $this->load->view('human_purchase_billing_menu_',$data); // admin_page_');
             $this->load->view('footer_dr_raje');

          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Purchase Record Not Saved Successfully!';
            $this->load->view('header_dr_raje');
            $this->load->view('human_purchase_billing_menu_', $data);
            $this->load->view('footer_dr_raje');
           } // 3 over
    } // 2

    //else  // qty1 and stock 1 not above 0 checking qty2 and stock 2
    // { // 2

    if ( $this->input->post('wpurcqty2') > 0  and $this->input->post('wstockid2') > 0 )
    { // 2 .1
          $data = array(
          'purchasebill' => $this->input->post('dinvoiceno') ,
          'purchasedate' => $this->input->post('dinvoicedate'),    
          'stockid'  => $this->input->post('wstockid2'),
          'purcqty' => $this->input->post('wpurcqty2'),
          'purrate' => $this->input->post('wpurrate2'),
          'puramount' => $this->input->post('wpuramount2'),
          'gstperc' => $this->input->post('wgstperc2'),
          'vendorid'  => $this->input->post('dsupplierid'),
          'batchcode' => $this->input->post('wbatchcode2'),
          'batchdate' => $this->input->post('wbatchdate2'),
          'sgstamount' => $this->input->post('wsgstamount2'), /* new added */
          'cgstamount' => $this->input->post('wcgstamount2'),
          'itemtotal' => $this->input->post('witemtotal2'),
          'discperc' => $this->input->post('wdiscperc2'),

          'hsncode' => $this->input->post('whsncode2'),
          'stockname' =>  $this->input->post('wstockname2'),
          'unit' =>  $this->input->post('wunitofmeasurement2'),

          'discountamount' => $this->input->post('wdiscountamount2')
          );
          $result = $this->login_database->human_purchasebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Purchase Record Saved Successfully !';
             $this->load->view('header_dr_raje');
             $this->load->view('human_purchase_billing_menu_',$data); // admin_page_');
             $this->load->view('footer_dr_raje');

          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Purchase Record Not Saved Successfully!';
            $this->load->view('header_dr_raje');
            $this->load->view('human_purchase_billing_menu_', $data);
            $this->load->view('footer_dr_raje');
           } // 3 over

       } // 2.1

       // else
       // { // 2.1

       if ( $this->input->post('wpurcqty3') > 0  and $this->input->post('wstockid3') > 0 )
       { // 2 .2
          $data = array(
          'purchasebill' => $this->input->post('dinvoiceno') ,
          'purchasedate' => $this->input->post('dinvoicedate'),    
          'stockid'  => $this->input->post('wstockid3'),
          'purcqty' => $this->input->post('wpurcqty3'),
          'purrate' => $this->input->post('wpurrate3'),
          'puramount' => $this->input->post('wpuramount3'),
          'gstperc' => $this->input->post('wgstperc3'),
          'vendorid'  => $this->input->post('dsupplierid'),
          'batchcode' => $this->input->post('wbatchcode3'),
          'batchdate' => $this->input->post('wbatchdate3'),
          'sgstamount' => $this->input->post('wsgstamount3'), /* new added */
          'cgstamount' => $this->input->post('wcgstamount3'),
          'itemtotal' => $this->input->post('witemtotal3'),
          'discperc' => $this->input->post('wdiscperc3'),

          'hsncode' => $this->input->post('whsncode3'),
          'stockname' =>  $this->input->post('wstockname3'),
          'unit' =>  $this->input->post('wunitofmeasurement3'),

          'discountamount' => $this->input->post('wdiscountamount3')
          );
          $result = $this->login_database->human_purchasebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Purchase Record Saved Successfully !';
             $this->load->view('header_dr_raje');
             $this->load->view('human_purchase_billing_menu_',$data); // admin_page_');
             $this->load->view('footer_dr_raje');

          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Purchase Record Not Saved Successfully!';
            $this->load->view('header_dr_raje');
            $this->load->view('human_purchase_billing_menu_', $data);
            $this->load->view('footer_dr_raje');
           } // 3 over

           } // 2.2

           // else
           // { // 2.2

          if ( $this->input->post('wpurcqty4') > 0  and $this->input->post('wstockid4') > 0 )
          { // 2 .3
          $data = array(
          'purchasebill' => $this->input->post('dinvoiceno') ,
          'purchasedate' => $this->input->post('dinvoicedate'),    
          'stockid'  => $this->input->post('wstockid4'),
          'purcqty' => $this->input->post('wpurcqty4'),
          'purrate' => $this->input->post('wpurrate4'),
          'puramount' => $this->input->post('wpuramount4'),
          'gstperc' => $this->input->post('wgstperc4'),
          'vendorid'  => $this->input->post('dsupplierid'),
          'batchcode' => $this->input->post('wbatchcode4'),
          'batchdate' => $this->input->post('wbatchdate4'),
          'sgstamount' => $this->input->post('wsgstamount4'), /* new added */
          'cgstamount' => $this->input->post('wcgstamount4'),
          'itemtotal' => $this->input->post('witemtotal4'),
          'discperc' => $this->input->post('wdiscperc4'),

          'hsncode' => $this->input->post('whsncode4'),
          'stockname' =>  $this->input->post('wstockname4'),
          'unit' =>  $this->input->post('wunitofmeasurement4'),

          'discountamount' => $this->input->post('wdiscountamount4')
          );
          $result = $this->login_database->human_purchasebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Purchase Record Saved Successfully !';
             $this->load->view('header_dr_raje');
             $this->load->view('human_purchase_billing_menu_',$data); // admin_page_');
             $this->load->view('footer_dr_raje');

          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Purchase Record Not Saved Successfully!';
            $this->load->view('header_dr_raje');
            $this->load->view('human_purchase_billing_menu_', $data);
            $this->load->view('footer_dr_raje');
           } // 3 over

           } // 2.3

         //    else
         //    { // 2.3

         if ( $this->input->post('wpurcqty5') > 0  and $this->input->post('wstockid5') > 0 )
         { // 2 .4
          $data = array(
          'purchasebill' => $this->input->post('dinvoiceno') ,
          'purchasedate' => $this->input->post('dinvoicedate'),    
          'stockid'  => $this->input->post('wstockid5'),
          'purcqty' => $this->input->post('wpurcqty5'),
          'purrate' => $this->input->post('wpurrate5'),
          'puramount' => $this->input->post('wpuramount5'),
          'gstperc' => $this->input->post('wgstperc5'),
          'vendorid'  => $this->input->post('dsupplierid'),
          'batchcode' => $this->input->post('wbatchcode5'),
          'batchdate' => $this->input->post('wbatchdate5'),
          'sgstamount' => $this->input->post('wsgstamount5'), /* new added */
          'cgstamount' => $this->input->post('wcgstamount5'),
          'itemtotal' => $this->input->post('witemtotal5'),
          'discperc' => $this->input->post('wdiscperc5'),

          'hsncode' => $this->input->post('whsncode5'),
          'stockname' =>  $this->input->post('wstockname5'),
          'unit' =>  $this->input->post('wunitofmeasurement5'),

          'discountamount' => $this->input->post('wdiscountamount5')
          );
          $result = $this->login_database->human_purchasebill_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Purchase Record Saved Successfully !';
             $this->load->view('header_dr_raje');
             $this->load->view('human_purchase_billing_menu_',$data); // admin_page_');
             $this->load->view('footer_dr_raje');

          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Purchase Record Not Saved Successfully!';
            $this->load->view('header_dr_raje');
            $this->load->view('human_purchase_billing_menu_', $data);
            $this->load->view('footer_dr_raje');
           } // 3 over
 
           } // 2.4

           //  } // 2.3


          // } // 2.2

      // } // 2.1
    // } // 2 over
    $this->session->set_flashdata('errors', validation_errors());
    $this->load->view('header_dr_raje');
    $data = array(
            'error_message' => 'purchase description or purchase qty empty'
             );
    $this->load->view('human_purchase_billing_menu_',$data);
    $this->load->view('footer_dr_raje');
    redirect( base_url('index.php/Home_Dr_Raje/human_new_purchase_medicines'));

    } // 1  over updatehumanpurchaseinfo() 

// purchase billing over

// stock

// stock list new stock entey
   public function human_patient_new_stock()
   {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_human');
         $this->load->view('registration_new_stock');  
         $this->load->view('footer_dr_raje');

   }
// Validate and store  for medicine stock human 
public function new_human_stock_registration() 
{
//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('stockname', 'stockname', 'trim|required|xss_clean');
$this->form_validation->set_rules('medicineshortcode', 'medicineshortcode', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form_human');
        $this->load->view('header_dr_raje_human');
        $this->load->view('registration_new_stock');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'stockshortcode' => $this->input->post('medicineshortcode'),
          'stockname' => $this->input->post('stockname'),    
          'reorderlevel'  => $this->input->post('reorderlevel'),
          'stockinhand' => $this->input->post('stockinhand'),
          'salerate' => $this->input->post('salerate'),
          'unit' => $this->input->post('unit'),
          'hsncode' => $this->input->post('hsncode'),
          'stockbinnumber'  => $this->input->post('stockbinnumber'),
          'gstperc' => $this->input->post('gstperc'),
          'cgst' => $this->input->post('cgst'),
          'sgst' => $this->input->post('sgst'), /* new added */
          'igst' => $this->input->post('igst'),
          'schedulestock' => $this->input->post('schedulestock'),
          'any_information_1' => $this->input->post('any_information_1'),
          'any_information_2' => $this->input->post('any_information_2')
   );
   $result = $this->login_database->registration_stock_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje_human');
    $this->load->view('registration_new_stock',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Stock name already exist!';
     $this->load->view('header_dr_raje_human');
     $this->load->view('registration_new_stock', $data);
     $this->load->view('footer_dr_raje');
  }
}
}
// new stock human end
// existing stock
public function human_patient_existing_stock() // pdgole
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data'] = $this->itemCRUD->get_stocklist();
         $this->load->view('header_dr_raje_human');
         $this->load->view('human_patient_existing_stock_',$data);  
         $this->load->view('footer_dr_raje');

}
// existing stock end
// stock end



    public function login() 
    {  
//die("s");
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
//die("1");
// echo "login";
         $this->load->view('header_dr_raje_main_view');
//       echo $this->session->flashdata('err_message'); 
         $this->load->view('login_menu_main_');  
         $this->load->view('footer_dr_raje');

    } 

 public function info()  
    { 
         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_Dr_Raje/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $data8['data8'] = $this->itemCRUD->get_pet_petdetails_for_userid(); // petsinformationdetail with id
         $data9['data9'] = $this->itemCRUD->get_pet_Diagnosis_for_userid(); // pet diagnosis
         $datamerge = array_merge($data8,$data9);
         $this->load->view('infomenu',$datamerge);  
         $this->load->view('footer_dr_raje');
    }  
public function reports()  
    {  
         $chk_user_id = $_SESSION['global_user_id']; 
         if ($chk_user_id == 0 )
         {
              redirect('Home_AutoRenta/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library("pagination");
         $config=array();
         $param=array();
         $trec = $this->itemCRUD->user_count();
         $config["total_rows"] = $this->itemCRUD->user_count();
         $config["per_page"] =  9; // 14; // 16; // 20;
         $config['use_page_numbers'] = TRUE;
         $config["uri_segment"] = 3; // 4; // 3;
         $choice = $config["total_rows"] / $config["per_page"];
        // $config["num_links"] = floor($choice); // $this->Leaddetails_model->buyingLeadsTableLedsUser_count($data['fromdate'], $data['todate']);
//         $config["cur_tag_open"] = "";
//         $config["cur_tag_close"] = "";
//         $config["next_link"] = "Next";
//         $config["prev_link"] = "Previous";
         $config['use_page_numbers'] = TRUE;
         $config['enable_query_strings']=TRUE;
         $config['base_url'] = base_url() . 'index.php/Home_AutoRenta/reports';
         $config['use_page_numbers'] = TRUE;
        // $config['num_links'] = $trec; // $total_row;
         $config['cur_tag_open'] = '<span class="btn btn-primary">'; // '&nbsp;<a class="current">';
         $config['cur_tag_close'] =  '</span>'; // '</a>';
         $config['cur_link'] = 'Continue';
         $config['next_tag_open'] = '<span class="btn btn-primary">';
         $config['next_tag_close'] = '</span>';
         $config['next_link'] = 'Next';
         $config['prev_tag_open'] = '<span class="btn btn-primary">';
         $config['prev_tag_close'] = '</span>';
         $config['prev_link'] = 'Previous';
         $this->pagination->initialize($config);
         if($this->uri->segment(3)){
              $page = ($this->uri->segment(3)) ; // 3
         }
         else{
              $page = 0; // 1;
         }
         $data["links"] = $this->pagination->create_links();
         if ($page==0)
         {
             $skprec =0;
         }
         else
         {
         $skprec = ( $this->uri->segment(3)-1)*$config["per_page"]; // 20;
         }
         $data['userrec']=$this->itemCRUD->get_itemCRUD_new($config["per_page"],$skprec); // 20
         if ($skprec == 0 )
         {
          $data['i']=1;
         }
         else
         {
            $data['i']= $skprec+1;
         }
        //  $i =$skprec;
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_menu_main_',$datamerge);  
         $this->load->view('footer_dr_raje');
    }  
public function nextvisit()  
    {  
         $chk_user_id = $_SESSION['global_user_id']; 
          if ($chk_user_id == 0 )
         {
              redirect('Home_Dr_Raje/logout'); 
         }
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data']    = $this->itemCRUD->get_Pet_itemCRUD(); // user login
         $data3['data3'] = $this->itemCRUD->get_petdetails_next_visit_CRUD(); // petsinformationdetail
         $data4['data4'] = $this->itemCRUD->get_Pet_itemCRUD(); // user login
         $data7['data7'] = $this->itemCRUD->get_petdetails_new(); // petsinformationdetail with id
         $data8['data8'] = $this->itemCRUD->get_petdetails_CRUD(); // petsinformationdetail with id
         $data9['data9'] = $this->itemCRUD->get_pet_Diagnosis(); // pet diagnosis
         $this->load->view('header_dr_raje'); // $data5,$data6
         $datamerge = array_merge($data,$data3,$data4,$data7,$data8,$data9);
         $this->load->view('nextvisitpet',$datamerge);  
         $this->load->view('footer_dr_raje');
    } 

   public function utilitymenu()  
    { 
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('utility_menu_main_');  
         $this->load->view('footer_dr_raje');
    }  


public function utilitylist()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['e'] = $this->itemCRUD->get_petdetails_utility_CRUD(); // petsinformationdetail
         $data['all'] = $this->itemCRUD->get_petdetails_CRUD(); // petsinformationdetail
         $data['next'] = $this->itemCRUD->get_next_visit_data();
         $data['birth'] = $this->itemCRUD->get_birth_date_data();
         // $datamerge = array_merge($data,$data1);
         $this->load->view('header_dr_raje');
         $this->load->view('utility_',$data); // $datamerge);  
         $this->load->view('footer_dr_raje');

    }  

public function utilityfulllist()  
    {  
         $chk_user_id = $_SESSION['global_user_id']; 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $config['base_url'] = base_url() . 'index.php/Home_Dr_Raje/utilityfulllist';
         $data['userrec']=$this->itemCRUD->get_itemCRUD_new_full(); // $config["per_page"],$skprec); // 20
         $datamerge = array_merge($data,$config);
         $this->load->view('header_dr_raje');
         $this->load->view('report_fulllist_main_',$datamerge);  
         $this->load->view('footer_dr_raje');
    }  



   public function petlist()  
    {  
 
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->view('header_dr_raje');
        $this->load->view('pet_list_');  
        $this->load->view('footer_dr_raje');

    } 
 public function diseaselist()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('disease_list_');  
         $this->load->view('footer_dr_raje');

    }
   public function injectionlist()  
    {  
 
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');

         $this->load->view('header_dr_raje');
         $this->load->view('injection_list_');  
         $this->load->view('footer_dr_raje');

    }  

   public function petsdetails()  
    {  
 
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
  //      $this->load-library('database');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_Pet_itemCRUD();
        $data1['data1'] = $this->itemCRUD->get_Pet_TypeList(0); // get_Pet_CRUD();
 //       $data2['data2']  =$this->itemCRUD->get_pethead_CRUD();
        $data3['data3']  = $this->itemCRUD->get_petdetails_CRUD();
        $data4['data4']    = $this->itemCRUD->get_Pet_itemCRUD();
 //       $data5['data5']    = $this->itemCRUD->get_Pet_itemCRUD();
//        $data6['data6']    = $this->itemCRUD->get_Pet_itemCRUD();
        $data7['data7']    = $this->itemCRUD->get_Pet_TypeList(0);
        $this->load->view('header_dr_raje'); // $data5,$data6
        $datamerge = array_merge($data, $data1,$data3,$data4,$data7);
//        $datamerge = array_combine($data, $data1,$data2,$data3,$data4,$data5,$data6);
        $this->load->view('petsdetails',$datamerge);  
        $this->load->view('footer_dr_raje');
    }  



public function drdiagnosispet()  
    {  
 
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');
        $data['data']    = $this->itemCRUD->get_Pet_itemCRUD(); // user login
        $data3['data3'] = $this->itemCRUD->get_petdetails_CRUD(); // petsinformationdetail
        $data4['data4'] = $this->itemCRUD->get_Pet_itemCRUD(); // user login
        $data7['data7'] = $this->itemCRUD->get_petdetails_new(); // petsinformationdetail with id
        $data8['data8'] = $this->itemCRUD->get_petdetails_CRUD(); // petsinformationdetail with id
        $data9['data9'] = $this->itemCRUD->get_pet_Diagnosis(); // pet diagnosis
        $this->load->view('header_dr_raje'); // $data5,$data6
        $datamerge = array_merge($data,$data3,$data4,$data7,$data8,$data9);
        $this->load->view('drdiagnosispet',$datamerge);  
        $this->load->view('footer_dr_raje');
    }  

     public function logme_system()  
    {  
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');  
        $this->load->view('logme_system');  
    }  
    public function signin()  
    {  
        $this->load->view('signin');  
    }  
    public function data()  
    {  
        if ($this->session->userdata('currently_logged_in'))   
        {  
              $this->load->view('login_view');   //  $this->load->view('data');  
        } else {  
           // remove  redirect('Main/invalid');  
        }  
    }  
    public function invalid()  
    {  
        $this->load->view('invalid');  
    }  


// Show registration page
public function user_registration_show()
{
// echo " here -----------------------------------";

// $this->load->view('registration_form');
     $this->load->view('header_dr_raje');
     $this->load->view('registration_form');
     $this->load->view('footer_dr_raje');
}

public function customer_user_registration_show()
{
// echo " here -----------------------------------";

// $this->load->view('registration_form');
     $this->load->view('header_dr_raje');
     $this->load->view('customer_registration_form');
     $this->load->view('footer_dr_raje');
}

public function emp_user_registration_show()
{
// echo " here -----------------------------------";

// $this->load->view('registration_form');
     $this->load->view('header_dr_raje');
     $this->load->view('emp_registration_form');
     $this->load->view('footer_dr_raje');
}

// Validate and store  petlist data in database
public function new_pet_list() 
{

// Check validation for user input in SignUp form

//echo "              new pet list ";

//echo " i am here for validation ";


//    $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
$this->form_validation->set_rules('pettype', 'pettype', 'trim|required|xss_clean');
$this->form_validation->set_rules('petsubtype', 'petsubtype', 'trim|required|xss_clean');
$this->form_validation->set_rules('speciality', 'speciality', 'trim|required|xss_clean');
$this->form_validation->set_rules('remarks', 'remarks', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{

//echo "               no validate ... 1";
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje');
        $this->load->view('pet_list_');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added

//echo "               yes  validate ... 2";
    $data = array(
          'pettype' => $this->input->post('pettype'),
          'petsubtype' => $this->input->post('petsubtype'),
          'speciality'  => $this->input->post('speciality'),
          'remarks' => $this->input->post('remarks')
   );


//echo "               yes  validate and insert ... 3";

   $result = $this->login_database->petlist_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Pet List Updated Successfully !';
  
    $this->load->view('header_dr_raje');
    $this->load->view('pet_list_'); // registration_form'); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Pet Name and sub type already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('pet_list_',$data); // registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

 

// injection list start

// Validate and store registration data in database
public function new_injection_registration() 
{

//echo " i am here for validation ";
 
// Check validation for user input in Injection form
//                                                 field         prompt
$this->form_validation->set_rules('injectionname', 'injectionname', 'trim|required|xss_clean');
$this->form_validation->set_rules('approxprice', 'approxprice', 'trim|required|xss_clean');
$this->form_validation->set_rules('usedindisease', 'usedindisease', 'trim|required|xss_clean');
$this->form_validation->set_rules('remarks', 'remarks', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{

        $this->load->view('header_dr_raje');
        $this->load->view('injection_list_'); // 'registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added


//  this left side will be in model for condition

 $data = array(
          'injectionname' => $this->input->post('injectionname'),
          'approxprice' => $this->input->post('approxprice'),
          'usedindisease'  => $this->input->post('usedindisease'),
          'remarks' => $this->input->post('remarks')
   );
   $result = $this->login_database->injectionlist_insert($data);


  if ($result == TRUE) 
  {
     $data['message_display'] = 'Injection List Added Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('injection_list_',$data); // 'registration_form'); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Injection name and used in disease name already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('injection_list_',$data); // 'registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

//  injection list end

// disease list start

// Validate and store registration data in database
public function new_disease_registration() 
{

//echo " i am here for validation ";
 
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('diseasename', 'diseasename', 'trim|required|xss_clean');
$this->form_validation->set_rules('seasonspecific', 'seasonspecific', 'trim|required|xss_clean');
$this->form_validation->set_rules('remarks', 'remarks', 'trim|required|xss_clean');
$this->form_validation->set_rules('injectionlist', 'injectionlist', 'trim|required|xss_clean');
$this->form_validation->set_rules('medicine1', 'injectionlist', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{

        $this->load->view('header_dr_raje');
        $this->load->view('disease_list_'); // 'registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added


//  this left side will be in model for condition

 $data = array(
          'diseasename' => $this->input->post('diseasename'),
          'seasonspecific' => $this->input->post('seasonspecific'),
          'remarks'  => $this->input->post('remarks'),
          'injectionlist' => $this->input->post('injectionlist'),
          'medicine1' => $this->input->post('medicine1'),
          'medicine2' => $this->input->post('medicine2')
   );
   $result = $this->login_database->diseaselist_insert($data);


  if ($result == TRUE) 
  {
     $data['message_display'] = 'Disease List Added Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('disease_list_',$data); // 'registration_form'); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Disease name and season name already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('disease_list_',$data); // 'registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

//  disease list end



// Validate and store registration data in database
public function new_pet_registration() 
{

//echo " i am here for validation ";
 
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('pettype', 'pettype', 'trim|required|xss_clean');
$this->form_validation->set_rules('petsubtype', 'petsubtype', 'trim|required|xss_clean');
$this->form_validation->set_rules('speciality', 'speciality', 'trim|required|xss_clean');
$this->form_validation->set_rules('remarks', 'remarks', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje');
        $this->load->view('pet_list_'); // 'registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added


//  this left side will be in model for condition

 $data = array(
          'pettype' => $this->input->post('pettype'),
          'petsubtype' => $this->input->post('petsubtype'),
          'speciality'  => $this->input->post('speciality'),
          'remarks' => $this->input->post('remarks')
   );
   $result = $this->login_database->petlist_insert($data);


  if ($result == TRUE) 
  {
     $data['message_display'] = 'Pet List Added Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('pet_list_',$data); // 'registration_form'); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Pet name and sub name already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('pet_list_',$data); // 'registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}



// reverse main voucher save correct start


public function reverse_main_voucher_save()
{
/*      $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
*/
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $validentry = true;

/*      $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
*/
        $wobdate1 =  $this->input->post('obdate1'); 
         $wregdate = $this->input->post('regdate'); 
         $wpettycashid1 = $this->input->post('pettycashid1'); 
         $wempid1 = $this->input->post('empid1'); /* employee id */
         $wexpid1 = $this->input->post('expid1'); /* expense ac head  */
         $wopbalid1 = $this->input->post('opbalid1');  /* ac in petty cash income  */ 
         $wamountgivenid1 =  $this->input->post('amountgivenid1');
         $wnar1 = $this->input->post('narration1');
         $wnar2 = $this->input->post('narration2');
         $wremarks = $this->input->post('remarks');
         $wglcodecr = 0;
         $wglcodedr = 0;
         $wopbal = 0;
         $wamtgiven = 0;
         $wamtspend = 0;
         $wamtadj =0;
        $monthlyaccode = 0;
        $monthlyamountgiven = 0;
        $monthlyamountspend = 0;
        $monthlybalance = 0;
        $monthofledger=0;
        $yearofledger=0;
//echo $wobdate1 ;
//echo " ref " . $wregdate;
// die("h");
       if ($wregdate < $wobdate1  )
       {
                   $validentry =false;
die ("1");
       }
        if ($wempid1 > 0 and ($wexpid1 == "0" and $wopbalid1== "0"))
       {
                   $validentry =false;
 die ("2");
       }
        if ($wopbalid1 > 0  and $wempid1 > 0 )
        {
                  $validentry =false;
 die ("3");
        }
         if ( $wamountgivenid1 <= 0 )
         {
  //                $validentry =false;
         }
         if ($wexpid1 == "0" )
         {
         }
         else
         {
               if ($wopbalid1 == "0")
               {
                }
              else
              {
                  $validentry =false;
  die ("4");
            //     die ("both cist");
            }
         }
         if ($validentry == false)
         {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $data['msg'] ="Data Cannot be saved ... ";
         $data['message_display'] = 'Data Not Saved Successfully   ! ! ! ! ';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
         }
         else
         {
                if ($wopbalid1 <> "0")
                {
                  
                    $wglcodedr = "1";
                    $wglcodecr = $wopbalid1; 
//echo $wglcodecr;
//die ("here");
                    $wopbal = 0 ;
                    $wamtgiven = $this->input->post('amountgivenid1');
                    $wamtspend = 0;
                    $wamtadj =0;     
                    $monthlyaccode = "1";
                    $monthlyamountgiven = $this->input->post('amountgivenid1');
                    $monthlyamountspend = 0;
                    $monthlybalance = 0;
 /*                 $monthofledger = month($this->input->post('regdate'));
                    $yearofledger = year($this->input->post('regdate')); */
                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']=$wopbalid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=1;
                }
                if ($wexpid1 <> "0")
                {
                   if ($wempid1 == "0")
                   {
                    $wglcodedr = $wexpid1;
                    $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = 0;
                    $wamtspend =  $this->input->post('amountgivenid1');
                    $wamtadj =0;  
// option 2 with out employee code start
                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid1');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=2;


// option 2 end
                    }
                    else
                    {
                    $wglcodedr = $wexpid1;
                    $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = $this->input->post('amountgivenid1');
                    $wamtspend = 0;
                    $wamtadj =0;  

// option 3 expense with  emp code start

                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid1');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=3;

// option 3 end
                     }               
                 }
                 $oprentrymaindata = array(
                 'glcodedr' => $wglcodedr,
                 'glcodecr' => $wglcodecr ,
                  'accode' =>  $this->input->post('empid1'), 
                  'acname' => $this->input->post('empid1'), 
                  'date' => $this->input->post('regdate'),
                  'openingbalance' =>  $wopbal , /* $this->input->post('opbalance'), */
                  'amountgiven' =>  $wamtgiven, /* $this->input->post('amountgiven'), */
                  'amountspend' =>  $wamtspend,  /* $this->input->post('expensesmade'), */
                  'narration1' => $this->input->post('narration1'),
                  'narration2' => $this->input->post('narration2'),
                   'amountadjusted'  =>  $wamtadj , /*   $this->input->post('amountadjusted'), */
                    'salarymonth'  =>  $this->input->post('salmonth'),
                    'salaryyear' => $this->input->post('adjyear'),
                    'remarks'  =>  $this->input->post('remarks')
                  );   
               
               $result1 = $this->login_database->oprentry_main_voucher_insert($oprentrymaindata);
               $result2 = $this->login_database->oprentry_main_voucher_update($oprentrymaindataupdate);   
               $this->load->helper('url');
               $this->load->helper('security');  
               $this->load->library('form_validation'); 
               $this->load->library('table'); 
               $data['data']  = $this->itemCRUD->get_empname();
               $data['datainc']  = $this->itemCRUD->get_ledger_income();
               $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
               $data['databank']  = $this->itemCRUD->get_ledger_bank();
               $data['msg'] = "Data Saved Successfully ";
               $data['message_display'] = 'Daily Saved Successfully  ! ! ! ! ';
               $this->load->view('header_dr_raje');
               $this->load->view('oprentry_main_voucher_',$data);  
               $this->load->view('footer_dr_raje');         
       }
}


// reverse main voucher save correct end

// payment voucher main entry save start

public function oprentry_main_voucher_save()
{
/*      $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
*/
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $validentry = true;

/*      $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
*/
        $wobdate1 =  $this->input->post('obdate1'); 
         $wregdate = $this->input->post('regdate'); 
         $wpettycashid1 = $this->input->post('pettycashid1'); 
         $wempid1 = $this->input->post('empid1'); /* employee id */
         $wexpid1 = $this->input->post('expid1'); /* expense ac head  */
         $wopbalid1 = $this->input->post('opbalid1');  /* ac in petty cash income  */ 
         $wamountgivenid1 =  $this->input->post('amountgivenid1');
         $wnar1 = $this->input->post('narration1');
         $wnar2 = $this->input->post('narration2');
         $wremarks = $this->input->post('remarks');
         $wglcodecr = 0;
         $wglcodedr = 0;
         $wopbal = 0;
         $wamtgiven = 0;
         $wamtspend = 0;
         $wamtadj =0;
        $monthlyaccode = 0;
        $monthlyamountgiven = 0;
        $monthlyamountspend = 0;
        $monthlybalance = 0;
        $monthofledger=0;
        $yearofledger=0;
//echo $wobdate1 ;
//echo " ref " . $wregdate;
// die("h");
       if ($wregdate < $wobdate1  )
       {
                   $validentry =false;
       }
        if ($wempid1 > 0 and ($wexpid1 == "0" and $wopbalid1== "0"))
       {
                   $validentry =false;
        }
        if ($wopbalid1 > 0  and $wempid1 > 0 )
        {
                  $validentry =false;
        }
         if ( $wamountgivenid1 <= 0 )
         {
                  $validentry =false;
         }
         if ($wexpid1 == "0" )
         {
         }
         else
         {
               if ($wopbalid1 == "0")
               {
                }
              else
              {
                  $validentry =false;
             //     die ("both cist");
            }
         }
         if ($validentry == false)
         {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $data['msg'] ="Data Cannot be saved ... ";
         $data['message_display'] = 'Data Not Saved Successfully   ! ! ! ! ';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
         }
         else
         {
                if ($wopbalid1 <> "0")
                {
                  
                    $wglcodedr = "1";
                    $wglcodecr = $wopbalid1; 
//echo $wglcodecr;
//die ("here");
                    $wopbal = 0 ;
                    $wamtgiven = $this->input->post('amountgivenid1');
                    $wamtspend = 0;
                    $wamtadj =0;     
                    $monthlyaccode = "1";
                    $monthlyamountgiven = $this->input->post('amountgivenid1');
                    $monthlyamountspend = 0;
                    $monthlybalance = 0;
 /*                 $monthofledger = month($this->input->post('regdate'));
                    $yearofledger = year($this->input->post('regdate')); */
                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']=$wopbalid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=1;
                }
                if ($wexpid1 <> "0")
                {
                   if ($wempid1 == "0")
                   {
                    $wglcodedr = $wexpid1;
                    $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = 0;
                    $wamtspend =  $this->input->post('amountgivenid1');
                    $wamtadj =0;  
// option 2 with out employee code start
                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid1');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=2;


// option 2 end
                    }
                    else
                    {
                    $wglcodedr = $wexpid1;
                    $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = $this->input->post('amountgivenid1');
                    $wamtspend = 0;
                    $wamtadj =0;  

// option 3 expense with  emp code start

                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid1');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid1');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=3;

// option 3 end
                     }               
                 }
                 $oprentrymaindata = array(
                 'glcodedr' => $wglcodedr,
                 'glcodecr' => $wglcodecr ,
                  'accode' =>  $this->input->post('empid1'), 
                  'acname' => $this->input->post('empid1'), 
                  'date' => $this->input->post('regdate'),
                  'openingbalance' =>  $wopbal , /* $this->input->post('opbalance'), */
                  'amountgiven' =>  $wamtgiven, /* $this->input->post('amountgiven'), */
                  'amountspend' =>  $wamtspend,  /* $this->input->post('expensesmade'), */
                  'narration1' => $this->input->post('narration1'),
                  'narration2' => $this->input->post('narration2'),
                   'amountadjusted'  =>  $wamtadj , /*   $this->input->post('amountadjusted'), */
                    'salarymonth'  =>  $this->input->post('salmonth'),
                    'salaryyear' => $this->input->post('adjyear'),
                    'remarks'  =>  $this->input->post('remarks')
                  );   
               
               $result1 = $this->login_database->oprentry_main_voucher_insert($oprentrymaindata);
               $result2 = $this->login_database->oprentry_main_voucher_update($oprentrymaindataupdate);   
               $this->load->helper('url');
               $this->load->helper('security');  
               $this->load->library('form_validation'); 
               $this->load->library('table'); 
               $data['data']  = $this->itemCRUD->get_empname();
               $data['datainc']  = $this->itemCRUD->get_ledger_income();
               $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
               $data['databank']  = $this->itemCRUD->get_ledger_bank();
               $data['msg'] = "Data Saved Successfully ";
               $data['message_display'] = 'Daily Saved Successfully  ! ! ! ! ';
               $this->load->view('header_dr_raje');
               $this->load->view('oprentry_main_voucher_',$data);  
               $this->load->view('footer_dr_raje');         
       }
}

// reverse entry start


public function reversepayupdate($id,$glcodedr,$glcodecr,$empcode)
{
/*      $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
*/
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $validentry = true;

/*      $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
*/
        $wobdate1 =  $this->input->post('obdate1'); 
         $wregdate = $this->input->post('regdate'); 
         $wpettycashid1 = $this->input->post('pettycashid1'); 
         $wempid1 =  $empcode;   // $this->input->post('empid1'); /* employee id */
         $wexpid1 = $this->input->post('expid1'); /* expense ac head  */
         $wopbalid1 = $this->input->post('opbalid1');  /* ac in petty cash income  */ 
         $wamountgivenid1 =  $this->input->post('amountgivenid');
         $wnar1 = $this->input->post('narration1');
         $wnar2 = $this->input->post('narration2');
         $wremarks = $this->input->post('remarks');
         $wglcodecr = $glcodecr; //  0;
         $wglcodedr = $glcodedr; // 0;

echo $wglcodecr;
echo $wglcodedr ;
echo  $wempid1;


         $wopbal = 0;
         $wamtgiven = 0;
         $wamtspend = 0;
         $wamtadj =0;
        $monthlyaccode = 0;
        $monthlyamountgiven = 0;
        $monthlyamountspend = 0;
        $monthlybalance = 0;
        $monthofledger=0;
        $yearofledger=0;
//echo $wobdate1 ;
//echo " ref " . $wregdate;
// die("h");
       if ($wregdate < $wobdate1  )
       {
             //      $validentry =false;
       }
        if ($wempid1 > 0 and ($wexpid1 == "0" and $wopbalid1== "0"))
       {
        //           $validentry =false;
        }
        if ($wopbalid1 > 0  and $wempid1 > 0 )
        {
           //       $validentry =false;
        }
         if ( $wamountgivenid1 <= 0 )
         {
           //       $validentry =false;
         }
         if ($wexpid1 == "0" )
         {
         }
         else
         {
               if ($wopbalid1 == "0")
               {
                }
              else
              {
          //        $validentry =false;
             //     die ("both cist");
            }
         }
         if ($validentry == false)
         {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['datainc']  = $this->itemCRUD->get_ledger_income();
         $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
         $data['databank']  = $this->itemCRUD->get_ledger_bank();
         $data['msg'] ="Data Cannot be saved ... ";
         $data['message_display'] = 'Data Not Saved Successfully   ! ! ! ! ';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_main_voucher_',$data);  
         $this->load->view('footer_dr_raje');
         }
         else
         {
                if ($wopbalid1 <> "0")
                {
                  
                //    $wglcodedr = "1";
                //    $wglcodecr = $wopbalid1; 
//echo $wglcodecr;
//die ("here");
                    $wopbal = 0 ;
                    $wamtgiven = $this->input->post('amountgivenid');
                    $wamtspend = 0;
                    $wamtadj =0;     
                    $monthlyaccode = "1";
                    $monthlyamountgiven = $this->input->post('amountgivenid');
                    $monthlyamountspend = 0;
                    $monthlybalance = 0;
 /*                 $monthofledger = month($this->input->post('regdate'));
                    $yearofledger = year($this->input->post('regdate')); */
                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=$this->input->post('amountgivenid');
                    $oprentrymaindataupdate['accodecr']=$wopbalid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=1;
                }
                if ($wexpid1 <> "0")
                {
                   if ($wempid1 == "0")
                   {
                 //   $wglcodedr = $wexpid1;
               //     $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = 0;
                    $wamtspend =  $this->input->post('amountgivenid');
                    $wamtadj =0;  
// option 2 with out employee code start
                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=2;


// option 2 end
                    }
                    else
                    {
               //     $wglcodedr = $wexpid1;
              //      $wglcodecr = "1";
                    $wopbal = 0;
                    $wamtgiven = $this->input->post('amountgivenid');
                    $wamtspend = 0;
                    $wamtadj =0;  

// option 3 expense with  emp code start

                    $monthlyaccode = "1";
                    $monthlyamountgiven =0;
                    $monthlyamountspend =  $this->input->post('amountgivenid');
                    $monthlybalance = 0;

                    $wregdate = $this->input->post('regdate');
                     $monthofledger= date('m', strtotime($wregdate));
                    $yearofledger = date('Y', strtotime($wregdate));
//echo  " month " . $monthofledger . " year " .  $yearofledger;
                    $oprentrymaindataupdate['accodeid']='1';
                    $oprentrymaindataupdate['amountgiventotal']=0;
                   $oprentrymaindataupdate['amountspendtotal']=$this->input->post('amountgivenid');
                    $oprentrymaindataupdate['accodecr']="1"; 
                    $oprentrymaindataupdate['accodedr']= $wexpid1; 
                    $oprentrymaindataupdate['monthofledger']=$monthofledger ; // month($this->input->post('regdate'));
                    $oprentrymaindataupdate['yearofledger']=  $yearofledger ; // year($this->input->post('regdate'));
                    $oprentrymaindataupdate['regdate']=$wregdate;
                     $oprentrymaindataupdate['option']=3;

// option 3 end
                     }           
                 }

echo $wopbal;
echo $wamtgiven;
echo $wamtspend;


                 $oprentrymaindata = array(
                 'glcodedr' => $wglcodedr,
                 'glcodecr' => $wglcodecr ,
                  'accode' => $wempid1 ,  //  $this->input->post('empid1'), 
                  'acname' => $wempid1, // $this->input->post('empid1'), 
                  'date' => $this->input->post('regdate'),
                  'openingbalance' =>  $wopbal , /* $this->input->post('opbalance'), */
                  'amountgiven' =>  $wamtgiven, /* $this->input->post('amountgiven'), */
                  'amountspend' =>  $wamtspend,  /* $this->input->post('expensesmade'), */
                  'narration1' => $this->input->post('narration1'),
                  'narration2' => $this->input->post('narration2'),
                   'amountadjusted'  =>  $wamtadj , /*   $this->input->post('amountadjusted'), */
                    'salarymonth'  =>  $this->input->post('salmonth'),
                    'salaryyear' => $this->input->post('adjyear'),
                    'remarks'  =>  $this->input->post('remarks')
                  );   
               
               $result1 = $this->login_database->oprentry_main_voucher_insert($oprentrymaindata);
               $result2 = $this->login_database->oprentry_main_voucher_update($oprentrymaindataupdate);   
               $this->load->helper('url');
               $this->load->helper('security');  
               $this->load->library('form_validation'); 
               $this->load->library('table'); 
               $data['data']  = $this->itemCRUD->get_empname();
               $data['datainc']  = $this->itemCRUD->get_ledger_income();
               $data['dataexp']  = $this->itemCRUD->get_ledger_expenses();
               $data['databank']  = $this->itemCRUD->get_ledger_bank();
               $data['msg'] = "Data Saved Successfully ";
               $data['message_display'] = 'Daily Saved Successfully  ! ! ! ! ';
               $this->load->view('header_dr_raje');
               $this->load->view('oprentry_main_voucher_',$data);  
               $this->load->view('footer_dr_raje');         
       }
}



// reverse entry end 



// payment voucher main entry save end 
// payment voucher employee entry save start

public function oprentry_voucher_save()
{
      $data['data']  = $this->itemCRUD->get_empname();
      $validentry = true;
      $wregdate = $this->input->post('regdate');
      $wempid1 = $this->input->post('empid1');
      $wopbalance = $this->input->post('opbalance');
      $wamountgiven =  $this->input->post('amountgiven');
      $wexpensesmade = $this->input->post('expensesmade');
      $wamountadjusted =  $this->input->post('amountadjusted');
      $wsalmonth =  $this->input->post('salmonth');
//echo    $wsalmonth;
      $wadjyear = $this->input->post('adjyear');

//

//echo " op " . $wopbalance;
//echo " am g " . $wamountgiven; 
//echo " exp " .  $wexpensesmade ;
//echo " adj " .  $wamountadjusted ;
//die("here");
//
      if ($wempid1 == '0' )
     {
         $validentry = false;
     }
    if ((float)$wamountgiven > 0 and (float)$wexpensesmade > 0 and (float)$wamountadjusted > 0 )
    {
         $validentry = false;
    }
    if ( ((float)$wopbalance > 0 ) and ((float)$wamountgiven+ (float)$wexpensesmade + (float)$wamountadjusted) > 0 )
    {
        $validentry = false;
    }
    if ( ((float)$wamountgiven > 0 ) and ((float)$wopbalance+ (float)$wexpensesmade + (float)$wamountadjusted) > 0 )
    {
      $validentry = false;
    }
    if ( ((float)$wexpensesmade > 0 ) and ((float)$wopbalance+ (float)$wamountgiven + (float)$wamountadjusted) > 0 )
    {
      $validentry = false;
    }
    if ( ((float)$wamountadjusted > 0 ) and ((float)$wopbalance+ (float)$wamountgiven + (float)$wexpensesmade) > 0 )
    {
      $validentry = false;
    }
    if ($wsalmonth == '00')
    {
    }
    else
    {
       if ($wadjyear == '')
       {
         $validentry = false;
       }
    }
    if ($validentry == false)
   {
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['msg'] ="Data Cannot be saved ... ";
         $data['message_display'] = 'Data Not Saved Successfully    ! ! ! ! ';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_voucher_',$data);  
         $this->load->view('footer_dr_raje');
   }
  else
  {
      $oprentrydata = array(
        'accode' =>  $this->input->post('empid1'), 
        'acname' => $this->input->post('empid1'), 
        'date' => $this->input->post('regdate'),
       'openingbalance' =>  $this->input->post('opbalance'),
       'amountgiven' => $this->input->post('amountgiven'),
       'amountspend' =>  $this->input->post('expensesmade'),
       'narration1' => $this->input->post('narration1'),
       'narration2' => $this->input->post('narration2'),
       'amountadjusted'  =>    $this->input->post('amountadjusted'),
        'salarymonth'  =>  $this->input->post('salmonth'),
        'salaryyear' => $this->input->post('adjyear'),
       'remarks'  =>  $this->input->post('remarks')
        );   

//echo " op " . $wopbalance;
//echo " am g " . $wamountgiven; 
//echo " exp " .  $wexpensesmade ;
//echo " adj " .  $wamountadjusted ;
//die("here after save ");

        $result1 = $this->login_database->oprentry_voucher_insert($oprentrydata);
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation'); 
         $this->load->library('table');
         $data['data']  = $this->itemCRUD->get_empname();
         $data['msg'] = "Data Saved  Successfully ... ";
         $data['message_display'] = 'Data Saved Successfully   ! ! ! ! ';
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_voucher_',$data);  
         $this->load->view('footer_dr_raje');
  } 
}
// payment voucher employee entry save end

// opr entry ledger start
public function oprentry_ledger()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_ledger_get_date_');  
         $this->load->view('footer_dr_raje');
}
// opr entry ledger end

// opr entry cash book start
public function oprentry_cash_book_print()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_cash_book_get_date_');  
         $this->load->view('footer_dr_raje');
}

// opr ledger print start
public function oprentry_cash_book_report()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $fdate = $this->input->post('datefrom');
         $tdate= $this->input->post('dateto');
        
         $data['data'] =   $this->itemCRUD->get_oprentry_cash_book_details($fdate,$tdate); // get_login_details();   
         $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
         $this->load->view('oprcashbookprint_',$data);    // 'logindata   
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');

}
// opr ledger print end
// opr entrycash book  end


// opr ledger print start
public function oprentry_ledger_report()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $fdate = $this->input->post('datefrom');
         $tdate= $this->input->post('dateto');
         $empcode =  $this->input->post('empid1');
         $expcode =  $this->input->post('expid1');
//echo $empcode;
//die ("chk");
         $data['data'] =   $this->itemCRUD->get_oprentry_details($fdate,$tdate,$empcode,$expcode); // get_login_details();   
         $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
         $this->load->view('oprledgerprint_',$data);    // 'logindata
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
}
// opr ledger print end

// Validate and store registration data in database for pets
public function new_drr_registration($date_emp)
{

//echo " here " . $date_emp . " .... " . "<br>";

$dataline = 0;
$result1 = False;
$result2 = False;
$result3 = False;
$result4 = False;
$result5 = False;
$result6 = False;
$result7 = False;
$result8 = False;
$result9 = False;
$result10 = False;

/* new added start */

$latenight_23hrs = 0; /*    75;  */
$earlymorning_6am = 0;  /*   50;   */

/* new added end */
$osrs = 400 ; /* $_SESSION['global_dayallowancers']; */
$nightrs = 100; /*  $_SESSION['global_nightallowancers']; */
$cleanrs = 25 ; /*  $_SESSION['global_cleaningallowancers']; */
$otrs = 40; 
$laters = 33;
$doubleshift=100;
$htnallowance = 400;
 $correctentry='True';
 $datainsert = 0 ;
      $data['data']  = $this->itemCRUD->get_empname();
      $data2_1['data2_1']  = $this->itemCRUD->get_customer();
      $data_2['data_2']  = $this->itemCRUD->get_empname();
      $data2_2['data2_2']  = $this->itemCRUD->get_customer();
      $data_3['data_3']  = $this->itemCRUD->get_empname();
      $data2_3['data2_3']  = $this->itemCRUD->get_customer();
      $data_4['data_4']  = $this->itemCRUD->get_empname();
      $data2_4['data2_4']  = $this->itemCRUD->get_customer();
      $data_5['data_5']  = $this->itemCRUD->get_empname();
      $data2_5['data2_5']  = $this->itemCRUD->get_customer();
      $data_6['data_6']  = $this->itemCRUD->get_empname();
      $data2_6['data2_6']  = $this->itemCRUD->get_customer();

       $data_7['data_7']  = $this->itemCRUD->get_empname();
       $data2_7['data2_7']  = $this->itemCRUD->get_customer();

       $data_8['data_8']  = $this->itemCRUD->get_empname();
       $data2_8['data2_8']  = $this->itemCRUD->get_customer();
       $data_9['data_9']  = $this->itemCRUD->get_empname();
       $data2_9['data2_9']  = $this->itemCRUD->get_customer();
       $data_10['data_10']  = $this->itemCRUD->get_empname();
       $data2_10['data2_10']  = $this->itemCRUD->get_customer();

      $data_11['data_11']  = $this->itemCRUD->get_empname();
      $data2_11['data2_11']  = $this->itemCRUD->get_customer();

       $data_12['data_12'] = "DATE";



$this->form_validation->set_rules('regdate', 'regdate', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{

         $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->library('table');

 
        $this->load->view('header_dr_raje'); // $data5,$data6
    /*    $datamerge = array_merge($data, $data1,$data2_1,   $data_2, $data1_2,$data2_2,    $data_3, $data1_3,$data2_3,  $data_4, $data1_4,$data2_4,  $data_5, $data1_5,$data2_5,  $data_6, $data1_6,$data2_6 ) ;  */ 
         $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3,  $data_4, $data2_4,  $data_5,$data2_5,  $data_6, $data2_6,  $data_7, $data2_7 , $data_8, $data2_8, $data_9, $data2_9, $data_10, $data2_10,$data_11,$data2_11,$data_12 ) ;  
       $this->load->view('DaaEntry_',$datamerge);  
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

    $wempid1 = $this->input->post('empid1');
    $wpresentid1 = $this->input->post('presentid1');
//echo $wpresentid1;

//echo $data_12[data_12];
//echo $date_emp;
//die("here");
    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate1');
    }
//echo $wregdate;
// echo "<br>". $date_emp;
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));
//echo $dayofdate;
//echo $monthofdate;
//echo $yearofdate ;
// die("day");
    // $day = date('l', $wregdate);
 //   echo  $dayofweek ;
 //   die("e");

    $wdutyid1 =  $this->input->post('dutyid1');
    $wcustid1 = $this->input->post('custid1');
    $wpass1 = $this->input->post('pass1');
    $wreporttime1 = $this->input->post('reporttime1');
    $woutdate1_1 =  $this->input->post('outdate1_1');
    $woutdate1_2 =  $this->input->post('outdate1_2');

    $wacthh1  =  $this->input->post('acthh1');
    $wactmm1  =  $this->input->post('actmm1');
    $wouthh1  =  $this->input->post('outhh1');
    $woutmm1  =  $this->input->post('outmm1');

    $wshiftid1 =  $this->input->post('shiftid1');

// echo " act hh " .   $wacthh1 . " act mm " .  $wactmm1 . " out hh " .  $wouthh1 . " out mm " .   $woutmm1  ;


    $iparr   = explode('~', $wempid1);
    $weid1 = $iparr[0];
    $xbsal = 0.00;
    if ( $this->input->post('basicsal1') > 0 )
    {
       $wbsal1 =  $this->input->post('basicsal1') / 30;
       $xbsal = $this->input->post('basicsal1') / 30;
    }
    else
    {
      $wbsal1 = 0;
      $xbsal = 0.00;
    }
    $woutdate1_1 =  $this->input->post('outdate1_1');
    $woutdate1_2 =  $this->input->post('outdate1_2');
   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine1 = $this->input->post('latecoming1');
    if ($latefine1 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
//echo $wdutyid1;
//echo $wpresentid1;
//die("before if");
    if ($wdutyid1 == 'O' and $wpresentid1== 'PO'  )
    {      
            /*  $daydiff = ( $woutdate1_2 - $woutdate1_1)/60/60/24; */
             /* ($end_date - $start_date)/60/60/24 */ 

            if ( $dayofweek == 'Sunday')
            {
                $wbsal1 = $wbsal1 * 2;
            }
            else
            {
               $wbsal1 = $wbsal1 * 1;
             }

           $date1 = new DateTime($woutdate1_2 );
           $date2  = new DateTime($woutdate1_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

         if (  (int) $wacthh1 > 0 )
         {
          if ((int)$wacthh1 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
      }

// echo  " ear "   . $earlymorning_6am . "  act hh " .  $wacthh1 ;

      if ($wdutyid1 == 'L'  )
      {
       if (  ( (int)$wouthh1 >= 24 ) or ( (int)$wouthh1 >= 23 and (int)$woutmm1 >= 0 )   )
       {
                 if ($wshiftid1 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }
       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }

   

    if ($wdutyid1 == 'L' and ( $wpresentid1== 'PR'  or $wpresentid1== 'PP' )  )
    { 
       $ottime = $this->input->post('ottime1');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh1 >= 24 ) or ( (int)$wouthh1 >= 23 and (int)$woutmm1 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid1 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
   }
   if ( $wpresentid1== 'DD'  or  $wpresentid1== 'DH')
  {
   if ( $wpresentid1== 'DD'  )
   {
          $doubleshift=100;
   }
    if ( $wpresentid1== 'DH'  )
   {
          $doubleshift=200;
   }  
   $wbsal1 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime1');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh1 >= 24 ) or ( (int)$wouthh1 >= 23 and (int)$woutmm1 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid1 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */
  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid1== 'HD'  or $wpresentid1== 'WD' )
  {
     if ( $this->input->post('basicsal1') > 0 )
    {
       $wbsal1 =  ($this->input->post('basicsal1') / 30)*2;
    }
    else
    {
      $wbsal1 = 0;
    }
    $ottime = $this->input->post('ottime1');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
//echo $ot;
//die("wd");
   }
   if ($wpresentid1 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance =0;
   }
///echo " present id " . $wpresentid1;
//echo " htn " . $htnallowance;
//die ("x");
if ($dayofdate == 31)
{
$wbsal1 = 0.00;
}

if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal1 = $wbsal1 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal1 = $wbsal1 + ($xbsal*2);
   }
}
}

    $data = array(
        'date' => $wregdate,     /*   $this->input->post('regdate'),    */
        'empid' =>  $weid1, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid1'),
        'duty'  =>  $this->input->post('dutyid1'),
        'outstationdatefrom'  =>  $this->input->post('outdate1_1'),
        'outstationdateto' => $this->input->post('outdate1_2'),
        'shift'  => $this->input->post('shiftid1'),
        'customername'   =>  $this->input->post('custid1'),
       'customerid'   =>  $this->input->post('custid1'),
       'passengername'  => $this->input->post('pass1'),
       'reportingtime'   => $this->input->post('reporttime1'),
       'intime'   =>  $this->input->post('intime1'), 
       'actualintime'   => $this->input->post('acttime1'),
       'outtime'    => $this->input->post('outtime1'),
       'actualouttime'   => $this->input->post('actouttime1'),
       'worktime'    => $this->input->post('workduration1'),
       'ottime'    =>  $this->input->post('ottime1'),
       'totalduration'    => $this->input->post('tottime1'),
       'remarks'    => $this->input->post('remarks1'),
      'basicsalary'    => $wbsal1, /* $this->input->post('basicsal1')/30                                                        $earlymorning_6am  */
      'latecoming' => $this->input->post('latecoming1'),
      'daysalary' =>  ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
     'doubleshift' => $doubleshift,
      'totalallowance'  =>  $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );      
//echo "day " . $wdayallowance ;
//echo " night " . $wnightallowance ;
//echo " clean " .  $wcleaningallowance; 
//echo " ot " . $ot ; 
//echo " dd " . $doubleshift; 
//echo " hn " . $htnallowance ;
// die ("d");
  if ($wempid1 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid1 == '0' )
    {
           $correctentry='False';
    }
    else
    {
    $result1 = $this->login_database->drr_registration_insert($data);
    $dataline = $dataline + 1;
    if ($result1 )
   {
          $datainsert = $datainsert + 1;
    }
           $date1 = new DateTime($woutdate1_2 );
           $date2  = new DateTime($woutdate1_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate1_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate1_1 = $date2;

                       if ( $this->input->post('basicsal1') > 0 )
                       {
                                $wbsal1 =  $this->input->post('basicsal1') / 30;
                       }
                      else
                      {
                         $wbsal1 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek1 = date('l', strtotime($wdate2));
                       $dayofdate_1= date('d',  strtotime($wdate2));

                      $monthofdate_1 = date ('F', strtotime ($wdate2));
                      $yearofdate_1 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek1 == 'Sunday')
                       {
                            $wbsal1 = $wbsal1 * 2;
                       }
                       else
                       {
                            $wbsal1 = $wbsal1 * 1;
                      }
                      if ($dayofdate_1 == 31)
                      {
                           $wbsal1 = 0;
                      }



                   if   ((0 == $yearofdate_1 % 4) & (0 != $yearofdate_1 % 100) | (0 ==$yearofdate_1 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_1 == 'February')
                   {
                      if  ($dayofdate_1 == 29)
                      {
                           $wbsal1 = $wbsal1 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_1 == 'February')
                {
                     if  ($dayofdate_1 == 28)
                     {
                        $wbsal1 = $wbsal1 + ($xbsal*2);
                     }
                }
                }


                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid1, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid1'),
                                 'duty'  =>  $this->input->post('dutyid1'),
                                 'outstationdatefrom'  =>   $this->input->post('outdate1_1'),
                                 'outstationdateto' => $this->input->post('outdate1_2'),
                                 'shift'  => $this->input->post('shiftid1'),
                                 'customername'   =>  $this->input->post('custid1'),
                                 'customerid'   =>  $this->input->post('custid1'),
                                 'passengername'  => $this->input->post('pass1'),
                                'reportingtime'   => $this->input->post('reporttime1'),
                                'intime'   =>  $this->input->post('intime1'), 
                                'actualintime'   => $this->input->post('acttime1'),
                                'outtime'    => $this->input->post('outtime1'),
                                'actualouttime'   => $this->input->post('actouttime1'),
                                'worktime'    => $this->input->post('workduration1'),
                               'ottime'    =>  $this->input->post('ottime1'),
                               'totalduration'    => $this->input->post('tottime1'),
                              'remarks'    => $this->input->post('remarks1'),
                             'basicsalary'    => $wbsal1, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming1'),
                             'daysalary' => $wbsal1, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  => 0, //  $ot,
                            'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid1 == 'O' and $wpresentid1== 'PO'  )
                   {
                                $result1 = $this->login_database->drr_registration_insert($data);  
                   }
           }

    
      
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */
    }
  }

// line 2 start

    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate2');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));

    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

    $wempid2 = $this->input->post('empid2');
    $wpresentid2 = $this->input->post('presentid2');

     $wshiftid2 =  $this->input->post('shiftid2');

//echo $wpresentid2;
//echo " 2 nd ";
    $wdutyid2 =  $this->input->post('dutyid2');
    $wcustid2 = $this->input->post('custid2');
    $wpass2 = $this->input->post('pass2');
    $wreporttime2 = $this->input->post('reporttime2');
    $iparr   = explode('~', $wempid2);
    $weid2 = $iparr[0];
  if ( $this->input->post('basicsal2') > 0 )
   {
     $wbsal2 =  $this->input->post('basicsal2') / 30;
     $xbsal = $this->input->post('basicsal2') / 30;

   }
   else
   {
     $wbsal2 = 0;
     $xbsal = 0;
   }
    $woutdate2_1 =  $this->input->post('outdate2_1');
    $woutdate2_2 =  $this->input->post('outdate2_2');

    $wacthh2  =  $this->input->post('acthh2');
    $wactmm2  =  $this->input->post('actmm2');
    $wouthh2  =  $this->input->post('outhh2');
    $woutmm2  =  $this->input->post('outmm2');

   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine2 = $this->input->post('latecoming2');
    if ($latefine2 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid2 == 'O' and $wpresentid2== 'PO'  )
    {      
           $date1 = new DateTime($woutdate2_2 );
           $date2  = new DateTime($woutdate2_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal2 = $wbsal2 * 2;
            }
            else
            {
               $wbsal2 = $wbsal2  * 1;
             }


         if (  (int) $wacthh2 > 0 )
         {
          if ((int)$wacthh2 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }

      }

      if ($wdutyid2 == 'L'  )
      {
       if (  ( (int)$wouthh2 >= 24 ) or ( (int)$wouthh2 >= 23 and (int)$woutmm2 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid2 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }

    if ($wdutyid2 == 'L' and ( $wpresentid2== 'PR'   or $wpresentid2== 'PP' )  )
    { 
       $ottime = $this->input->post('ottime2');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

 
       if (  ( (int)$wouthh2 >= 24 ) or ( (int)$wouthh2 >= 23 and (int)$woutmm2 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid2 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      



   }
   if ( $wpresentid2== 'DD'  or  $wpresentid2== 'DH')
  {
//echo "dd";
   if ( $wpresentid2 == 'DD')
   {
        $doubleshift=100;
   }
   if ($wpresentid2  == 'DH')
   {
       $doubleshift = 200;
   }
   $wbsal2 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime2');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh2 >= 24 ) or ( (int)$wouthh2 >= 23 and (int)$woutmm2 >= 0 )   )
       {
 //                $latenight_23hrs = 75;
                 if ($wshiftid2 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */

  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid2== 'HD'  or $wpresentid2== 'WD' )
  {
     if ( $this->input->post('basicsal2') > 0 )
    {
       $wbsal2 =  ($this->input->post('basicsal2') / 30)*2;
    }
    else
    {
      $wbsal2 = 0;
    }
    $ottime = $this->input->post('ottime2');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid2 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
   }
if ($dayofdate == 31)
{
$wbsal2 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal2 = $wbsal2 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal2 = $wbsal2 + ($xbsal*2);
   }
}
}



    $data = array(
        'date' => $wregdate,     /*     $this->input->post('regdate'),    */ 
        'empid' =>  $weid2, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid2'),
        'duty'  =>  $this->input->post('dutyid2'),
        'outstationdatefrom'  =>  $this->input->post('outdate2_1'),
        'outstationdateto' => $this->input->post('outdate2_2'),
        'shift'  => $this->input->post('shiftid2'),
        'customername'   =>  $this->input->post('custid2'),
       'customerid'   =>  $this->input->post('custid2'),
       'passengername'  => $this->input->post('pass2'),
       'reportingtime'   => $this->input->post('reporttime2'),
       'intime'   =>  $this->input->post('intime2'), 
       'actualintime'   => $this->input->post('acttime2'),
       'outtime'    => $this->input->post('outtime2'),
       'actualouttime'   => $this->input->post('actouttime2'),
       'worktime'    => $this->input->post('workduration2'),
       'ottime'    =>  $this->input->post('ottime2'),
       'totalduration'    => $this->input->post('tottime2'),
       'remarks'    => $this->input->post('remarks2'),
      'basicsalary'    =>  $wbsal2,  /* $this->input->post('basicsal2')/30 */
      'latecoming' => $this->input->post('latecoming2'),
      'daysalary' => ($wbsal2 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid2 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid2 == '0' )
    {
           $correctentry='False';
    }
    else
    {


  $result2 = $this->login_database->drr_registration_insert($data);
 //  $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result2 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate2_2 );
           $date2  = new DateTime($woutdate2_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate2_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate2_1 = $date2;

                       if ( $this->input->post('basicsal2') > 0 )
                       {
                                $wbsal2 =  $this->input->post('basicsal2') / 30;
                       }
                      else
                      {
                         $wbsal2 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek2 = date('l', strtotime($wdate2));
                       $dayofdate_2= date('d',  strtotime($wdate2));

                      $monthofdate_2 = date ('F', strtotime ($wdate2));
                      $yearofdate_2 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek2 == 'Sunday')
                       {
                            $wbsal2 = $wbsal2 * 2;
                       }
                       else
                       {
                            $wbsal2 = $wbsal2 * 1;
                      }
                      if ($dayofdate_2 == 31)
                      {
                           $wbsal2 = 0;
                      }

                   if   ((0 == $yearofdate_2 % 4) & (0 != $yearofdate_2 % 100) | (0 ==$yearofdate_2 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_2 == 'February')
                   {
                      if  ($dayofdate_2 == 29)
                      {
                           $wbsal2 = $wbsal2 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_2 == 'February')
                {
                     if  ($dayofdate_2 == 28)
                     {
                        $wbsal2 = $wbsal2 + ($xbsal*2);
                     }
                }
                }




                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid2, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid2'),
                                 'duty'  =>  $this->input->post('dutyid2'),
                                 'outstationdatefrom'  =>   $this->input->post('outdate2_1'),
                                 'outstationdateto' => $this->input->post('outdate2_2'),
                                 'shift'  => $this->input->post('shiftid2'),
                                 'customername'   =>  $this->input->post('custid2'),
                                 'customerid'   =>  $this->input->post('custid2'),
                                 'passengername'  => $this->input->post('pass2'),
                                'reportingtime'   => $this->input->post('reporttime2'),
                                'intime'   =>  $this->input->post('intime2'), 
                                'actualintime'   => $this->input->post('acttime2'),
                                'outtime'    => $this->input->post('outtime2'),
                                'actualouttime'   => $this->input->post('actouttime2'),
                                'worktime'    => $this->input->post('workduration2'),
                               'ottime'    =>  $this->input->post('ottime2'),
                               'totalduration'    => $this->input->post('tottime2'),
                              'remarks'    => $this->input->post('remarks2'),
                             'basicsalary'    => $wbsal2, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming2'),
                             'daysalary' => $wbsal2, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                            'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid2 == 'O' and $wpresentid2== 'PO'  )
                   {
                        $result2 = $this->login_database->drr_registration_insert($data);  
                   }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */


    }
  }

// line 2 end

// line 3 start

    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate3');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));


    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

     $wshiftid3 =  $this->input->post('shiftid3');

    $wempid3 = $this->input->post('empid3');
    $wpresentid3 = $this->input->post('presentid3');
    $wdutyid3 =  $this->input->post('dutyid3');
    $wcustid3 = $this->input->post('custid3');
    $wpass3 = $this->input->post('pass3');
    $wreporttime3 = $this->input->post('reporttime3');
    $iparr   = explode('~', $wempid3);
    $weid3 = $iparr[0];
    if ( $this->input->post('basicsal3') > 0 )
   {
     $wbsal3 =  $this->input->post('basicsal3') / 30;
     $xbsal    =  $this->input->post('basicsal3') / 30;
   }
   else
   {
     $wbsal3 = 0;
     $xbsal = 0;
   }
    $woutdate3_1 =  $this->input->post('outdate3_1');
    $woutdate3_2 =  $this->input->post('outdate3_2');

    $wacthh3  =  $this->input->post('acthh3');
    $wactmm3  =  $this->input->post('actmm3');
    $wouthh3  =  $this->input->post('outhh3');
    $woutmm3  =  $this->input->post('outmm3');

   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine3 = $this->input->post('latecoming3');
    if ($latefine3 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid3 == 'O' and $wpresentid3== 'PO'  )
    {      
           $date1 = new DateTime($woutdate3_2 );
           $date2  = new DateTime($woutdate3_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
            $wnightallowance = $daysdiff * $nightrs;
            $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal3 = $wbsal3 * 2;
            }
            else
            {
               $wbsal3 = $wbsal3 * 1;
             }


         if (  (int) $wacthh3 > 0 )
         {
          if ((int)$wacthh3 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }

      if ($wdutyid3 == 'L'  )
      {
       if (  ( (int)$wouthh3 >= 24 ) or ( (int)$wouthh3 >= 23 and (int)$woutmm3 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid3 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }


    if ($wdutyid3 == 'L' and ( $wpresentid3== 'PR'  or $wpresentid3 == 'PP' )  )
    { 
       $ottime = $this->input->post('ottime3');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh3 >= 24 ) or ( (int)$wouthh3 >= 23 and (int)$woutmm3 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid3 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
 
   }
  if ( $wpresentid3== 'DD'  or $wpresentid3 == 'DH')
  {
   if ($wpresentid3 == 'DD' )
  {
         $doubleshift=100;
   }
   if ($wpresentid3 == 'DH')
   {
       $doubleshift = 200;
   }
   $wbsal3 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime3');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh3 >= 24 ) or ( (int)$wouthh3 >= 23 and (int)$woutmm3 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid3 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */

  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid3== 'HD'  or $wpresentid3== 'WD' )
  {
     if ( $this->input->post('basicsal3') > 0 )
    {
       $wbsal3 =  ($this->input->post('basicsal3') / 30)*2;
    }
    else
    {
      $wbsal3 = 0;
    }
    $ottime = $this->input->post('ottime3');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid3 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
   }

if ($dayofdate == 31)
{
$wbsal3 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal3 = $wbsal3 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal3 = $wbsal3 + ($xbsal*2);
   }
}
}


    $data = array(
        'date' => $wregdate,     /*   $this->input->post('regdate'),    */ 
        'empid' =>  $weid3, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid3'),
        'duty'  =>  $this->input->post('dutyid3'),
        'outstationdatefrom'  =>  $this->input->post('outdate3_1'),
        'outstationdateto' => $this->input->post('outdate3_2'),
        'shift'  => $this->input->post('shiftid3'),
        'customername'   =>  $this->input->post('custid3'),
       'customerid'   =>  $this->input->post('custid3'),
       'passengername'  => $this->input->post('pass3'),
       'reportingtime'   => $this->input->post('reporttime3'),
       'intime'   =>  $this->input->post('intime3'), 
       'actualintime'   => $this->input->post('acttime3'),
       'outtime'    => $this->input->post('outtime3'),
       'actualouttime'   => $this->input->post('actouttime3'),
       'worktime'    => $this->input->post('workduration3'),
       'ottime'    =>  $this->input->post('ottime3'),
       'totalduration'    => $this->input->post('tottime3'),
       'remarks'    => $this->input->post('remarks3'),
      'basicsalary'    =>  $wbsal3 ,  /* $this->input->post('basicsal3')/30 */
      'latecoming' => $this->input->post('latecoming3'),
      'daysalary' => ($wbsal3 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
     'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );
  if ($wempid3 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid3 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result3 = $this->login_database->drr_registration_insert($data);
  // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result3 )
   {
          $datainsert = $datainsert + 1;
    }


           $date1 = new DateTime($woutdate3_2 );
           $date2  = new DateTime($woutdate3_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate3_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate3_1 = $date2;

                       if ( $this->input->post('basicsal3') > 0 )
                       {
                                $wbsal3 =  $this->input->post('basicsal3') / 30;
                       }
                      else
                      {
                         $wbsal3 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek3 = date('l', strtotime($wdate2));
                       $dayofdate_3= date('d',  strtotime($wdate2));

                      $monthofdate_3 = date ('F', strtotime ($wdate2));
                      $yearofdate_3 = date ('Y', strtotime ($wdate2));



                       if ($dayofweek3 == 'Sunday')
                       {
                            $wbsal3 = $wbsal3 * 2;
                       }
                       else
                       {
                            $wbsal3 = $wbsal3 * 1;
                      }
                      if ($dayofdate_3 == 31)
                      {
                           $wbsal3 = 0;
                      }

                   if   ((0 == $yearofdate_3 % 4) & (0 != $yearofdate_3 % 100) | (0 ==$yearofdate_3 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_3 == 'February')
                   {
                      if  ($dayofdate_3 == 29)
                      {
                           $wbsal3 = $wbsal3 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_3 == 'February')
                {
                     if  ($dayofdate_3 == 28)
                     {
                        $wbsal3 = $wbsal3 + ($xbsal*2);
                     }
                }
                }


                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid3, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid3'),
                                 'duty'  =>  $this->input->post('dutyid3'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate3_1'),
                                 'outstationdateto' => $this->input->post('outdate3_2'),
                                 'shift'  => $this->input->post('shiftid3'),
                                 'customername'   =>  $this->input->post('custid3'),
                                 'customerid'   =>  $this->input->post('custid3'),
                                 'passengername'  => $this->input->post('pass3'),
                                'reportingtime'   => $this->input->post('reporttime3'),
                                'intime'   =>  $this->input->post('intime3'), 
                                'actualintime'   => $this->input->post('acttime3'),
                                'outtime'    => $this->input->post('outtime3'),
                                'actualouttime'   => $this->input->post('actouttime3'),
                                'worktime'    => $this->input->post('workduration3'),
                               'ottime'    =>  $this->input->post('ottime3'),
                               'totalduration'    => $this->input->post('tottime3'),
                              'remarks'    => $this->input->post('remarks3'),
                             'basicsalary'    => $wbsal3, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming3'),
                             'daysalary' => $wbsal3, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                            'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid3 == 'O' and $wpresentid3== 'PO'  )
                   {
                          $result3 = $this->login_database->drr_registration_insert($data);  
                   }
           }

     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */
    }
  }

// line 3 end

// line 4 start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate4');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

     $wshiftid4 =  $this->input->post('shiftid4');

    $wempid4 = $this->input->post('empid4');
    $wpresentid4 = $this->input->post('presentid4');
    $wdutyid4 =  $this->input->post('dutyid4');
    $wcustid4 = $this->input->post('custid4');
    $wpass4 = $this->input->post('pass4');
    $wreporttime4 = $this->input->post('reporttime4');
    $iparr   = explode('~', $wempid4);
    $weid4 = $iparr[0];
    if ( $this->input->post('basicsal4') > 0 )
   {
     $wbsal4 =  $this->input->post('basicsal4') / 30;
     $xbsal   =  $this->input->post('basicsal4') / 30;

   }
   else
   {
     $wbsal4 = 0;
     $xbsal    = 0;
   }
    $woutdate4_1 =  $this->input->post('outdate4_1');
    $woutdate4_2 =  $this->input->post('outdate4_2');

    $wacthh4  =  $this->input->post('acthh4');
    $wactmm4  =  $this->input->post('actmm4');
    $wouthh4  =  $this->input->post('outhh4');
    $woutmm4  =  $this->input->post('outmm4');


   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine4 = $this->input->post('latecoming4');
    if ($latefine4 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid4 == 'O' and $wpresentid4== 'PO'  )
    {      
           $date1 = new DateTime($woutdate4_2 );
           $date2  = new DateTime($woutdate4_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal4 = $wbsal4 * 2;
            }
            else
            {
               $wbsal4 = $wbsal4 * 1;
             }


         if (  (int) $wacthh4 > 0 )
         {
          if ((int)$wacthh4 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }
      if ($wdutyid4 == 'L'  )
      {
       if (  ( (int)$wouthh4 >= 24 ) or ( (int)$wouthh4 >= 23 and (int)$woutmm4 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid4 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }


    if ($wdutyid4 == 'L' and ( $wpresentid4== 'PR'  or $wpresentid4 == 'PP' )  )
    { 
       $ottime = $this->input->post('ottime4');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh4 >= 24 ) or ( (int)$wouthh4 >= 23 and (int)$woutmm4 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid4 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
 

   }
  if ( $wpresentid4== 'DD'  or $wpresentid4 == 'DH' )
  {
   if ($wpresentid4 == 'DD' )
   {
        $doubleshift=100;
   }
   if ($wpresentid4 == 'DH')
   {
      $doubleshift = 200;
   }
   $wbsal4 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime4');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh4 >= 24 ) or ( (int)$wouthh4 >= 23 and (int)$woutmm4 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid4 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid4== 'HD'  or $wpresentid4== 'WD' )
  {
     if ( $this->input->post('basicsal4') > 0 )
    {
       $wbsal4 =  ($this->input->post('basicsal4') / 30)*2;
    }
    else
    {
      $wbsal4 = 0;
    }
    $ottime = $this->input->post('ottime4');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid4 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
   }
if ($dayofdate == 31)
{
$wbsal4 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal4 = $wbsal4 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal4 = $wbsal4 + ($xbsal*2);
   }
}
}



    $data = array(
        'date' => $wregdate,     /*     $this->input->post('regdate'),    */
        'empid' =>  $weid4, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid4'),
        'duty'  =>  $this->input->post('dutyid4'),
        'outstationdatefrom'  =>  $this->input->post('outdate4_1'),
        'outstationdateto' => $this->input->post('outdate4_2'),
        'shift'  => $this->input->post('shiftid4'),
        'customername'   =>  $this->input->post('custid4'),
       'customerid'   =>  $this->input->post('custid4'),
       'passengername'  => $this->input->post('pass4'),
       'reportingtime'   => $this->input->post('reporttime4'),
       'intime'   =>  $this->input->post('intime4'), 
       'actualintime'   => $this->input->post('acttime4'),
       'outtime'    => $this->input->post('outtime4'),
       'actualouttime'   => $this->input->post('actouttime4'),
       'worktime'    => $this->input->post('workduration4'),
       'ottime'    =>  $this->input->post('ottime4'),
       'totalduration'    => $this->input->post('tottime4'),
       'remarks'    => $this->input->post('remarks4'),
      'basicsalary'    => $wbsal4, /*  $this->input->post('basicsal4')/30 */
      'latecoming' => $this->input->post('latecoming4'),
      'daysalary' => ($wbsal4 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid4 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid4 == '0' )
    {
           $correctentry='False';
    }
    else
    {

  $result4 = $this->login_database->drr_registration_insert($data);
 // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result4 )
   {
          $datainsert = $datainsert + 1;
    }


           $date1 = new DateTime($woutdate4_2 );
           $date2  = new DateTime($woutdate4_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate4_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate4_1 = $date2;

                       if ( $this->input->post('basicsal4') > 0 )
                       {
                                $wbsal4 =  $this->input->post('basicsal4') / 30;
                       }
                      else
                      {
                         $wbsal4 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek4 = date('l', strtotime($wdate2));
                       $dayofdate_4= date('d',  strtotime($wdate2));

                      $monthofdate_4 = date ('F', strtotime ($wdate2));
                      $yearofdate_4 = date ('Y', strtotime ($wdate2));



                       if ($dayofweek4 == 'Sunday')
                       {
                            $wbsal4 = $wbsal4 * 2;
                       }
                       else
                       {
                            $wbsal4 = $wbsal4 * 1;
                      }
                      if ($dayofdate_4 == 31)
                      {
                           $wbsal4 = 0;
                      }


                   if   ((0 == $yearofdate_4 % 4) & (0 != $yearofdate_4 % 100) | (0 ==$yearofdate_4 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_4 == 'February')
                   {
                      if  ($dayofdate_4 == 29)
                      {
                           $wbsal4 = $wbsal4 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_4 == 'February')
                {
                     if  ($dayofdate_4 == 28)
                     {
                        $wbsal4 = $wbsal4 + ($xbsal*2);
                     }
                }
                }




                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid4, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid4'),
                                 'duty'  =>  $this->input->post('dutyid4'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate4_1'),
                                 'outstationdateto' => $this->input->post('outdate4_2'),
                                 'shift'  => $this->input->post('shiftid4'),
                                 'customername'   =>  $this->input->post('custid4'),
                                 'customerid'   =>  $this->input->post('custid4'),
                                 'passengername'  => $this->input->post('pass4'),
                                'reportingtime'   => $this->input->post('reporttime4'),
                                'intime'   =>  $this->input->post('intime4'), 
                                'actualintime'   => $this->input->post('acttime4'),
                                'outtime'    => $this->input->post('outtime4'),
                                'actualouttime'   => $this->input->post('actouttime4'),
                                'worktime'    => $this->input->post('workduration4'),
                               'ottime'    =>  $this->input->post('ottime4'),
                               'totalduration'    => $this->input->post('tottime4'),
                              'remarks'    => $this->input->post('remarks4'),
                             'basicsalary'    => $wbsal4, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming4'),
                             'daysalary' => $wbsal4, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid4 == 'O' and $wpresentid4 == 'PO'  )
                   {
                         $result4 = $this->login_database->drr_registration_insert($data);  
                    }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */
    }
  }

// line 4 end

// line 5 start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate5');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



   $latenight_23hrs = 0; /*    75;  */
   $earlymorning_6am = 0;  /*   50;   */

    $wshiftid5 =  $this->input->post('shiftid5');

    $wempid5 = $this->input->post('empid5');
    $wpresentid5 = $this->input->post('presentid5');
    $wdutyid5 =  $this->input->post('dutyid5');
    $wcustid5 = $this->input->post('custid5');
    $wpass5 = $this->input->post('pass5');
    $wreporttime5 = $this->input->post('reporttime5');
    $iparr   = explode('~', $wempid5);
    $weid5 = $iparr[0];
    if ( $this->input->post('basicsal5') > 0 )
   {
     $wbsal5 =  $this->input->post('basicsal5') / 30;
     $xbsal   =   $this->input->post('basicsal5') / 30;

   }
   else
   {
     $wbsal5 = 0;
     $xbsal   = 0;
   }
    $woutdate5_1 =  $this->input->post('outdate5_1');
    $woutdate5_2 =  $this->input->post('outdate5_2');

    $wacthh5  =  $this->input->post('acthh5');
    $wactmm5  =  $this->input->post('actmm5');
    $wouthh5  =  $this->input->post('outhh5');
    $woutmm5  =  $this->input->post('outmm5');


   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine5 = $this->input->post('latecoming5');
    if ($latefine5 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid5 == 'O' and $wpresentid5== 'PO'  )
    {      
           $date1 = new DateTime($woutdate5_2 );
           $date2  = new DateTime($woutdate5_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal5 = $wbsal5 * 2;
            }
            else
            {
               $wbsal5 = $wbsal5 * 1;
             }


         if (  (int) $wacthh5 > 0 )
         {
          if ((int)$wacthh5 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }

      if ($wdutyid5 == 'L'  )
      {
       if (  ( (int)$wouthh5 >= 24 ) or ( (int)$wouthh5 >= 23 and (int)$woutmm5 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid5 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }


    if ($wdutyid5 == 'L' and ( $wpresentid5== 'PR'   or $wpresentid5 == 'PP' ) )
    { 
       $ottime = $this->input->post('ottime5');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh5 >= 24 ) or ( (int)$wouthh5 >= 23 and (int)$woutmm5 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid5 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
 
   }
  if ( $wpresentid5== 'DD' or $wpresentid5 == 'DH' )
  {
   if ($wpresentid5 == 'DD')
   {
         $doubleshift=100;
   }
   if ($wpresentid5 == 'DH')
   {
       $doubleshift = 200;
   }
   $wbsal5 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime5');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh5 >= 24 ) or ( (int)$wouthh5 >= 23 and (int)$woutmm5 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid5 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid5== 'HD'  or $wpresentid5== 'WD' )
  {
     if ( $this->input->post('basicsal5') > 0 )
    {
       $wbsal5 =  ($this->input->post('basicsal5') / 30)*2;
    }
    else
    {
      $wbsal5 = 0;
    }
    $ottime = $this->input->post('ottime5');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid5 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
    }    
if ($dayofdate == 31)
{
$wbsal5 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal5 = $wbsal5 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal5 = $wbsal5 + ($xbsal*2);
   }
}
}

    $data = array(
        'date' =>  $wregdate,     /*    $this->input->post('regdate'),    */
        'empid' =>  $weid5, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid5'),
        'duty'  =>  $this->input->post('dutyid5'),
        'outstationdatefrom'  =>  $this->input->post('outdate5_1'),
        'outstationdateto' => $this->input->post('outdate5_2'),
        'shift'  => $this->input->post('shiftid5'),
        'customername'   =>  $this->input->post('custid5'),
       'customerid'   =>  $this->input->post('custid5'),
       'passengername'  => $this->input->post('pass5'),
       'reportingtime'   => $this->input->post('reporttime5'),
       'intime'   =>  $this->input->post('intime5'), 
       'actualintime'   => $this->input->post('acttime5'),
       'outtime'    => $this->input->post('outtime5'),
       'actualouttime'   => $this->input->post('actouttime5'),
       'worktime'    => $this->input->post('workduration5'),
       'ottime'    =>  $this->input->post('ottime5'),
       'totalduration'    => $this->input->post('tottime5'),
       'remarks'    => $this->input->post('remarks5'),
      'basicsalary'    => $wbsal5, /*  $this->input->post('basicsal5')/30 */
      'latecoming' => $this->input->post('latecoming5'),
      'daysalary' => ($wbsal5 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid5 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid5 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result5 = $this->login_database->drr_registration_insert($data);
 //  $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result5 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate5_2 );
           $date2  = new DateTime($woutdate5_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate5_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate5_1 = $date2;

                       if ( $this->input->post('basicsal5') > 0 )
                       {
                                $wbsal5 =  $this->input->post('basicsal5') / 30;
                       }
                      else
                      {
                         $wbsal5 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek5 = date('l', strtotime($wdate2));
                       $dayofdate_5= date('d',  strtotime($wdate2));

                      $monthofdate_5 = date ('F', strtotime ($wdate2));
                      $yearofdate_5 = date ('Y', strtotime ($wdate2));


                     if ($dayofweek5 == 'Sunday')
                       {
                            $wbsal5 = $wbsal5 * 2;
                       }
                       else
                       {
                            $wbsal5 = $wbsal5 * 1;
                      }
                      if ($dayofdate_5 == 31)
                      {
                           $wbsal5 = 0;
                      }


                   if   ((0 == $yearofdate_5 % 4) & (0 != $yearofdate_5 % 100) | (0 ==$yearofdate_5 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_5 == 'February')
                   {
                      if  ($dayofdate_5 == 29)
                      {
                           $wbsal5 = $wbsal5 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_5 == 'February')
                {
                     if  ($dayofdate_5 == 28)
                     {
                        $wbsal5 = $wbsal5 + ($xbsal*2);
                     }
                }
                }





                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid5, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid5'),
                                 'duty'  =>  $this->input->post('dutyid5'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate5_1'),
                                 'outstationdateto' => $this->input->post('outdate5_2'),
                                 'shift'  => $this->input->post('shiftid5'),
                                 'customername'   =>  $this->input->post('custid5'),
                                 'customerid'   =>  $this->input->post('custid5'),
                                 'passengername'  => $this->input->post('pass5'),
                                'reportingtime'   => $this->input->post('reporttime5'),
                                'intime'   =>  $this->input->post('intime5'), 
                                'actualintime'   => $this->input->post('acttime5'),
                                'outtime'    => $this->input->post('outtime5'),
                                'actualouttime'   => $this->input->post('actouttime5'),
                                'worktime'    => $this->input->post('workduration5'),
                               'ottime'    =>  $this->input->post('ottime5'),
                               'totalduration'    => $this->input->post('tottime5'),
                              'remarks'    => $this->input->post('remarks5'),
                             'basicsalary'    => $wbsal5, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming5'),
                             'daysalary' => $wbsal5, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid5 == 'O' and $wpresentid5 == 'PO'  )
                   {
                        $result5 = $this->login_database->drr_registration_insert($data);  
                  }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

    }
  }

// line 5 end

// line 6 start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate6');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



   $latenight_23hrs = 0; /*    75;  */
   $earlymorning_6am = 0;  /*   50;   */

    $wshiftid6  =  $this->input->post('shiftid6');

    $wempid6 = $this->input->post('empid6');
    $wpresentid6 = $this->input->post('presentid6');
    $wdutyid6 =  $this->input->post('dutyid6');
    $wcustid6 = $this->input->post('custid6');
    $wpass6 = $this->input->post('pass6');
    $wreporttime6 = $this->input->post('reporttime6');
    $iparr   = explode('~', $wempid6);
    $weid6 = $iparr[0];
    if ( $this->input->post('basicsal6') > 0 )
   {
     $wbsal6 =  $this->input->post('basicsal6') / 30;

       $xbsal = $this->input->post('basicsal6') / 30;
   }
   else
   {
     $wbsal6 = 0;
     $xsbal = 0;
   }
    $woutdate6_1 =  $this->input->post('outdate6_1');
    $woutdate6_2 =  $this->input->post('outdate6_2');

    $wacthh6  =  $this->input->post('acthh6');
    $wactmm6 =  $this->input->post('actmm6');
    $wouthh6  =  $this->input->post('outhh6');
    $woutmm6  =  $this->input->post('outmm6');

   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine6 = $this->input->post('latecoming6');
    if ($latefine6 > 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid6 == 'O' and $wpresentid6== 'PO'  )
    {      
           $date1 = new DateTime($woutdate6_2 );
           $date2  = new DateTime($woutdate6_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal6 = $wbsal6 * 2;
            }
            else
            {
               $wbsal6 = $wbsal6 * 1;
             }


         if (  (int) $wacthh6 > 0 )
         {
          if ((int)$wacthh6 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }

      }

     if ($wdutyid6 == 'L'  )
      {
       if (  ( (int)$wouthh6 >= 24 ) or ( (int)$wouthh6 >= 23 and (int)$woutmm6 >= 0 )   )
       {
//                 $latenight_23hrs = 75;
                 if ($wshiftid6 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }

    if ($wdutyid6 == 'L' and  ( $wpresentid6== 'PR'   or $wpresentid6 == 'PP' ) )
    { 
       $ottime = $this->input->post('ottime6');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh6 >= 24 ) or ( (int)$wouthh6 >= 23 and (int)$woutmm6 >= 0 )   )
       {
 //                $latenight_23hrs = 75;
                 if ($wshiftid6 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
  
   }
  if ( $wpresentid6== 'DD' or $wpresentid6 == 'DH' )
  {
   if ($wpresentid6 == 'DD')
   {
        $doubleshift=100;
   }
   if ($wpresentid6 == 'DH')
   {
        $doubleshift=200;
   }
   $wbsal6 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime6');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh6 >= 24 ) or ( (int)$wouthh6 >= 23 and (int)$woutmm6 >= 0 )   )
       {
 //                $latenight_23hrs = 75;
                 if ($wshiftid6 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid6== 'HD'  or $wpresentid6== 'WD' )
  {
     if ( $this->input->post('basicsal6') > 0 )
    {
       $wbsal6 =  ($this->input->post('basicsal6') / 30)*2;
    }
    else
    {
      $wbsal6 = 0;
    }
    $ottime = $this->input->post('ottime6');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid6 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
   }    
if ($dayofdate == 31)
{
$wbsal6 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal6 = $wbsal6 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal6 = $wbsal6 + ($xbsal*2);
   }
}
}

    $data = array(
        'date' =>  $wregdate,     /*     $this->input->post('regdate'),    */
        'empid' =>  $weid6, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid6'),
        'duty'  =>  $this->input->post('dutyid6'),
        'outstationdatefrom'  =>  $this->input->post('outdate6_1'),
        'outstationdateto' => $this->input->post('outdate6_2'),
        'shift'  => $this->input->post('shiftid6'),
        'customername'   =>  $this->input->post('custid6'),
       'customerid'   =>  $this->input->post('custid6'),
       'passengername'  => $this->input->post('pass6'),
       'reportingtime'   => $this->input->post('reporttime6'),
       'intime'   =>  $this->input->post('intime6'), 
       'actualintime'   => $this->input->post('acttime6'),
       'outtime'    => $this->input->post('outtime6'),
       'actualouttime'   => $this->input->post('actouttime6'),
       'worktime'    => $this->input->post('workduration6'),
       'ottime'    =>  $this->input->post('ottime6'),
       'totalduration'    => $this->input->post('tottime6'),
       'remarks'    => $this->input->post('remarks6'),
      'basicsalary'    =>   $wbsal6, /*  $this->input->post('basicsal6')/30 */
      'latecoming' => $this->input->post('latecoming6'),
      'daysalary' => ($wbsal6 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid6 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid6 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result6 = $this->login_database->drr_registration_insert($data);
  // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result6 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate6_2 );
           $date2  = new DateTime($woutdate6_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate6_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate6_1 = $date2;

                       if ( $this->input->post('basicsal6') > 0 )
                       {
                                $wbsal6 =  $this->input->post('basicsal6') / 30;
                       }
                      else
                      {
                         $wbsal6 = 0;
                      }

                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek6 = date('l', strtotime($wdate2));
                       $dayofdate_6= date('d',  strtotime($wdate2));

                       $monthofdate_6 = date ('F', strtotime ($wdate2));
                       $yearofdate_6 = date ('Y', strtotime ($wdate2));



                       if ($dayofweek6 == 'Sunday')
                       {
                            $wbsal6 = $wbsal6 * 2;
                       }
                       else
                       {
                            $wbsal6 = $wbsal6 * 1;
                      }
                      if ($dayofdate_6 == 31)
                      {
                           $wbsal6 = 0;
                      }


                   if   ((0 == $yearofdate_6 % 4) & (0 != $yearofdate_6 % 100) | (0 ==$yearofdate_6 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_6 == 'February')
                   {
                      if  ($dayofdate_6 == 29)
                      {
                           $wbsal6 = $wbsal6 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_6 == 'February')
                {
                     if  ($dayofdate_6 == 28)
                     {
                        $wbsal6 = $wbsal6 + ($xbsal*2);
                     }
                }
                }



                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid6, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid6'),
                                 'duty'  =>  $this->input->post('dutyid6'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate6_1'),
                                 'outstationdateto' => $this->input->post('outdate6_2'),
                                 'shift'  => $this->input->post('shiftid6'),
                                 'customername'   =>  $this->input->post('custid6'),
                                 'customerid'   =>  $this->input->post('custid6'),
                                 'passengername'  => $this->input->post('pass6'),
                                'reportingtime'   => $this->input->post('reporttime6'),
                                'intime'   =>  $this->input->post('intime6'), 
                                'actualintime'   => $this->input->post('acttime6'),
                                'outtime'    => $this->input->post('outtime6'),
                                'actualouttime'   => $this->input->post('actouttime6'),
                                'worktime'    => $this->input->post('workduration6'),
                               'ottime'    =>  $this->input->post('ottime6'),
                               'totalduration'    => $this->input->post('tottime6'),
                              'remarks'    => $this->input->post('remarks6'),
                             'basicsalary'    => $wbsal6, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming6'),
                             'daysalary' => $wbsal6, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid6 == 'O' and $wpresentid6== 'PO'  )
                   {
                         $result6 = $this->login_database->drr_registration_insert($data);  
                   }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

    }
  }

// line 6 end

// line 7 start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate7');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

    $wshiftid7 =  $this->input->post('shiftid7');

    $wempid7 = $this->input->post('empid7');
    $wpresentid7 = $this->input->post('presentid7');
    $wdutyid7 =  $this->input->post('dutyid7');
    $wcustid7= $this->input->post('custid7');
    $wpass7 = $this->input->post('pass7');
    $wreporttime7 = $this->input->post('reporttime7');
    $iparr   = explode('~', $wempid7);
    $weid7 = $iparr[0];
    if ( $this->input->post('basicsal7') > 0 )
   {
     $wbsal7 =  $this->input->post('basicsal7') / 30;
       $xbsal = $this->input->post('basicsal7') / 30;
   }
   else
   {
     $wbsal7 = 0;
     $xsbal = 0;
   }
    $woutdate7_1 =  $this->input->post('outdate7_1');
    $woutdate7_2 =  $this->input->post('outdate7_2');

    $wacthh7  =  $this->input->post('acthh7');
    $wactmm7  =  $this->input->post('actmm7');
    $wouthh7  =  $this->input->post('outhh7');
    $woutmm7  =  $this->input->post('outmm7');


   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine7 = $this->input->post('latecoming7');
    if ($latefine7> 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid7 == 'O' and $wpresentid7== 'PO'  )
    {      
           $date1 = new DateTime($woutdate7_2 );
           $date2  = new DateTime($woutdate7_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal7 = $wbsal7 * 2;
            }
            else
            {
               $wbsal7 = $wbsal7 * 1;
             }


         if (  (int) $wacthh7 > 0 )
         {
          if ((int)$wacthh7 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }

      }

     if ($wdutyid7 == 'L'  )
      {
       if (  ( (int)$wouthh7 >= 24 ) or ( (int)$wouthh7 >= 23 and (int)$woutmm7 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid7 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }
    if ($wdutyid7 == 'L' and ( $wpresentid7== 'PR'  or $wpresentid7 == 'PP' )  )
    { 
       $ottime = $this->input->post('ottime7');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

       if (  ( (int)$wouthh7 >= 24 ) or ( (int)$wouthh7 >= 23 and (int)$woutmm7 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid7 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
  
   }
  if ( $wpresentid7== 'DD'  or $wpresentid7 == 'DH')
  {
   if (  $wpresentid7 == 'DD')
   {
        $doubleshift=100;
   }
   if ( $wpresentid7 == 'DH' )
   {
      $doubleshift = 200;
  }
   $wbsal7 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime7');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh7 >= 24 ) or ( (int)$wouthh7 >= 23 and (int)$woutmm7 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid7 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid7== 'HD'  or $wpresentid7== 'WD' )
  {
     if ( $this->input->post('basicsal7') > 0 )
    {
       $wbsal7 =  ($this->input->post('basicsal7') / 30)*2;
    }
    else
    {
      $wbsal7 = 0;
    }
    $ottime = $this->input->post('ottime7');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid7 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
    }  
if ($dayofdate == 31)
{
$wbsal7 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal7 = $wbsal7 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal7 = $wbsal7 + ($xbsal*2);
   }
}
}


    $data = array(
        'date' =>  $wregdate,     /*     $this->input->post('regdate'),    */
        'empid' =>  $weid7, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid7'),
        'duty'  =>  $this->input->post('dutyid7'),
        'outstationdatefrom'  =>  $this->input->post('outdate7_1'),
        'outstationdateto' => $this->input->post('outdate7_2'),
        'shift'  => $this->input->post('shiftid7'),
        'customername'   =>  $this->input->post('custid7'),
       'customerid'   =>  $this->input->post('custid7'),
       'passengername'  => $this->input->post('pass7'),
       'reportingtime'   => $this->input->post('reporttime7'),
       'intime'   =>  $this->input->post('intime7'), 
       'actualintime'   => $this->input->post('acttime7'),
       'outtime'    => $this->input->post('outtime7'),
       'actualouttime'   => $this->input->post('actouttime7'),
       'worktime'    => $this->input->post('workduration7'),
       'ottime'    =>  $this->input->post('ottime7'),
       'totalduration'    => $this->input->post('tottime7'),
       'remarks'    => $this->input->post('remarks7'),
      'basicsalary'    =>   $wbsal7, /*  $this->input->post('basicsal6')/30 */
      'latecoming' => $this->input->post('latecoming7'),
      'daysalary' => ($wbsal7 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid7 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid7 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result7 = $this->login_database->drr_registration_insert($data);
  // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result7 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate7_2 );
           $date2  = new DateTime($woutdate7_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate7_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate7_1 = $date2;

                       if ( $this->input->post('basicsal7') > 0 )
                       {
                                $wbsal7 =  $this->input->post('basicsal7') / 30;
                       }
                      else
                      {
                         $wbsal7 = 0;
                      }

                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofdate_7= date('d',  strtotime($wdate2));
                       $dayofweek7 = date('l', strtotime($wdate2));

                      $monthofdate_7 = date ('F', strtotime ($wdate2));
                      $yearofdate_7 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek7 == 'Sunday')
                       {
                            $wbsal7 = $wbsal7 * 2;
                       }
                       else
                       {
                            $wbsal7 = $wbsal7 * 1;
                      }
                      if ($dayofdate_7 == 31)
                      {
                           $wbsal7 = 0;
                      }


                   if   ((0 == $yearofdate_7 % 4) & (0 != $yearofdate_7 % 100) | (0 ==$yearofdate_7 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_7 == 'February')
                   {
                      if  ($dayofdate_7 == 29)
                      {
                           $wbsal7 = $wbsal7 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_7 == 'February')
                {
                     if  ($dayofdate_7 == 28)
                     {
                        $wbsal7 = $wbsal7 + ($xbsal*2);
                     }
                }
                }



                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid7, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid7'),
                                 'duty'  =>  $this->input->post('dutyid7'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate7_1'),
                                 'outstationdateto' => $this->input->post('outdate7_2'),
                                 'shift'  => $this->input->post('shiftid7'),
                                 'customername'   =>  $this->input->post('custid7'),
                                 'customerid'   =>  $this->input->post('custid7'),
                                 'passengername'  => $this->input->post('pass7'),
                                'reportingtime'   => $this->input->post('reporttime7'),
                                'intime'   =>  $this->input->post('intime7'), 
                                'actualintime'   => $this->input->post('acttime7'),
                                'outtime'    => $this->input->post('outtime7'),
                                'actualouttime'   => $this->input->post('actouttime7'),
                                'worktime'    => $this->input->post('workduration7'),
                               'ottime'    =>  $this->input->post('ottime7'),
                               'totalduration'    => $this->input->post('tottime7'),
                              'remarks'    => $this->input->post('remarks7'),
                             'basicsalary'    => $wbsal7, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming7'),
                             'daysalary' => $wbsal7, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid7 == 'O' and $wpresentid7== 'PO'  )
                   {
                         $result7 = $this->login_database->drr_registration_insert($data);  
                   }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

    }
  }

// line 7 end


// line 8 start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate8');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

     $wshiftid8 =  $this->input->post('shiftid8');

    $wempid8 = $this->input->post('empid8');
    $wpresentid8 = $this->input->post('presentid8');
    $wdutyid8 =  $this->input->post('dutyid8');
    $wcustid8= $this->input->post('custid8');
    $wpass8 = $this->input->post('pass8');
    $wreporttime8 = $this->input->post('reporttime8');
    $iparr   = explode('~', $wempid8);
    $weid8 = $iparr[0];
    if ( $this->input->post('basicsal8') > 0 )
   {
     $wbsal8 =  $this->input->post('basicsal8') / 30;
     $xbsal = $this->input->post('basicsal8') / 30;

   }
   else
   {
     $wbsal8 = 0;
     $xbsal = 0;
   }
    $woutdate8_1 =  $this->input->post('outdate8_1');
    $woutdate8_2 =  $this->input->post('outdate8_2');

    $wacthh8  =  $this->input->post('acthh8');
    $wactmm8  =  $this->input->post('actmm8');
    $wouthh8  =  $this->input->post('outhh8');
    $woutmm8  =  $this->input->post('outmm8');


   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine8 = $this->input->post('latecoming8');
    if ($latefine8> 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid8 == 'O' and $wpresentid8== 'PO'  )
    {      
           $date1 = new DateTime($woutdate8_2 );
           $date2  = new DateTime($woutdate8_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal8 = $wbsal8 * 2;
            }
            else
            {
               $wbsal8 = $wbsal8 * 1;
             }


         if (  (int) $wacthh8 > 0 )
         {
          if ((int)$wacthh8 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }

     if ($wdutyid8 == 'L'  )
      {
       if (  ( (int)$wouthh8 >= 24 ) or ( (int)$wouthh8 >= 23 and (int)$woutmm8 >= 0 )   )
       {
 //                $latenight_23hrs = 75;
                 if ($wshiftid8 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }
    if ($wdutyid8 == 'L' and ( $wpresentid8== 'PR'   or $wpresentid8 == 'PP' ) )
    { 
       $ottime = $this->input->post('ottime8');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh8 >= 24 ) or ( (int)$wouthh8 >= 23 and (int)$woutmm8 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid8 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
  

   }
  if ( $wpresentid8== 'DD'  or $wpresentid8 == 'DH')
  {
   if (  $wpresentid8 == 'DD' )
   {
        $doubleshift=100;
   }
   if (  $wpresentid8 == 'DH')
   {
      $doubleshift = 200;
   }
   $wbsal8 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime8');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh8 >= 24 ) or ( (int)$wouthh8 >= 23 and (int)$woutmm8 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid8 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid8== 'HD'  or $wpresentid8== 'WD' )
  {
     if ( $this->input->post('basicsal8') > 0 )
    {
       $wbsal8 =  ($this->input->post('basicsal8') / 30)*2;
    }
    else
    {
      $wbsal8 = 0;
    }
    $ottime = $this->input->post('ottime8');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid8 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
    }
if ($dayofdate == 31)
{
$wbsal8 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal8 = $wbsal8 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal8 = $wbsal8 + ($xbsal*2);
   }
}
}

  
    $data = array(
        'date' =>  $wregdate,     /*    $this->input->post('regdate'),    */
        'empid' =>  $weid8, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid8'),
        'duty'  =>  $this->input->post('dutyid8'),
        'outstationdatefrom'  =>  $this->input->post('outdate8_1'),
        'outstationdateto' => $this->input->post('outdate8_2'),
        'shift'  => $this->input->post('shiftid8'),
        'customername'   =>  $this->input->post('custid8'),
       'customerid'   =>  $this->input->post('custid8'),
       'passengername'  => $this->input->post('pass8'),
       'reportingtime'   => $this->input->post('reporttime8'),
       'intime'   =>  $this->input->post('intime8'), 
       'actualintime'   => $this->input->post('acttime8'),
       'outtime'    => $this->input->post('outtime8'),
       'actualouttime'   => $this->input->post('actouttime8'),
       'worktime'    => $this->input->post('workduration8'),
       'ottime'    =>  $this->input->post('ottime8'),
       'totalduration'    => $this->input->post('tottime8'),
       'remarks'    => $this->input->post('remarks8'),
      'basicsalary'    =>   $wbsal8, /*  $this->input->post('basicsal6')/30 */
      'latecoming' => $this->input->post('latecoming8'),
      'daysalary' => ($wbsal8 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid8 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid8 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result8 = $this->login_database->drr_registration_insert($data);
  // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result8 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate8_2 );
           $date2  = new DateTime($woutdate8_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate8_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate8_1 = $date2;

                       if ( $this->input->post('basicsal8') > 0 )
                       {
                                $wbsal8 =  $this->input->post('basicsal8') / 30;
                       }
                      else
                      {
                         $wbsal8 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek8 = date('l', strtotime($wdate2));
                       $dayofdate_8 = date('d',  strtotime($wdate2));

                      $monthofdate_8 = date ('F', strtotime ($wdate2));
                      $yearofdate_8 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek8 == 'Sunday')
                       {
                            $wbsal8 = $wbsal8 * 2;
                       }
                       else
                       {
                            $wbsal8 = $wbsal8 * 1;
                      }
                      if ($dayofdate_8 == 31)
                      {
                           $wbsal8 = 0;
                      }

                   if   ((0 == $yearofdate_8 % 4) & (0 != $yearofdate_8 % 100) | (0 ==$yearofdate_8 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_8 == 'February')
                   {
                      if  ($dayofdate_8 == 29)
                      {
                           $wbsal8 = $wbsal8 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_8 == 'February')
                {
                     if  ($dayofdate_8 == 28)
                     {
                        $wbsal8 = $wbsal8 + ($xbsal*2);
                     }
                }
                }




                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid8, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid8'),
                                 'duty'  =>  $this->input->post('dutyid8'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate8_1'),
                                 'outstationdateto' => $this->input->post('outdate8_2'),
                                 'shift'  => $this->input->post('shiftid8'),
                                 'customername'   =>  $this->input->post('custid8'),
                                 'customerid'   =>  $this->input->post('custid8'),
                                 'passengername'  => $this->input->post('pass8'),
                                'reportingtime'   => $this->input->post('reporttime8'),
                                'intime'   =>  $this->input->post('intime8'), 
                                'actualintime'   => $this->input->post('acttime8'),
                                'outtime'    => $this->input->post('outtime8'),
                                'actualouttime'   => $this->input->post('actouttime8'),
                                'worktime'    => $this->input->post('workduration8'),
                               'ottime'    =>  $this->input->post('ottime8'),
                               'totalduration'    => $this->input->post('tottime8'),
                              'remarks'    => $this->input->post('remarks8'),
                             'basicsalary'    => $wbsal8, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming8'),
                             'daysalary' => $wbsal8, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid8 == 'O' and $wpresentid8 == 'PO'  )
                   {
                        $result8 = $this->login_database->drr_registration_insert($data);  
                   }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

    }
  }

// line 8 end

// line 9 start

    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate9');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));




    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

     $wshiftid9 =  $this->input->post('shiftid9');

    $wempid9 = $this->input->post('empid9');
    $wpresentid9 = $this->input->post('presentid9');
    $wdutyid9 =  $this->input->post('dutyid9');
    $wcustid9= $this->input->post('custid9');
    $wpass9 = $this->input->post('pass9');
    $wreporttime9 = $this->input->post('reporttime9');
    $iparr   = explode('~', $wempid9);
    $weid9 = $iparr[0];
    if ( $this->input->post('basicsal9') > 0 )
   {
     $wbsal9 =  $this->input->post('basicsal9') / 30;
     $xbsal = $this->input->post('basicsal9') / 30;

   }
   else
   {
     $wbsal9 = 0;
     $xbsal    = 0;
   }
    $woutdate9_1 =  $this->input->post('outdate9_1');
    $woutdate9_2 =  $this->input->post('outdate9_2');

    $wacthh9  =  $this->input->post('acthh9');
    $wactmm9  =  $this->input->post('actmm9');
    $wouthh9  =  $this->input->post('outhh9');
    $woutmm9  =  $this->input->post('outmm9');

   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine9 = $this->input->post('latecoming9');
    if ($latefine9> 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid9 == 'O' and $wpresentid9== 'PO'  )
    {      
           $date1 = new DateTime($woutdate9_2 );
           $date2  = new DateTime($woutdate9_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal9 = $wbsal9 * 2;
            }
            else
            {
               $wbsal9 = $wbsal9 * 1;
             }


         if (  (int) $wacthh9 > 0 )
         {
          if ((int)$wacthh9 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }

     if ($wdutyid9 == 'L'  )
      {
       if (  ( (int)$wouthh9 >= 24 ) or ( (int)$wouthh9 >= 23 and (int)$woutmm9 >= 0 )   )
       {
 //                $latenight_23hrs = 75;
                 if ($wshiftid9 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }
    if ($wdutyid9 == 'L' and ( $wpresentid9== 'PR'   or $wpresentid9 == 'PP' ) )
    { 
       $ottime = $this->input->post('ottime9');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh9 >= 24 ) or ( (int)$wouthh9 >= 23 and (int)$woutmm9 >= 0 )   )
       {
  //               $latenight_23hrs = 75;
                 if ($wshiftid9 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
  
   }
  if ( $wpresentid9== 'DD' or $wpresentid9 == 'DH' )
  {
   if ($wpresentid9 == 'DD')
   {
         $doubleshift=100;
   }
   if ($wpresentid9 == 'DH')
   {
       $doubleshift = 200;
   }
   $wbsal9 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime9');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh9 >= 24 ) or ( (int)$wouthh9 >= 23 and (int)$woutmm9 >= 0 )   )
       {
      //           $latenight_23hrs = 75;
                 if ($wshiftid9 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid9== 'HD'  or $wpresentid9== 'WD' )
  {
     if ( $this->input->post('basicsal9') > 0 )
    {
       $wbsal9 =  ($this->input->post('basicsal9') / 30)*2;
    }
    else
    {
      $wbsal9 = 0;
    }
    $ottime = $this->input->post('ottime9');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid9 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
    } 

if ($dayofdate == 31)
{
$wbsal9 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal9 = $wbsal9 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal9 = $wbsal9 + ($xbsal*2);
   }
}
}
 
    $data = array(
        'date' =>  $wregdate,     /*     $this->input->post('regdate'),    */
        'empid' =>  $weid9, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid9'),
        'duty'  =>  $this->input->post('dutyid9'),
        'outstationdatefrom'  =>  $this->input->post('outdate9_1'),
        'outstationdateto' => $this->input->post('outdate9_2'),
        'shift'  => $this->input->post('shiftid9'),
        'customername'   =>  $this->input->post('custid9'),
       'customerid'   =>  $this->input->post('custid9'),
       'passengername'  => $this->input->post('pass9'),
       'reportingtime'   => $this->input->post('reporttime9'),
       'intime'   =>  $this->input->post('intime9'), 
       'actualintime'   => $this->input->post('acttime9'),
       'outtime'    => $this->input->post('outtime9'),
       'actualouttime'   => $this->input->post('actouttime9'),
       'worktime'    => $this->input->post('workduration9'),
       'ottime'    =>  $this->input->post('ottime9'),
       'totalduration'    => $this->input->post('tottime9'),
       'remarks'    => $this->input->post('remarks9'),
      'basicsalary'    =>   $wbsal9, /*  $this->input->post('basicsal6')/30 */
      'latecoming' => $this->input->post('latecoming9'),
      'daysalary' => ($wbsal9 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid9 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid9 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result9 = $this->login_database->drr_registration_insert($data);
  // $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result9 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate9_2 );
           $date2  = new DateTime($woutdate9_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate9_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate9_1 = $date2;

                       if ( $this->input->post('basicsal9') > 0 )
                       {
                                $wbsal9 =  $this->input->post('basicsal9') / 30;
                       }
                      else
                      {
                         $wbsal9 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek9 = date('l', strtotime($wdate2));
                       $dayofdate_9= date('d',  strtotime($wdate2));

                      $monthofdate_9 = date ('F', strtotime ($wdate2));
                      $yearofdate_9 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek9 == 'Sunday')
                       {
                            $wbsal9 = $wbsal9 * 2;
                       }
                       else
                       {
                            $wbsal9 = $wbsal9 * 1;
                      }
                     if ($dayofdate_9 == 31)
                      {
                           $wbsal9 = 0;
                      }



                   if   ((0 == $yearofdate_9 % 4) & (0 != $yearofdate_9 % 100) | (0 ==$yearofdate_9 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_9 == 'February')
                   {
                      if  ($dayofdate_9 == 29)
                      {
                           $wbsal9 = $wbsal9 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_9 == 'February')
                {
                     if  ($dayofdate_9 == 28)
                     {
                        $wbsal9 = $wbsal9 + ($xbsal*2);
                     }
                }
                }






                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid9, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid9'),
                                 'duty'  =>  $this->input->post('dutyid9'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate9_1'),
                                 'outstationdateto' => $this->input->post('outdate9_2'),
                                 'shift'  => $this->input->post('shiftid9'),
                                 'customername'   =>  $this->input->post('custid9'),
                                 'customerid'   =>  $this->input->post('custid9'),
                                 'passengername'  => $this->input->post('pass9'),
                                'reportingtime'   => $this->input->post('reporttime9'),
                                'intime'   =>  $this->input->post('intime9'), 
                                'actualintime'   => $this->input->post('acttime9'),
                                'outtime'    => $this->input->post('outtime9'),
                                'actualouttime'   => $this->input->post('actouttime9'),
                                'worktime'    => $this->input->post('workduration9'),
                               'ottime'    =>  $this->input->post('ottime9'),
                               'totalduration'    => $this->input->post('tottime9'),
                              'remarks'    => $this->input->post('remarks9'),
                             'basicsalary'    => $wbsal9, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming9'),
                             'daysalary' => $wbsal9, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance
                     );   
                    if ($wdutyid9 == 'O' and $wpresentid9== 'PO'  )
                   {
                         $result9 = $this->login_database->drr_registration_insert($data);  
                   }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */
    }
  }
// line 9 end
// line10  start


    if ($date_emp == "DATE")  
    {
          $wregdate = $this->input->post('regdate');
    }
    else
    {
          $wregdate = $this->input->post('regdate10');
    }
    $dayofweek = date('l', strtotime($wregdate));
    $dayofdate= date('d', strtotime($wregdate));
    $monthofdate = date ('F', strtotime ($wregdate));
    $yearofdate = date ('Y', strtotime ($wregdate));



    $latenight_23hrs = 0; /*    75;  */
    $earlymorning_6am = 0;  /*   50;   */

    $wshiftid10 =  $this->input->post('shiftid10');

    $wempid10 = $this->input->post('empid10');
    $wpresentid10 = $this->input->post('presentid10');
    $wdutyid10 =  $this->input->post('dutyid10');
    $wcustid10= $this->input->post('custid10');
    $wpass10 = $this->input->post('pass10');
    $wreporttime10 = $this->input->post('reporttime10');
    $iparr   = explode('~', $wempid10);
    $weid10 = $iparr[0];
    if ( $this->input->post('basicsal10') > 0 )
   {
     $wbsal10 =  $this->input->post('basicsal10') / 30;
     $xbsal = $this->input->post('basicsal10') / 30;

   }
   else
   {
     $wbsal10 = 0;
     $xbsal = 0;
   }
    $woutdate10_1 =  $this->input->post('outdate10_1');
    $woutdate10_2 =  $this->input->post('outdate10_2');

    $wacthh10  =  $this->input->post('acthh10');
    $wactmm10  =  $this->input->post('actmm10');
    $wouthh10  =  $this->input->post('outhh10');
    $woutmm10  =  $this->input->post('outmm10');


   $wdayallowance = 0;
   $wnightallowance = 0;
   $wcleaningallowance =0;   
   $ot =0;
    $latefine10 = $this->input->post('latecoming10');
    if ($latefine10> 0 )
    {
       $laters = 33;
   }
   else
   {
     $laters = 0.00;
   }
    if ($wdutyid10 == 'O' and $wpresentid10== 'PO'  )
    {      
           $date1 = new DateTime($woutdate10_2 );
           $date2  = new DateTime($woutdate10_1 );
          $daysdiff = $date1->diff($date2)->format("%d");

// echo $daysdiff;
            $wdayallowance = ($daysdiff+1)*$osrs;
           $wnightallowance = $daysdiff * $nightrs;
          $wcleaningallowance = ($daysdiff)*$cleanrs;

            if ( $dayofweek == 'Sunday')
            {
                $wbsal10 = $wbsal10 * 2;
            }
            else
            {
               $wbsal10 = $wbsal10 * 1;
             }


         if (  (int) $wacthh10 > 0 )
         {
          if ((int)$wacthh10 < 6 )
         {
                 $earlymorning_6am = 50;  /*   50;   */
         }
         else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }
          }
          else
          {
                    $earlymorning_6am = 0;  /*   50;   */
          }


      }

// echo "earl " .   $earlymorning_6am ,  " act h " . $wacthh10 ;

     if ($wdutyid10 == 'L'  )
      {
       if (  ( (int)$wouthh10 >= 24 ) or ( (int)$wouthh10 >= 23 and (int)$woutmm10 >= 0 )   )
       {
    //             $latenight_23hrs = 75;
                 if ($wshiftid10 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   }


    if ($wdutyid10 == 'L' and ( $wpresentid10== 'PR'  or $wpresentid10 == 'PP' )  )
    { 
       $ottime = $this->input->post('ottime10');
       $iparr   = explode(':', $ottime);
      $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);

        if (  ( (int)$wouthh10 >= 24 ) or ( (int)$wouthh10 >= 23 and (int)$woutmm10 >= 0 )   )
       {
       //          $latenight_23hrs = 75;
                 if ($wshiftid10 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }      
   
   }
  if ( $wpresentid10== 'DD'  or   $wpresentid10 == 'DH')
  {
  if ( $wpresentid10== 'DD'  )
  {
       $doubleshift=100;
   }
   if ( $wpresentid10 == 'DH'  )
   {
       $doubleshift=200;
   }
   $wbsal10 =0 ;
   $wdayallowance  = 0.0;
   $wnightallowance = 0.0;
   $wcleaningallowance = 0.0;
   $ot = 0.0;
   $laters =0;

/* ot calculation for double shift */
       $ottime = $this->input->post('ottime10');
       $iparr   = explode(':', $ottime);
       $othh = $iparr[0];
       $otmm =  $iparr[1];
       $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
       if (  ( (int)$wouthh10 >= 24 ) or ( (int)$wouthh10 >= 23 and (int)$woutmm10 >= 0 )   )
       {
      //           $latenight_23hrs = 75;
                 if ($wshiftid10 <> "N")
                 {
                     $latenight_23hrs = 75;
                 }
                 else
                 {
                     $latenight_23hrs = 0;
                 }

       }
       else
       {
               $latenight_23hrs = 0;
       }
/* ot calculation for double shift over */


  }
  else
  {
  $doubleshift=00;
  }
   if ($wpresentid10== 'HD'  or $wpresentid10== 'WD' )
  {
     if ( $this->input->post('basicsal10') > 0 )
    {
       $wbsal10 =  ($this->input->post('basicsal10') / 30)*2;
    }
    else
    {
      $wbsal10 = 0;
    }
    $ottime = $this->input->post('ottime10');
    $iparr   = explode(':', $ottime);
    $othh = $iparr[0];
    $otmm =  $iparr[1];
    $ot = ($otrs * $othh) + ( ($otmm*$otrs)/60);
   }
   if ($wpresentid10 == 'HN')
   {
    $htnallowance = 400;
   }
   else
   {
    $htnallowance = 0;
    }  
if ($dayofdate == 31)
{
$wbsal10 = 0.00;
}


if((0 == $yearofdate % 4) & (0 != $yearofdate % 100) | (0 ==$yearofdate % 400))
{
//echo "$year is a Leap Year.";    
if ($monthofdate == 'February')
{
   if ($dayofdate == 29)
   {
     $wbsal10 = $wbsal10 + $xbsal;
   }
}
}
else  
{  
//echo "$year is not a Leap Year.";    
if ($monthofdate == 'February')
{
   if    ($dayofdate == 28)
   {
     $wbsal10 = $wbsal10 + ($xbsal*2);
   }
}
}


    $data = array(
        'date' =>  $wregdate,     /*     $this->input->post('regdate'),    */
        'empid' =>  $weid10, /* $this->input->post('empid1'), */
        'presentabsent' => $this->input->post('presentid10'),
        'duty'  =>  $this->input->post('dutyid10'),
        'outstationdatefrom'  =>  $this->input->post('outdate10_1'),
        'outstationdateto' => $this->input->post('outdate10_2'),
        'shift'  => $this->input->post('shiftid10'),
        'customername'   =>  $this->input->post('custid10'),
       'customerid'   =>  $this->input->post('custid8'),
       'passengername'  => $this->input->post('pass10'),
       'reportingtime'   => $this->input->post('reporttime10'),
       'intime'   =>  $this->input->post('intime10'), 
       'actualintime'   => $this->input->post('acttime10'),
       'outtime'    => $this->input->post('outtime10'),
       'actualouttime'   => $this->input->post('actouttime10'),
       'worktime'    => $this->input->post('workduration10'),
       'ottime'    =>  $this->input->post('ottime10'),
       'totalduration'    => $this->input->post('tottime10'),
       'remarks'    => $this->input->post('remarks10'),
      'basicsalary'    =>   $wbsal10, /*  $this->input->post('basicsal6')/30 */
      'latecoming' => $this->input->post('latecoming10'),
      'daysalary' => ($wbsal10+ $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am)-$laters,
      'cleaningallowance'  => $wcleaningallowance,
      'nightallowance'  =>  $wnightallowance ,
      'dayallowance'  =>  $wdayallowance ,
      'overtime'  =>  $ot,
      'doubleshift' => $doubleshift,
      'totalallowance'  => $wdayallowance + $wnightallowance + $wcleaningallowance+$ot+$doubleshift+$htnallowance+$latenight_23hrs +$earlymorning_6am
   );

  if ($wempid10 == '0')
  {
    $correctentry='False';
  }
  else
  {
    if  ($wpresentid10 == '0' )
    {
           $correctentry='False';
    }
    else
    {
  $result10 = $this->login_database->drr_registration_insert($data);
 //  $datainsert = $datainsert + 1;
    $dataline = $dataline + 1;
    if ($result10 )
   {
          $datainsert = $datainsert + 1;
    }

           $date1 = new DateTime($woutdate10_2 );
           $date2  = new DateTime($woutdate10_1 );

          $daysdiff = $date1->diff($date2)->format("%d");
           for ($x = 0; $x <$daysdiff; $x++)
          {

                       $date2 =  (new DateTime($woutdate10_1))->add(new DateInterval('P1D'))->format('Y-m-d');
                       $woutdate10_1 = $date2;

                       if ( $this->input->post('basicsal10') > 0 )
                       {
                                $wbsal10 =  $this->input->post('basicsal10') / 30;
                       }
                      else
                      {
                         $wbsal10 = 0;
                      }


                       $wdate2 = $date2;     /* $this->input->post('regdate');  */
                       $dayofweek10 = date('l', strtotime($wdate2));
                       $dayofdate_10 = date('d',  strtotime($wdate2));

                      $monthofdate_10 = date ('F', strtotime ($wdate2));
                      $yearofdate_10 = date ('Y', strtotime ($wdate2));


                       if ($dayofweek10 == 'Sunday')
                       {
                            $wbsal10 = $wbsal10 * 2;
                       }
                       else
                       {
                            $wbsal10 = $wbsal10 * 1;
                      }
                      if ($dayofdate_10 == 31)
                      {
                           $wbsal10 = 0;
                      }


                   if   ((0 == $yearofdate_10 % 4) & (0 != $yearofdate_10 % 100) | (0 ==$yearofdate_10 % 400))
                   {                   //echo "$year is a Leap Year.";    
                   if ($monthofdate_10 == 'February')
                   {
                      if  ($dayofdate_10 == 29)
                      {
                           $wbsal10 = $wbsal10 + $xbsal;
                      }
                  }
                 }
                else  
                {      //echo "$year is not a Leap Year.";    
                if ($monthofdate_10 == 'February')
                {
                     if  ($dayofdate_10 == 28)
                     {
                        $wbsal10 = $wbsal10 + ($xbsal*2);
                     }
                }
                }



                      $data = array(
                                 'date' =>  $date2, //  $this->input->post('regdate'),    
                                 'empid' =>  $weid10, /* $this->input->post('empid1'), */
                                 'presentabsent' => $this->input->post('presentid10'),
                                 'duty'  =>  $this->input->post('dutyid10'),
                                 'outstationdatefrom'  =>  $this->input->post('outdate10_1'),
                                 'outstationdateto' => $this->input->post('outdate10_2'),
                                 'shift'  => $this->input->post('shiftid10'),
                                 'customername'   =>  $this->input->post('custid10'),
                                 'customerid'   =>  $this->input->post('custid10'),
                                 'passengername'  => $this->input->post('pass10'),
                                'reportingtime'   => $this->input->post('reporttime10'),
                                'intime'   =>  $this->input->post('intime10'), 
                                'actualintime'   => $this->input->post('acttime10'),
                                'outtime'    => $this->input->post('outtime10'),
                                'actualouttime'   => $this->input->post('actouttime10'),
                                'worktime'    => $this->input->post('workduration10'),
                               'ottime'    =>  $this->input->post('ottime10'),
                               'totalduration'    => $this->input->post('tottime10'),
                              'remarks'    => $this->input->post('remarks10'),
                             'basicsalary'    => $wbsal10, /* $this->input->post('basicsal1')/30 */
                             'latecoming' => $this->input->post('latecoming10'),
                             'daysalary' => $wbsal10, // ($wbsal1 + $wdayallowance + $wnightallowance + $wcleaningallowance+$ot)-$laters,
                             'cleaningallowance'  => 0, // $wcleaningallowance,
                             'nightallowance'  => 0, //  $wnightallowance ,
                             'dayallowance'  => 0, //  $wdayallowance ,
                             'overtime'  =>  $ot,
                             'doubleshift' => 0,
                            'totalallowance'  => 0 // $wdayallowance + $wnightallowance + $wcleaningallowance+$ot
                     );   
                    if ($wdutyid10 == 'O' and $wpresentid10== 'PO'  )
                   {
                         $result10 = $this->login_database->drr_registration_insert($data);  
                    }
           }
     /*  echo '<html><body><marquee><font size="14" color="blue">' .  "  Total Record Inserted are " . $datainsert . " " .   '</font> </marquee> </body></html>';   */

    }
  }

// line 10 end

  if ($result1 == TRUE or $result2 == TRUE   or $result3 == TRUE   or $result4 == TRUE or $result5 == TRUE or 
       $result6 == TRUE  or $result7 == TRUE or $result8 == TRUE or $result9 == TRUE or $result10 == TRUE) 
  { 

      $data['data']  = $this->itemCRUD->get_empname();
      $data2_1['data2_1']  = $this->itemCRUD->get_customer();
      $data_2['data_2']  = $this->itemCRUD->get_empname();
      $data2_2['data2_2']  = $this->itemCRUD->get_customer();
      $data_3['data_3']  = $this->itemCRUD->get_empname();
      $data2_3['data2_3']  = $this->itemCRUD->get_customer();
      $data_4['data_4']  = $this->itemCRUD->get_empname();
      $data2_4['data2_4']  = $this->itemCRUD->get_customer();
      $data_5['data_5']  = $this->itemCRUD->get_empname();
      $data2_5['data2_5']  = $this->itemCRUD->get_customer();
      $data_6['data_6']  = $this->itemCRUD->get_empname();
      $data2_6['data2_6']  = $this->itemCRUD->get_customer();

       $data_7['data_7']  = $this->itemCRUD->get_empname();
       $data2_7['data2_7']  = $this->itemCRUD->get_customer();

       $data_8['data_8']  = $this->itemCRUD->get_empname();
       $data2_8['data2_8']  = $this->itemCRUD->get_customer();
       $data_9['data_9']  = $this->itemCRUD->get_empname();
       $data2_9['data2_9']  = $this->itemCRUD->get_customer();
       $data_10['data_10']  = $this->itemCRUD->get_empname();
       $data2_10['data2_10']  = $this->itemCRUD->get_customer();

      $data_11['data_11']  = $this->itemCRUD->get_empname();
      $data2_11['data2_11']  = $this->itemCRUD->get_customer();

      $data_12['data_12'] = "DATE";



     $data_13['message_display'] = 'Daily Attendence Register Entered Successfully ! ! ! !  ( Total Number of Records Inserted/Total Records )   ' .  $datainsert .  '/ ' . $dataline  ;

         $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3,  $data_4, $data2_4,  $data_5,$data2_5,  $data_6, $data2_6,  $data_7, $data2_7 , $data_8, $data2_8, $data_9, $data2_9, $data_10, $data2_10,$data_11,$data2_11,$data_12 ,$data_13) ;  
 
    $this->load->view('header_dr_raje');
    $this->load->view('DaaEntry_',$datamerge); // admin_page_');
    $this->load->view('footer_dr_raje');
  }
   else
  {

      $data['data']  = $this->itemCRUD->get_empname();
      $data2_1['data2_1']  = $this->itemCRUD->get_customer();
      $data_2['data_2']  = $this->itemCRUD->get_empname();
      $data2_2['data2_2']  = $this->itemCRUD->get_customer();
      $data_3['data_3']  = $this->itemCRUD->get_empname();
      $data2_3['data2_3']  = $this->itemCRUD->get_customer();
      $data_4['data_4']  = $this->itemCRUD->get_empname();
      $data2_4['data2_4']  = $this->itemCRUD->get_customer();
      $data_5['data_5']  = $this->itemCRUD->get_empname();
      $data2_5['data2_5']  = $this->itemCRUD->get_customer();
      $data_6['data_6']  = $this->itemCRUD->get_empname();
      $data2_6['data2_6']  = $this->itemCRUD->get_customer();

       $data_7['data_7']  = $this->itemCRUD->get_empname();
       $data2_7['data2_7']  = $this->itemCRUD->get_customer();

       $data_8['data_8']  = $this->itemCRUD->get_empname();
       $data2_8['data2_8']  = $this->itemCRUD->get_customer();
       $data_9['data_9']  = $this->itemCRUD->get_empname();
       $data2_9['data2_9']  = $this->itemCRUD->get_customer();
       $data_10['data_10']  = $this->itemCRUD->get_empname();
       $data2_10['data2_10']  = $this->itemCRUD->get_customer();

      $data_11['data_11']  = $this->itemCRUD->get_empname();
      $data2_11['data2_11']  = $this->itemCRUD->get_customer();

      $data_12['data_12'] = "DATE";
      $data_13['message_display'] = 'Daily Attendence Register Not Saved Successfully  (No Duplicate Entries)  ! ! ! !  (Total Records Inserted )    ' . $datainsert  .  '/ ' . $dataline   ;  // GOLE


         $datamerge = array_merge($data,$data2_1,   $data_2,$data2_2,    $data_3, $data2_3,  $data_4, $data2_4,  $data_5,$data2_5,  $data_6, $data2_6,  $data_7, $data2_7 , $data_8, $data2_8, $data_9, $data2_9, $data_10, $data2_10,$data_11,$data2_11,$data_12 ,$data_13) ;  

 //     $data_12['data_12'] = "DATE";
 
    $this->load->view('header_dr_raje');
    $this->load->view('DaaEntry_',$datamerge); // $data,$data_12); // admin_page_');
    $this->load->view('footer_dr_raje');
  }
}
}
public function new_user_registration() 
{
//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
//$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
//$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje');
        $this->load->view('registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'user_name' => $this->input->post('username'),
       //   'user_email' => $this->input->post('email_value'),
          'user_type'  => $this->input->post('user_type_value'),
          'user_password' => $this->input->post('password'),
       //   'pethuman' => $this->input->post('pethuman'),
          'nameofperson' => $this->input->post('nameofperson'),
   //       'ad1' => $this->input->post('ad1'),
     //     'ad2'  => $this->input->post('ad2'),
     //     'pincode' => $this->input->post('pincode'),
          'mobile1' => $this->input->post('mobile1'),
          'mobile2' => $this->input->post('mobile2'),
          'workin' =>  $this->input->post('workin')
   );
   $result = $this->login_database->registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('registration_form',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Username already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

// pay system data maintaince start

  public function  paydatamaintaince()
   { 
       $this->load->library('table');
//       $data['data'] =   $this->itemCRUD->get_payment_details(); //   get_login_details();   ///  $this->itemCRUD->get_itemCRUD_only_pets();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');    
       $this->load->view('paymentreggetdate_');    // 'itemcrudlist'
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

     public function   reverseentry()
   { 
       $this->load->library('table');
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');    
       $this->load->view('paymentreverse_');    // 'itemcrudlist'
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

// pay system data  maintenance end


// login name loginmaintaince start

  public function loginmaintaince()
   {
       $this->load->library('table');
       $data['data'] =   $this->itemCRUD->get_login_details();   ///  $this->itemCRUD->get_itemCRUD_only_pets();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('logindata',$data);    // 'itemcrudlist'
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

// login name maintenance end

// employee maintain start

  public function empmaintain()
   {
       $this->load->library('table');
       $data['data'] =   $this->itemCRUD->get_emp_details(); // get_login_details();   
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('empdata',$data);    // 'logindata
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

// employee maintain end

// customer maintain start

  public function custmaintain()
   {
       $this->load->library('table');
       $data['data'] =   $this->itemCRUD->get_cust_details(); // get_login_details();   
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('custdata',$data);    // 'logindata
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

//  customer maintain end


// drr  maintain start

  public function drrmaintain()
   {

//
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje');
         $this->load->library('table');
         $this->load->view('drrgetdate_');         $this->load->view('footer_dr_raje');
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');


//
  
   }

//  drr  maintain end
// drr edit start

public function drredit($id)
{
      $item = $this->itemCRUD->find_drr_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('drredit_',array('daaentry'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');

}

// drr edit end

public function drrregdatedata()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $fdate = $this->input->post('datefrom');
         $tdate= $this->input->post('dateto');
         $data['data'] =   $this->itemCRUD->get_drr_details($fdate,$tdate); // get_login_details();   
         $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
         $this->load->view('drrdata_',$data);    // 'logindata
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');

}

// reverse data from pay details

public function reversedetails()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $fdate = $this->input->post('datefrom');
         $tdate= $this->input->post('dateto');
         $ecode = $this->input->post('empid1');
//echo $fdate;
//echo $tdate;
//echo $ecode;
         $data['data'] =   $this->itemCRUD->get_reverse_payment_details($fdate,$tdate,$ecode); // get_login_details();    get_payment_details
         $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
         $this->load->view('reversepaydetailsdata_',$data);    // 'logindata  paydetailsdata_
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');

}
// payment date wise data start

public function paydetailsdatedata()
{
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $fdate = $this->input->post('datefrom');
         $tdate= $this->input->post('dateto');
         $ecode = $this->input->post('empid1');
//echo $fdate;
//echo $tdate;
//echo $ecode;
         $data['data'] =   $this->itemCRUD->get_payment_details($fdate,$tdate,$ecode); // get_login_details();   
         $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
         $this->load->view('paydetailsdata_',$data);    // 'logindata
         $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');

}

// payment date wise data end


// new customer regitration
public function new_customer_registration() 
{

//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
//$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
//$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
//echo "form valid ";
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje');
        $this->load->view('customer_registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'name' => $this->input->post('username'),
    //      'user_email' => $this->input->post('email_value'),
     //     'user_type'  => $this->input->post('user_type_value'),
       //   'user_password' => $this->input->post('password'),
       //   'pethuman' => $this->input->post('pethuman'),
        //  'nameofperson' => $this->input->post('nameofperson'),
       //   'ad1' => $this->input->post('ad1'),
        //  'ad2'  => $this->input->post('ad2'),
     //     'pincode' => $this->input->post('pincode'),
          'mobile1' => $this->input->post('mobile1'),
          'mobile2' => $this->input->post('mobile2')
   );
   $result = $this->login_database->customer_registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('customer_registration_form',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Customer name already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('customer_registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

// new customer regitration
public function new_emp_registration() 
{

echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
//$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
//$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje');
echo "one";
        $this->load->view('emp_registration_form');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
//   echo $this->input->post('shift');
 //echo $this->input->post('pethuman');
//die("here");
    $data = array(
          'name' => $this->input->post('username'),
           'shift' => $this->input->post('shift'),
           'inhh'  =>   $this->input->post('inhh10'),
           'inmm' => $this->input->post('inmm11'),
           'outhh' =>  $this->input->post('out12'),
           'outmm' => $this->input->post('out13'),
           'tothh' => $this->input->post('tot14'),
           'totmm'  => $this->input->post('tot15'),
           'basicsal' => $this->input->post('basicsalary'),
          'designation' => $this->input->post('designation'),
          'intime' =>  $this->input->post('inhh10') . ':' . $this->input->post('inmm11'),
          'outtime' =>  $this->input->post('out12') . ":". $this->input->post('out13'),
          'tottime' =>  $this->input->post('tot14') . ":" . $this->input->post('tot15')
   );
   $result = $this->login_database->emp_registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('emp_registration_form',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Employee name already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('emp_registration_form', $data);
     $this->load->view('footer_dr_raje');
  }
}
}

// new vendor registration



// Validate and store registration data in database for human vendor
public function new_human_vendor_registration() 
{

//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('vendorname', 'vendorname', 'trim|required|xss_clean');
$this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value2', 'Email', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form_human');
        $this->load->view('header_dr_raje');
        $this->load->view('registration_new_vendor');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'vendorname' => $this->input->post('vendorname'),
          'vendorad1' => $this->input->post('ad1'),
          'vendorad2'  => $this->input->post('ad2'),
          'vendorpin' => $this->input->post('pincode'),
          'vendormobile1' => $this->input->post('mobile1'),
          'vendormobile2' => $this->input->post('mobile2'), /* new added */
          'contactperson' => $this->input->post('contactperson'),
          'gstnumber' => $this->input->post('gstnumber'),
          'panno' => $this->input->post('panno'),
          'emailid1' => $this->input->post('email_value'),
          'emailid2' => $this->input->post('email_value2'),
          'gender' => $this->input->post('vendorgender'),
          'referred_by' => $this->input->post('referred_by'),
          'any_information_1' => $this->input->post('any_information_1'),
          'any_information_2' => $this->input->post('any_information_2')
   );
   $result = $this->login_database->vendor_registration_insert($data); // gole
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje');
    $this->load->view('registration_new_vendor',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Username already exist!';
     $this->load->view('header_dr_raje');
     $this->load->view('registration_new_vendor', $data);
     $this->load->view('footer_dr_raje');
  }
}
}


// new vendor registration ends

// Validate and store registration data in database for human
public function new_human_user_registration() 
{

//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form_human');
        $this->load->view('header_dr_raje_human');
        $this->load->view('registration_form_human');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'user_name' => $this->input->post('username'),
          'user_email' => $this->input->post('email_value'),
          'user_type'  => $this->input->post('user_type_value'),
          'user_password' => $this->input->post('password'),
          'pethuman' => $this->input->post('pethuman'),
          'clinicalid' => $this->input->post('clinicalid'),
          'nameofperson' => $this->input->post('nameofperson'),
          'ad1' => $this->input->post('ad1'),
          'ad2'  => $this->input->post('ad2'),
          'pincode' => $this->input->post('pincode'),
          'mobile1' => $this->input->post('mobile1'),
          'mobile2' => $this->input->post('mobile2'), /* new added */
          'gender' => $this->input->post('humangender'),
          'dateofbirth' => $this->input->post('birthdate'),
          'veg_non_veg_frequency' => $this->input->post('vegnonveg'),
          'placeofbirth' => $this->input->post('placeofbirth'),
          'allergyofany' => $this->input->post('allergyofany'),
          'sleepingtime' => $this->input->post('sleeptimings'),
          'getuptime' => $this->input->post('wakeuptimings'), 
          'soundsleep ' => $this->input->post('soundsleepoption'),
          'yoga_exercise' => $this->input->post('yogaactivities'),
          'waterdrinkinghabit' => $this->input->post('waterdrinkinghabits'),
          'lunch_dinner_timing' => $this->input->post('lunchtimings'),
          'dinner_timing' => $this->input->post('dinnertimings'),
          'daily_routine_1' =>    $this->input->post('daily_routine_1'),
          'daily_routine_2' =>    $this->input->post('daily_routine_2'),
          'physical_problem_1' => $this->input->post('physical_problems_1'),
          'physical_problem_2' => $this->input->post('physical_problems_2'),
          'medicines_list_1' => $this->input->post('medicine_list_1'),
          'medicines_list_2' => $this->input->post('medicine_list_2'),
          'medicines_list_3' => $this->input->post('medicine_list_3'),
          'bad_habit_1' => $this->input->post('bad_habits_1'),
          'bad_habit_2' => $this->input->post('bad_habits_2'),
          'about_delivery_1' => $this->input->post('about_delivery_1'),
          'about_delivery_2' => $this->input->post('about_delivery_2'),
          'bp_diabetics_level' => $this->input->post('bp_diabetic_level'),
          'diabetic_level' => $this->input->post('diabetic_level'),
          'which_milk_products_1' => $this->input->post('milk_product_consumption_1'),
          'which_milk_products_2' => $this->input->post('milk_product_consumption_2'),
          'gas_acidity_abdomen_1' => $this->input->post('gas_acidity_problem_1'),
          'gas_acidity_abdomen_2' => $this->input->post('gas_acidity_problem_2'),
          'reference' => $this->input->post('reference'),
          'occupation' => $this->input->post('occupation'),
          'whatupno1' => $this->input->post('whatupno1'),
          'whatupno2' => $this->input->post('whatupno2'),
          'enquirydetail1' => $this->input->post('enquiry1'),
          'enquirydetail2' => $this->input->post('enquiry2'),
          'followup1' => $this->input->post('followup1'),
          'followup2' => $this->input->post('followup2'),
          'hereditarydisease' => $this->input->post('heridieterydisease'),
          'registrationdate' => $this->input->post('registrationdate'),
          'patientphoto' => $this->input->post('patientphoto'),
          'weight' =>  $this->input->post('patientweight'),
          'height' => $this->input->post('patientheight'),
          'asthma_problem' =>  $this->input->post('asthma_problem'),
          'other_problem' => $this->input->post('other_problem'),
          'nadi_problem' => $this->input->post('nadi_problem'),
          'urine_issue' => $this->input->post('urine_issue'),
          'duration_disease_1' => $this->input->post('duration_diseases_1'),
          'duration_disease_2' => $this->input->post('duration_diseases_2'),
          'duration_disease_3' => $this->input->post('duration_diseases_3'),
          'duration_disease_4' => $this->input->post('duration_diseases_4'),
          'any_other_diseases_1' => $this->input->post('any_other_diseases_1'), 
          'any_other_diseases_2' => $this->input->post('any_other_diseases_2'),
          'any_surgeries_1' => $this->input->post('any_surgeries_1'),
          'any_surgeries_2' => $this->input->post('any_surgeries_2'),
          'any_surgeries_3' => $this->input->post('any_surgeries_3'),
          'emergency_contact_1' => $this->input->post('emergency_contact_1'),
          'emergency_contact_2' => $this->input->post('emergency_contact_2'),
          'family_member_disease_1' => $this->input->post('familydisease_1'),
          'family_member_disease_2' => $this->input->post('familydisease_2'),
          'anyreferencenameno1' => $this->input->post('anyreferencenameno1'),
          'anyreferencenameno2' => $this->input->post('anyreferencenameno2'),
          'anyreferencenameno3' => $this->input->post('anyreferencenameno3'),
          'anyreferencenameno4' => $this->input->post('anyreferencenameno4'),
          'any_information_1' => $this->input->post('any_information_1'),
          'any_information_2' => $this->input->post('any_information_2')
   );
   $result = $this->login_database->registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje_human');
    $this->load->view('registration_form_human',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Username already exist!';
     $this->load->view('header_dr_raje_human');
     $this->load->view('registration_form_human', $data);
     $this->load->view('footer_dr_raje');
  }
}
}




// new user human end

// Check for user login process
public function user_login_process() 
{  // 0

    $this->load->helper('form');
    $this->load->library('form_validation');
//echo '<pre>'; var_dump($this->input->post()); echo '</pre>';
// echo 'here ... 0 ';

   $this->form_validation->set_rules('username', 'username', 'trim|required|xss_clean');
   $this->form_validation->set_rules('password', 'password', 'trim|required|xss_clean');
   if ($this->form_validation->run() == FALSE) 
   {   // 1 form validation fail
 // echo '0.4';
        if(isset($this->session->userdata['logged_in']))
        {
//echo '0.4.1';
              $this->load->view('header_dr_raje_main_view');
              $this->load->view('admin_page_');
              $this->load->view('footer_dr_raje');

        }
        else
         {   // form validation fail
  // echo '0.5';   
             $this->load->view('header_dr_raje_main_view');
             $this->load->view('login_menu_main_');  
             $this->load->view('footer_dr_raje'); 
    
      //     $this->load->view('login_menu_');   //  $this->load->view('login_form');
         }
    } 
    else 
    { // 1  correct form validation  now checking user name password clinic type validation with database
 // echo 'here ... 1';

//echo $this->input->post('user_type_value');
// die ("m");

        $data = array(
                   'username' => $this->input->post('username'),
                   'password' => $this->input->post('password'),
                   'pethuman' => $this->input->post('user_type_value') 
                    );
     

//echo $this->input->post('username');
//echo $this->input->post('password');
//echo  $this->input->post('user_type_value');
//die("here");

        $result = $this->login_database->login($data);
        if ($result == TRUE)
        { // 3 correct login 

// echo "test 1";
             $username = $this->input->post('username');
             $result = $this->login_database->read_user_information($username);
             if ($result != false) 
             {
                $session_data = array(
                   'username' => $result[0]->user_name,
           //        'email' => $result[0]->user_email,
                   'user_type' => $result[0]->user_type,
                  'patient_type' => $result[0]->workin,
                 );   //  patient is user or admin and then human or pet 
// Add user data in session
               $this->session->set_userdata('logged_in', $session_data);

               $_SESSION['global_user_name'] = $result[0]->user_name ;
               $_SESSION['global_user_id'] = $result[0]->id;
               $_SESSION['global_name_of_person'] = $result[0]->nameofperson;
               $_SESSION['global_clinic_type'] = $result[0]->workin;

// echo isset($this->session->userdata['logged_in']);
// die("in user login process");

// actual login page 
//die ("act page");


 
                if ($result[0]->workin == 'DAA')
                {
// die ("here");
                $this->load->view('header_dr_raje');
                $this->load->view('admin_page_');
                $this->load->view('footer_dr_raje');
                } 
               if ($result[0]->workin == 'PEC')      
                {
                $this->load->view('header_dr_raje_human');
                $this->load->view('admin_page_');
                $this->load->view('footer_dr_raje');

                }

           
 

      //          $this->load->view('admin_page_');
             }
       }
       else 
       { // 3  invalid user name and password 

// echo "test 2";

             $data = array(
                   'error_message' => 'Invalid Username or Password'
             );

             $this->load->view('header_dr_raje_main_view');
             $this->load->view('login_menu_main_' , $data);  
             $this->load->view('footer_dr_raje');  
   
      //     $this->load->view('login_menu_');
       // check this for $data      $this->load->view('login_menu_', $data);
       } // 3 over
   } // 1 over
} // 0 over

  
    public function login_action()  
    {  
        $this->load->helper('security');  
        $this->load->library('form_validation');  
        $this->form_validation->set_rules('username', 'username:', 'required|trim|xss_clean|callback_validation');  
        $this->form_validation->set_rules('password', 'password:', 'required|trim');  
        if ($this->form_validation->run())   
        {  
            $data = array(  
                'username' => $this->input->post('username'),  
                'currently_logged_in' => 1  ,
          //      'nameofcompany' => $this->$data('nameofcompany');
                );    
                $this->session->set_userdata($data);  
                redirect('Main/data');  
        }   
        else {  
            $this->load->view('login_view');  
        }  
    }  
  
    public function signin_validation()  
    {  
        $this->load->library('form_validation');   
        $this->form_validation->set_rules('username', 'username', 'trim|xss_clean|is_unique[signup.username]');  
        $this->form_validation->set_rules('password', 'password', 'required|trim');  
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|trim|matches[password]');  
        $this->form_validation->set_message('is_unique', 'username already exists');  
    if ($this->form_validation->run())  
        {  
            echo "Welcome, you are logged in.";  
         }   
            else {  
              
            $this->load->view('signin');  
        }  
    }   
    public function validation()  
    {  
        $this->load->model('login_model');  
  
        if ($this->login_model->log_in_correctly())  
        {  
            return true;  
        } else {  
            $this->form_validation->set_message('validation', 'Incorrect username/password.');  
            return false;  
        }  
    }  
    public function logout()  
    {  
        $this->session->sess_destroy();  
        $_SESSION['global_user_name'] = ' ';       
        redirect('Home_AutoRenta/login'); //  redirect ('Cntr_Login/login'); // ('Main/login');  
    }  

public function maintenance_show()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
 
         $this->load->view('header_dr_raje');
         $this->load->view('maintenance_menu_main_');  
         $this->load->view('footer_dr_raje');

    }   
  
//} 

// payment system maintenance start

public function oprentry_maintain()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
 
         $this->load->view('header_dr_raje');
         $this->load->view('oprentry_maintain_menu_main_');  
         $this->load->view('footer_dr_raje');

    }   

// payment system maintenance end


public function human_patient_diagnosis()
{


         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->library('table');
         $data['data']    = $this->itemCRUD->get_suppliername();
         $data1['data1']    = $this->itemCRUD->get_patientname();
         $data3['data3'] = $this->itemCRUD->get_humandiagnosis(); 
         $datamerge = array_merge($data, $data1,$data3) ;
         $this->load->view('header_dr_raje_human');
         $this->load->view('human_patient_diagnosis_view_',$datamerge);  
         $this->load->view('footer_dr_raje');
}
public function updatehumandiagnosis()
{
    $pid = 0;
    $pnm = '';
    $recsave =0;
    $bm = $this->input->post('billamount');
    $pm = $this->input->post('paidamount');
    if ($bm == 0 and $pm == 0 )
    {
    }
    else
    {
          $pid=  $this->session->userdata('global_patient_id');
          $pnm = $this->session->userdata('global_patient_name');
          $data = array(
          'userid' => $pid, //  $this->input->post('sb1') ,
          'dateofvisit' => $this->input->post('entrydate'),    
          'illness1'  => $this->input->post('illnessdetails'),
          'illness2' => $this->input->post('illnessdetails2'),
          'dignosis1' => $this->input->post('allergydetails1'),
          'dignosis2' => $this->input->post('allergydetails2'),
          'medicine1' => $this->input->post('medicinedetails'),
          'medicine2'  => $this->input->post('medicinedetails2'),
          'billamount' => $this->input->post('billamount'),
          'paidamount' => $this->input->post('paidamount'),
          'nextvisit' => $this->input->post('nextvisitdate'), /* new added */
          'remarks' => $this->input->post('remarks'),
          'dateofdeath' => $this->input->post('deathdate'),
          'reasonfordeath' => $this->input->post('deathreason'),
          'nameofperson' => $pnm //   $this->input->post('nameofperson')
          );      //                       human_patient_diagnosis_insert
          $result = $this->login_database->human_patient_diagnosis_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Patient Diagnosis Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Patient Diagnosis Not Saved Successfully!';
           } // 3 over
    }
    $this->load->view('header_dr_raje');
    redirect('Home_Dr_Raje/human_patient_diagnosis'); 
    $this->load->view('footer_dr_raje');
}


//

public function updatepetsappointments()
{

      $wPetsNewPatient = $this->input->post('PetsNewPatient'); 
      $wpetspatientname = $this->input->post('PetsPatientname');
echo "new " . $wPetsNewPatient;
echo " pat name " . $wpetspatientname;
// die("here");

      $wdateofappointment = $this->input->post('dateofapp1');
      $wclinictype = $this->input->post('ClinicName');
echo $wdateofappointment;
echo "<br>" .  $wclinictype ;
die("1");
      if ($wclinictype == 0 )
      {
echo  "<br>" .  $wclinictype ;
 die("d");
        echo '<html><body><br><br><br><br><br><marquee><font color="red"> clinic type not selected </font> </marquee> </body></html>';
      }
      else // rest insert programme
      {
      }


          $data = array(
          'userid' => $pid, //  $this->input->post('sb1') ,
          'nameofperson' => $pnm //   $this->input->post('nameofperson')
          );      //                       human_patient_diagnosis_insert
          $result = $this->login_database->human_patient_diagnosis_insert($data);
          if ($result == TRUE) 
          { // 3
             $data['message_display'] = 'Patient Diagnosis Saved Successfully !';
          } // 3
           else 
          {  // 3
            $data['message_display'] = 'Patient Diagnosis Not Saved Successfully!';
           } // 3 over
    
    $this->load->view('header_dr_raje');
    redirect('Home_Dr_Raje/human_patient_diagnosis'); 
    $this->load->view('footer_dr_raje');
}


//

// itemcrud from net start

 

   /**
    * Display Data this method.
    *
    * @return Response
   */
   public function itemcrudindex()
   {
       $this->load->library('table');
       $data['data'] = $this->itemCRUD->get_itemCRUD_only_pets();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('itemcrudlist',$data);
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

 public function petcrudindex()
   {
       $this->load->library('table');
       $data['data'] = $this->itemCRUD->get_petCRUD();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('petcrudlist',$data);
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

   public function injectionlistmodify()
   {
       $this->load->library('table');
       $data['data'] = $this->injectionCRUD->get_itemCRUD();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('injectioncrudlist',$data);
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

  public function diseaselistmodify()
   {
       $this->load->library('table');
       $data['data'] = $this->disCRUD->get_itemCRUD();
       $this->load->view('header_dr_raje'); // $this->load->view('itemcrudheader');       
       $this->load->view('diseasecrudlist',$data);
       $this->load->view('footer_dr_raje'); // $this->load->view('itemcrudfooter');
   }

   /**
    * Show Details this method.
    *
    * @return Response
   */

   public function empshow($id)
   {
      $item = $this->itemCRUD->find_emp_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('empshow_',array('emptable'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

   public function custshow($id)
   {
      $item = $this->itemCRUD->find_cust_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('custshow_',array('customer'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

   public function usershow($id)
   {
      $item = $this->itemCRUD->find_user_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('usershow_',array('user_login'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

 public function drrshow($id)
   {
      $item = $this->itemCRUD->find_drr_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('drrshow_',array('daaentry'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }
 public function payshow($id)
   {
      $item = $this->itemCRUD->find_pay_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('payshow_',array('paymentregister'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

 public function payedit($id)
   {
      $item = $this->itemCRUD->find_pay_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('payedit_',array('paymentregister'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }


 public function reversepayedit($id)
   {
      $item = $this->itemCRUD->find_pay_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('reversepayedit_',array('paymentregister'=>$item));  //   payedit_   ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }


   public function show($id)
   {
      $item = $this->itemCRUD->find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('show',array('user_login'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }
   public function showhuman($id) // show user
   {
      $item = $this->itemCRUD->find_item($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('showhuman',array('user_login'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }
// stock item show
   public function showhumanstock($id) // show stock
   {
      $item = $this->itemCRUD->find_stock($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('showhumanstock_',array('stocklistofhuman'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }
// vendor show
   public function showhumanvendor($id) // show vendor
   {
      $item = $this->itemCRUD->find_vendor($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('showhumanvendor_',array('vendorlist'=>$item));  // ITEMcrud/showvendor
      $this->load->view('footer_dr_raje');
   }
// vendor edit
   public function edithumanvendor($id) // show vendor
   {
      $item = $this->itemCRUD->find_vendor($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('edithumanvendor_',array('vendorlist'=>$item));  // ITEMcrud/editvendor
      $this->load->view('footer_dr_raje');
   }

   public function showpettype($id)
   {
      $item = $this->itemCRUD->find_pettype($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('showpettype',array('petstypelist'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

 

   public function showinjection($id)
   {
      $item = $this->injectionCRUD->find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('showinjection',array('injectionlist'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

   public function showdisease($id)
   {
      $item = $this->disCRUD->find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('showdisease',array('listofdisease'=>$item));  // ITEMcrud/show
      $this->load->view('footer_dr_raje');
   }

   /**
    * Create from display on this method.
    *
    * @return Response
   */
   public function create()
   {
      $this->load->view('theme/header');
      $this->load->view('itemCRUD/create');
      $this->load->view('theme/footer');   
   }


   /**
    * Store Data from this method.
    *
    * @return Response
   */
   public function store()
   {
        $this->form_validation->set_rules('title', 'title', 'required');
        $this->form_validation->set_rules('description', 'description', 'required');


        if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('itemCRUD/create'));
        }else{
           $this->itemCRUD->insert_item();
           redirect(base_url('itemCRUD'));
        }
    }


   /**
    * Edit Data from this method.
    *
    * @return Response
   */
   public function useredit($id)
   {
      $item = $this->itemCRUD->find_user_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('useredit_',array('user_login'=>$item));
      $this->load->view('footer_dr_raje');     
   }
  public function custedit($id)
   {
      $item = $this->itemCRUD->find_cust_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('custedit_',array('customer'=>$item));
      $this->load->view('footer_dr_raje');     
   }
  public function empedit($id)
   {
      $item = $this->itemCRUD->find_emp_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('empedit_',array('emptable'=>$item));
      $this->load->view('footer_dr_raje');     
   }
   public function edit($id)
   {
      $item = $this->itemCRUD->find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('edit',array('user_login'=>$item));
      $this->load->view('footer_dr_raje');     
   }
   public function edithuman($id) // edit user
   {
      $item = $this->itemCRUD->find_item($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('edithuman',array('user_login'=>$item));
      $this->load->view('footer_dr_raje');     
   }
   public function edithumanstock($id) // edit stock pdgole
   {
      $item = $this->itemCRUD->find_stock($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('edithumanstock_',array('stocklistofhuman'=>$item));
      $this->load->view('footer_dr_raje');     
   }
   public function edithuman_photoupload($id)
   {
      $item = $this->itemCRUD->find_item($id);
      $this->load->view('header_dr_raje_human');  // array('item'=>$item
      $this->load->view('edithuman_photoupload_',array('user_login'=>$item));
      $this->load->view('footer_dr_raje');     
   }
public function editpettype($id)
   {
      $item = $this->itemCRUD->find_pettype($id); // find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('editpettype',array('petstypelist'=>$item));
      $this->load->view('footer_dr_raje');     
   }
  public function editinjection($id)
   {
      $item = $this->injectionCRUD->find_item($id);
      $this->load->view('header_dr_raje');  // array('item'=>$item
      $this->load->view('editinjection',array('injectionlist'=>$item));
      $this->load->view('footer_dr_raje');     
   }
   /**
    * Update Data from this method.
    *
    * @return Response
   */
   public function updatepettype($id)
   {
//                                                      field         prompt 
          $this->itemCRUD->update_pettype($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje/petcrudindex'));
   }

   public function userupdate($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
  //      $this->form_validation->set_rules('useremail', 'user_email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_AutoRenta/useredit/'.$id));
        }
        else
       { 
//echo "here";
          $this->itemCRUD->update_user_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_AutoRenta/loginmaintaince'));
        }
   }

   public function drrupdate($id)
   {
//die ( "in");
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
 //    $this->form_validation->set_rules('presentabsent', 'presentid1', 'required');
  //      $this->form_validation->set_rules('password', 'password', 'required');
/*
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_AutoRenta/drredit/'.$id));
        }
        else
       { */

//echo " in congttol here";
          $this->itemCRUD->update_drr_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_AutoRenta/drrmaintain'));
   /*     }*/
   }

// pay update start
   public function payupdate($id,$glcodedr,$glcodecr)
   {
//echo $id ;
//echo $glcodedr;
//echo $glcodecr;
//echo  " in controller " . "<br>".
// die ( "in");
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
 //    $this->form_validation->set_rules('presentabsent', 'presentid1', 'required');
  //      $this->form_validation->set_rules('password', 'password', 'required');
/*
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_AutoRenta/paydatamaintaince') );  // drredit/'.$id));
        }
        else
       { */
    $validdata = true;
    $wopbalance = $this->input->post('opbalance');
    $wamountgiven =  $this->input->post('amountgiven');
    $wexpensesmade =  $this->input->post('expensesmade');
    $wnarration1 = $this->input->post('narration1');
    $wnarration2 = $this->input->post('narration2');
    $wamountadjusted = $this->input->post('amountadjusted');
    $wsalarymonth = $this->input->post('salarymonth');
    $wadjyear = $this->input->post('adjyear');
    $wremarks =  $this->input->post('remarks');
    $wnewempid1 =  $this->input->post('newempid1');
//echo " op " . $wopbalance;
//echo " am g " . $wamountgiven; 
//echo " exp " .  $wexpensesmade ;
//echo " adj " .  $wamountadjusted ;
    if ( ($wopbalance > 0 ) and ($wamountgiven+ $wexpensesmade + $wamountadjusted) > 0 )
    {
       $validdata = false;
    }
    if ( ($wamountgiven > 0 ) and ($wopbalance+ $wexpensesmade + $wamountadjusted) > 0 )
    {
       $validdata = false;
    }
    if ( ($wexpensesmade > 0 ) and ($wopbalance+ $wamountgiven + $wamountadjusted) > 0 )
    {
       $validdata = false;
    }
    if ( ($wamountadjusted > 0 ) and ($wopbalance+ $wamountgiven + $wexpensesmade) > 0 )
    {
       $validdata = false;
    }
//echo " in congttol here";
    if ($validdata == true )
    {
          $this->itemCRUD->update_pay_item($id,$glcodedr,$glcodecr);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_AutoRenta/paydatamaintaince'));
   }
   else
   {
           redirect( base_url('index.php/Home_AutoRenta/paydatamaintaince'));
  }
   }
// pay update end

// cust update start
   public function custupdate($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
     $this->form_validation->set_rules('name', 'name', 'required');
  //      $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_AutoRenta/custedit/'.$id));
        }
        else
       { 
 
          $this->itemCRUD->update_cust_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_AutoRenta/custmaintain'));
        }
   }
// cust update end
   public function empupdate($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
     $this->form_validation->set_rules('name', 'name', 'required');
  //      $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_AutoRenta/empedit/'.$id));
        }
        else
       { 
//echo "here";
          $this->itemCRUD->update_emp_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_AutoRenta/empmaintain'));
        }
   }

    public function update($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul

        $this->form_validation->set_rules('useremail', 'user_email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_Dr_Raje/edit/'.$id));
        }
        else
       { 
          $this->itemCRUD->update_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje/itemcrudindex'));
        }
   }
    public function updatehuman($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
        $this->form_validation->set_rules('useremail', 'user_email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());
         // redirect(base_url('itemCRUD/edit/'.$id));
            redirect(base_url('index.php/Home_Dr_Raje/edithuman/'.$id));
        }
        else
       { 
          $this->itemCRUD->update_item_human($id);    
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_patient')); // itemcrudindex'));
        }
   }
//

// update human vendor

    public function updatehumanstock($id)
   {
          $this->itemCRUD->update_stock_human($id); // update_stock_human   
          redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_stock')); // itemcrudindex'));
   }

// update human vendor

    public function updatehumanvendor($id)
   {
          $this->itemCRUD->update_vendor_human($id); // update_stock_human   
          redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_vendor')); // itemcrudindex'));
//        }
   }

//
    public function updatehuman_photoupload($id)
   {
          $this->itemCRUD->update_item_human_photo($id);   
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_patient')); // itemcrudindex'));
    /*    } */
   }
  public function updateinjection($id)
   {
//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
        $this->form_validation->set_rules('approxprice', 'approxprice', 'required');
        $this->form_validation->set_rules('usedindisease', 'usedindisease', 'required');
        $this->form_validation->set_rules('remarks', 'remarks', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('errors', validation_errors());       
            redirect(base_url('index.php/Home_Dr_Raje/editinjection/'.$id));
        }
        else
       { 
           $this->injectionCRUD->update_item($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje//injectionlistmodify'));
        }
   }
   public function updatepetsinfo()
   { //  updatepetsinfo($id)

//die (" in home check");

//                                                      field         prompt
//      $this->form_validation->set_rules('field_name', 'Label', 'rule1|rule2|rul
//  remove        $this->form_validation->set_rules('ulusername', 'ulusername', 'required');
//        if ($this->form_validation->run() == FALSE)
//        {
//            $this->session->set_flashdata('errors', validation_errors());
// die (" in home check 1");
//            redirect(base_url('index.php/Home_Dr_Raje/petsdetails/'.$id));
//        }
//        else
//       { 

//echo $id;

 // die (" in home check");
 
          $this->itemCRUD->update_petshead();  // update_petshead($id);
         // redirect(base_url('itemCRUD'));
          redirect( base_url('index.php/Home_Dr_Raje/petsdetails'));
//        }
   }

 

 public function updatepetsdiagnose()
 { 
          $this->itemCRUD->update_petsdiagnose();  // update_petshead($id);
          redirect( base_url('index.php/Home_Dr_Raje/drdiagnosispet')); 
   }

 
   /**
    * Delete Data from this method.
    *
    * @return Response
   */
  public function userdelete($id)
   {
//echo "here";
       $item = $this->itemCRUD->delete_user_item($id);
    redirect( base_url('index.php/Home_AutoRenta/loginmaintaince'));
   }
  public function empdelete($id)
   {
 
       $item = $this->itemCRUD->delete_emp_item($id);
    redirect( base_url('index.php/Home_AutoRenta/empmaintain'));
   }
  public function custdelete($id)
   {
 
       $item = $this->itemCRUD->delete_cust_item($id);
    redirect( base_url('index.php/Home_AutoRenta/custmaintain'));
   }
 public function drrdelete($id)
   {
//echo "here";
       $item = $this->itemCRUD->delete_drr_item($id);
    redirect( base_url('index.php/Home_AutoRenta/drrmaintain'));
   }
 public function paydelete($id,$glcodecr,$glcodedr)
   {
//echo "here";
       if ($glcodecr == 0 and $glcodedr == 0 )
       {
       $item = $this->itemCRUD->delete_pay_item($id);
      $data['message_display'] = 'Record Deleteed Successfully  !';
       }
      else
       {
          $data['message_display'] = 'Record Not  Deleteed Successfully Contact Administrator  !';
        }
    redirect( base_url('index.php/Home_AutoRenta/paydatamaintaince'));
   }

   public function delete($id)
   {
       $item = $this->itemCRUD->delete_item($id);
       redirect( base_url('index.php/Home_Dr_Raje/itemcrudindex'));
   }
   public function deletehuman($id) // delete user
   {
       $item = $this->itemCRUD->delete_item($id);
       redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_patient')); // itemcrudindex'));
   }
   public function deletehumanstock($id) // delete  stock
   {
       $item = $this->itemCRUD->delete_stock($id);
       redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_stock')); // itemcrudindex'));
   }
   public function deletehumanvendor($id) // delete vendor
   {
       $item = $this->itemCRUD->delete_vendor($id);
       redirect( base_url('index.php/Home_Dr_Raje/human_patient_existing_vendor')); // itemcrudindex'));
   }
   public function deletepettype($id)
   {
       $item = $this->itemCRUD->delete_pettype($id);
 
       redirect( base_url('index.php/Home_Dr_Raje/petcrudindex'));

   }


 public function deleteinjection($id)
   {
       $item = $this->injectionCRUD->delete_item($id);
       redirect( base_url('index.php/Home_Dr_Raje/injectionlistmodify'));
   }

 public function getuseridfrompetid($id)
   {
         if ($id == 0 )
         {
              echo "here 0 ";
          }
        else
         {
              echo "here 1 ";
          }
         exit;

   }



// item crud from net end
// --------------------   HUMAN LOGIN STARTS -----

public function human_registration()
{
// echo " here -----------------------------------";
 
     $this->load->view('header_dr_raje_human');  
     $this->load->view('registration_form_human');
     $this->load->view('footer_dr_raje');
}

// naturopathy college clinic starts

public function Nature_Registration()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
 
         $this->load->view('header_dr_raje_nature');
         $this->load->view('Nature_Registration_');  
         $this->load->view('footer_dr_raje');

    }   
public function Nature_Maintenance()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
 
         $this->load->view('header_dr_raje_nature');
         $this->load->view('Nature_Maintenance_');  
         $this->load->view('footer_dr_raje');

    }   
public function Nature_report_upload()  
    {  
 
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
 
         $this->load->view('header_dr_raje_nature');
         $this->load->view('Nature_Report_');  
         $this->load->view('footer_dr_raje');

    }   

 public function human_patient_new_patient_nature()  
    {  
         $this->load->helper('url');
         $this->load->helper('security');  
         $this->load->library('form_validation');
         $this->load->view('header_dr_raje_nature');
         $this->load->view('registration_form_nature');  
         $this->load->view('footer_dr_raje');
    } 

// Validate and store registration data in database for human
public function new_nature_user_registration() 
{

//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
$this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form_human');
        $this->load->view('header_dr_raje_nature');
        $this->load->view('registration_form_nature');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'user_name' => $this->input->post('username'),
          'user_email' => $this->input->post('email_value'),
          'user_type'  => $this->input->post('user_type_value'),
          'user_password' => $this->input->post('password'),
          'pethuman' => $this->input->post('pethuman'),
          'clinicalid' => $this->input->post('clinicalid'),
          'nameofperson' => $this->input->post('nameofperson'),
          'ad1' => $this->input->post('ad1'),
          'ad2'  => $this->input->post('ad2'),
          'pincode' => $this->input->post('pincode'),
          'mobile1' => $this->input->post('mobile1'),
          'mobile2' => $this->input->post('mobile2'), /* new added */
          'gender' => $this->input->post('humangender'),
          'dateofbirth' => $this->input->post('birthdate'),
          'veg_non_veg_frequency' => $this->input->post('vegnonveg'),
          'placeofbirth' => $this->input->post('placeofbirth'),
          'allergyofany' => $this->input->post('allergyofany'),
          'sleepingtime' => $this->input->post('sleeptimings'),
          'getuptime' => $this->input->post('wakeuptimings'), 
          'soundsleep ' => $this->input->post('soundsleepoption'),
          'yoga_exercise' => $this->input->post('yogaactivities'),
          'waterdrinkinghabit' => $this->input->post('waterdrinkinghabits'),
          'lunch_dinner_timing' => $this->input->post('lunchtimings'),
          'dinner_timing' => $this->input->post('dinnertimings'),
          'daily_routine_1' =>    $this->input->post('daily_routine_1'),
          'daily_routine_2' =>    $this->input->post('daily_routine_2'),
          'physical_problem_1' => $this->input->post('physical_problems_1'),
          'physical_problem_2' => $this->input->post('physical_problems_2'),
          'medicines_list_1' => $this->input->post('medicine_list_1'),
          'medicines_list_2' => $this->input->post('medicine_list_2'),
          'medicines_list_3' => $this->input->post('medicine_list_3'),
          'bad_habit_1' => $this->input->post('bad_habits_1'),
          'bad_habit_2' => $this->input->post('bad_habits_2'),
          'about_delivery_1' => $this->input->post('about_delivery_1'),
          'about_delivery_2' => $this->input->post('about_delivery_2'),
          'bp_diabetics_level' => $this->input->post('bp_diabetic_level'),
          'diabetic_level' => $this->input->post('diabetic_level'),
          'which_milk_products_1' => $this->input->post('milk_product_consumption_1'),
          'which_milk_products_2' => $this->input->post('milk_product_consumption_2'),
          'gas_acidity_abdomen_1' => $this->input->post('gas_acidity_problem_1'),
          'gas_acidity_abdomen_2' => $this->input->post('gas_acidity_problem_2'),
          'reference' => $this->input->post('reference'),
          'occupation' => $this->input->post('occupation'),
          'whatupno1' => $this->input->post('whatupno1'),
          'whatupno2' => $this->input->post('whatupno2'),
          'enquirydetail1' => $this->input->post('enquiry1'),
          'enquirydetail2' => $this->input->post('enquiry2'),
          'followup1' => $this->input->post('followup1'),
          'followup2' => $this->input->post('followup2'),
          'hereditarydisease' => $this->input->post('heridieterydisease'),
          'registrationdate' => $this->input->post('registrationdate'),
          'patientphoto' => $this->input->post('patientphoto'),
          'weight' =>  $this->input->post('patientweight'),
          'height' => $this->input->post('patientheight'),
          'asthma_problem' =>  $this->input->post('asthma_problem'),
          'other_problem' => $this->input->post('other_problem'),
          'nadi_problem' => $this->input->post('nadi_problem'),
          'urine_issue' => $this->input->post('urine_issue'),
          'duration_disease_1' => $this->input->post('duration_diseases_1'),
          'duration_disease_2' => $this->input->post('duration_diseases_2'),
          'duration_disease_3' => $this->input->post('duration_diseases_3'),
          'duration_disease_4' => $this->input->post('duration_diseases_4'),
          'any_other_diseases_1' => $this->input->post('any_other_diseases_1'), 
          'any_other_diseases_2' => $this->input->post('any_other_diseases_2'),
          'any_surgeries_1' => $this->input->post('any_surgeries_1'),
          'any_surgeries_2' => $this->input->post('any_surgeries_2'),
          'any_surgeries_3' => $this->input->post('any_surgeries_3'),
          'emergency_contact_1' => $this->input->post('emergency_contact_1'),
          'emergency_contact_2' => $this->input->post('emergency_contact_2'),
          'family_member_disease_1' => $this->input->post('familydisease_1'),
          'family_member_disease_2' => $this->input->post('familydisease_2'),
          'anyreferencenameno1' => $this->input->post('anyreferencenameno1'),
          'anyreferencenameno2' => $this->input->post('anyreferencenameno2'),
          'anyreferencenameno3' => $this->input->post('anyreferencenameno3'),
          'anyreferencenameno4' => $this->input->post('anyreferencenameno4'),
          'any_information_1' => $this->input->post('any_information_1'),
          'any_information_2' => $this->input->post('any_information_2')
   );
   $result =   $this->NatureModel->registration_insert($data); //  $this->login_database->registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje_nature');
    $this->load->view('registration_form_nature',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Username already exist!';
     $this->load->view('header_dr_raje_nature');
     $this->load->view('registration_form_nature', $data);
     $this->load->view('footer_dr_raje');
  }
}
}




// new user human end

public function nature_admin_registration_show()
{
// echo " here -----------------------------------";

// $this->load->view('registration_form');
     $this->load->view('header_dr_raje_nature');
     $this->load->view('registration_form_nature_admin_');
     $this->load->view('footer_dr_raje');
}

public function new_user_registration_nature() 
{

//echo " i am here for validation ";
//die("vali");
// Check validation for user input in SignUp form
//                                                 field         prompt
$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
// $this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
$this->form_validation->set_rules('user_type_value', 'user_type_value', 'trim|required|xss_clean');
if ($this->form_validation->run() == FALSE) 
{
 //     $this->load->view('registration_form');
        $this->load->view('header_dr_raje_nature');
        $this->load->view('registration_form_nature_admin_');
        $this->load->view('footer_dr_raje');
}
 else
{ // user type added
    $data = array(
          'user_name' => $this->input->post('username'),
          'user_email' => $this->input->post('email_value'),
          'user_type'  => $this->input->post('user_type_value'),
          'user_password' => $this->input->post('password'),
          'pethuman' => $this->input->post('pethuman'),
          'nameofperson' => $this->input->post('nameofperson'),
          'ad1' => $this->input->post('ad1'),
          'ad2'  => $this->input->post('ad2'),
          'pincode' => $this->input->post('pincode'),
          'mobile1' => $this->input->post('mobile1'),
          'mobile2' => $this->input->post('mobile2')
   );
   $result = $this->NatureModel->registration_insert($data);
  if ($result == TRUE) 
  {
     $data['message_display'] = 'Registration Successfully !';
   //  $this->load->view('login_form', $data);
    $this->load->view('header_dr_raje_nature');
    $this->load->view('registration_form_nature_admin_',$data); // admin_page_');
    $this->load->view('footer_dr_raje');

  }
  else 
 {
     $data['message_display'] = 'Username already exist!';
     $this->load->view('header_dr_raje_nature');
     $this->load->view('registration_form_nature_admin_', $data);
     $this->load->view('footer_dr_raje');
  }
}
}




}// end of class Home_Dr_Raje  extends CI_Controller 
?>