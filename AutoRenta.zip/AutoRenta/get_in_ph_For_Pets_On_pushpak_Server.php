<?php
// FOR PETS ADD LATER
   $uname = $_GET['username'];
   $upass = $_GET['password'];
   $d1 = $_GET['usertype'];
   
//  echo $uname . "<br>";
//  echo $upass . "<br>";
//  echo $d1 . "<br>";
  // $utype = $_GET['usertype'];
   $json = array();
   $db_host =  "207.174.212.181" ; // "localhost";   
   $db_username = "pushpzii_root"; // "root";   
   $db_pass =  "Pdg_Admin@1234"; // '';    
   $db_name =  "pushpzii_pushpzii_ct"; // "demo";  
   $con = new mysqli($db_host, $db_username, $db_pass, $db_name);  
   if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 
   $rowcount = 0;
   $con = new mysqli($db_host, $db_username, $db_pass, $db_name);  
   $sql = "SELECT * FROM signup where username='$uname' and password='$upass'"; 
   // echo $sql;
   if ($result = mysqli_query($con,$sql)) 
   {
      $rowcount = mysqli_num_rows($result); 
     // echo "<br>" . " nos " . $rowcount . " == ";
      if ($rowcount > 0) 
      { 
        // echo "<br>". " in ";
        while($row[] = $result->fetch_assoc()) 
        {
 	        $json = json_encode($row);
        }
        echo $json;
      } 
      else 
      {          
         $json="0 results";
         echo  "0 results";
      }
   }
$con->close();
?>  