<?php 
session_start();   
global $fld1;
$lbltxt = " ";
$custaddress = ''; 
$formorderid =0;
$lblcorrect = "false";   
$formnewcustname = '';
$formnewcustaddress = '';
$formnewcustpin = '';
$formnewfunaddress = '';
$formnewfuncpin = ''; 
$formnewquotno = '';
$formnewquotdate = '';
$formneworderno = '';
$formneworderdate = '';  
$wmaxid = "0";
global $neworderid ;
global $formsrno;
$neworderid="0";
$fld1 = 0;
$custpin = '';
$myerror = 'FALSE';

 
//    $id = $_POST["getaddress"];
 //   echo "The id is ".id;
 


/*
$db_host = "localhost"; 
$db_username = "root"; 
$db_pass = "admin@123"; 
$db_name = "santosh_decorates_database"; 
$con=mysql_connect("$db_host","$db_username","$db_pass") or die ("could not connect to mysql");
mysql_connect("$db_host","$db_username","$db_pass") or die ("could not connect to mysql");
mysql_select_db("$db_name")  or die ("no database");  
*/

$db_host = $_SESSION['global_db_host']; // "localhost"; 
$db_username = $_SESSION['global_db_username'];  // "root"; 
$db_pass = $_SESSION['global_db_pass']; // "admin@123"; 
$db_name =  $_SESSION['global_db_name']; // "santosh_decorates_database"; 

$con=mysql_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
mysql_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
mysql_select_db("$db_name")  or die ("no database"); 


function newaddress()
{
// echo "here";
// if (isset($_POST['getaddress'])) // Get Address']))
// {
   if(array_key_exists('getaddress',$_POST))
   {
    

 //  echo "in";
    $fld1 = $_POST["wcname"];
 //   echo $fld1;
	$result = mysql_query("Select * from customermaster where customerid = " . $fld1);
	while($row = mysql_fetch_array($result))
    {
    $custaddress =  $row['2'] ."\n"   . $row['3'] ."\n"   . $row['4'] ."\n"    . $row['5']  ;
//	echo $row['6'];
	if ($row['6'] == '')
	{
	   $custpin = '';
	}
	else
	{
	$custpin = 'Pin code:-' . $row['6'];
	}
	
//	echo $custaddress;
    }
}

//echo "out";

}

function convert_number_to_words($number) 
{
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
 // return $result . "Rupees  " . $points . " Paise";
  return "Rupees  " . $result . " only." ; //  . "Rupees  " . $points . " Paise";

}

 
 
if ($_SESSION['User'] === '' )
{
  echo "<html><head> <title> Alert </title> <script> alert('Not Allowed without proper Login System.. '); </script> </head> <body> </body> </html>";
  echo '<br> <br><font color="red"><marquee> <h2> Not Allowed Without Proper Login System </h2> </marquee> </font>';
  return;
} 
$xcompid =   $_SESSION['CompanyID'];

// echo $xcompid;
//if (isset($_POST['grandtotal']))
//{
//exec('notepad.exe');
//  system("notepad.exe "  . "in_php_notepad.txt");
//}

if (isset($_POST['new']))
{
  $_SESSION['global_orderid']=0;
}

if (isset($_POST['print']) or isset($_POST['quotation']) )
{
// LOGIC FROM ORDER_CUM_INVOICE IN SAVE STARTS
// print start

//if (isset($_POST['print']) or isset($_POST['quotation']) )
//{
  $fldinvoicenumber = (int)$_POST["invoicenumber"]; // $formorderno; // 
  $myerror = 'FALSE';
  $fldwquot_no = $_POST['wquot_no'];
  $fldwquot_dt = $_POST['wquot_dt'];
  if (isset($_POST['print']) )
  {
  if ($fldinvoicenumber <= 0 )
  {
    echo "<html><head> <title> Alert </title> <script> alert('Not Allowed to print without Invoice Number (Generate Invoice).. '); </script> </head> <body> </body> </html>";
    $myerror = 'TRUE'; 
  }
  }
  if ($myerror == 'FALSE')
  {
  $formwid = $wmaxid ; // $_POST["wid"];
  $compname = substr($_SESSION['CompanyName'],0,2);
  $finyear = $_SESSION['fy'];
  $formcompanyid = $_SESSION['CompanyID'];
  $sqlgetinvoice = "Select * from companymaster where companyid = " . $formcompanyid;
  $result = mysql_query($sqlgetinvoice);
  while($row = mysql_fetch_array($result))
  {
     $printname = $row['1'];
     $printinvoice = $row['33'];
	 $printpanno = $row['36'];
	 $printadr = $row['2']. ' ' . $row['3'] . ' ' . $row['4'] . ' ' . $row['5'] . ' '.$row['6'];

     $printadr1 = $row['2'];
     $printadr2 = $row['3'];
     $printadr3 = $row['4'];
     $printadr4 = $row['5']. ' ' . $row['6'] ;
	 

	 $printl1 = $row['7'];
	 $printl2 = $row['8'];	
	 $printl3 = $row['9'];	 

	 $printl4 = $row['10'];
	 $printl5 = $row['11'];	
	 $printl6 = $row['12'];
	 
	 $printl7 = $row['13'];
	 $printl8 = $row['14'];	
	 $printl9 = $row['15'];
	 
	 $printl10 = $row['16'];
	 $printl11 = $row['17'];	
	 $printl12 = $row['18'];
	 
	 $printl13 = $row['19'];
	 $printl14 = $row['20'];	
	 $printl15 = $row['21'];
	 
	 $printl16 = $row['22'];
	 $printl17 = $row['23'];	
	 $printl18 = $row['24'];
	 
	 
     $printwebsite = $row['38'];
     $printemailid = $row['39'];	 

	 
	 $printl19 = $row['25'];
	 $printl20 = $row['26'];	

  }  
  $filename = $compname . '_' . $finyear. "_". $formwid .'.html';
//echo $filename;
  $myfile = fopen($filename, "w") or die("Unable to open file!");
  $txt = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">'. '<br>' . '<html>';
  fwrite($myfile, $txt);
  
// here
  $txt = '<head>' . '<br>'. '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
  fwrite($myfile,$txt);
  $txt = '<style type="text/css" media="print, handheld">';
  fwrite($myfile,$txt);
  $txt = 'h1 { background-color: #6495ed; }';
  fwrite($myfile,$txt);
  $txt = 'p { background-color: #e0ffff; }';
  fwrite($myfile,$txt);
  $txt = 'div {     background-color: #b0c4de; }';
  fwrite($myfile,$txt);
  $txt = '.footer { bottom: 0; left: 0; background-color: white; width: 100%; font-size:.3em;  font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }';
  fwrite($myfile,$txt);
  $txt ='.footerInner p{     font-size:1.3em; font-weight:bold; font-family:Verdana, Geneva, sans-serif; padding:  10px 0; }';
  fwrite($myfile,$txt);
  $txt = '</style>';
  fwrite ($myfile,$txt);
  $txt='</head>';
  fwrite($myfile,$txt);
  $txt = '<body bgcolor="#E6E6FA">';
  fwrite($myfile, $txt);
  $txt = '<font face="Verdana"><font size=3>';
  fwrite($myfile, $txt);
//  $txt = '<center>';
 // fwrite($myfile, $txt); 
 
 // first invoice start
  
  $txt = '<table border="0"><tr><td>';  // with border line border="1"
  fwrite($myfile, $txt);
  
  $txt = '<table border="0" width="890px"><tr>';  // if with image <td width="300px">';
// logo image  $txt .= '<img src="satyasaient_logo_jpg.jpg" width="100px" height="50px"></img>'. '</td><td width="620px">'.$printname . '<br>' . $printadr  . '</td></tr>';
//  $txt .= '&nbsp;'. '</td><td width="620px"> if with image '.$printname . '<br>' . $printadr  . '</td></tr>';
// kvsons_logo_png.png  // old name K_V_SONS_LOGO.jpg

// logo center  $txt .= '<td width="440" align="left">'. '<font face="Cooper Black" size="5"> ' . strtoupper($printname) . '</font>' . '</td><td width="100" align="center"><img src="kvsons_logo_png.png"></td><td width="350" align="left">'. '<b>' . $printinvoice . '</b>' . '</td></tr>';
// this is with logo  $txt .= '<td width="440" align="left"><img src="kvsons_logo_png.png">' . '</td><td width="100" align="center"></td><td width="350" align="left">'. '<b>' . $printinvoice . '</b>' . '</td></tr>';

  $txt .= '<td width="440" align="left">'. '<font face="Cooper Black" size="6"> ' . strtoupper($printname) . '</font>' . '</td><td width="100" align="center"></td><td width="350" align="CENTER">'. '<font face="Book Antiqua" size="5"> <b>' . $printinvoice . '</b></font>' . '</td></tr>';

//  $txt .= '<td width="440" align="left">'. '<font face="Cooper Black" size="5"> ' . strtoupper($printname) . '</font>' . '</td><td width="100" align="center"></td><td width="350" align="left">' . '</td></tr>';

// remove   $txt .= '<td width="80" align="right"><img src="K_V_SONS_LOGO.jpg"></td>'; '<hr style="margin:0">' 

// remove  $txt .= '<td  align="center" width="840px">'.   '<font face="Cooper Black" size="8"> ' . strtoupper($printname) . '</font>' . '<br>' . $printadr . '<hr style="margin:0">' . '</td></tr>';

  fwrite($myfile,$txt); // satyasaient_logo_jpg.jpg '' <br>' . $printadr.
  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' .$printadr1 . '</font>' .   '</td><td width="100" align="center"></td><td width="350" align="left">'. '<b>Invoice No :- '  . $fldinvoicenumber .  '</b>' . '</td></tr>';
  fwrite($myfile,$txt); 
  $printcname = trim($_POST["customername"]);
  if (strlen($printcname) < 70)
  {
      $gap = str_repeat("&nbsp;",  70-strlen($printcname));
  }

  $printaddress1 = $_POST["wcadd1"]; // trim($_POST["wcadd1"]);
  $printaddress = explode("~",$printaddress1);
  $printfuncadd = trim($_POST["wfaddress"]);
  $printwfdate = $_POST["wfdate"];
  
  $printnameofwork = $_POST["nameofwork"];
  $printadvance_rs = $_POST["advance_rs"];
  $printmaterial_payment_rs = $_POST["material_payment_rs"];
  $printprint_advance = $_POST["print_advance"];
  $printprint_material_payment = $_POST["print_material_payment"];
    
  
  $prad1 = $printaddress[0]; // substr($printaddress,0,30);
  $prad2 = $printaddress[1]; // substr($printaddress,30,30);
  $prad3 = $printaddress[2]; // substr($printaddress,60,30);
  $prad4 = $printaddress[3]; // substr($printaddress,90,30);

  $printpin = $_POST["wpin"];
  $printinvdate = $_POST["winvoice_dt"];
  
  $printinvdate = date("d-m-Y", strtotime($printinvdate));

  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' .$printadr2 . '</font></td><td width="100" align="center"></td><td width="350" align="left">Invoice Date :- '  . $printinvdate . '</td></tr>';
  fwrite($myfile,$txt); // $printcname
//  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' .$printadr3 . '</font></td><td width="100" align="center"><font face="Verdana" size="3"><b>Billing To,</b></font></td><td width="350" align="left"> ' . $printcname . '</td></tr>';
  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' .$printadr3 . '</font></td><td width="100" align="center"></td><td width="350" align="left"> ' .'<font face="Verdana" size="4"><b>Billing To,</b></font>'.   '</td></tr>';
  fwrite($myfile,$txt); //$prad1
  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' .$printadr4 . '</font></td><td width="100" align="center"></td><td width="350" align="left">' . $printcname  . '</td></tr>';
  fwrite($myfile,$txt); //$prad1

  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">Email ID: ' . $printemailid . '</font></td><td width="100" align="center"></td><td width="350" align="left">' .  $prad1 . '</td></tr>';
  fwrite($myfile,$txt); //$prad1  
 
 
  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">Web Site: ' . $printwebsite . '</td><td width="100" align="center"></td><td width="350" align="left">' . $prad2 . '</td></tr>';
  fwrite($myfile,$txt); //$prad2
 
  if ($prad3 == '' )
  {
  }
  else
  {  
  $txt = '<tr><td width="440" align="left"></td><td width="100" align="center"></td><td width="350" align="left">' . $prad3 . '</td></tr>';
  fwrite($myfile,$txt); //$prad3
  }
  if ($prad4 == '')
  {
  }
  else
  {  
  $txt = '<tr><td width="440" align="left"></td><td width="100" align="center"></td><td width="350" align="left">' . $prad4 . '</td></tr>';
  fwrite($myfile,$txt); //$prad4
  }
  if ($printpin == '')
  {
  }
  else
  {
  $txt = '<tr><td width="440" align="left"></td><td width="100" align="center"></td><td width="350" align="left">' . $printpin . '</td></tr>';
  fwrite($myfile,$txt); //$printpin
  }
  
  $txt = '<tr><td width="440" align="left"><font face="Book Antiqua" size="3">' . '</font></td><td width="100" align="center"></td><td width="350" align="left"><b>NAME OF WORK : ' .  $printnameofwork  . '</b></td></tr>';
  fwrite($myfile,$txt); //$prad1  
 
  
 // Invoice Date:</td><td>'.$printinvdate 
  
  $txt = '</table>';
  fwrite($myfile,$txt);  // 920

  $txt = '<table border="0" width="890px"><tr><td width="920px" align="center">';
  fwrite($myfile,$txt);  
//  if (isset($_POST['save']) ) // or isset($_POST['quotation']) )
 // {
  //    $txt .= '<b>' . $printinvoice . '</b>' . '</td></tr></table>';
//  }
//  fwrite($myfile, $txt);


//  $txt = "<br>";
//  fwrite($myfile, $txt);
  $gap = "&nbsp;";
//  $txt = '<table border="0" style="width=920px"><tr><td>';  
 // $txt .='To,</td></tr>';
 // fwrite($myfile, $txt); /// customername
  $printcname = trim($_POST["customername"]);
  if (strlen($printcname) < 70)
  {
      $gap = str_repeat("&nbsp;",  70-strlen($printcname));
  }
//  echo $gap;
//echo $printcname;
//die ("here");
 

  $printaddress1 = $_POST["wcadd1"]; // trim($_POST["wcadd1"]);
  $printaddress = explode("~",$printaddress1);
 
 
  
  
  $prad1 = $printaddress[0]; // substr($printaddress,0,30);
  $prad2 = $printaddress[1]; // substr($printaddress,30,30);
  $prad3 = $printaddress[2]; // substr($printaddress,60,30);
  $prad4 = $printaddress[3]; // substr($printaddress,90,30);

 


//  $printaddress = $_POST["wcadd1"]; // trim($_POST["wcadd1"]);
//echo $printaddress;
//die("ghh");
  $printfuncadd = trim($_POST["wfaddress"]);
  $printwfdate = $_POST["wfdate"];
  
//echo $prad1 . $prad2 . $prad3 . $prad4;
//echo $prad2;
//die("ghh");
  $printpin = $_POST["wpin"];
  $printinvdate = $_POST["winvoice_dt"];
  if (isset($_POST['save']) )
  {
// $txt = '<tr><td style="width=500px">' . $printcname . $gap . ',</td> <td style="width: 3px"> &nbsp&nbsp; </td><td> </td> <td>'. '</td></tr>';
// fwrite($myfile, $txt); 
// $txt ='<tr><td style="width=500px">'.$prad1. '</td><td style="width=3px">&nbsp;&nbsp;</td><td></td><td>'. "</td></tr>";
// fwrite($myfile, $txt);   
  }
  if ($prad2 == '')
  {
  }
  else
  {
//  $txt = '<tr><td style="width=500px">'.$prad2.'</td><td style="width=3px"> &nbsp&nbsp; </td><td></td><td style="width: 150px">'. "</td></tr>";
//  fwrite($myfile, $txt); 
  }
  if ($prad3 == '' )
  {
  }
  else
  {  
//  $txt = '<tr><td style="width=500px">'.$prad3.'</td><td style="width=3px"> &nbsp&nbsp; </td><td></td><td>'. "</td></tr>";
//  fwrite($myfile, $txt); 
  }
  if ($prad4 == '')
  {
  }
  else
  {  
//  $txt = '<tr><td style="width=500px">'.$prad4.'</td><td style="width=3px"> &nbsp&nbsp; </td><td>&nbsp&nbsp; </td></tr>';
 // fwrite($myfile, $txt); 
  }
  if ($printpin == '')
  {
  }
  else
  {
//  $txt = '<tr><td style="width=500px">'.$printpin.'</td><td style="width=3px"> &nbsp&nbsp; </td><td>&nbsp&nbsp; </td></tr>';
 // fwrite($myfile, $txt) ;
  }
//  $txt="</table>";
//  fwrite($myfile, $txt);
 
//  $txt='<hr style="margin:0">';
//  fwrite($myfile, $txt); 
  $fldremarks1 = $_POST["remarks1"];
  $fldremarks2 = $_POST["remarks2"];
  /*
  $txt = '<table border="0" width="920px"><tr><td width="150px">Remarks : </td> ';
  $txt .= '<td width="820px">' . $fldremarks1 . ' </td></tr>';
  fwrite($myfile, $txt);  
  if ($fldremarks2 == '')
  {
  }
  else
  {
  $str =  str_repeat('&nbsp;', 15); // adds 45 spaces
  $txt = '<tr><td width="150px"> </td><td width="820px"> ' ;
  $txt .=  $fldremarks2 . '</td></tr></table>';
  fwrite($myfile, $txt);  
  }
  */
  $txt='<table border="1" width="890px">';  // 920
  fwrite($myfile, $txt);  // 180 + 
  $txt ='<tr><td width="30">Sr.No</td><td width="150">Description</td><td width="40">Rate</td><td width="50">Unit</td><td width="50">Qty</td><td width="80">Amount</td></tr>';
  fwrite($myfile, $txt); 
  
// start invoice details GOLE
  $formorderid = $_POST["printheadid"] ; // original $wmaxid; // $_POST["newmyid"]; // $_POST["myid"];
 // echo "formorderid = " . $formorderid;
  $sqlgetparticulars = "Select * from order_cum_invoice_detail where headID = " . $formorderid ;
  $result = mysql_query($sqlgetparticulars);
// echo $sqlgetparticulars;
  $srnoi = 0;
  while($row = mysql_fetch_array($result))
  {
	$srnoi++;
    $txt = "<tr><td>".$row['3']."</td>";
	$txt .='<td style="width: 150px">'.$row['13'].'</td>'; 
	$txt .='<td align="right">'.$row['12']."</td>";
	$txt .="<td>".$row['11']."</td>";
	$txt .='<td align="right">'.$row['10']."</td>";
	$txt .='<td align="right">'.round($row['14'],0)."</td></tr>";				  
    fwrite($myfile, $txt);
   }
   $txt = "</table>";
   fwrite($myfile, $txt); 
   if ($srnoi > 21 )
   {
   }
   else
   {
     $txt = '';
     while ($srnoi <= 20 )
	 {
	    $txt .= '<br>';
		$srnoi++;
	 }
	 fwrite($myfile, $txt); 
   }
   $txt='<table border="0" width="890px">'; // 920
   fwrite($myfile, $txt);  
//   $txt ='<tr><td width="30">&nbsp;</td><td width="200">&nbsp;</td><td width="40">&nbsp;</td><td width="50">&nbsp;</td><td width="50">&nbsp;</td><td width="80">&nbsp;</td></tr>';
//   fwrite($myfile, $txt); 
   $fldtotal = $_POST["wtotal"];
   $fldtransport = $_POST["transport"];
   $formGrand_Rs = $_POST["wgtotal"];  
   $formservice_amt = $_POST["service_amt"];
   $formvat_amount = $_POST["vat"];
   $formvat_pec = $_POST["vat_perc"];
   $formswbharat_rs = $_POST["swbharat_rs"];
   $formkrishikalyan_rs = $_POST["krishikalyan_rs"];
   $formnotallowed = $_POST["notallowed"];
   $formstaxperc = $_POST["service_perc"];
   $formswbharat = $_POST["swbharat_perc"];
   $formkrishi_kalyan_cess = $_POST["krishikalyan_perc"];
   $txt = '<tr><td> &nbsp;</td> <td style="width: 200px"> &nbsp; </td>';
   $txt .= '<td> Total Rs </td> <td> &nbsp; </td><td> &nbsp; </td>';
   $txt .= '<td align="right">'. round($fldtotal,0) . '</td></tr>';
   fwrite($myfile, $txt);  
   if ($fldtransport > 0 )
   {
   $txt = '<tr><td> &nbsp;</td> <td style="width: 150px"> &nbsp; </td>';
   $txt .= '<td> Transport Rs </td> <td> &nbsp; </td><td> &nbsp; </td>';
 
   $txt .= '<td align="right">'. round($fldtransport,0) . '</td></tr>';
   fwrite($myfile, $txt);   
   } 
// print advance and  material 
// echo "here"   ;

   if ($printprint_advance == "YES")
   {
   $txt = '<tr><td> Less  : </td><td style="width:350px">Advance Paid ' ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td>';
   $txt .= '<td align="right">' . round($printadvance_rs,0). '</td> </tr>';
   fwrite($myfile, $txt); 
   }
   if ($printprint_material_payment == "YES")
   {
   $txt = '<tr><td> Less  : </td><td style="width:350px">Material Payment by client ' ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td>';
   $txt .= '<td align="right">' . round($printmaterial_payment_rs,0). '</td> </tr>';
   fwrite($myfile, $txt); 
   }

   if ($formvat_amount > 0 )
   {
   $txt = '<tr><td> Add : </td><td style="width:350px">VAT @ ' . $formvat_pec . "%" ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td>';
   $txt .= '<td align="right">' . round($formvat_amount,0). '</td> </tr>';
   fwrite($myfile, $txt);  
   }     
   if ($formstaxperc > 0 )
   {
   $txt = '<tr><td> Add : </td><td style="width:350px">Service tax ' . $formstaxperc . "%";
   if ( $formnotallowed > 0 )
   {
      $txt .= '&nbsp;' . $formnotallowed . '%'  ;
   }
   $txt .=  ''; // ' on ' . 'Rs.' . round($fldtotal,0) ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td>';
   $txt .= '<td align="right">' . round($formservice_amt,0) . '</td> </tr>';
   fwrite($myfile, $txt);  
   }
   if ($formswbharat_rs > 0 )
   {
   $txt = '<tr><td> Add : </td><td style="width:350px">SWATCH BHARAT CESS @ ' . $formswbharat ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td>';
   $txt .= '<td align="right">' . round($formswbharat_rs,0). '</td> </tr>';
   fwrite($myfile, $txt);  
   }
   if ($formkrishikalyan_rs > 0 )
   {
   $txt = '<tr><td> Add : </td><td style="width:350px">KRISHI KALYAN CESS @ ' . $formkrishi_kalyan_cess ;
   $txt .= '</td>';
   $txt .= '<td> </td> <td> </td> <td> &nbsp; </td> ';
   $txt .= '<td align="right">' . round($formkrishikalyan_rs,0). '</td> </tr>';
   fwrite($myfile, $txt);  
   } 
   if ($formGrand_Rs > 0 )
   {
   if ($printprint_advance == "YES")
   {
       $formGrand_Rs = $formGrand_Rs - $printadvance_rs ;
   }
   if ($printprint_material_payment == "YES")
   {
       $formGrand_Rs = $formGrand_Rs - $printmaterial_payment_rs ;
   }
   $txt = '<tr><td> </td><td style="width:350px">'   ;
   $txt .= '</td>';
   $txt .= '<td> <b>Grand Total Rs </b>  </td> <td> </td><td> &nbsp; </td>  ';
   $txt .= '<td align="right">' . round($formGrand_Rs,0). '</td> </tr>';
   fwrite($myfile, $txt);  
   } 
  $txt ="</table>";
  fwrite($myfile, $txt);
  $txt='<table border="0" width="890px"><tr><td style="width:1px"> &nbsp;</td><td style="width:889px">';
  fwrite($myfile, $txt);  
//$txt = '<b>' . ucfirst(convert_number_to_words(round($formGrand_Rs, 0))) . '</td></tr>';
  $txt = '<b> ' . strtoupper(convert_number_to_words(round($formGrand_Rs, 0))) . ' </td></tr>';
  fwrite($myfile,$txt);
  $txt = "</table>";
  fwrite($myfile,$txt); // after amount in words under line
  $txt='<table border="0" width="890px"><tr><td style="width:890px"><hr style="margin:0"></td></tr></table>'; 
  fwrite($myfile,$txt);
  $txt ='<table border="0" width="890px"><tr><td style="width:500px"><b>E&OE </b>'.'</td><td style="width:370px"><b> For ' . $printname . '</b> </td></tr>';
  fwrite($myfile,$txt);
  $txt = '</table>';
  fwrite($myfile,$txt); 
  
  $txt='<table border="0" width="890px">';   
  fwrite($myfile,$txt);
  if (isset($_POST['print'])) // 'save' or isset($_POST['quotation']) )
  {
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl1 . '</font>' .  '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);

  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl2 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl3 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
//  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . $printl4 . '</font>' . '</td><td style="width:370px"> For ' . $printname . ' </td></tr>';
//  fwrite($myfile,$txt);

  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl4 . '</font>' . '</td><td style="width:370px"><b> PRORIETOR/AUTHORISED SIGNATORY</b> </td></tr>';
  fwrite($myfile,$txt);
  
  
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl5 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl6 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl7 .  '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl8 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl9 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl10 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  . $printl11 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:500px">' . '<font size=1.5>'  .  $printl12 . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  }
  else
  {
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; ' . '</font>' .  '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);

  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . ' &nbsp;&nbsp;'  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . ' &nbsp;&nbsp;'  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . ' &nbsp;&nbsp;'  . '</font>' . '</td><td style="width:370px"> For ' . $printname . ' </td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . ' &nbsp;&nbsp;'  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; ' .  '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"> PRORIETOR/AUTHORISED SIGNATORY</td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  . '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  $txt = '<tr><td style="width:550px">' . '<font size=1.5>'  .  '&nbsp;&nbsp; '  . '</font>' . '</td><td style="width:370px"></td></tr>';
  fwrite($myfile,$txt);
  
  }
  $txt = '</table>';
  fwrite($myfile,$txt);
  $txt='<table border="0" width="890px">'; 
  fwrite($myfile,$txt);
  $txt ='<tr><td align="left"> <font face="Verdana" size="3"><b>Payment Details </b> </font></td> <td> <font face="Verdana" size="3"><b>Tax Details </b></font> </td></tr>';
  fwrite($myfile,$txt);
// nw
  $txt = '<tr><td> BANK : State Bank of India </td><td> Pan No : AADPQ8107D </td></tr>';
  fwrite($myfile,$txt);

  $txt = '<tr><td> A/C No : 64029846705 </td><td> Service Tax : AADPQ8107DSD001 </td></tr>';
  fwrite($myfile,$txt);
  
  $txt = '<tr><td> IFSC Code : SBMY0040368 </td><td> VAT Tin  No : 27681480473C </td></tr>';
  fwrite($myfile,$txt);
 
  $txt = '<tr><td>  </td><td> ESIC  No : 35000390810000999 </td></tr>';
  fwrite($myfile,$txt); 

// mw over  
 
  
  $txt = '</table>'; // new added to put border
  fwrite($myfile,$txt);      
  
 // $txt = '<tr><td colspan="2">Should You have any enquiries concerning this INVOICE please contact on 9833951545 </td></tr>';
 // fwrite($myfile,$txt);   
  
  
  $txt = '</table>';
  fwrite($myfile,$txt);    
  $txt ="</td></tr></table>"; // last border line
  fwrite($myfile, $txt);
  $txt = '<b>Should You have any enquiries concerning this INVOICE please contact on 9833951545 </b>';
  fwrite($myfile,$txt);  

 
// first invoice over
 
   
  
 // $txt="</center>";
 // fwrite($myfile, $txt);
  $txt="</body>";
  fwrite($myfile, $txt);
  $txt = "</html>";
  fwrite($myfile, $txt);
  fclose($myfile);
  $txt =   $filename ; // 'http://localhost/pushpakagency.com/admin/'. $filename;
// here
   ?>
   <a href=" <?php echo $txt; ?>">  Open Invoice .. (<?php echo $txt ?>)  </a>  <br><br>
   <?php  
   }

  
//$notepad="wordpad.exe " . $filename; // somefile.txt ";
 // exec('c:\windows\wordpad.exe');
//exec('start /b ' . $notepad  );
//system("notepad.exe ".$filename);

//    exec("notepad", $output, $return);
 //   echo "The command returned $return, and output:\n";
 //   echo "<br><pre>";
 //   var_dump($output);
 //   echo "</pre>";

//}
 


// print end 	

// LOGIC FROM ORDER CUM INVOICE IN SAVE ENDS


  
//$notepad="wordpad.exe " . $filename; // somefile.txt ";
 // exec('c:\windows\wordpad.exe');
//exec('start /b ' . $notepad  );
//system("notepad.exe ".$filename);

//    exec("notepad", $output, $return);
 //   echo "The command returned $return, and output:\n";
 //   echo "<br><pre>";
 //   var_dump($output);
 //   echo "</pre>";

}
 

if (isset($_POST['invoice']))
{
//   echo "invoice";

	$formcy = $_SESSION['fy'];
 
	$formcompanyid = $_SESSION['CompanyID'];
    $myerror = 'FALSE';
    $formorderid = (int)$_POST["newmyid"]; // (int)$_POST["myid"];

	$forminvoicedate = $_POST["winvoice_dt"];
	$forminvoicenumber = (int)$_POST["invoicenumber"];
	
//echo "order " .  $formorderid;
//echo "<br>" . " inv no " . $forminvoicenumber;
 	
	if ($forminvoicenumber == 0 )
	{
//	echo $formorderid; 
//	echo "<br>" . "inv date " . $forminvoicedate  ;
	if ($formorderid  == 0  || $formorderid == -99)
	{
	 echo "<html><head> <title> Alert </title> <script> alert('Save Record First.. '); </script> </head> <body> </body> </html>";
     $lbltxt ="First Save Record Before INVOICE GENERATION ..... ";
	 $myerror = "TRUE";
//	 return;
	}
	if ($forminvoicedate == '')
	{
	 echo "<html><head> <title> Alert </title> <script> alert('Save Record First with Invoice Date.. '); </script> </head> <body> </body> </html>";
     $lbltxt ="First Save Record  with INVOICE Date ..... ";
	 $myerror = "TRUE";
    }
	if ($myerror == "TRUE")
	{
		 echo "<html><head> <title> Alert </title> <script> alert('Record annot be Saved Wrong Invoice No, Date.. '); </script> </head> <body> </body> </html>";
         $lbltxt ="First Save Record  with INVOICE Date ..... ";

	}
	else
	{
    $result = mysql_query("SELECT max(order_no) as maxorderno  FROM last_order_no where companyid = " . $formcompanyid . " and fy = '" . $formcy . "'"     );
	while($row = mysql_fetch_array($result))
    {
	    if ($row['0'] > 0 )
		{
            $formorderno  =  $row['0'] + 1;
		}
		else
		{
	    	$formorderno = 1;
		}
    }

//


	$sqllastorderno ="Update last_order_no  set Order_NO = ". $formorderno . " , OrderDate = '" .  $forminvoicedate . "'  where  companyid =" . $formcompanyid . " and fy = '" . $formcy . "'" ;
//	echo $sqllastorderno;	
    $retval = mysql_query($sqllastorderno,$con);
 
	
// here


	
    $sqlorder = "Update order_cum_inv_head set orderno = " . $formorderno  . ", orderdate = '" . $forminvoicedate . "' " .  " where id = " . $formorderid ;
	$retval = mysql_query($sqlorder,$con);

//echo $sqlorder;
//echo "<br>" . $formorderid ;

//	here ends
	
	echo "<html><head> <title> Alert </title> <script> alert(' Record   Inserted In the System.. '); </script> </head> <body> </body> </html>";
  
	} //  formorderid
	} 


//	
	
	
}

if (isset($_POST['change_save'])) // update save
{
   $formorderid = $_POST["orderid"];
   if ($formorderid == -99) 
   {   
       echo "<html><head> <title> Alert </title> <script> alert('Please select Order ID Properly.. '); </script> </head> <body> </body> </html>";
   }
   echo $formorderid;
}
if (isset($_POST['submit'])) // modify   
{
$_SESSION['global_orderid'] = 0;
$formorderid = $_POST["orderid"];
if ($formorderid == -99) 
{   
  echo "<html><head> <title> Alert </title> <script> alert('Please select Order ID Properly.. '); </script> </head> <body> </body> </html>";
}

}
if (isset($_POST['save'])) // save   
{ 
    $lblcorrect = "true";
    $formid = $_POST["wid"];   
    $formcname = $_POST["wcname"];	
	
//	echo $formid;
//	echo $fld1;
	
	
	$formcustomer_code =   $_POST["customer_code"]; // customer_code
//echo "<br> cc " . $formcustomer_code . "<br>" ;

	$formquotno = 0;
//	$formorderid = $_POST["orderid"];
//echo "cust code "  . $formcustomer_code ;

    $formorderid = (int)$_POST["newmyid"];  $_POST["myid"];// most important field 

//echo $formorderid;	// check
	
	
	$formcustomername  = "";
	$formcy = $_SESSION['fy'];
	$formcompanyname= "";
	$formwmaxid = 0;
	$wmaxid = 0;
	$formcompanyid = $_SESSION['CompanyID'];
	$formfuncdate = $_POST["wfdate"];
	$formfadd  = $_POST["wfaddress"];
	$sqlcompanyname = "Select * from companymaster where companyid = " . $formcompanyid ;
    $result = mysql_query($sqlcompanyname);
    while($row = mysql_fetch_array($result))
    {
       $formcompanyname =  $row['1']  ;
    }
	$fld3 = $_POST["winvoice_dt"];
	$fld3_1 = $fld3;
	$flddd = substr($fld3_1,0,2);   
    $fldmm = substr($fld3_1,3,2);
    $fldyy = substr($fld3_1,6,4);
    $formorderdate = $fldyy . "-" . $fldmm . "-" .  $flddd;
	$fld3_quotdate = $_POST["wquot_dt"];
//echo '<br>' . '$fld3_quotdate' .$fld3_quotdate . '<br>';
	$fldquotdd =  substr($fld3_quotdate,0,2); //12-09-2016  
    $fldquotmm = substr($fld3_quotdate,3,2);
    $fldquotyy = substr($fld3_quotdate,6,4);
	$formstax_perc = $_POST["service_perc"];
    $formstax_Rs = $_POST["service_amt"];
	$formvat_perc = $_POST["vat_perc"];
	$formvat_Rs = $_POST["vat"];
	
	$formnotification = $_POST["notallowed"];
	$formswbharat = $_POST["swbharat_perc"];
	$formswbharat_Rs = $_POST["swbharat_rs"];
	$formkrishi_kalyan_cess = $_POST["krishikalyan_perc"];
	$formkrishi_kalyan_cess_Rs = $_POST["krishikalyan_rs"];
	
	$formtotal_rs = $_POST["wtotal"];
	$formtransport_rs = $_POST["transport"];
	$formGrand_Rs = $_POST["wgtotal"];
	
	
	$formremarks1 = $_POST["remarks1"];
	$formremarks2 = $_POST["remarks2"];
    $formquotdate = $fld3_quotdate ; // $fldquotyy . "-" . $fldquotmm . "-" .  $fldquotdd;
//echo '<br>'.'quot date'.$formquotdate.'<br>';

//echo " form id " . $formorderid;
//echo " <br> " . "form " . $formid;  

//echo $lblcorrect ;


    if ($lblcorrect == "true")
    {	
//echo " <br> form id " . $formorderid; // id from database serial number
//echo " <br> " . "form " . $formid; // i 
	if ($formorderid == 0  || $formorderid == -99 )  // serial no from database
	{
//echo " form id " . $formorderid; // id from database serial number
//echo " <br> " . "form " . $formid;  
	$sql ="INSERT INTO order_cum_inv_head ( companyid , Company_Name ,fy   ) VALUES  (  '$formcompanyid', '$formcompanyname' ,  '$formcy' )";
//	echo $sql;	
    $retval = mysql_query($sql,$con);
    $result = mysql_query("SELECT max(Quot_No) as maxquotno  FROM last_order_no where companyid = " . $formcompanyid . " and fy = '" . $formcy . "'"     );
	while($row = mysql_fetch_array($result))
    {
	    if ($row['0'] > 0 )
		{
            $formquotno  =  $row['0'] + 1;
		}
		else
		{
	    	$formquotno = 1;
		}
    }
//echo '<br>' . '$formquotno'. $formquotno ; 	
    $sqlmaxid = "Select max(id) as maxid from order_cum_inv_head";
    $retval = mysql_query($sqlmaxid,$con);
    $result = mysql_query($sqlmaxid);
	while($row = mysql_fetch_array($result))
    {
	    if ($row['0'] > 0 )
		{
            $wmaxid  =  $row['0'] ;
		}
		else
		{
	    	$wmaxid = 1;
		}
    }	

// gole 
	
    $sqlorder = "Update order_cum_inv_head set Quot_no = " . $formquotno  . ", Quot_date = '" . $formquotdate . "' " .  " where id = " . $wmaxid ;
	$retval = mysql_query($sqlorder,$con);
	$sqlgetcustomer = "select * from customermaster where Customerid = " . $formcustomer_code;
//echo " " . $sqlgetcustomer ;
	$result = mysql_query($sqlgetcustomer);
	while($row = mysql_fetch_array($result))
    {
        $formcustomername =  $row['1'];
    }
//echo " cname " . $formcustomername ;	
	$sqlupdatecustomer = "Update order_cum_inv_head set 	customerid = " . $formcustomer_code . ", customername = '" . $formcustomername . "' " .  " where id = " . $wmaxid ;
	$retval = mysql_query($sqlupdatecustomer,$con);
	
	$formfunc_ad_1 = substr($formfadd,0,99); // $formfadd  $formadd
	$formfunc_ad_2 = substr($formfadd,100,199);
	$formfunc_ad_3 = substr($formfadd,200,299);
	$formfunc_ad_4 = substr($formfadd,300,399);
	$formfpincode = $_POST["wfpincode"];
	$sqlfunctiondtadd = "Update order_cum_inv_head set function_date = '" . $formfuncdate . "' , func_ad_1 = '" . $formfunc_ad_1 . "', func_ad_2 = '" . $formfunc_ad_2 . "' , func_ad_3 = '" . $formfunc_ad_3 . "' ,  func_ad_4 = '" . $formfunc_ad_4 . "' , func_pin = '" . $formfpincode . "' where  id = " . $wmaxid ;
	$retval = mysql_query($sqlfunctiondtadd,$con);
//echo '<br>'.$sqlfunctiondtadd;	
//echo '<br>' .  ' qut no ' . $formquotno;
     $sqlnotificationadd = "Update order_cum_inv_head set  Stax_INCL = '" . $formstax_perc . "' , STAX_RS = " . $formstax_Rs . " , vat_incl = '" . $formvat_perc . "' , vat_Rs = " . $formvat_Rs . " , Notification_allowed = '" . $formnotification . "' , swbharat = " . $formswbharat . " , swbharat_rs = " . $formswbharat_Rs . " , krishi_kalyan_cess = " . $formkrishi_kalyan_cess . " , krishi_kalyan_cess_Rs = " . $formkrishi_kalyan_cess_Rs . " where id = " . $wmaxid ;
//echo $sqlnotificationadd ; 
     $retval = mysql_query($sqlnotificationadd,$con); 

    $sqltotaltransportgrandrs = "Update order_cum_inv_head set	total_rs  = " . $formtotal_rs . " , transport_rs = " . $formtransport_rs . " , Grand_RS = " . $formGrand_Rs . " where id = " . $wmaxid ;
	$retval = mysql_query($sqltotaltransportgrandrs ,$con); 

    $sqlremarksadd = "Update order_cum_inv_head set remarks_1 = '" . $formremarks1 . "' , remarks_2 = '" . $formremarks2 . "' where id = " . $wmaxid ;
 	$retval = mysql_query($sqlremarksadd,$con);
	
	$formsrno = 0;
// insert into order_cum_invoice_details

    $formcode1 = $_POST["code1"];
	$formdesc1 = $_POST["desc1"];
	$formrate1 = $_POST["rate1"];
	$formunit1 = $_POST["unit1"];
	$formqty1 = $_POST["qty1"];
	$formamount1 = $_POST["amount1"];
	if ($formrate1 > 0 && $formqty1 > 0 && $formamount1 > 0  )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode1', '$formqty1','$formunit1','$formrate1','$formdesc1','$formamount1','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}
// 2nd row

    $formcode2 = $_POST["code2"];
	$formdesc2 = $_POST["desc2"];
	$formrate2 = $_POST["rate2"];
	$formunit2 = $_POST["unit2"];
	$formqty2 = $_POST["qty2"];
	$formamount2 = $_POST["amount2"];
	if ($formrate2 > 0 && $formqty2 > 0 && $formamount2 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode2', '$formqty2','$formunit2','$formrate2','$formdesc2','$formamount2','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}
	
// 3rd row

    $formcode3 = $_POST["code3"];
	$formdesc3 = $_POST["desc3"];
	$formrate3 = $_POST["rate3"];
	$formunit3 = $_POST["unit3"];
	$formqty3 = $_POST["qty3"];
	$formamount3 = $_POST["amount3"];
	if ($formrate3 > 0 && $formqty3 > 0 && $formamount3 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode3', '$formqty3','$formunit3','$formrate3','$formdesc3','$formamount3','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 4th row

    $formcode4 = $_POST["code4"];
	$formdesc4 = $_POST["desc4"];
	$formrate4 = $_POST["rate4"];
	$formunit4 = $_POST["unit4"];
	$formqty4 = $_POST["qty4"];
	$formamount4 = $_POST["amount4"];
	if ($formrate4 > 0 && $formqty4 > 0 && $formamount4 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode4', '$formqty4','$formunit4','$formrate4','$formdesc4','$formamount4','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 5th row

    $formcode5 = $_POST["code5"];
	$formdesc5 = $_POST["desc5"];
	$formrate5 = $_POST["rate5"];
	$formunit5 = $_POST["unit5"];
	$formqty5 = $_POST["qty5"];
	$formamount5 = $_POST["amount5"];
	if ($formrate5 > 0 && $formqty5 > 0 && $formamount5 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode5', '$formqty5','$formunit5','$formrate5','$formdesc5','$formamount5','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 6th row

    $formcode6 = $_POST["code6"];
	$formdesc6 = $_POST["desc6"];
	$formrate6 = $_POST["rate6"];
	$formunit6 = $_POST["unit6"];
	$formqty6 = $_POST["qty6"];
	$formamount6 = $_POST["amount6"];
	if ($formrate6 > 0 && $formqty6 > 0 && $formamount6 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode6', '$formqty6','$formunit6','$formrate6','$formdesc6','$formamount6','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 7th row

    $formcode7 = $_POST["code7"];
	$formdesc7 = $_POST["desc7"];
	$formrate7 = $_POST["rate7"];
	$formunit7 = $_POST["unit7"];
	$formqty7 = $_POST["qty7"];
	$formamount7 = $_POST["amount7"];
	if ($formrate7 > 0 && $formqty7 > 0 && $formamount7 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode7', '$formqty7','$formunit7','$formrate7','$formdesc7','$formamount7','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 8th row

    $formcode8 = $_POST["code8"];
	$formdesc8 = $_POST["desc8"];
	$formrate8 = $_POST["rate8"];
	$formunit8 = $_POST["unit8"];
	$formqty8 = $_POST["qty8"];
	$formamount8 = $_POST["amount8"];
	if ($formrate8 > 0 && $formqty8 > 0 && $formamount8 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode8', '$formqty8','$formunit8','$formrate8','$formdesc8','$formamount8','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 9th row

    $formcode9 = $_POST["code9"];
	$formdesc9 = $_POST["desc9"];
	$formrate9 = $_POST["rate9"];
	$formunit9 = $_POST["unit9"];
	$formqty9 = $_POST["qty9"];
	$formamount9 = $_POST["amount9"];
	if ($formrate9 > 0 && $formqty9 > 0 && $formamount9 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode9', '$formqty9','$formunit9','$formrate9','$formdesc9','$formamount9','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 10 th row

    $formcode10 = $_POST["code10"];
	$formdesc10 = $_POST["desc10"];
	$formrate10 = $_POST["rate10"];
	$formunit10 = $_POST["unit10"];
	$formqty10 = $_POST["qty10"];
	$formamount10 = $_POST["amount10"];
	if ($formrate10 > 0 && $formqty10 > 0 && $formamount10 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode10', '$formqty10','$formunit10','$formrate10','$formdesc10','$formamount10','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}


	if ($formquotno == 1 ) // $formquotno
	{
	$sqllastorderno ="INSERT INTO last_order_no ( companyid ,Quot_no,quot_Date ,fy   ) VALUES  (  '$formcompanyid', '$formquotno' ,'$formquotdate',  '$formcy' )";
//	echo $sqllastorderno;	
    $retval = mysql_query($sqllastorderno,$con);

	}
	else
	{
	$sqllastorderno ="Update last_order_no  set Quot_no = ". $formquotno . " , quot_Date = '" .  $formquotdate . "'  where  companyid =" . $formcompanyid . " and fy = '" . $formcy . "'" ;
//	echo $sqllastorderno;	
    $retval = mysql_query($sqllastorderno,$con);
	}
	echo "<html><head> <title> Alert </title> <script> alert(' Record   Inserted In the System.. '); </script> </head> <body> </body> </html>";
    echo "<marquee > Record Inserted  ...  </marquee>";
	
	$_SESSION['global_orderid']= 0;

 
	} //  formorderid
	else
	{ 
//	echo "here 2"; // EXISTING ORDER ID
	
//    echo "here 2";
// doing stuff for inv order head
    $formquotno = $_POST["wquot_no"];
	$formquotdate = $_POST["wquot_dt"];
	
    $wmaxid = $formorderid;
	$sqlgetcustid = "Select * from order_cum_inv_head where id = " . $wmaxid;
	$result = mysql_query($sqlgetcustid);
	while($row = mysql_fetch_array($result))
    {
        $formcustomer_code =  $row['8'];
    }	
// echo "id " . $wmaxid;
    $sqlorder = "Update order_cum_inv_head set Quot_no = " . $formquotno  . ", Quot_date = '" . $formquotdate . "' " .  " where id = " . $wmaxid ;
	$retval = mysql_query($sqlorder,$con);

//echo "here";

	$formnameofwork = $_POST["nameofwork"];
	$formadvance_rs = $_POST["advance_rs"];
	$formmaterial_payment_rs = $_POST["material_payment_rs"];
	$formprint_advance = $_POST["print_advance"];
	$formprint_material_payment = $_POST["print_material_payment"];

//echo "here overr";	
	
	$formnewcustcode = $_POST["newcustcode"];
	if ($formnewcustcode > 0 ) // new customer code
	{
	   $formcustomer_code = $formnewcustcode;
	}
//	echo "here";
	$sqlgetcustomer = "select * from customermaster where Customerid = " . $formcustomer_code;
//echo " " . $sqlgetcustomer ;
	$result = mysql_query($sqlgetcustomer);
	while($row = mysql_fetch_array($result))
    {
        $formcustomername =  $row['1'];
    }
//echo " cname " . $formcustomername ;	
	$sqlupdatecustomer = "Update order_cum_inv_head set 	customerid = " . $formcustomer_code . ", customername = '" . $formcustomername . "' " .  " where id = " . $wmaxid ;
	$retval = mysql_query($sqlupdatecustomer,$con);

	$sqlupdatecustomer = "Update order_cum_inv_head set nameofwork = '" . $formnameofwork . "', advance_rs = " . $formadvance_rs . ", Material_Payment =  " .  $formmaterial_payment_rs .  " , Print_Advance = '" . $formprint_advance .   "' , Print_Material_Payment = '" . $formprint_material_payment . "' where id = " . $wmaxid ;
	$retval = mysql_query($sqlupdatecustomer,$con);

 //   echo $sqlupdatecustomer;
	
	$formfunc_ad_1 = substr($formfadd,0,99); // $formfadd  $formadd
	$formfunc_ad_2 = substr($formfadd,100,199);
	$formfunc_ad_3 = substr($formfadd,200,299);
	$formfunc_ad_4 = substr($formfadd,300,399);
	$formfpincode = $_POST["wfpincode"];
	$sqlfunctiondtadd = "Update order_cum_inv_head set function_date = '" . $formfuncdate . "' , func_ad_1 = '" . $formfunc_ad_1 . "', func_ad_2 = '" . $formfunc_ad_2 . "' , func_ad_3 = '" . $formfunc_ad_3 . "' ,  func_ad_4 = '" . $formfunc_ad_4 . "' , func_pin = '" . $formfpincode . "' where  id = " . $wmaxid ;
	$retval = mysql_query($sqlfunctiondtadd,$con);
//echo '<br>'.$sqlfunctiondtadd;	
//echo '<br>' .  ' qut no ' . $formquotno;
     $sqlnotificationadd = "Update order_cum_inv_head set  Stax_INCL = '" . $formstax_perc . "' , STAX_RS = " . $formstax_Rs . " , vat_incl = '" . $formvat_perc . "' , vat_Rs = " . $formvat_Rs . " , Notification_allowed = '" . $formnotification . "' , swbharat = " . $formswbharat . " , swbharat_rs = " . $formswbharat_Rs . " , krishi_kalyan_cess = " . $formkrishi_kalyan_cess . " , krishi_kalyan_cess_Rs = " . $formkrishi_kalyan_cess_Rs . " where id = " . $wmaxid ;
//echo $sqlnotificationadd ; 
    $retval = mysql_query($sqlnotificationadd,$con); 

    $sqltotaltransportgrandrs = "Update order_cum_inv_head set	total_rs  = " . $formtotal_rs . " , transport_rs = " . $formtransport_rs . " , Grand_RS = " . $formGrand_Rs . " where id = " . $wmaxid ;
	$retval = mysql_query($sqltotaltransportgrandrs ,$con); 

    $sqlremarksadd = "Update order_cum_inv_head set remarks_1 = '" . $formremarks1 . "' , remarks_2 = '" . $formremarks2 . "' where id = " . $wmaxid ;
 	$retval = mysql_query($sqlremarksadd,$con);
	
// update here order_cum_invoice_detail start
	$actnoofentries = $_POST["noofentries"];
	if ($actnoofentries == 1)
	{
	$action1 =  $_POST["action_change1"];  // editaction
	$actcode = $_POST["change_code1"]; // gole
   	$actrate = $_POST["change_rate1"];
	$actqty = $_POST["change_quantity1"];
	$actamount = $_POST["change_amount1"];
	$actnoofentries = $_POST["noofentries"];
	
	if ($action1=="Update")
	{
	        $formamount = $actqty  * $actrate;
        	$sqlupdateme = "update order_cum_invoice_detail set quantity = " . $actqty . " ,  rate = " . $actrate . " , amount =" . $formamount . "  where headid = ".$wmaxid . " and stockcode = " . $actcode;
		//	echo $sqlupdateme;
//			die ("hh");
			$resultupdateme = mysql_query($sqlupdateme);					
	}
	if ($action1=="Delete")
	{
        	$sqldeleteme = "Delete from order_cum_invoice_detail where headid = ".$wmaxid . " and quantity = " . $actqty . " and stockcode = " . $actcode . " and amount =" . $actamount ;
		//	echo $sqldeleteme;
			$resultupdateme = mysql_query($sqldeleteme);				
	}

	
	}
	if ($actnoofentries > 1 )
	{
     $action1 =  $_POST["action_change"];  // editaction
	$actcode = $_POST["change_code"]; // gole
   	$actrate = $_POST["change_rate"];
	$actqty = $_POST["change_quantity"];
	$actamount = $_POST["change_amount"];
	$actnoofentries = $_POST["noofentries"];
	
	foreach ($action1 as $key => $formeditaction_change)
	{	
    //    echo $formeditaction_change;
		$formcode = $actcode[$key];
   		$formrate = $actrate[$key];
		$formqty = $actqty[$key];
		$formamount = $actamount[$key];
    	if ($formeditaction_change=="Update")
		{
        	$sqlupdateme = "update order_cum_invoice_detail set quantity = " . $formqty . " ,  rate = " . $formrate . " , amount =" . $formamount . "  where headid = ".$wmaxid . " and stockcode = " . $formcode;
		//	echo $sqlupdateme;
//			die ("hh");
			$resultupdateme = mysql_query($sqlupdateme);					
		}
		if ($formeditaction_change=="Delete")
		{
        	$sqldeleteme = "Delete from order_cum_invoice_detail where headid = ".$wmaxid . " and quantity = " . $formqty . " and stockcode = " . $formcode . " and amount =" . $formamount ;
		//	echo $sqldeleteme;
			$resultupdateme = mysql_query($sqldeleteme);				
		}
	}
    }
// update here order_cum_invoice_detail end	
	
	
	
	$sqlgetparticulars = "Select * from order_cum_invoice_detail where headID = " . $wmaxid ;
    $result = mysql_query($sqlgetparticulars);
	$formsrno =0;
//echo $sqlgetparticulars;
    while($row = mysql_fetch_array($result))
    {
	$formsrno ++;
	}
// insert into detail start

    $formcode1 = $_POST["code1"];
	$formdesc1 = $_POST["desc1"];
	$formrate1 = $_POST["rate1"];
	$formunit1 = $_POST["unit1"];
	$formqty1 = $_POST["qty1"];
	$formamount1 = $_POST["amount1"];
	if ($formrate1 > 0 && $formqty1 > 0 && $formamount1 > 0  )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode1', '$formqty1','$formunit1','$formrate1','$formdesc1','$formamount1','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}
// 2nd row

    $formcode2 = $_POST["code2"];
	$formdesc2 = $_POST["desc2"];
	$formrate2 = $_POST["rate2"];
	$formunit2 = $_POST["unit2"];
	$formqty2 = $_POST["qty2"];
	$formamount2 = $_POST["amount2"];
	if ($formrate2 > 0 && $formqty2 > 0 && $formamount2 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode2', '$formqty2','$formunit2','$formrate2','$formdesc2','$formamount2','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}
	
// 3rd row

    $formcode3 = $_POST["code3"];
	$formdesc3 = $_POST["desc3"];
	$formrate3 = $_POST["rate3"];
	$formunit3 = $_POST["unit3"];
	$formqty3 = $_POST["qty3"];
	$formamount3 = $_POST["amount3"];
	if ($formrate3 > 0 && $formqty3 > 0 && $formamount3 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode3', '$formqty3','$formunit3','$formrate3','$formdesc3','$formamount3','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 4th row

    $formcode4 = $_POST["code4"];
	$formdesc4 = $_POST["desc4"];
	$formrate4 = $_POST["rate4"];
	$formunit4 = $_POST["unit4"];
	$formqty4 = $_POST["qty4"];
	$formamount4 = $_POST["amount4"];
	if ($formrate4 > 0 && $formqty4 > 0 && $formamount4 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode4', '$formqty4','$formunit4','$formrate4','$formdesc4','$formamount4','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 5th row

    $formcode5 = $_POST["code5"];
	$formdesc5 = $_POST["desc5"];
	$formrate5 = $_POST["rate5"];
	$formunit5 = $_POST["unit5"];
	$formqty5 = $_POST["qty5"];
	$formamount5 = $_POST["amount5"];
	if ($formrate5 > 0 && $formqty5 > 0 && $formamount5 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode5', '$formqty5','$formunit5','$formrate5','$formdesc5','$formamount5','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 6th row

    $formcode6 = $_POST["code6"];
	$formdesc6 = $_POST["desc6"];
	$formrate6 = $_POST["rate6"];
	$formunit6 = $_POST["unit6"];
	$formqty6 = $_POST["qty6"];
	$formamount6 = $_POST["amount6"];
	if ($formrate6 > 0 && $formqty6 > 0 && $formamount6 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode6', '$formqty6','$formunit6','$formrate6','$formdesc6','$formamount6','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 7th row

    $formcode7 = $_POST["code7"];
	$formdesc7 = $_POST["desc7"];
	$formrate7 = $_POST["rate7"];
	$formunit7 = $_POST["unit7"];
	$formqty7 = $_POST["qty7"];
	$formamount7 = $_POST["amount7"];
	if ($formrate7 > 0 && $formqty7 > 0 && $formamount7 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode7', '$formqty7','$formunit7','$formrate7','$formdesc7','$formamount7','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 8th row

    $formcode8 = $_POST["code8"];
	$formdesc8 = $_POST["desc8"];
	$formrate8 = $_POST["rate8"];
	$formunit8 = $_POST["unit8"];
	$formqty8 = $_POST["qty8"];
	$formamount8 = $_POST["amount8"];
	if ($formrate8 > 0 && $formqty8 > 0 && $formamount8 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode8', '$formqty8','$formunit8','$formrate8','$formdesc8','$formamount8','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 9th row

    $formcode9 = $_POST["code9"];
	$formdesc9 = $_POST["desc9"];
	$formrate9 = $_POST["rate9"];
	$formunit9 = $_POST["unit9"];
	$formqty9 = $_POST["qty9"];
	$formamount9 = $_POST["amount9"];
	if ($formrate9 > 0 && $formqty9 > 0 && $formamount9 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ('$wmaxid', '$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode9', '$formqty9','$formunit9','$formrate9','$formdesc9','$formamount9','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}

	
// 10 th row

    $formcode10 = $_POST["code10"];
	$formdesc10 = $_POST["desc10"];
	$formrate10 = $_POST["rate10"];
	$formunit10 = $_POST["unit10"];
	$formqty10 = $_POST["qty10"];
	$formamount10 = $_POST["amount10"];
	if ($formrate10 > 0 && $formqty10 > 0 && $formamount10 > 0    )
	{
	    $formsrno ++;
	    $sqlinvoicedetail1 = "Insert into order_cum_invoice_detail (HeadID,srno ,  companyid , customerid , mysrno , quotno , stockcode , quantity , unit_of_measurement , rate , description , amount , fy , quotdate ) values ( '$wmaxid','$formsrno' , '$formcompanyid' , '$formcustomer_code' , '$formsrno' , '$formquotno', '$formcode10', '$formqty10','$formunit10','$formrate10','$formdesc10','$formamount10','$formcy','$formquotdate'  )";
        $retval = mysql_query($sqlinvoicedetail1,$con); 
	}


// insert into detail end	
	
    $_SESSION['global_orderid']= 0;

//	
	}
	} // lblcorrect
	else
	{
	  echo "<html><head> <title> Alert </title> <script> alert(' Record is not Inserted In the System.. '); </script> </head> <body> </body> </html>";
      echo "<marquee > Some Wrong Input Please contact Administrator ...  </marquee>";
	  $_SESSION['global_orderid']= 0;

      return;
	}
	
}
if (isset($_POST['getaddress']))
{
    $fld1 = $_POST["wcname"];
 //   echo $fld1;
	$result = mysql_query("Select * from customermaster where customerid = " . $fld1);
	while($row = mysql_fetch_array($result))
    {
    $custaddress =  $row['2'] ."\n"   . $row['3'] ."\n"   . $row['4'] ."\n"    . $row['5']  ;
//	echo $row['6'];
	if ($row['6'] == '')
	{
	   $custpin = '';
	}
	else
	{
	$custpin = 'Pin code:-' . $row['6'];
	}
	
//	echo $custaddress;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Order Cum Invoice Details</title>
    <link href="/resources/css/bootstrap.min.css" rel="stylesheet">
    <link href="/resources/css/common.css" rel="stylesheet">
	<script src="/resources/js/bootstrap.min.js"></script>
	<script>

    function validateform()
    { 
           var wfname=document.loginform.wusername.value;  
		   var wfpassword=document.loginform.wpassword.value;
		   var wfc = document.loginform.companyname.value;
	       var wfy = document.loginform.fyyear.value;
		   var wfcompany_text = document.loginform.company_text.value;
		   var wfyear_text = document.loginform.text_fyear.value;
           if (wfname.value === '' ||   wfname.length === 0)
           {  
                  alert("Please Enter Login Name Properly ");  
                  return false;  
           }
           if (wfpassword.value === '' ||   wfpassword.length === 0)
           {  
                  alert("Please Enter Login Password Properly ");  
                  return false;  
           }
		   if (wfcompany_text.value === 'company name' || wfc <= 0  )
           {  
		   
                  alert("Please Select company Name  ");  
                 return false;  
           }
		   if (wfyear_text.value === 'Financial Year' ||   wfy <= 0)
           {  
                alert("Please Select financial Year   ");  
                 return false;  
           }
		   return true;
    } 
	function wcnameenabled(form)
	{ 
	  document.getElementById("wcname").size= 5; // =true;
	}
	function wcnameoff(form)
	{
	  document.getElementById("wcname").size=1;
	}
	function getcustomeraddress(form)
	{
	//   alert('here');
	   var var1;
	        var e = document.getElementById("wcname");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.wcadd1.value=split[1] + ' ' + split[2] + split[3] + split[4] ;
	 document.ordercuminvoiceform.customername.value =  split[0];
	 document.ordercuminvoiceform.newcustcode.value = split[6];
	 document.ordercuminvoiceform.wpin.value = split[5];
	// document.ordercuminvoiceform.unit1.value=split[2];	
	// document.ordercuminvoiceform.rate1.value=split[3];	
	   
	}
	function  mycurrency1(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code1");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc1.value=split[0];
	 document.ordercuminvoiceform.unit1.value=split[2];	
	 document.ordercuminvoiceform.rate1.value=split[3];	 
	}
	function  mycurrency2(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code2");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc2.value=split[0];
	 document.ordercuminvoiceform.unit2.value=split[2];	
	 document.ordercuminvoiceform.rate2.value=split[3];	 
	}
	function  mycurrency3(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code3");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc3.value=split[0];
	 document.ordercuminvoiceform.unit3.value=split[2];	
	 document.ordercuminvoiceform.rate3.value=split[3];	 
	}
	function  mycurrency4(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code4");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc4.value=split[0];
	 document.ordercuminvoiceform.unit4.value=split[2];	
	 document.ordercuminvoiceform.rate4.value=split[3];	 
	}
	function  mycurrency5(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code5");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc5.value=split[0];
	 document.ordercuminvoiceform.unit5.value=split[2];	
	 document.ordercuminvoiceform.rate5.value=split[3];	 
	}
	function  mycurrency6(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code6");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc6.value=split[0];
	 document.ordercuminvoiceform.unit6.value=split[2];	
	 document.ordercuminvoiceform.rate6.value=split[3];	 
	}
	function  mycurrency7(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code7");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc7.value=split[0];
	 document.ordercuminvoiceform.unit7.value=split[2];	
	 document.ordercuminvoiceform.rate7.value=split[3];	 
	}
	function  mycurrency8(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code8");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc8.value=split[0];
	 document.ordercuminvoiceform.unit8.value=split[2];	
	 document.ordercuminvoiceform.rate8.value=split[3];	 
	}
	function  mycurrency9(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code9");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc9.value=split[0];
	 document.ordercuminvoiceform.unit9.value=split[2];	
	 document.ordercuminvoiceform.rate9.value=split[3];	 
	}
	function  mycurrency10(form)
	{
	 var val1 , n , strUser;
     var e = document.getElementById("code10");
     var strUser = e.options[e.selectedIndex].text;
     var split = strUser.split('~');
     document.ordercuminvoiceform.desc10.value=split[0];
	 document.ordercuminvoiceform.unit10.value=split[2];	
	 document.ordercuminvoiceform.rate10.value=split[3];	 
	}
	function  myamount1(form)
	{
	 var vrate1;
	 vrate1 = parseFloat(document.ordercuminvoiceform.rate1.value);	
	 vqty1 =  parseFloat(document.ordercuminvoiceform.qty1.value);	
     if (isNaN(vrate1) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate1.focus();
 		return;
	 }
	 if (isNaN(vqty1) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty1.focus();
    	return;
	 } 
	 if (vrate1 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate1.focus();
 		return;
	 }
	 if (vqty1 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty1.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount1.value = vrate1 * vqty1;
	}
	function  myamount2(form)
	{
	 var vrate2;
	 vrate2 = parseFloat(document.ordercuminvoiceform.rate2.value);	
	 vqty2 =  parseFloat(document.ordercuminvoiceform.qty2.value);	
     if (isNaN(vrate2) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate2.focus();
 		return;
	 }
	 if (isNaN(vqty2) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty2.focus();
    	return;
	 } 
	 if (vrate2 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate2.focus();
 		return;
	 }
	 if (vqty2 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty2.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount2.value = vrate2 * vqty2;
	} 
	function  myamount3(form)
	{
	 var vrate3;
	 vrate3 = parseFloat(document.ordercuminvoiceform.rate3.value);	
	 vqty3 =  parseFloat(document.ordercuminvoiceform.qty3.value);	
     if (isNaN(vrate3) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate3.focus();
 		return;
	 }
	 if (isNaN(vqty3) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty3.focus();
    	return;
	 } 
	 if (vrate3 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate3.focus();
 		return;
	 }
	 if (vqty3 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty3.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount3.value = vrate3 * vqty3;
	}
	function  myamount4(form)
	{
	 var vrate4;
	 vrate4 = parseFloat(document.ordercuminvoiceform.rate4.value);	
	 vqty4 =  parseFloat(document.ordercuminvoiceform.qty4.value);	
     if (isNaN(vrate4) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate4.focus();
 		return;
	 }
	 if (isNaN(vqty4) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty4.focus();
    	return;
	 } 
	 if (vrate4 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate4.focus();
 		return;
	 }
	 if (vqty4 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty4.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount4.value = vrate4 * vqty4;
	}
	function  myamount5(form)
	{
	 var vrate5;
	 vrate5 = parseFloat(document.ordercuminvoiceform.rate5.value);	
	 vqty5 =  parseFloat(document.ordercuminvoiceform.qty5.value);	
     if (isNaN(vrate5) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate5.focus();
 		return;
	 }
	 if (isNaN(vqty5) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty5.focus();
    	return;
	 } 
	 if (vrate5 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate5.focus();
 		return;
	 }
	 if (vqty5 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty5.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount5.value = vrate5 * vqty5;
	}
	function  myamount6(form)
	{
	 var vrate1;
	 vrate1 = parseFloat(document.ordercuminvoiceform.rate6.value);	
	 vqty1 =  parseFloat(document.ordercuminvoiceform.qty6.value);	
     if (isNaN(vrate1) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate6.focus();
 		return;
	 }
	 if (isNaN(vqty1) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty6.focus();
    	return;
	 } 
	 if (vrate1 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate6.focus();
 		return;
	 }
	 if (vqty1 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty6.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount6.value = vrate1 * vqty1;
	}
	function  myamount7(form)
	{
	 var vrate7;
	 vrate7 = parseFloat(document.ordercuminvoiceform.rate7.value);	
	 vqty7 =  parseFloat(document.ordercuminvoiceform.qty7.value);	
     if (isNaN(vrate7) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate7.focus();
 		return;
	 }
	 if (isNaN(vqty7) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty7.focus();
    	return;
	 } 
	 if (vrate7 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate7.focus();
 		return;
	 }
	 if (vqty7 <  0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty7.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount7.value = vrate7 * vqty7;
	}
	function  myamount8(form)
	{
	 var vrate8;
	 vrate8 = parseFloat(document.ordercuminvoiceform.rate8.value);	
	 vqty8 =  parseFloat(document.ordercuminvoiceform.qty8.value);	
     if (isNaN(vrate8) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate8.focus();
 		return;
	 }
	 if (isNaN(vqty8) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty8.focus();
    	return;
	 } 
	 if (vrate8 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate8.focus();
 		return;
	 }
	 if (vqty8 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty8.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount8.value = vrate8 * vqty8;
	}
	function  myamount9(form)
	{
	 var vrate9;
	 vrate9 = parseFloat(document.ordercuminvoiceform.rate9.value);	
	 vqty9 =  parseFloat(document.ordercuminvoiceform.qty9.value);	
     if (isNaN(vrate9) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate9.focus();
 		return;
	 }
	 if (isNaN(vqty9) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty9.focus();
    	return;
	 } 
	 if (vrate9 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate9.focus();
 		return;
	 }
	 if (vqty9 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty9.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount9.value = vrate9 * vqty9;
	}
	function  myamount10(form)
	{
	 var vrate10;
	 vrate10 = parseFloat(document.ordercuminvoiceform.rate10.value);	
	 vqty10 =  parseFloat(document.ordercuminvoiceform.qty10.value);	
     if (isNaN(vrate10) == true )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate10.focus();
 		return;
	 }
	 if (isNaN(vqty10) == true  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty10.focus();
    	return;
	 } 
	 if (vrate10 < 0  )
	 {
	    alert("Rate cannot be negative or zero ... ");
		document.ordercuminvoiceform.rate10.focus();
 		return;
	 }
	 if (vqty10 < 0  )
	 {
	    alert("Quantity cannot be negative or zero ... ");
		document.ordercuminvoiceform.qty10.focus();
 		return
	 }
	 document.ordercuminvoiceform.amount10.value = vrate10 * vqty10;
	}
	function mytotal1(form)
	{
//alert('total ');
	var formtotal=0;
	var v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,vtransport;
	v1 =    parseFloat(document.ordercuminvoiceform.amount1.value);	
	v2 =    parseFloat(document.ordercuminvoiceform.amount2.value);	
	v3 =    parseFloat(document.ordercuminvoiceform.amount3.value);
//alert ("v1 v2 v3");
//alert(v1);
//alert(v2);
//alert(v3);
	v4 =   parseFloat(document.ordercuminvoiceform.amount4.value);	
	v5 =    parseFloat(document.ordercuminvoiceform.amount5.value);	
	v6 =    parseFloat(document.ordercuminvoiceform.amount6.value);	
	v7 =   parseFloat(document.ordercuminvoiceform.amount7.value);	
	v8 =    parseFloat(document.ordercuminvoiceform.amount8.value);	
//alert ("v 4 to 8");
//alert(v4);
//alert(v5);
//alert(v6);
//alert(v7);
//alert(v8);
	v9 =   parseFloat(document.ordercuminvoiceform.amount9.value);	
	v10 =   parseFloat(document.ordercuminvoiceform.amount10.value);
//alert ("v9 10");
//alert(v9);
//alert(v10);
	vtransport =  0; //  parseFloat(document.ordercuminvoiceform.transport.value);	
//alert("transport");
//alert(vtransport);
    formtotal = parseFloat(v1)+parseFloat(v2)+parseFloat(v3)+parseFloat(v4)+parseFloat(v5)+parseFloat(v6)+parseFloat(v7)+parseFloat(v8)+parseFloat(v9)+parseFloat(v10)+parseFloat(vtransport);   
//alert('formtotal');
//alert(formtotal);
    var theForm = document.getElementById("ordercuminvoiceform");
////	alert('here');
	var newaction = 0; //  theForm.action_change.length[] ; //theForm.document.action_change.length; // getElementById("action_change[]");
//alert(newaction);
    var noofelements = document.ordercuminvoiceform.noofentries.value;
//alert(noofelements);
    if (noofelements == 0 )
	{
	    oldtotal = 0;
	}
    if ( noofelements > 1 )
	{
    var actionchange = document.ordercuminvoiceform.elements["action_change[]"];
	var oldrate = document.ordercuminvoiceform.elements["change_rate[]"];

			
	
	var oldqty = document.ordercuminvoiceform.elements["change_quantity[]"];
	var oldamount = document.ordercuminvoiceform.elements["change_amount[]"];
//alert(noofelements);
//	alert(actionchange.length);
    var oldtotal = 0;
	var oldamt =0;
    for (var i = 0, len = noofelements; i < len; i++) // actionchange.length; i < len; i++) 
	{ // document.getElementById(examStateArr[i]).innerHTML = xmlHttp.responseText   
 	    var oldtotal = oldtotal + oldrate[i].value * oldqty[i].value;
        oldamount[i].value = oldrate[i].value * oldqty[i].value;
	//	alert(oldtotal);
//		alert(oldamount[i].value);
//	  }
    }
	}
	if ( noofelements == 1)
	{ // nno of elements = 1
	//alert('inside* only 1');
    var actionchange = document.ordercuminvoiceform.action_change1.value;
	var oldrate = document.ordercuminvoiceform.change_rate1.value;

//alert('act oldr');

	//alert(actionchange);
    //alert(oldrate);

	
	
	var oldqty = document.ordercuminvoiceform.change_quantity1.value;
	var oldamount = document.ordercuminvoiceform.change_amount1.value;
	
//alert('ty amt');

//	alert(oldqty);
 //   alert(oldamount);
	
	
//alert(noofelements);
//	alert(actionchange.length);
    var oldtotal = 0;
	var oldamt =0;
  
 	    var oldtotal = oldtotal + oldrate * oldqty;
        oldamount.value = oldrate * oldqty;
//	alert(oldtotal);
//		alert(oldamount[i].value);
//	  }
  //  }
	
	
	} // no of elements = 1 over
//	alert ('out of all cod  ttoal over');
	formtotal =  parseFloat(formtotal) + parseFloat(oldtotal);
	document.ordercuminvoiceform.wtotal.value = Math.round(formtotal);
//	document.ordercuminvoiceform.wtotal.focus();
	}
	

	function mygrandamount(form)
	{
//alert('in grands total ');
	  var vgt,vgtotal,vam1,vam2,vam3,vam4,vam5,vam6,vam7,vam8,vam9,vam10,vserv,vedu,vvat,vsw,vkk,vtr,formtotal;
	  myamount1(this.form);
	  myamount2(this.form);
	  myamount3(this.form);
	  myamount4(this.form);
	  myamount5(this.form);
	  myamount6(this.form);
	  myamount7(this.form);
	  myamount8(this.form);
	  myamount9(this.form);
	  myamount10(this.form); 
//alert('before mytot');
	  mytotal1(this.form);
//alert(document.ordercuminvoiceform.wtotal.value);
//alert('in gr total value of total');
      myservamount(this.form);
	  vedu = 0.00;
//	  myeducessamount(this.form);
	  myvatamount(this.form);
	  myswamount(this.form);
	  mykkamount(this.form); 
	  
	  vam1 = parseFloat(document.ordercuminvoiceform.amount1.value);
	  vam2 = parseFloat(document.ordercuminvoiceform.amount2.value);
	  vam3 = parseFloat(document.ordercuminvoiceform.amount3.value);
	  vam4 = parseFloat(document.ordercuminvoiceform.amount4.value);
	  vam5 = parseFloat(document.ordercuminvoiceform.amount5.value);
	  vam6 = parseFloat(document.ordercuminvoiceform.amount6.value);

	  vam7 = parseFloat(document.ordercuminvoiceform.amount7.value);
	  vam8 = parseFloat(document.ordercuminvoiceform.amount8.value);
	  vam9 = parseFloat(document.ordercuminvoiceform.amount9.value);
	  vam10 = parseFloat(document.ordercuminvoiceform.amount10.value);
	  
	  vt  =   0; // parseFloat(document.ordercuminvoiceform.transport.value);
	  vtransport =  parseFloat(document.ordercuminvoiceform.transport.value);	
	  
      formtotal = vam1+vam2+vam3+vam4+vam5+vam6+vam7+vam8+vam9+vam10+vt;   
	  document.ordercuminvoiceform.wtotal.value = Math.round(formtotal);
// old data start

    var theForm = document.getElementById("ordercuminvoiceform");
//	alert('here **');
	var newaction = 0; //  theForm.action_change.length[] ; //theForm.document.action_change.length; // getElementById("action_change[]");
//	alert(newaction);
//    var actionchange = document.ordercuminvoiceform.elements["action_change[]"];
//	var oldrate = document.ordercuminvoiceform.elements["change_rate[]"];
//	var oldqty = document.ordercuminvoiceform.elements["change_quantity[]"];
//	var oldamount = document.ordercuminvoiceform.elements["change_amount[]"];	
//	alert(actionchange.length);

// old logic startt
//    var noofelements = document.ordercuminvoiceform.noofentries.value;
 
 //   var oldtotal = 0;
//	var oldamt =0;
  //  for (var i = 0, len = noofelements; i < len; i++) // actionchange.length; i < len; i++) 
	//{  
	 //   var oldtotal = oldtotal + oldrate[i].value * oldqty[i].value;
      //  oldamount[i].value = oldrate[i].value * oldqty[i].value;
 
   // }
	//formtotal =  parseFloat(formtotal) + parseFloat(oldtotal);
	//document.ordercuminvoiceform.wtotal.value = Math.round(formtotal);

// old data end
// old logic end

// new logic start

 // remove this   formtotal = parseFloat(v1)+parseFloat(v2)+parseFloat(v3)+parseFloat(v4)+parseFloat(v5)+parseFloat(v6)+parseFloat(v7)+parseFloat(v8)+parseFloat(v9)+parseFloat(v10)+parseFloat(vtransport);   
//alert('formtotal');
//alert(formtotal);
 // remove this    var theForm = document.getElementById("ordercuminvoiceform");
//	alert('here');
	var newaction = 0; //  theForm.action_change.length[] ; //theForm.document.action_change.length; // getElementById("action_change[]");
//alert(newaction);
    var noofelements = document.ordercuminvoiceform.noofentries.value;
//alert(noofelements);
    if ( noofelements == 0  )
	{
//	   alert('here');
	   oldtotal = 0;
	}
    if ( noofelements > 1 )
	{
    var actionchange = document.ordercuminvoiceform.elements["action_change[]"];
	var oldrate = document.ordercuminvoiceform.elements["change_rate[]"];

			
	
	var oldqty = document.ordercuminvoiceform.elements["change_quantity[]"];
	var oldamount = document.ordercuminvoiceform.elements["change_amount[]"];
//alert(noofelements);
//	alert(actionchange.length);
    var oldtotal = 0;
	var oldamt =0;
    for (var i = 0, len = noofelements; i < len; i++) // actionchange.length; i < len; i++) 
	{ // document.getElementById(examStateArr[i]).innerHTML = xmlHttp.responseText   
 	    var oldtotal = oldtotal + oldrate[i].value * oldqty[i].value;
        oldamount[i].value = oldrate[i].value * oldqty[i].value;
	//	alert(oldtotal);
//		alert(oldamount[i].value);
//	  }
    }
	}
	if ( noofelements == 1 )
	{ // nno of elements = 1
//	alert('inside* only 1');
    var actionchange = document.ordercuminvoiceform.action_change1.value;
	var oldrate = document.ordercuminvoiceform.change_rate1.value;

//alert('act oldr');

//	alert(actionchange);
 //   alert(oldrate);

	
	
	var oldqty = document.ordercuminvoiceform.change_quantity1.value;
	var oldamount = document.ordercuminvoiceform.change_amount1.value;
	
//alert('ty amt');

//	alert(oldqty);
//    alert(oldamount);
	
	
//alert(noofelements);
//	alert(actionchange.length);
    var oldtotal = 0;
	var oldamt =0;
  
 	    var oldtotal = oldtotal + oldrate * oldqty;
        oldamount.value = oldrate * oldqty;
//	alert(oldtotal);
//		alert(oldamount[i].value);
//	  }
  //  }
	
	
	} // no of elements = 1 over
//	alert ('out of all cod ');
	formtotal =  parseFloat(formtotal) + parseFloat(oldtotal);
	document.ordercuminvoiceform.wtotal.value = Math.round(formtotal);


// new logic end	  
	  
	  
//alert(formtotal);    
	  
	  vserv = document.ordercuminvoiceform.service_amt.value;
//alert("vserv");alert(vserv);  
//	  vedu = document.ordercuminvoiceform.educess.value;
	 if (isNaN(vserv) === true  )
	 {
	    vserv = 0;
		document.ordercuminvoiceform.service_amt.value =0;
//		alert('zsro');
	 }
	  vvat = document.ordercuminvoiceform.vat.value;
	 if (isNaN(vvat) === true  )
	 {
	    vvat = 0;
		document.ordercuminvoiceform.vat.value =0;
//		alert(' vat% is zsro');
	 }
	  vsw = document.ordercuminvoiceform.swbharat_rs.value;
	 if (isNaN(vsw) === true  )
	 {
	    vsw = 0;
		document.ordercuminvoiceform.swbharat_rs.value =0;
//		alert('zsro');
	 }
//alert(vsw); alert('vsw'); //             krishikalyan_rs
	  vkk = document.ordercuminvoiceform.krishikalyan_rs.value;
	 if (isNaN(vkk) === true  )
	 {
	    vkk = 0;
		document.ordercuminvoiceform.krishikalyan_rs.value =0;
//		alert('zsro');
	 }
//alert('vkk check'); alert(vkk);
	  vgtotal = parseFloat(oldtotal)+parseFloat(vam1)+parseFloat(vam2)+parseFloat(vam3)+parseFloat(vam4)+parseFloat(vam5)+parseFloat(vam6)+parseFloat(vam7)+parseFloat(vam8)+parseFloat(vam9)+parseFloat(vam10)+parseFloat(vtransport)+parseFloat(vserv)+parseFloat(vedu)+parseFloat(vvat)+parseFloat(vsw)+parseFloat(vkk);
//alert('vgt *');alert(vgtotal);  

	  vgt  = Math.round(vgtotal);
	  document.ordercuminvoiceform.wgtotal.value = Math.round(vgt);
//	  document.ordercuminvoiceform.wgtotal.focus();
//alert('last');alert(document.ordercuminvoiceform.wgtotal.value);	  
	}
	
	
	function myservamount(form)
	{
	  var vservperc,vservamount,vnottotal,vnotallowed;
	  vservperc = 0;
	  vservamount = 0;
	  vnotallowed = parseFloat(document.ordercuminvoiceform.notallowed.value);
	  if (parseFloat(document.ordercuminvoiceform.notallowed.value) > 0 )
	  {
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value) * vnotallowed / 100;
	  }
	  else
	  { 
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value);
	  }
	  vservperc = parseFloat(document.ordercuminvoiceform.service_perc.value);
	  vservamount = vnottotal * vservperc /100; // parseFloat(document.ordercuminvoiceform.wtotal.value) * vservperc /100;
	  document.ordercuminvoiceform.service_amt.value = Math.round(vservamount);
	}
	function myeducessamount(form)
	{
	  var veducessperc,veducessamount,vnottotal,vnotallowed;
	  veducessperc=0.00;
	  veducessamount=0.00;
	  vnotallowed = parseFloat(document.ordercuminvoiceform.notallowed.value);
	  if (parseFloat(document.ordercuminvoiceform.notallowed.value) > 0 )
	  {
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value) * vnotallowed / 100;
	  }
	  else
	  { 
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value);
	  }
	  veducessperc = parseFloat(document.ordercuminvoiceform.educess_perc.value);
	  veducessamount = vnottotal * veducessperc /100; // parseFloat(document.ordercuminvoiceform.wtotal.value) * veducessperc /100;
	  document.ordercuminvoiceform.educess.value = Math.round(veducessamount);
	}
    function myvatamount(form)  // gole
	{
//alert("here");
	  var vvatperc,vvatamount,vnottotal,vnotallowed;
	  vvatperc=0.00;
	  vvatamount=0.00;
	  vnotallowed = parseFloat(document.ordercuminvoiceform.notallowed.value);
	  if (parseFloat(document.ordercuminvoiceform.notallowed.value) > 0 )
	  {
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value) * vnotallowed / 100;
	  }
	  else
	  { 
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value);
	  }
	  
	  vvat = document.ordercuminvoiceform.vat_perc.value;
//alert(vvat);
	  if (isNaN(vvat) === true  )
	  {
	    vvat = 0;
		document.ordercuminvoiceform.vat_perc.value =0;
		alert(' vat% is zsro');
	  }
	  
	  
	  vvatperc = parseFloat(vvat); // document.ordercuminvoiceform.vat_perc.value);
	  vvatamount = vnottotal * vvatperc /100; // parseFloat(document.ordercuminvoiceform.wtotal.value) * vvatperc /100;
	  document.ordercuminvoiceform.vat.value = Math.round(vvatamount);
	}
	function  myswamount(form)
	{
	  var vvatperc,vvatamount,vswbharat_perc , vswbharat_rs;
	  vswbharat_perc=0.00;
	  vswbharat_rs=0.00;
	  vnotallowed = parseFloat(document.ordercuminvoiceform.notallowed.value);
	  if (parseFloat(document.ordercuminvoiceform.notallowed.value) > 0 )
	  {
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value) * vnotallowed / 100;
	  }
	  else
	  { 
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value);
	  }
	  vswbharat_perc = parseFloat(document.ordercuminvoiceform.swbharat_perc.value);
	  vswbharat_rs = vnottotal * vswbharat_perc /100; // parseFloat(document.ordercuminvoiceform.wtotal.value) * vvatperc /100;
	  document.ordercuminvoiceform.swbharat_rs.value = Math.round(vswbharat_rs);
	}
	function  mykkamount(form) 
	{
	  var vvatperc,vvatamount,vkrishikalyan_perc , vkrishikalyan_rs;
	  vkrishikalyan_perc=0.00;
	  vkrishikalyan_rs=0.00;
	  vnotallowed = parseFloat(document.ordercuminvoiceform.notallowed.value);
	  if (parseFloat(document.ordercuminvoiceform.notallowed.value) > 0 )
	  {
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value) * vnotallowed / 100;
	  }
	  else
	  { 
	     vnottotal = parseFloat(document.ordercuminvoiceform.wtotal.value);
	  }
	  vkrishikalyan_perc = parseFloat(document.ordercuminvoiceform.krishikalyan_perc.value);
	  vkrishikalyan_rs = vnottotal * vkrishikalyan_perc /100; // parseFloat(document.ordercuminvoiceform.wtotal.value) * vvatperc /100;
	  document.ordercuminvoiceform.krishikalyan_rs.value = Math.round(vkrishikalyan_rs);
	}
	function adrfunction()
	{
	   alert("adr");
	   alert("<?PHP newaddress(); ?>");
	   


   }
   function testme(form)
   {
     alert('fff');
   }
</script>
</head>
<body>
<?php 

$db_host = $_SESSION['global_db_host']; // "localhost"; 
$db_username = $_SESSION['global_db_username'];  // "root"; 
$db_pass = $_SESSION['global_db_pass']; // "admin@123"; 
$db_name =  $_SESSION['global_db_name']; // "santosh_decorates_database"; 

$con=mysql_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
mysql_connect($db_host,$db_username,$db_pass) or die ("could not connect to mysql");
mysql_select_db("$db_name")  or die ("no database"); 


/*
$db_host = "localhost"; 
$db_username = "root"; 
$db_pass = "admin@123"; 
$db_name = "santosh_decorates_database"; 
$con=mysql_connect("$db_host","$db_username","$db_pass") or die ("could not connect to mysql");
mysql_connect("$db_host","$db_username","$db_pass") or die ("could not connect to mysql");
mysql_select_db("$db_name")  or die ("no database"); 
*/

?>

<div class="container">
 	<form method="POST" name="ordercuminvoiceform"  class="form-signin" onsubmit="return validateform()" action="<?php echo $_SERVER['PHP_SELF']; ?>">		 
        <h2 class="form-heading"> <?php echo 'Welcome : ' .  $_SESSION['CompanyName'] . ' Fy : ' . $_SESSION['fy']  ; ?> &nbsp; Order Cum Invoice Form </h2>
        <hr>
         <div class="form-group"> 
		    <table border="0" class="form-control">
			<?php 
//echo "inside";
			   $formcompanyid = $_SESSION['CompanyID'];
			   $formfy = $_SESSION['fy'];
			   $sqlordershow = "Select * from order_cum_inv_head where companyid = '$formcompanyid' and fy = '" . $formfy . "' order by  customername";
//echo $sqlordershow;
			?>
			<tr> <td> Search On Customer Name/Order No./Quot No:</td>  
			
			     <td> 
				      <select  name="orderid" style="width: 150px"> 
				      <option value="-99">Order_Quot_ID</option>
					  <?php
                      $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where companyid = " . $formcompanyid  . " and fy = '" . $formfy  . "' order by  customername ");
                      while($row = mysql_fetch_array( $sqlordershow ))
                      {
                        echo "<option value=" . $row['0'] . "> "  . $row['9'].'~'.$row['3'].'~'.$row['4'].'~' .$row['1'].'~'. $row['2'] . "</option>";
                      }
                      ?>	         				   
				      </select>
				</td>
				<td> &nbsp;&nbsp; </td>
				<td> <button class="btn btn-lg btn-primary btn-block" id="submit"    name="submit" type="submit">MODIFY</button>
				</td>
				<td> <input type="hidden" readonly name="myid" id="myid" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { $neworderid = $row['0']; echo $neworderid; $_SESSION['global_orderid']=$row['0']; } }?>">

				</td> 
				<td>
				 <input type="hidden" readonly name="newmyid" id="newmyid" value="<?php $neworderid = $_SESSION['global_orderid'];  echo $neworderid; ?> ">
                </td>
				</tr>			 

		     </tr>
			 </table>
			<!-- <hr> -->


			 <table border="0" class="form-control">

			 <td>Customer Name <input type="hidden" name="wid" id="wid"> </td>
		     <td>
			 <select name ="wcname"  style="width: 150px" onfocus="wcnameenabled(this.form)" onBlur="wcnameoff(this.form)" id="wcname" class="form-control"  placeholder="Customer Name"/>
             <option value="0">Change Customer Name</option>
             <?php
                   $result = mysql_query("SELECT * FROM customermaster order by Customername ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  . $row['1'] . "~" . $row['2'] . "~" . $row['3'] . "~" . $row['4'] . "~" . $row['5'] . "~" . $row['6'] . "~" . $row['0'] . "</option>";
                   }
             ?>		 
			 </select>
         	 <input type="text"  hidden name="customer_text" id="text_customer" value="" />
			 <input type="text"  hidden name="customer_code" id="code_customer" value="<?php 
			 
			 if(isset($_POST['submit']) ) 
			 {
			 $formorderid = $_POST["orderid"]; 

             $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid );
		//	 echo $sqlfindcustomer;
			 while($row = mysql_fetch_array($sqlfindcustomer))
             {
			     $fld1 = $row['8']; //echo "cust" . $fld1;
				 $formnewfunaddress = $row['10']. ''. $row['11']. ''. $row['12']. '' . $row['13'];
                 $formnewfuncpin = $row['14'];
				 $formnewquotno = $row['3'];
	    		 $formnewquotdate  = $row['4'];
    			 $formneworderno = $row['1'];
                 $formneworderdate = $row['2'];
				 // gole
             }
			 
			 $result = mysql_query("Select * from customermaster where customerid = " . $fld1);
			 while($row = mysql_fetch_array($result)) 
			 { 
			    $formnewcustname = $row['1'];
				$formnewcustaddress = $row['2']. '~'. $row['3']. '~' . $row['4']. '~' . $row['5'];
                $formnewcustpin = $row['6'];
 
			 } 
			 } 
			 else 
			 {
			 if (isset($_POST['getaddress'])){ $fld1 = $_POST["wcname"]; echo $fld1; } } ?>" />
			 &nbsp;
	 		 <input type="submit" hidden name="getaddress" id="getaddress" value="Get Address"> <!-- onclick="getaddress()> -->
		<!--	 <input type="button" name="getaddress" id="getaddress" value="getaddress" onclick="adrfunction()">  -->


			 <input type ="text"  hidden  name="newcustcode" id="newcustcode" value="<?php if (isset($_POST['getaddress'])){$fld1 = $_POST["wcname"];echo $fld1;}else {echo '0';} ?>" readonly>

			 <br>
			 <input type="text"    name="customername" readonly id="customername" value="<?php if(isset($_POST['submit']) ) {echo $formnewcustname;} if (isset($_POST['getaddress'])){ $fld1 = $_POST["wcname"];  	$result = mysql_query("Select * from customermaster where customerid = " . $fld1); while($row = mysql_fetch_array($result)) { echo $row['1']    ;  } } ?>" />
			 </td>
             <td> &nbsp;&nbsp; </td>
		     <td> Address </td>
			 <td> 
			 <textarea name="wcadd1" id="wcadd1" readonly cols="50" rows="2" onfocus="getcustomeraddress(this.form)" class="form-control"><?php if(isset($_POST['submit']) ) {echo $formnewcustaddress;}  if (isset($_POST['getaddress'])){ echo $custaddress;} ?>   </textarea>
			 <br> Pin code :- <input type="text" name="wpin" id="wpin" class="form-control" value="<?php if(isset($_POST['submit']) ) {echo $formnewcustpin;} if (isset($_POST['getaddress'])){ $fld1 = $_POST["wcname"]; $result = mysql_query("Select * from customermaster where customerid = " . $fld1); while($row = mysql_fetch_array($result)) { if ($row['6'] == '') { echo ''; } else { echo  'Pin code:-' . $row['6']; } } }?>" placeholder="Pin Number"/>
			 </td> <td> &nbsp;&nbsp; </td>
			 <td>  </td>
			 <td> 
			 </td>
			 <td> 
			 </td>
			 </tr>			 
			 <tr hidden>
			 <td> &nbsp; </td>
			 </tr> 

            <tr> <td> Name of Work </td> 
			      <td> <input name="nameofwork" id="nameofwork" type="text" placeholder="Name of Work" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { echo $row['56'];  } }?>"> </td> 
		    </tr>
			
			 <tr>
			      <td> Advance Amount </td>
			      <td> <input type="text"  name="advance_rs" id = "advance_rs" placeholder="Advance Rs" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { echo $row['32'];  } }?>"> </td> 
				  <td> &nbsp; </td>
				  <td> Print Yes/No : </td>
				  <td> <input type="text" name="print_advance" id="print_advance" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { echo $row['58'];  } }?>"> </td>
			  </tr>

			 <tr>
			      <td> Material Payment by Client   </td>
			      <td> <input type="text"  name="material_payment_rs" id = "material_payment_rs" placeholder="Material Payment Rs" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { echo $row['59'];  } }?>"> </td> 
			      <td> &nbsp; </td>
				  <td> Print Yes/No : </td>
				  <td> <input type="text" name="print_material_payment" id="print_material_payment" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"]; $sqlordershow  = mysql_query("SELECT * FROM order_cum_inv_head where  id = " . $formorderid ); while($row = mysql_fetch_array( $sqlordershow )) { echo $row['60'];  } }?>"> </td>
			  </tr>			
			
<!--           <tr> <td> address </td> 
			      <td> <input name="xaddress" id="xaddress" type="text"> </td> 
		    </tr> -->
			 
			 <tr hidden> <td hidden>Func. Dt</td>
			 <td>
             <input name="wfdate" id="wfdate"  hidden type="date" class="form-control" placeholder="function date" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['15']; }}?>"/>
             </td> <td hidden> &nbsp;&nbsp; </td>
		     <td hidden>Address</td>
		     <td hidden>
             <textarea name="wfaddress" hidden id="wfaddress" cols="50" rows="1" value="ad" class="form-control"><?php if(isset($_POST['submit']) ) {echo $formnewfunaddress;} ?> </textarea>
			 <br> Pin Code:-  <input name="wfpincode"  hidden id="wfpincode"  type="text" class="form-control" value="<?php if(isset($_POST['submit']) ) {echo $formnewfuncpin;} ?>" placeholder="6 Digit Pin code"/>
             </td> <td hidden> &nbsp;&nbsp; </td>
			 <td>   </td>
			 <td>           
             </td>
			 <td> 
			 </td>
			 </tr> 
             <tr>
			 <td> &nbsp; </td>
			 </tr>		 
			 <tr hidden> <td hidden>Order ID </td>
			 <td>
             <input name="wid" id="wid" hidden readonly type="text" class="form-control" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['1']; }}?>" placeholder="ID-AutoGenerated"/>
             </td> <td>&nbsp;&nbsp; </td>
		     <td hidden>Quot. No. and Date</td>
			 <td>
             <input name="wquot_no" id="wquot_no" hidden readonly type="text" class="form-control" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['3']; }}?>" placeholder="QuotNo-AutoGenerated"/>
			 &nbsp;&nbsp;  <input name="wquot_dt" hidden id="wquot_dt" type="date" class="form-control" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['4']; }}?>" placeholder="Quot. date"/>
             </td>
             </td> <td> &nbsp;&nbsp; </td>
			 <td> </td>
		     <td>
			 </tr> 
			 </table>
			 <?php  $srnoi =0; ?>
			 <?php
			 
			 if(isset($_POST['submit']) ) 
			 {
			 ?>
			 <br> <hr>
			 <center> Please change Order Below (please enter Quantity as 0 To Delte IT)
			 <input type="text" hidden name="printheadid" id ="printheadid" value="<?php echo $formorderid; ?>">
			 <hr>
			 <table border="1" class="form-control">
			 <tr> <td style="width: 3px"> Sr.No </td> <td style="width: 5px"> Code </td> 
			      <td> Description </td> <td>Rate</td>
				  <td> Unit </td> <td>Quantity <br>Put 0 to delete </td> <td> Amount </td>
                  <td> ACTION </td>				  
			 </tr>
			 <?php
			      $formorderid = $_POST["orderid"];
//				  echo "formorderid = " . $formorderid;

// checking no of entries first 
                  $entryfirst = 0;
				  $sqlgetparticulars = "Select * from order_cum_invoice_detail where headID = " . $formorderid ;
                  $result = mysql_query($sqlgetparticulars);

                  while($row = mysql_fetch_array($result))
                  {
                    $entryfirst ++;
				  }
//
                  if ( $entryfirst == 1)
				  {
// only one entry start

				  $sqlgetparticulars = "Select * from order_cum_invoice_detail where headID = " . $formorderid ;
                  $result = mysql_query($sqlgetparticulars);

                  while($row = mysql_fetch_array($result))
                  {
				  $srnoi++;
                  ?>
				  <tr> 
	              <td> <?php echo $row['3']; ?></td>
				  <td style="width: 5px"> <input type="text" readonly name="change_code1" id="change_code1" value="<?php echo  substr($row['9'],0,3); ?>"> </td>
				  <td> <?php echo $row['13']; ?> </td>
				  <td> <input type="text" size="3" name="change_rate1" id="change_rate1" value="<?php echo $row['12'] ; ?>"> </td>
			      <td> <input type="text" size="3" name="change_unit1" id="change_unit1" value="<?php echo $row['11']; ?>"> </td>
			      <td> <input type="text" name="change_quantity1" id="change_quantity1" value="<?php echo $row['10']; ?>"> </td>	
			      <td> <input type="text" name="change_amount1" id="change_amount1" value="<?php echo $row['14']; ?>"> </td>				  
                  <td> <select name="action_change1" onBlur="mygrandamount(this.form)"> <!--testme(this.form) onBlur="mygrandamount(this.form)" -->
				       <option value="NoAction">NoAction</option>
					   <option value="Update">Update</option>
					   <option value="Delete">Delete</option>
					   </select>
				  </td>
				  </tr>
				  <?php
                  } 


/// only one entry end
				  }
				  else
				  {
				  $sqlgetparticulars = "Select * from order_cum_invoice_detail where headID = " . $formorderid ;
                  $result = mysql_query($sqlgetparticulars);

                  while($row = mysql_fetch_array($result))
                  {
				  $srnoi++;
                  ?>
				  <tr> 
	              <td> <?php echo $row['3']; ?></td>
				  <td style="width: 5px"> <input type="text" readonly name="change_code[]" id="change_code[]" value="<?php echo  substr($row['9'],0,3); ?>"> </td>
				  <td> <?php echo $row['13']; ?> </td>
				  <td> <input type="text" size="3" name="change_rate[]" id="change_rate[]" value="<?php echo $row['12'] ; ?>"> </td>
			      <td> <input type="text" size="3" name="change_unit[]" id="change_unit[]" value="<?php echo $row['11']; ?>"> </td>
			      <td> <input type="text" name="change_quantity[]" id="change_quantity[]" value="<?php echo $row['10']; ?>"> </td>	
			      <td> <input type="text" name="change_amount[]" id="change_amount[]" value="<?php echo $row['14']; ?>"> </td>				  
                  <td> <select name="action_change[]" onBlur="mygrandamount(this.form)"> <!--testme(this.form) onBlur="mygrandamount(this.form)" -->
				       <option value="NoAction">NoAction</option>
					   <option value="Update">Update</option>
					   <option value="Delete">Delete</option>
					   </select>
				  </td>
				  </tr>
				  <?php
                  } 
                  }				  
			 ?>
			 <tr> <td></td> <td> </td> <td>Total Entries</td><td> <input type="text" readonly name="noofentries" id="noofentries" value="0<?php echo $srnoi ?>"> </td> </tr>
			 </table>
<!--			 <hr>
			 <input type="submit" name="change_save" id="change_save" value="UPDATE ME"> &nbsp;&nbsp; -->
<!--			 <input type="reset"  value="RESET ME">
			 <hr> -->
			 <?php
			 }			 
			 ?>
			 <br> <hr>
			 <center>Please Place New Order Below
			 <hr>

			 <table border="1" class="form-control">
			 <tr> <td> Sr.No </td> <td> Code </td> 
			      <td> Description </td> <td>Rate</td>
				  <td> Unit </td> <td>Quantity </td> <td> Amount </td>
			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code1" id="code1" style="width: 100px">
			    <option value="0">Select Code</option>
				<?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2'] .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>		 
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc1" name="desc1" size="20" onfocus="mycurrency1(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate1" name="rate1" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit1" name="unit1" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty1" name="qty1" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount1"  name="amount1" size="15" onfocus="myamount1(this.form)"  value="0"  maxlength="40" placeholder="Amount">
			 </td>
			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code2" id="code2" style="width: 100px">
			   <option value="0">Select Code</option>
			   <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2'] .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc2" name="desc2" size="20" onfocus="mycurrency2(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate2" name="rate2" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>			 
			 <td>
			 <input type="text" id="unit2" name="unit2" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty2" name="qty2" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount2" name="amount2" size="15" onfocus="myamount2(this.form)"  value="0" maxlength="40" placeholder="Amount">
			 </td>

			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code3" id="code3" style="width: 100px" >
			   <option value="0">Select Code</option>
			   <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2'] .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc3" name="desc3" size="20" onfocus="mycurrency3(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate3" name="rate3" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 
			 <td>
			 <input type="text" id="unit3" name="unit3" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty3" name="qty3" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount3" name="amount3" size="15" onfocus="myamount3(this.form)"  value="0"  maxlength="40" placeholder="Amount">
			 </td>

			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
             <td> 
			 <select name="code4" id="code4" style="width: 100px">
			    <option value="0">Select Code</option>
		  	    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc4" name="desc4" size="20" onfocus="mycurrency4(this.form)"  maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate4" name="rate4" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>	 
			 <td>
			 <input type="text" id="unit4" name="unit4" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty4" name="qty4" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount4" name="amount4" size="15" onfocus="myamount4(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>

			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code5" id="code5" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc5" name="desc5" size="20" onfocus="mycurrency5(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate5" name="rate5" value="0" size="10" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit5" name="unit5" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty5" name="qty5" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount5" name="amount5" size="15" onfocus="myamount5(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>
			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code6" id="code6" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc6" name="desc6" size="20" onfocus="mycurrency6(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate6" name="rate6" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>	 
			 <td>
			 <input type="text" id="unit6" name="unit6" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty6" name="qty6" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount6" name="amount6" size="15" onfocus="myamount6(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>
			 </tr>
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code7" id="code7" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .   $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc7" name="desc7" size="20" onfocus="mycurrency7(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate7" name="rate7" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit7" name="unit7" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty7" name="qty7" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount7" name="amount7" size="15" onfocus="myamount7(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>
			 </tr>	
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code8" id="code8" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc8" name="desc8" size="20" onfocus="mycurrency8(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate8" name="rate8" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit8" name="unit8" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty8" name="qty8" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount8" name="amount8" size="15" onfocus="myamount8(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>
			 </tr>	
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code9" id="code9" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc9" name="desc9" size="20" onfocus="mycurrency9(this.form)"   maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate9" name="rate9" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit9" name="unit9" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty9" name="qty9" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount9" name="amount9" size="15" onfocus="myamount9(this.form)"  value="0" maxlength="40" placeholder="Amount">
			 </td>

			 </tr>	
			 <tr> 
			 <td> <?php $srnoi++; echo $srnoi; ?> </td>
			 <td> 
			 <select name="code10" id="code10" style="width: 100px">
			    <option value="0">Select Code</option>
			    <?php
                   $result = mysql_query("SELECT * FROM stockmaster order by Description ");
                   while($row = mysql_fetch_array($result))
                   {
                     echo "<option value=" . $row['0'] . "> "  .  $row['2']  .'~'.$row['1'].'~'.$row['5'].'~' .$row['6'] . "</option>";
                   }
                ?>	
			 </select>
			 </td>
			 <td>
			 <input type="text" id="desc10" name="desc10" size="20" onfocus="mycurrency10(this.form)" maxlength="250" placeholder="Description">
			 </td>
			 <td>
			 <input type="text" id="rate10" name="rate10" size="10" value="0" maxlength="30" placeholder="Rate">
			 </td>
			 <td>
			 <input type="text" id="unit10" name="unit10" size="10" maxlength="20" placeholder="Unit">
			 </td>
			 <td>
			 <input type="text" id="qty10" name="qty10" size="10" value="0" maxlength="25" placeholder="Quantity">
			 </td>
			 <td>
			 <input type="text" id="amount10" name="amount10" size="15" onfocus="myamount10(this.form)" value="0" maxlength="40" placeholder="Amount">
			 </td>
			 </tr>			 			 
<!--			 </table>
			 <hr>
			 <table border="0" class="form-control"> -->
			 <tr> 
<!--			 <td colspan="5">  -->
			 <td>Remark</td>
			 <td> <input type="text" name="remarks1" id="remarks1" size="30" maxlength="250" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['19']; }}   ?>" placeholder="Remarks if any ..">
			 </td> 
			 <td> </td> <td> </td> <td> </td>
			 <td>(+) Transport
			 </td>
			 <td> <input type="text" name="transport" id="transport"   size="15" maxlength="40" value="0<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['29']; }}   ?>" placeholder="Transport" >
			 </tr>
			 <tr> 
<!--			 <td colspan="5">  -->
			 <td>Remark</td>
			 <td>  <input type="text" name="remarks2" id="remarks2"  size="30" maxlength="250" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['20']; }}   ?>" placeholder="Remarks if any ..">
			 </td>
			 <td> </td> <td> </td> <td> </td>
			 <td>(=) Total
			 </td>
			 <td> 
			 <input type="text" name="wtotal" id="wtotal"   onfocus="mytotal1(this.form)" value="0<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['21']; }}   ?>" size="15" maxlength="40" placeholder="Total(1)" >
             </td>
			 </tr>

			 <tr> 
<!--			 <td colspan="5"> -->
             <td>service tax%<input type="text" name="service_perc" size="4" id="service_perc" value="<?php if (isset($_POST['getaddress'])){   $result = mysql_query("Select * from companymaster where companyid = " . $xcompid); while($row = mysql_fetch_array($result)) { if ($row['27'] == '') { echo '0'; } else { echo   $row['27']; } } } if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['16']; }}   ?>" size="10"  placeholder = "service tax%"> 
			 </td>
			 <td><input type="text" name="service_amt" id="service_amt"  onfocus="myservamount(this.form)"  value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['22']; }}   ?>"  placeholder = "service tax amount Rs.">
             </td>
			 <td><!-- educess cess %<input type="text" name="educess_perc" size="4" id="educess_perc" value="<?php if (isset($_POST['getaddress'])){   $result = mysql_query("Select * from companymaster where companyid = " . $xcompid); while($row = mysql_fetch_array($result)) { if ($row['28'] == '') { echo '0'; } else { echo   $row['28']; } } }?>" placeholder = "edcess%">  -->
			 </td>
			 <td> <!-- <input type="text" name="educess" id="educess" onfocus="myeducessamount(this.form)"   placeholder = "cess Rs."> -->
             </td>
			<td> </td>
			<td> </td>
			<td> </td>
			</tr>
            <tr>			
             <td>vat %<input type="text" name="vat_perc"  size="4" id="vat_perc" value="<?php if (isset($_POST['getaddress'])){  $result = mysql_query("Select * from companymaster where companyid = " . $xcompid); while($row = mysql_fetch_array($result)) { if ($row['29'] == '') { echo '0'; } else { echo   $row['29']; } } } if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['18']; }}  ?>" size="5" placeholder="vat %">
			 </td>
			 <td> <input type="text" name="vat" id="vat" onfocus="myvatamount(this.form)" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['24']; }} ?>" placeholder="vat Rs.">
			</td>
            <td> Notification Allowed % </td>
			<td> <input type="text" name="notallowed" id="notallowed" value="<?php if (isset($_POST['getaddress'])){ $fld1 = $_POST["wcname"];  $result = mysql_query("Select * from customermaster where customerid = " . $fld1); while($row = mysql_fetch_array($result)) { if ($row['13'] == '') { echo '0'; } else { echo   $row['13']; } } }  if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['45']; }}    ?>"  size="5">
			</td>
			<td> </td>
			<td> </td>
			<td> </td>
			</tr>
			<tr>
			<td>swatch bharat %<input type="text" name="swbharat_perc" id="swbharat_perc" value="<?php if (isset($_POST['getaddress'])){   $result = mysql_query("Select * from companymaster where companyid = " . $xcompid); while($row = mysql_fetch_array($result)) { if ($row['35'] == '') { echo '0'; } else { echo   $row['35']; } } } if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['51']; }}?>"  size="4" placeholder="Sw %">
			</td>
			<td> <input type="text" name="swbharat_rs" id="swbharat_rs" onfocus="myswamount(this.form)"   value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['52']; }}?>" placeholder="Swatch Bharat Rs">
			</td>
			<td>krishi kalyan%<input type="text" name="krishikalyan_perc" size="4" id="krishikalyan_perc" value="<?php if (isset($_POST['getaddress'])){   $result = mysql_query("Select * from companymaster where companyid = " . $xcompid); while($row = mysql_fetch_array($result)) { if ($row['37'] == '') { echo '0'; } else { echo   $row['37']; } } } if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['53']; }}?>" placeholder="Krishi Kalyan cess %">
			</td>
			<td><input type="text" name="krishikalyan_rs" id="krishikalyan_rs" size="10"   value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['54']; }}?>" onfocus="mykkamount(this.form)" placeholder="KK cess Rs">
			 </td>
			 <td> &nbsp; </td>
			 <td>(=) GRAND TOTAL(WITH TAX)
			 </td>
			 <td>
<!--			 <input type="text" name="wtotal"  id="wtotal"   onfocus="mytotal1(this.form)"      value="0" size="15" maxlength="40" placeholder="Total(1)" >
-->
			 <input type="text" name="wgtotal" id="wgtotal"  onFocus="mygrandamount(this.form)" onClick="mygrandamount(this.form)" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['30']; }}?>" size="15" maxlength="40" placeholder="Grand Total" >
             </td>
			 </tr>	
             <tr>
<!--             <td colspan="5">  -->
			 <td>Inv No</td>
			 <td> <input type="text" name="invoicenumber"  readonly id="invoicenumber" value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['1']; }}?>"  placeholder="Inv No">
			 </td>
			 <td> <input name="winvoice_dt" id="winvoice_dt" type="date" class="form-control"  value="<?php if(isset($_POST['submit']) ) {$formorderid = $_POST["orderid"];  $sqlfindcustomer = mysql_query("Select * from order_cum_inv_head where id = " . $formorderid ); while($row = mysql_fetch_array($sqlfindcustomer)){ echo $row['2']; }}?>"  placeholder="Invoice date"/>
			 </td>
			 <td> </td> <td> </td>
             </tr>			 
			 </table>
			 <table border="0" class="form-control">
			 <tr>
			 <td> </td>
			 <!--
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="new" name="new" type="submit">NEW</button>
			</td>
			 <td> </td>
			 -->
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="save" name="save" type="submit">SAVE</button>
			</td>
			<td> </td>
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="delete" name="delete" type="submit">DELETE</button>
			</td>
			<td> </td>
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="cancel" name="cancel" type="RESET">CANCEL</button>
			</td>
			<td> </td>
		<!--
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="quotation" name="quotation" type="submit">QUOTATION</button>
			</td>
			<td> </td>
	 
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="invoice" name="invoice" type="submit">INVOICE</button>
			</td>
			<td> </td> 
			-->
			<td>
            <button class="btn btn-lg btn-primary btn-block" id="print" name="print" type="submit">PRINT</button>
			</td>
			</tr>

			</table>
			<hr>
        </div>
    </form>

</div>
</body>
</html>