-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: sql313.gungoos.com
-- Generation Time: Jun 13, 2019 at 05:33 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gungo_23120970_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `injectionlist`
--

CREATE TABLE IF NOT EXISTS `injectionlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `injectionname` varchar(255) NOT NULL,
  `approxprice` decimal(12,2) NOT NULL,
  `usedindisease` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `injectionlist`
--

INSERT INTO `injectionlist` (`id`, `injectionname`, `approxprice`, `usedindisease`, `remarks`) VALUES
(1, 'chlorophorm', '1200.00', 'BLOOD PRESSURE', 'new');

-- --------------------------------------------------------

--
-- Table structure for table `listofdisease`
--

CREATE TABLE IF NOT EXISTS `listofdisease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `diseasename` varchar(255) NOT NULL,
  `seasonspecific` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `injectionlist` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `listofdisease`
--

INSERT INTO `listofdisease` (`id`, `diseasename`, `seasonspecific`, `remarks`, `injectionlist`) VALUES
(1, 'cough', 'cold', 'warm clothes', 'sdhd'),
(2, 'cough', 'heat', 'lot of water', 'clothes');

-- --------------------------------------------------------

--
-- Table structure for table `petdiagnosis`
--

CREATE TABLE IF NOT EXISTS `petdiagnosis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `petdetid` int(11) NOT NULL,
  `dateofvisit` date NOT NULL,
  `illness1` varchar(255) NOT NULL,
  `illness2` varchar(255) NOT NULL,
  `dignosis1` varchar(255) NOT NULL,
  `dignosis2` varchar(255) NOT NULL,
  `medicine1` varchar(255) NOT NULL,
  `medicine2` varchar(255) NOT NULL,
  `billamount` double NOT NULL,
  `paidamount` double NOT NULL,
  `nextvisit` date NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `dateofdeath` date NOT NULL,
  `reasonfordeath` varchar(255) NOT NULL,
  `petname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `petdiagnosis`
--

INSERT INTO `petdiagnosis` (`id`, `userid`, `petdetid`, `dateofvisit`, `illness1`, `illness2`, `dignosis1`, `dignosis2`, `medicine1`, `medicine2`, `billamount`, `paidamount`, `nextvisit`, `remarks`, `dateofdeath`, `reasonfordeath`, `petname`) VALUES
(1, 19, 1, '2019-02-01', 'ill cold', '', 'allergy found', '', 'injection type 1', '', 100, 90, '0000-00-00', '', '0000-00-00', '', 'john'),
(2, 19, 2, '2019-02-13', 'having cold and fever', '', 'due to old age', '', 'victamibe z', '', 100, 10, '0000-00-00', 'visit after 20 days', '0000-00-00', '', 'winchy'),
(3, 26, 3, '2005-05-19', 'fever', '', 'infection', '', 'inj.melonex', '', 400, 400, '0000-00-00', 'nil', '0000-00-00', '', 'tomy');

-- --------------------------------------------------------

--
-- Table structure for table `petsinformationdetail`
--

CREATE TABLE IF NOT EXISTS `petsinformationdetail` (
  `petdetailsid` int(11) NOT NULL AUTO_INCREMENT,
  `petheadid` int(11) NOT NULL,
  `pettype` varchar(90) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `petname` varchar(255) NOT NULL,
  `dateofbirth` date NOT NULL,
  `origin` varchar(100) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `illness1` varchar(255) NOT NULL,
  `illness2` varchar(255) NOT NULL,
  `dignosis1` varchar(255) NOT NULL,
  `dignosis2` varchar(255) NOT NULL,
  `medicine1` varchar(255) NOT NULL,
  `medicine2` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `BillAmount` double NOT NULL,
  `BillDate` date NOT NULL,
  `PaidAmount` double NOT NULL,
  `NextVisitDate` date NOT NULL,
  `firstvisitdate` date NOT NULL,
  `allergy1` varchar(255) NOT NULL,
  `allergy2` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `contactperson` varchar(90) NOT NULL,
  `TotalPendingAmount` double NOT NULL,
  `petid` int(11) NOT NULL,
  PRIMARY KEY (`petdetailsid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `petsinformationdetail`
--

INSERT INTO `petsinformationdetail` (`petdetailsid`, `petheadid`, `pettype`, `gender`, `petname`, `dateofbirth`, `origin`, `speciality`, `illness1`, `illness2`, `dignosis1`, `dignosis2`, `medicine1`, `medicine2`, `remarks`, `BillAmount`, `BillDate`, `PaidAmount`, `NextVisitDate`, `firstvisitdate`, `allergy1`, `allergy2`, `userid`, `username`, `contactperson`, `TotalPendingAmount`, `petid`) VALUES
(1, 19, '0', 'MALE', 'john', '2017-07-01', 'from amar pets nashik', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2019-02-11', '', '', 19, 'Suvarna Raje', 'SUVARNA DATTATRYA raje', 0, 29),
(2, 19, '0', 'MALE', 'winchy', '2010-09-09', 'origin from australia', '', '', '', '', '', '', '', 'winchy doberman', 0, '0000-00-00', 0, '0000-00-00', '2019-02-12', '', '', 19, 'Suvarna Raje', 'SUVARNA DATTATRYA raje', 0, 2),
(3, 26, '0', 'MALE', 'tomy', '0000-00-00', 'cofered market', '', 'na', 'na', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2025-04-19', 'no', 'na', 26, 'bala bhoir', 'bala bhoir', 0, 31),
(4, 20, '0', 'MALE', 'Tt', '0000-00-00', 'Hg', 'Tf', 'Ff', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '0000-00-00', 'Gg', '', 20, 'Prashant', 'PRASHANT GOLE', 0, 27),
(5, 20, '0', 'MALE', 'Vgg', '0000-00-00', 'Ff', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '0000-00-00', 'Cc', '', 20, 'Prashant', 'PRASHANT GOLE', 0, 31),
(6, 20, 'Dog  Chow Chow', 'MALE', 'test', '2009-09-09', 'na', 'very angry', 'leg injury', '', '', '', '', '', 'na', 0, '0000-00-00', 0, '0000-00-00', '2019-04-14', 'ana', '', 20, 'Prashant', 'PRASHANT GOLE', 0, 37),
(7, 26, 'dog  pomerion', 'MALE', 'na', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '0000-00-00', '', '', 26, 'bala bhoir', 'bala bhoir', 0, 31),
(8, 20, 'Tortoise  indian', 'MALE', '', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 20, 'Prashant', 'PRASHANT GOLE', 0, 53),
(9, 24, 'dog  labrador', 'FEMALE', 'Sweety', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '0000-00-00', '', '', 24, 'murari joshi', 'murari joshi', 0, 32),
(10, 21, 'dog  pomerion', 'MALE', 's', '0000-00-00', 'cofered market', 'aggressive', 'n', '', '', '', '', '', 'good', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'Nl', '', 21, 'Hajare Badalapur', 'Hajare', 0, 31),
(11, 23, 'dog  pomerion', 'MALE', 'n', '0000-00-00', 'friends', 'good', 'n', 'n', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 23, 'Bhutkar', 'Bhutkar', 0, 31),
(12, 24, 'dog  labrador', 'FEMALE', 'n', '0000-00-00', 'premium pets', '', 'n', 'n', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 24, 'murari joshi', 'murari joshi', 0, 32),
(13, 25, 'dog  labrador', 'MALE', 'n', '0000-00-00', 'n', 'n', 'n', 'n', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 25, 'kharate ritesh', 'kharate ritesh', 0, 32),
(14, 26, 'dog  pomerion', 'MALE', '', '0000-00-00', 'n', 'n', 'n', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 26, 'bala bhoir', 'bala bhoir', 0, 31),
(15, 27, 'Dog  indian', 'MALE', 'rancho', '0000-00-00', 'stray local', 'n', 'n', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 27, 'manashi gosavi', 'manashi gosavi', 0, 58),
(16, 28, 'dog  doberman', 'MALE', '', '0000-00-00', 'friends', '', 'n', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 28, 'patil harish', 'patil harish', 0, 2),
(17, 29, 'dog  labrador', 'FEMALE', 'j', '0000-00-00', 'n', 'n', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 29, 'sakpal ahok', 'sakpal ahok', 0, 32),
(18, 30, 'dog  alsetion', 'MALE', 'n', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 30, 'bhanushali sai', 'bhanushali sai', 0, 30),
(19, 31, 'Dog  indian', 'MALE', 'n', '0000-00-00', 'local', 'aggressive', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 31, 'sonawane chatnya', 'sonawane chatnya', 0, 58),
(20, 32, 'dog  labrador', 'MALE', '', '0000-00-00', 'n', 'n', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 32, 'sonawane amit', 'sonawane amit', 0, 32),
(21, 32, 'Dog  Beagle', 'MALE', 'b', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 32, 'sonawane amit', 'sonawane amit', 0, 36),
(22, 33, 'dog  pomerion', 'MALE', 'Taffy', '0000-00-00', 'friends', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 33, 'patel pratiksha', 'patel pratiksha', 0, 31),
(23, 34, 'dog  labrador', 'MALE', 'Buzzo', '0000-00-00', 'n', '', 'n', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 34, 'khare dipa', 'khare dipa', 0, 32),
(24, 35, 'Dog  indian', 'MALE', 'n', '0000-00-00', 'n', '', 'n', 'n', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 35, 'yadav pradip', 'yadav pradip', 0, 58),
(25, 36, 'dog  doberman', 'MALE', '', '0000-00-00', '', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 36, 'bhoir moreshwar', 'bhoir moreshwar', 0, 2),
(26, 37, 'dog  labrador', 'MALE', 'n', '0000-00-00', 'ajay nakhwal', 'good', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 37, 'mangesh pisawali', 'mangesh pisawali', 0, 32),
(27, 38, 'dog  labrador', 'FEMALE', 's', '0000-00-00', 'n', '', '', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 38, 'sonar prakash', 'sonar prakash', 0, 32),
(28, 39, 'Dog  Great Dane', 'MALE', '', '0000-00-00', 'friends', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'nn', 39, 'aniket kajale', 'aniket kajale', 0, 39),
(29, 40, 'dog  labrador', 'FEMALE', 'sweety', '0000-00-00', 'n', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 40, 'kadam mangesh', 'kadam mangesh', 0, 32),
(30, 41, 'dog  pomerion', 'MALE', '', '0000-00-00', 'friends', '', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 41, 'thakare prakash', 'thakare prakash', 0, 31),
(31, 42, 'dog  pomerion', 'FEMALE', 'n', '0000-00-00', 'n', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 42, 'suryanshi ramchandra lahanu', 'suryanshi ramchandra lahanu', 0, 31),
(32, 43, 'dog  labrador', 'MALE', '', '0000-00-00', 'n', 'n', 'n', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 43, 'ramesh joshi', 'ramesh joshi', 0, 32),
(33, 44, 'dog  labrador', 'MALE', '', '0000-00-00', 'friends', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 44, 'prabhu titwala', 'prabhu titwala', 0, 32),
(34, 45, 'Dog  Rottweiler', 'MALE', '', '0000-00-00', 'friends', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 45, 'mhatre jayesh', 'mhatre jayesh', 0, 38),
(35, 46, 'Dog  Rottweiler', 'MALE', '', '0000-00-00', '', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 46, 'gagli hotel', 'gugli hotel', 0, 38),
(36, 47, 'dog  pomerion', 'MALE', '', '0000-00-00', 'friends', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 47, 'gawali dipak', 'gawali dipak', 0, 31),
(37, 20, 'dog  labrador', 'MALE', '', '0000-00-00', '', 'n', '', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', 'n', 20, 'Prashant', 'PRASHANT GOLE', 0, 32),
(38, 49, 'Dog  indian', 'MALE', '', '0000-00-00', 'n', '', '', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 49, 'sanap vijay', 'sanap vijay', 0, 58),
(39, 50, 'Dog  Beagle', 'FEMALE', 'b', '0000-00-00', 'cofered market', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 50, 'chachlani manisha', 'chachlani manisha', 0, 36),
(40, 51, 'Dog  Rottweiler', 'MALE', '', '0000-00-00', '', 'n', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 51, 'shinganiya anil', 'shinghaniya anil', 0, 38),
(41, 52, 'dog  doberman', 'MALE', '', '0000-00-00', 'n', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 52, 'kailash shinde', 'kailash shinde', 0, 2),
(42, 53, 'Dog  indian', 'MALE', '', '0000-00-00', '', 'n', 'n', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 53, 'mahendra lodha', 'mahindra lodha', 0, 58),
(43, 54, 'dog  pomerion', 'FEMALE', 's', '0000-00-00', 'n', 'n', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', 'n', 54, 'pednekar pravin', 'pednekar pravin', 0, 31),
(44, 55, 'Dog  indian', 'MALE', '', '0000-00-00', '', 'n', '', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 55, 'bhoir prakash', 'bhoir prakash', 0, 58),
(45, 56, 'Dog  Dalmation', 'MALE', '', '0000-00-00', '', 'n', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', 'n', 56, 'narode rajendra', 'narode rajendra', 0, 43),
(46, 57, 'Dog  indian', 'MALE', '', '0000-00-00', 'n', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 57, 'pillae balkrishna', 'pillage balkrishna', 0, 58),
(47, 58, 'dog  labrador', 'MALE', '', '0000-00-00', 'n', 'n', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', 'n', 58, 'sing arpit', 'sing arpit', 0, 32),
(48, 60, 'Dog  indian', 'MALE', '', '0000-00-00', '', '', 'n', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', 'n', '', 60, 'gurirya synthetic', 'gurirya synthetic', 0, 58),
(49, 20, 'Dog  indian', 'MALE', '', '0000-00-00', '', 'n', 'n', '', '', '', '', '', 'n', 0, '0000-00-00', 0, '0000-00-00', '2028-04-19', '', '', 20, 'Prashant', 'PRASHANT GOLE', 0, 58),
(50, 253, 'dog  labrador', 'MALE', '', '0000-00-00', 'friends', 'aggressive', '', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2029-04-19', 'n', 'n', 253, 'janvi bhosale', 'janvi bhosale', 0, 32),
(51, 254, 'Dog  indian', 'MALE', 'ashu', '0000-00-00', 'local', '', 'n', '', '', '', '', '', 'Ashu ', 0, '0000-00-00', 0, '0000-00-00', '2029-04-19', 'n', 'n', 254, 'Gauri dugie', 'GAURI DUGIE', 0, 58),
(52, 253, 'dog  pomerion', 'MALE', 'Prience', '0000-00-00', 'friends', 'aggressive', '', 'n', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2029-04-19', 'n', '', 253, 'janvi bhosale', 'janvi bhosale', 0, 31),
(53, 258, 'Tortoise  indian', 'MALE', 'n', '0000-00-00', 'n', '', 'n', '', '', '', '', '', '', 0, '0000-00-00', 0, '0000-00-00', '2029-04-19', 'n', '', 258, 'Abhijit chawan', 'Abhijit chawan', 0, 53);

-- --------------------------------------------------------

--
-- Table structure for table `petsinformationhead`
--

CREATE TABLE IF NOT EXISTS `petsinformationhead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `contactperson` varchar(90) NOT NULL,
  `dateofvisit` date NOT NULL,
  `address_1` varchar(90) NOT NULL,
  `address_2` varchar(90) NOT NULL,
  `city` varchar(90) NOT NULL,
  `pincode` int(6) NOT NULL,
  `phone1` varchar(90) NOT NULL,
  `phone2` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `petsinjections`
--

CREATE TABLE IF NOT EXISTS `petsinjections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `petsdetailsid` int(11) NOT NULL,
  `injectionid` int(11) NOT NULL,
  `injectionname` varchar(255) NOT NULL,
  `dateofinjection` date NOT NULL,
  `whengiven` date NOT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `petstypelist`
--

CREATE TABLE IF NOT EXISTS `petstypelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pettype` varchar(90) NOT NULL,
  `petsubtype` varchar(90) NOT NULL,
  `speciality` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `petstypelist`
--

INSERT INTO `petstypelist` (`id`, `pettype`, `petsubtype`, `speciality`, `remarks`) VALUES
(1, 'cat', 'small cat', 'milk and other animals', 'life upto 15 years'),
(2, 'dog', 'doberman', 'strong', 'eats flesh'),
(27, 'cat', 'big cat', 'jungle desnse', 'very strong built'),
(29, 'Horse', 'Arbi Borse', 'Fast Running', 'normal height 6 feet'),
(30, 'dog', 'alsetion', 'pedigree', 'good'),
(31, 'dog', 'pomerion', 'busy', 'good'),
(32, 'dog', 'labrador', 'trained', 'good'),
(33, 'Dog', 'Afghan hound', 'Long hair', 'busy'),
(35, 'Dog', 'Basset Hound', 'trained', 'good'),
(36, 'Dog', 'Beagle', 'trained', 'good'),
(37, 'Dog', 'Chow Chow', 'trained', 'good'),
(38, 'Dog', 'Rottweiler', 'trained', 'good'),
(39, 'Dog', 'Great Dane', 'Height', 'Heavy bone'),
(40, 'Dog', 'Cocker Spaniel', 'Long ear', 'hong hair'),
(41, 'Dog', 'Golden retriwer', 'busy', 'double bone'),
(42, 'Dog', 'Boxer', 'Punch face', 'pedigree'),
(43, 'Dog', 'Dalmation', 'spotted', 'white / brown'),
(44, 'Dog', 'Siberian Husky', 'long hair', 'snow white'),
(45, 'Dog', 'Poodle', 'long hair', 'milky white'),
(46, 'Dog', 'Bulldog', 'english / british', 'heavy size'),
(47, 'Dog', 'American Bully', 'heavy', 'Fatty'),
(48, 'Dog', 'Pug', 'short body heavy head', 'Fatty'),
(49, 'Dog', 'Bullmastiff', 'heavy', 'heavy size'),
(50, 'Dog', 'Saint Bernard', 'long hair', 'Heavy bone'),
(51, 'Dog', 'Neapolitan Mastiff', 'heavy', 'Heavy bone'),
(52, 'Dog', 'Dashund', 'Short and long body', 'sharp'),
(53, 'Tortoise', 'indian', 'forest', 'good'),
(54, 'Tortoise', 'singapure', 'red ear', 'good'),
(55, 'Tortoise', 'malasian', 'Tringle', 'brownish'),
(56, 'cat', 'persian', 'long hair', 'iranian ,flat face ,short face,'),
(57, 'Rabbit', 'Blue eyes', 'milky', 'white'),
(58, 'Dog', 'indian', 'cross', 'good'),
(59, 'Bird', 'Love bird', 'agapornis comman name', 'Greay headed'),
(60, 'Parrot', 'Cockatoo', 'Psittaciformes', 'colourful feathers'),
(61, 'Parrot', 'The blue-and-yellow ', 'The blue-and-yellow macaw (Ara ararauna), also known as the blue-and-gold macaw, is a large', 'striking color Speak'),
(62, 'Horse', 'Arabian Horse', 'has long been a favorite the world over. Hailing from the Arabian Peninsula, this breed is easy to spot with its distinctive head shape and high, proud tail carriage.', 'sharp'),
(63, 'Horse', 'quarter horse', 'Known as the fastest breed of horse over short distances, Quarter horses are popular mounts for both trail and competition. They are often used for western pleasure riding and other western events such as barrel racing, roping and cutting, but they can al', 'American breed'),
(64, 'Horse', 'Thoroughbred', 'The Thoroughbred is best known for its use in horse racing. Developed in England in the 17th and 18th century, this breed is high spirited and known for its heart.', 'High spirted ,Good for racing'),
(65, 'Horse', 'Tennessee Walker', 'Its smooth gaits, such as the four-beat "running walk," make it comfortable for riding long distances, so it was the mount of choice for many Civil War generals.', 'gaited breed of horse ,use Farm & plantation'),
(66, 'Horse', 'Morgan', 'long hair', 'Compact, brave and agreeable, the Morgan horse is best known for its versatility. One of the oldest breeds developed in the United States, all Morgans trace back to the foundation sire, Figure'),
(67, 'Horse', 'paint', 'While some people consider the paint a "color breed," the American Paint Horse Association considers them a true breed, as paints have a strict bloodline requirement and distinctive breed characteristics.', 'heavy size'),
(68, 'Horse', 'Appaloosas', ', Appaloosas are best known for their colorful spotted coat', 'They are tough, independent, hardy and sure-footed, with big bodies and sparse manes and tails. Appaloosas are often used as stock horses and pleasure mounts, and also make excellent trail horses'),
(69, 'Horse', 'miniature horse', 'The miniature horse was developed in Europe in the 1600s. The breed''s two registries have different height requirements, but the horses must fall under 34-38 inches, measured from the last hairs of the mane', 'While they are extremely small, they are considered horses and not ponies. In the past, the breed has been kept as pets by nobility and used for work in coal mines. Today they are used as driving horses and sometimes even as service animals'),
(70, 'Horse', 'wormblood', 'Technically warmbloods are not a breed but a group that encompasses a number of types and breeds, including the Hanoverian, Holsteiner, Oldenburg, and Trakhner.', 'Warmbloods are characterized by open stud book policies and are known for their prowess as sport horses, excelling in jumping as well as dressage.'),
(71, 'Horse', 'Karwad', 'Curved ear', 'sharp ,running'),
(72, 'Horse', 'Punjabi', 'heavy bone', 'long size');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'laptio', '14 inch dell ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'computer', 'sony 18"', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'jtp', 'jtp');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `PetHuman` varchar(7) NOT NULL,
  `Nameofperson` varchar(100) NOT NULL,
  `ad1` varchar(100) NOT NULL,
  `ad2` varchar(100) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `mobile1` varchar(16) NOT NULL,
  `mobile2` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=332 ;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `user_email`, `user_type`, `user_password`, `PetHuman`, `Nameofperson`, `ad1`, `ad2`, `pincode`, `mobile1`, `mobile2`) VALUES
(1, 'admin', 'prashant.gole@gmail.com', 'ADMIN', 'admin', 'PETS', '', '', '', '', '', ''),
(2, 'pdg', 'sharprash@yahoo.com', 'USER', 'pdg', '', '', '', '', '', '', ''),
(20, 'Prashant', 'prashant.gole@gmail.com', 'USER', 'p@1234', 'PETS', 'PRASHANT GOLE', 'Building No 3 Block  5 Chandrashekhar Society Swami Nityananda Road Andheri East', '', '400069', '+919869068331', ''),
(19, 'Suvarna Raje', 'suvarnad.raje@gmail.com', 'USER', '982099', 'PETS', 'SUVARNA DATTATRYA raje', '13 sai Krupa apt Netivali kalyan.e', '', '421306', '9819345153', ''),
(18, 'userhuman', 'u4@u4.com', 'USER', 'userhuman', 'HUMAN', '', '', '', '', '', ''),
(16, 'parthapets', 'parth.ngo@gmail.com', 'ADMIN', 'parthapets', 'PETS', '', '', '', '', '', ''),
(17, 'userpets', 'x1@t.com', 'USER', 'userpets', 'PETS', '', '', '', '', '', ''),
(15, 'PARTHAHUMAN', 'parth.ngo@gmail.com', 'ADMIN', 'parthahuman', 'HUMAN', '', '', '', '', '', ''),
(21, 'Hajare Badalapur', 'prashant.gole@gmail.com', 'USER', '9221307949', 'PETS', 'Hajare', 'Ambernarh', '', '4', '', '+91'),
(22, 'Ashok kale', 'prashant.gole@gmail.com', 'USER', '9702166307', 'PETS', 'Ashok kale', 'Mumbai', '', '4', '9619433809', ''),
(23, 'Bhutkar', 'prashant.gole@gmail.com', 'USER', '9821671330', 'PETS', 'Bhutkar', 'Dombivali', '', '4', '', '982137241'),
(24, 'murari joshi', 'raje.datta007@gmail.com', 'USER', '9920426265', 'PETS', 'murari joshi', 'dombivali .w', '4', '4', '7776074604', ''),
(25, 'kharate ritesh', 'raje.datta007@gmail.com', 'USER', '9224387866', 'PETS', 'kharate ritesh', 'Near D ward kalyan.e', '', '421306', '9221212727', ''),
(26, 'bala bhoir', 'raje.datta007@gmail.com', 'USER', '9967570737', 'PETS', 'bala bhoir', ' gauri pada yogidham', '', '4', '9967570737', ''),
(27, 'manashi gosavi', 'raje.datta007@gmail.com', 'USER', '9822872706', 'PETS', 'manashi gosavi', 'no', '', '4', '9822872706', ''),
(28, 'patil harish', 'raje.datta007@gmail.com', 'USER', '9967541111', 'PETS', 'patil harish', 'matlu bangla kyn shil ', '', '4', '9967541111', ''),
(29, 'sakpal ahok', 'raje.datta007@gmail.com', 'USER', '9028880355', 'PETS', 'sakpal ahok', 'badlapur w', '', '4', '8108686449', ''),
(30, 'bhanushali sai', 'raje.datta007@gmail.com', 'USER', '9892798804', 'PETS', 'bhanushali sai', 'no', '', 'no', '9892798804', ''),
(31, 'sonawane chatnya', 'raje.datta007@gmail.com', 'USER', '9930816123', 'PETS', 'sonawane chatnya', 'kolsewadi kyn e', '', '4', '9930816123', ''),
(32, 'sonawane amit', 'raje.datta007@gmail.com', 'USER', '9867444789', 'PETS', 'sonawane amit', 'hazi malag r kyn e', '', '4', '9867444789', ''),
(33, 'patel pratiksha', 'raje.datta007@gmail.com', 'USER', '9224081457', 'PETS', 'patel pratiksha', 'jammi baug  kyn e', '', '4', '9224081457', ''),
(34, 'khare dipa', 'raje.datta007@gmail.com', 'USER', '9820869604', 'PETS', 'khare dipa', 'no', '', '4', '9820869604', ''),
(35, 'yadav pradip', 'raje.datta007@gmail.com', 'USER', '9892130275', 'PETS', 'yadav pradip', 'wavanja road taloja', '', '4', '9892130275', ''),
(36, 'bhoir moreshwar', 'raje.datta007@gmail.com', 'USER', '9930606999', 'PETS', 'bhoir moreshwar', 'pisawali', '', '4', '9930606999', ''),
(37, 'mangesh pisawali', 'raje.datta007@gmail.com', 'USER', '9969376711', 'PETS', 'mangesh pisawali', 'manse offic kyn e', '', '4', '9969376711', ''),
(38, 'sonar prakash', 'raje.datta007@gmail.com', 'USER', '9029263748', 'PETS', 'sonar prakash', 'kolsewadi kyn e ', '', '4', '9029263748', ''),
(39, 'aniket kajale', 'raje.datta007@gmail.com', 'USER', '9594936701', 'PETS', 'aniket kajale', 'badlapur w', '', '4', '9594936701', ''),
(40, 'kadam mangesh', 'raje.datta007@gmail.com', 'USER', '98196777271', 'PETS', 'kadam mangesh', 'bhanushali hall kyn e', '', '4', '9819677271', ''),
(41, 'thakare prakash', 'raje.datta007@gmail.com', 'USER', '9821995456', 'PETS', 'thakare prakash', 'shatri nager kyn e', '', '4', '9821995456', ''),
(42, 'suryanshi ramchandra lahanu', 'raje.datta007@gmail.com', 'USER', '9892013037', 'PETS', 'suryanshi ramchandra lahanu', 'tisgoan road kyn e', '', '4', '9892013037', ''),
(43, 'ramesh joshi', 'raje.datta007@gmail.com', 'USER', '9821461231', 'PETS', 'ramesh joshi', 'junni dom w', '', '4', '9821461231', ''),
(44, 'prabhu titwala', 'raje.datta007@gmail.com', 'USER', '9664447053', 'PETS', 'prabhu titwala', 'gr patil clg titwala e', '', '4', '964447053', ''),
(45, 'mhatre jayesh', 'raje.datta007@gmail.com', 'USER', '9819844435', 'PETS', 'mhatre jayesh', 'sai gaon manpada dombivali', '', '4', '9819844435', ''),
(46, 'gagli hotel', 'raje.datta007@gmail.com', 'USER', '9223364444', 'PETS', 'gugli hotel', 'desai villege kyn shil road', '', '4', '9223364444', ''),
(47, 'gawali dipak', 'raje.datta007@gmail.com', 'USER', '8976158959', 'PETS', 'gawali dipak', 'gawali chall kyn e', '', '4', '8976158959', ''),
(48, 'kiran', 'raje.datta007@gmail.com', 'USER', '9969376711', 'PETS', 'kiran', 'pisawali kyn e', '', '4', '9969376711', ''),
(49, 'sanap vijay', 'raje.datta007@gmail.com', 'USER', '9702711781', 'PETS', 'sanap vijay', 'sai baba nager kyn e', '', '421306', '8097858158', ''),
(50, 'chachlani manisha', 'raje.datta007@gmail.com', 'USER', '9867232734', 'PETS', 'chachlani manisha', 'lodha heaven green park bunglo no 107', '', '4', '9867232734', ''),
(51, 'shinganiya anil', 'raje.datta007@gmail.com', 'USER', '9324341111', 'PETS', 'shinghaniya anil', 'gol maidan ulasnager-1', '', '4', '9324311111', ''),
(52, 'kailash shinde', 'raje.datta007@gmail.com', 'USER', '9821876999', 'PETS', 'kailash shinde', 'tata power kyn e', '', '421306', '9821876999', ''),
(53, 'mahendra lodha', 'raje.datta007@gmail.com', 'USER', '9029633204', 'PETS', 'mahindra lodha', 'chandresen niketen g wing 303 lodha kyn e', '', '421306', '9029633204', ''),
(54, 'pednekar pravin', 'raje.datta007@gmail.com', 'USER', '9987211374', 'PETS', 'pednekar pravin', 'd-11/8 saydri nager kyn w', '', '4', '9987211374', ''),
(55, 'bhoir prakash', 'raje.datta007@gmail.com', 'USER', '9221528979', 'PETS', 'bhoir prakash', 'manpada [ratna]', '', '4', '9221528979', ''),
(56, 'narode rajendra', 'raje.datta007@gmail.com', 'USER', '9930934399', 'PETS', 'narode rajendra', 'katemanivali kyn -e', '', '4', '9930934399', ''),
(57, 'pillae balkrishna', 'raje.datta007@gmail.com', 'USER', '9819280390', 'PETS', 'pillage balkrishna', 'sai baba nager kyn e', '', '4', '9819280390', ''),
(58, 'sing arpit', 'raje.datta007@gmail.com', 'USER', '8976235815', 'PETS', 'sing arpit', 'chinchapada road kyn -e', '', '4', '8976235815', ''),
(59, 'prabhu gite', 'raje.datta007@gmail.com', 'USER', '9664447053', 'PETS', 'prabhu gite', 'titwala -e gr patil high school', '', '4', '9664447053', ''),
(60, 'gurirya synthetic', 'raje.datta007@gmail.com', 'USER', '9222000887', 'PETS', 'gurirya synthetic', 'phase-1 midc dombivali -e', '', '4', '9222000887', ''),
(61, 'old age home', 'raje.datta007@gmail.com', 'USER', '9821916422', 'PETS', 'old age home', 'hazi malag r kyn e', '', '421306', '9594839548', ''),
(62, 'mhatre machindra', 'raje.datta007@gmail.com', 'USER', '9819535545', 'PETS', 'mhatre machindra', 'gograwadi dombivali -e', '', '4', '9819195154', ''),
(63, 'yadav sameer', 'sai.vetclinic@yahoo.com', 'USER', '9987912696', 'PETS', 'yadav sameer', 'G.571 railway quarter Rb 3978kalyan.e', '', '421306', '9987912696', ''),
(64, 'shivangi bagi ramesh', 'sai.vetclinic@yahoo.com', 'USER', '9920839698', 'PETS', 'shinangi bagi ramesh', 'A.304 dev darshan adeshwar park bail bazar kalyan', '', '421301', '9920839698', ''),
(65, 'waghchore aruna', 'sai.vetclinic@yahoo.com', 'USER', '9867337999', 'PETS', 'waghchore aruna', '106 ,sai hiradeep society behind Raymond show room shanti nager ulasnager.3', '', '4', '9867337999', ''),
(66, 'amar Rajput', 'sai.vetclinic@yahoo.com', 'USER', '9867371014', 'PETS', 'Amar Rajput', 'bhandarli villeage swami samarth mandir ', '', '4', '9867371014', ''),
(67, 'anjankar Nishant', 'sai.vetclinic@yahoo.com', 'USER', '8805285900', 'PETS', 'Anjankar Nishant', 'Rashree dhara , C wing 702 Tejpal netivali kalyan.e', '', '421306', '8805285900', ''),
(68, 'Gaikwad sunny', 'sai.vetclinic@yahoo.com', 'USER', '9821009402', 'PETS', 'Gaikwad sunny', 'Gaikwad chall opp Gayatri school kolsewadi kalyan.e', '', '421306', '9821009402', ''),
(69, 'Hitesh pahanji', 'sai.vetclinic@yahoo.com', 'USER', '9323291229', 'PETS', 'Hitesh pahanji', 'B. no 530 room no 11,12 shiru chowk ulasnager 2', '', '4', '9323291229', ''),
(70, 'Amar deep sawant', 'sai.vetclinic@yahoo.com', 'USER', '9004432660', 'PETS', 'Amaedeep sawant', 'Ganesh A. 001 apt Karpe wadi kalyan.e', '', '421306', '9004432660', ''),
(71, 'Dipak yadav', 'sai.vetclinic@yahoo.com', 'USER', '8097677021', 'PETS', 'Dipak Yadav', 'nandadeep nager Gosavi pura kalyan.e', '', '421306', '9930725113', ''),
(72, 'Thakre facebook', 'sai.vetclinic@yahoo.com', 'USER', '9920061542', 'PETS', 'Thakre facebook', 'maitri apt back side of mahajan hospital kalyan.w', '', '4', '9920061542', ''),
(73, 'chawan manish', 'sai.vetclinic@yahoo.com', 'USER', '996749718', 'PETS', 'Chawan manish', 'chawan baug santoshi mata road kalyan.w', '', '4', '9967497108', ''),
(74, 'Kukadiya rakesh', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', 'Kukadiya Rakesh', 'Gurukrupa society chall no 2/3 santoshi mata road kalyan.w', '', '4', '9821456672', ''),
(75, 'Chawan GSD', 'sai.vetclinic@yahoo.com', 'USER', '9321040785', 'PETS', 'Chawan GSD', 'A.11 anmol Garden kalyan.e', '', '421306', '9321040785', ''),
(76, 'Pawase nana', 'sai.vetclinic@yahoo.com', 'USER', '9821027585', 'PETS', 'Pawase nana', 'gaon devi temple chinpada road kalyan.e', '', '421306', '9821027585', ''),
(77, 'Rajiv raj', 'sai.vetclinic@yahoo.com', 'USER', '9867045206', 'PETS', 'rajiv raj', 'Room no K 9 Gokul society tukaram bhane nager adhavali kalyan.e', '', '421306', '9867045206', ''),
(78, 'Khot ritesh', 'sai.vetclinic@yahoo.com', 'USER', '9167676868', 'PETS', 'Khot ritesh', 'Gangari apt opp Hotel kalyan.e', '', '421306', '9167676868', ''),
(79, 'Tushar patil', 'sai.vetclinic@yahoo.com', 'USER', '9321141010', 'PETS', 'Tushar patil', 'Laxmikant Farm mamnoli ', '', '4', '9321141010', ''),
(80, 'barge avinash', 'sai.vetclinic@yahoo.com', 'USER', '9221944399', 'PETS', 'Barge avinash', 'BR no railway quarter kalyan.e', '', '421306', '9221944399', ''),
(81, 'Sanjay Gaikwad', 'sai.vetclinic@yahoo.com', 'USER', '9271513911', 'PETS', 'Sanjay gaikwad', 'Room no 2 kamgar vasahat tawari pada kalyan.w', '', '4', '9271513911', ''),
(82, 'Devkule Trupti', 'sai.vetclinic@yahoo.com', 'USER', '9220869353', 'PETS', 'Devkule trupti', 'palava', '', '421306', '9220869353', ''),
(83, 'Maharaj', 'sai.vetclinic@yahoo.com', 'USER', '9819358984', 'PETS', 'Maharaj', 'ambe mata mandir warap', '', '4', '9819358984', ''),
(84, 'Rane pom', 'sai.vetclinic@yahoo.com', 'USER', '8108706545', 'PETS', 'Rane pom', 'Ganesh apt netivali kalyan.e', '', '421306', '8108706545', ''),
(85, 'Umesh reddy', 'sai.vetclinic@yahoo.com', 'USER', '9029353130', 'PETS', 'Umesh Reddy', 'sai apt netivali kalyan.e', '', '421306', '9029353130', ''),
(86, 'Anushree bemal sarkar', 'sai.vetclinic@yahoo.com', 'USER', '9167947596', 'PETS', 'Anushree bemal sarkar', 'A sarvoday garden 3 /402 kalyan.w', '', '421306', '9167947596', ''),
(87, 'waman shinde', 'sai.vetclinic@yahoo.com', 'USER', '9594026199', 'PETS', 'waman shinde', 'classic apt room no 16 kailash nzger shanker pawase r katemanivali kyn -e', '', '421306', '9594026199', ''),
(88, 'Gopal Krishna', 'sai.vetclinic@yahoo.com', 'USER', '9869697054', 'PETS', 'Gopal krishna', 'Lokvatika', '', '421306', '9869697054', ''),
(89, 'Dipali jadhav', 'sai.vetclinic@yahoo.com', 'USER', '9930841819', 'PETS', 'Dipali jadhav', 'Shikshak sadan room no 4 puna link road chakki naka kalyan,e', '', '4', '9930841819', ''),
(90, 'Khajid cat', 'sai.vetclinic@yahoo.com', 'USER', '9867863755', 'PETS', 'Khajid cat', 'saryoday garden patri pul kalyan.w', '421301', '421301', '9867863755', ''),
(91, 'Gangaram bhoir', 'sai.vetclinic@yahoo.com', 'USER', '9221781143', 'PETS', 'Gangaram bhoir', 'Ram mandir chikanghar kalyan.w', '', '421301', '9221781143', ''),
(92, 'kathwate horse', 'sai.vetclinic@yahoo.com', 'USER', '9270843413', 'PETS', 'Kathwate horse', 'pali chinwali taloja road ', '', '4', '9270843413', ''),
(93, 'Bhoir shripal', 'sai.vetclinic@yahoo.com', 'USER', '9930885050', 'PETS', 'Bhoir shripal', 'gulmohar bangla pisawali chetna kalyan-E', '', '4', '9930885050', ''),
(94, 'vipin sukla lab', 'sai.vetclinic@yahoo.com', 'USER', '9870835555', 'PETS', 'vipin sukla lab', 'sai kunj apt 206 pawse chowk katemanevali', '', '4', '9870835555', ''),
(95, 'Sai Ganesh Apt Vijay Ngr', 'sai.vetclinic@yahoo.com', 'USER', '9.18656E+11', 'PETS', 'Sai Ganesh Apt Vijay Ngr', '', '', '4', '9.18656E+11', ''),
(96, 'nisha mahindaran', 'sai.vetclinic@yahoo.com', 'USER', '91 86 98 885185', 'PETS', 'nisha mahindaran', '"Nisha Mansharamani', '', '4', '91 86 98 885185', ''),
(97, 'choudhary shankar', 'sai.vetclinic@yahoo.com', 'USER', '9768286323', 'PETS', 'choudhary shankar', '1 laxman nivash nira nager cholegon thakurli .e', '', '4', '9768286323', ''),
(98, 'shinde', 'saivetclinic@yahoo.com', 'USER', '9029815929', 'PETS', 'shinde ', ':R.S. Jetwan nagar\\, baba more nagar', '', '4', '9029815929', ''),
(99, 'ajay lab', 'saivetclinic@yahoo.com', 'USER', '9920201511', 'PETS', 'ajay lab', '36/37 suphala apt opp joker talkies Nr k c gandhi', '', '4', '9920201511', ''),
(100, 'salvi', 'saivetclinic@yahoo.com', 'USER', '9702699577', 'PETS', 'salvi', 'salvi chall chetna', '', '4', '9702699577', ''),
(101, 'Bhosale narayan', 'saivetclinic@yahoo.com', 'USER', '8879002944', 'PETS', 'Bhosale narayan', 'Nandivali nr chakki sai chal', '', '4', '8879002944', ''),
(102, 'gupta ajay', 'saivetclinic@yahoo.com', 'USER', '9320222038', 'PETS', 'gupta ajay', 'rajendra shopping centre 7 mohane ambivali', '', '4', '7208299732', ''),
(103, 'nagre prathamesh', 'saivetclinic@yahoo.com', 'USER', '9702166307', 'PETS', 'nagre prathamesh', 'krupa prasad 24, sai baba nager kyn-w ', '', '4', '9702166307', '8286016321'),
(104, 'chamunda mata temple', 'sai.vetclinic@yahoo.com', 'USER', '9320111130', 'PETS', 'chamunda mata temple', 'ulasnager 1 near gajanan market', '', '4', '9320111130', '9323117338'),
(105, 'sanjay rathod', 'sai.vetclinic@yahoo.com', 'USER', '8976360186', 'PETS', 'sanjay rathod', 'farmasist', '', '4', '8976360186', '7208377796'),
(106, 'dukhiram company', 'sai.vetclinic@yahoo.com', 'USER', '9967999774', 'PETS', 'dukhiram company', 'uttarshiv shil panvel road ', '', '4', '9967999774', '9601999215'),
(107, 'prashant bhoir', 'sai.vetclinic@yahoo.com', 'USER', '9920908995', 'PETS', 'prashant bhoir', 'pisawali kyn e', '', '421306', ' 99 20 908995', ''),
(108, 'Alayam pritesh pug', 'sai.vetclinic@yahoo.com', 'USER', '9167106801', 'PETS', 'Alayam pritesh pug', 'tisai naka ', '', '421306', '9167106801', ''),
(109, 'rawat shobha', 'sai.vetclinic@yahoo.com', 'USER', '8291081641', 'PETS', 'rawat shobha ', 'Ganesh krupa building Nr arya school nandivali kyn.e', '', '421306', '8291081641', '8689952404'),
(110, 'pal railway', 'sai.vetclinic@yahoo.com', 'USER', '9820586976', 'PETS', 'Chawan GSD', 'pisawali kyn e', '', '421306', '9820586976', '8080141643'),
(111, 'arya gurukul school', 'sai.vetclinic@yahoo.com', 'USER', '9619168777', 'PETS', 'arya gurukul school', 'nandivali kalyan.e', '', '421306', '9029633204', ''),
(112, 'vandana kava pom', 'sai.vetclinic@yahoo.com', 'USER', '9909132760', 'PETS', 'chamunda mata temple', 'bail bazar kalyan.w', '', '421301', '9909132760', ''),
(113, 'Ajay sufala lab', 'sai.vetclinic@yahoo.com', 'USER', '9920201511', 'PETS', 'ajay sufala lab', 'chandresen niketen g wing 303 lodha kyn e', '', '421301', '9920201511', '9594439443'),
(114, 'pramod lab', 'sai.vetclinic@yahoo.com', 'USER', '7208646026', 'PETS', 'pramod lab', 'ambivali.e', '', '4', '7208646026', ''),
(115, 'shinde pom', 'sai.vetclinic@yahoo.com', 'USER', '9594026199', 'PETS', 'shinde pom', 'ambedkar chowk ', '', '4', '9594026199', ''),
(116, 'swapnil amardeep', 'sai.vetclinic@yahoo.com', 'USER', '9820935488', 'PETS', 'swapnil amardeep', 'bhanushali hall kyn e', '', '421306', '9820935488', ''),
(117, 'Aroskar chetna', 'sai.vetclinic@yahoo.com', 'USER', '8108563716', 'PETS', 'aroskar chetna', 'pipeline road chetna kalyan.e', '', '421306', '8108563716', '9821254958'),
(118, 'ashish sing', 'sai.vetclinic@yahoo.com', 'USER', '9769844681', 'PETS', 'ashish sing', 'nishant apt', '', '421306', '9769844681', '8976893987'),
(119, 'baba patil amb', 'sai.vetclinic@yahoo.com', 'USER', '8796291436', 'PETS', 'baba patil amb', 'ambernath', '', '4', '8796291436', '9822191811'),
(120, 'bablu omkar', 'sai.vetclinic@yahoo.com', 'USER', '9594176211', 'PETS', 'bablu omkar', 'omkar nager kalyan.e', '', '421306', '9594176211', '9004903220'),
(121, 'Bipin Purushottam', 'sai.vetclinic@yahoo.com', 'USER', '8655559133', 'PETS', 'Bipin purushottam', 'Rail Quarter kalyan.e', '', '421306', '8655559133', ''),
(122, 'Nikhil randive', 'sai.vetclinic@yahoo.com', 'USER', '9769448936', 'PETS', 'Nikhil randive', 'bail bazar kalyan.w', '', '421301', '9769448936', ''),
(123, 'pankaj tripathi', 'sai.vetclinic@yahoo.com', 'USER', '9619403420', 'PETS', 'pankaj tripathi', 'bail bazar kalyan.w', '', '421301', '9619403420', ''),
(124, 'SUJIT SING', 'sai.vetclinic@yahoo.com', 'USER', '9821214445', 'PETS', 'SUJIT SING', 'river deal vista 14 floor godrej hill kyn.w', '', '421301', '9821214445', ''),
(125, 'sudesh lab', 'sai.vetclinic@yahoo.com', 'USER', '9967434223', 'PETS', 'sudesh lab', '19 ashtami apt c vijay ngr kyn.e', '', '421306', '9967434223', ''),
(126, 'Naresh ambulkar', 'sai.vetclinic@yahoo.com', 'USER', '9664804241', 'PETS', 'Naresh ambulkar', 'Kachore villeage', '', '421306', '9664804241', ''),
(127, 'mohit bangels', 'sai.vetclinic@yahoo.com', 'USER', '9930559239', 'PETS', 'mohit bangels', 'aarti apt chinchpada kalyan.e', '', '421306', '9930559239', ''),
(128, 'Chetan londe', 'sai.vetclinic@yahoo.com', 'USER', '9175072919', 'PETS', 'Chetan londe ambernath .w', 'dubai colony', '', '4', '9175072919', '9049121396'),
(129, 'google dhaba', 'sai.vetclinic@yahoo.com', 'USER', '9223214444', 'PETS', 'google dhaba', 'desai villeage shil road kalyan.e', '', '4', '9223214444', ''),
(130, 'Gopale lab', 'sai.vetclinic@yahoo.com', 'USER', '9004100017', 'PETS', 'Gopale lab', 'chinchpada ', '', '421306', '9004100017', '9702242207'),
(131, 'waghmare dhananjay', 'sai.vetclinic@yahoo.com', 'USER', '9619360873', 'PETS', 'waghmare dhananjay', 'Sidharth nager kalyan.e', '', '421306', '9619360873', '7700062413'),
(132, 'Navnit Gaikar', 'sai.vetclinic@yahoo.com', 'USER', '9594339594', 'PETS', 'Navnit gaikar', 'Vicco naka regency', '', '421306', '9594339594', '8082528082'),
(133, 'potdar sunil', 'sai.vetclinic@yahoo.com', 'USER', '9967450171', 'PETS', 'potdar sunil', 'dudh naka kalyan.w', '', '421301', '9967450171', '9821667632'),
(134, 'Rupwate bouncer', 'sai.vetclinic@yahoo.com', 'USER', '9657800777', 'PETS', 'Rupwate bouncer', 'Opp gaon devi temple ulasnager 4', '', '4', '9657800777', ''),
(135, 'sanjay seth gaikwad', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', 'sanjay seth gaikwad', 'tisai ', '', '421306', '8652623415', ''),
(136, 'shankeshwar pom', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', 'shankeshwar pom', 'manpada', '', '4', '9833054679', ''),
(137, 'sukla lab', 'sai.vetclinic@yahoo.com', 'USER', '9224572530', 'PETS', 'sukla lab', 'kolsewadi kalyan.e opp majid', '', '4', '9224572530', ''),
(138, 'sing lab', 'sai.vetclinic@yahoo.com', 'USER', '9699369991', 'PETS', 'sing lab', '', '', '4', '9699369991', ''),
(139, 'abhay seth', 'sai.vetclinic@yahoo.com', 'USER', '9322820756', 'PETS', 'abhay seth', '', '', '4', '9322820756', ''),
(140, 'aditi sonar', 'sai.vetclinic@yahoo.com', 'USER', '9833996262', 'PETS', 'aditi sonar', 'Aditi Ashish sonar Ajanta society plot no 118 Anant banglow 1 st floor near parag banglow nandivali ', '', '4', '9833996262', ''),
(141, 'Baliram Salunke', 'sai.vetclinic@yahoo.com', 'USER', '9270278530', 'PETS', 'Baliram Salunke', 'nr ashwini dhaba', '', '4', '9270278530', ''),
(142, 'bhane Mahesh', 'sai.vetclinic@yahoo.com', 'USER', '9920299169', 'PETS', 'bhane Mahesh', 'adhavali villeage', '', '4', '9920299169', ''),
(143, 'Bodke Sanglewadi', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', 'Bodke Sanglewadi', '', '', '4', '9870747049', ''),
(144, 'chincholkar pradeep', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', 'chincholkar pradeep', '', '', '4', '9324936836', ''),
(145, 'Choudhari Shankar Thakurli', 'sai.vetclinic@yahoo.com', 'USER', '9768286323', 'PETS', 'Choudhari Shankar Thakurli', '1 ,laxman nivas building niranagar cholegaon thakurli (E)', '', '4', '9768286323', ''),
(146, 'cockes Spaniel Triveni Colony', 'sai.vetclinic@yahoo.com', 'USER', '9323643730', 'PETS', 'cockes Spaniel Triveni Colony', 'Triveni Colony Nr Nana Birwadkar Chakki Naka Kyn. E', '', '4', '9323643730', ''),
(147, '.dashoond Ula', 'sai.vetclinic@yahoo.com', 'USER', '9821456672', 'PETS', '.dashoond Ula', '', '', '4', '9823116738', ''),
(148, '.dhumal Nikhil Nr', 'sai.vetclinic@yahoo.com', 'USER', '8108732434', 'PETS', '.dhumal Nikhil Nr ', 'Nr Khadani Chakki Naka Kyn. R', '', '4', '8108732434', ''),
(149, 'Dipti Thakurli', 'sai.vetclinic@yahoo.com', 'USER', '8082207809', 'PETS', 'Dipti Thakurli', '', '', '4', '8082207809', ''),
(150, 'Divakar Lab Nandivali', 'sai.vetclinic@yahoo.com', 'USER', '9702195944', 'PETS', 'Divakar Lab Nandivali', '', '', '4', '9702195944', ''),
(151, 'Chetan Paldhikar', 'sai.vetclinic@yahoo.com', 'USER', '9320957312', 'PETS', 'Chetan Paldhikar', 'ulasnager', '', '4', '9764769161', ''),
(152, 'Dongre Net Lab', 'sai.vetclinic@yahoo.com', 'USER', '8976869853', 'PETS', 'dongre net lab', 'Opp Shriram Medical', '', '4', '8976869853', ''),
(153, '.fulchandani Baset Hound', 'sai.vetclinic@yahoo.com', 'USER', '7769961060', 'PETS', '.fulchandani Baset Hound', '701 , TerraceFlat , Classic Apts , Nehru Chowk , Ulhasnagar - 2', '', '4', '9823607421', ''),
(154, '.gajanan Awad', 'sai.vetclinic@yahoo.com', 'USER', '9867318866', 'PETS', '.gajanan Awad', '', '', '4', '9867318866', ''),
(155, '.Gangurde Sandap', 'sai.vetclinic@yahoo.com', 'USER', '9702440730', 'PETS', '.Gangurde Sandap ', 'sandap villeage titwala', '', '4', '9702440730', ''),
(156, '. holly cross school', 'sai.vetclinic@yahoo.com', 'USER', '9819574992', 'PETS', '. holly cross school', '', '', '4', '9819574992', ''),
(157, '.j P Resort', 'sai.vetclinic@yahoo.com', 'USER', '9702046074', 'PETS', '.j P Resort', '', '', '4', '9702046074', ''),
(158, '.Jagtap Raj Cammel', 'sai.vetclinic@yahoo.com', 'USER', '9881998682', 'PETS', '.Jagtap Raj Cammel', '', '', '4', '9822833323', ''),
(159, '. jain French Mastiff', 'sai.vetclinic@yahoo.com', 'USER', '8806267167', 'PETS', '. jain French Mastiff', '', '', '4', '8806267167', ''),
(160, '.Jalal Baba', 'sai.vetclinic@yahoo.com', 'USER', '9004047470', 'PETS', '.Jalal Baba', '', '', '4', '9004047470', ''),
(161, '.janvi Bhosale', 'sai.vetclinic@yahoo.com', 'USER', '76666 78910', 'PETS', '.janvi Bhosale', 'ula bhosale hospital', '', '4', ' 76666 78910', ''),
(162, '.Jayprakash Nandivali', 'sai.vetclinic@yahoo.com', 'USER', '8655534207', 'PETS', '.Jayprakash Nandivali', 'Sai sadan flat no.13 behind behind anmol garden nandivali', '', '4', '8655534207', ''),
(163, '.jitendra Karwan Lic', 'sai.vetclinic@yahoo.com', 'USER', '9004080136', 'PETS', '.jitendra Karwan Lic', 'back of sonar aquarium', '', '4', '9004080136', ''),
(164, '.kamble karan begal', 'sai.vetclinic@yahoo.com', 'USER', '9821589183', 'PETS', '.kamble karan begal', 'Vijay Nager Begal', '', '982158', '9821589183', ''),
(165, '.kamble Scumbag GSD', 'sai.vetclinic@yahoo.com', 'USER', '9867715307', 'PETS', '.kamble Scumbag GSD', 'maral  ula', '', '4', '9867715307', ''),
(166, '. kamlesh Jadhav', 'sai.vetclinic@yahoo.com', 'USER', '9821766646', 'PETS', '. kamlesh Jadhav', 'sidharth nager kalyan.e', '', '4', '9821766646', ''),
(167, '.Kanta Ratan', 'sai.vetclinic@yahoo.com', 'USER', '8087383046', 'PETS', '.Kanta Ratan ', 'Barec No 949/ 21 Near Narayan Dash Hospital Ula. 3', '', '4', '8087383046', ''),
(168, '.kedare Sidh Nag', 'sai.vetclinic@yahoo.com', 'USER', '9930908279', 'PETS', '.kedare Sidh Nag', 'sidharth nager kalyan.e', '', '4', '9930908279', ''),
(169, '.Keshwani Mukesh', 'sai.vetclinic@yahoo.com', 'USER', '9762737446', 'PETS', '.Keshwani Mukesh', 'ula 2 crime branch', '', '4', '9762737446', ''),
(170, '.kukadia lab', 'sai.vetclinic@yahoo.com', 'USER', '9702187288', 'PETS', '.kukadia lab', '', '', '4', '9702187288', ''),
(171, '.Rupesh Gavkar', 'sai.vetclinic@yahoo.com', 'USER', '8655587978', 'PETS', '.Rupesh Gavkar', 'Sai Ganesh Apt Vijay Ngr', '', '4', '8655587978', ''),
(172, '. sandip Wagh', 'sai.vetclinic@yahoo.com', 'USER', '9867831091', 'PETS', '. sandip Wagh', 'Sahyadri Ngr', '', '4', '9867831091', ''),
(173, '. satish Pom', 'sai.vetclinic@yahoo.com', 'USER', '9167067331', 'PETS', '. satish Pom', 'Nandivali', '', '4', '9167067331', ''),
(174, '. shradha Ula', 'sai.vetclinic@yahoo.com', 'USER', '9028997619', 'PETS', '. shradha Ula', 'ula', '', '4', '9028997619', ''),
(175, 'sunil sukla', 'sai.vetclinic@yahoo.com', 'USER', '8828576875', 'PETS', 'sunil sukla', 'health care lab kolsewadi kalyan.e', '', '4', '8828576875', ''),
(176, '. Singaniya Anil', 'sai.vetclinic@yahoo.com', 'USER', '9699999990', 'PETS', '. Singaniya Anil', 'Gol Maidan Ulasnager', '', '4', '9699999990', ''),
(177, '. sutar', 'sai.vetclinic@yahoo.com', 'USER', '8108080270', 'PETS', '. sutar ', 'suchak naka', '', '4', '8108080270', ''),
(178, '. Thakkar Lab', 'sai.vetclinic@yahoo.com', 'USER', '7498212387', 'PETS', '. Thakkar Lab', '', '', '4', '7498212387', ''),
(179, '. vicky Shriram The', 'sai.vetclinic@yahoo.com', 'USER', '7040237731', 'PETS', '. vicky Shriram The', '', '', '4', '7040237731', ''),
(180, '.vipul Lab', 'sai.vetclinic@yahoo.com', 'USER', '9819549128', 'PETS', '.vipul Lab', '001 Bsnl Chinchpada Road', '', '4', '9819549128', ''),
(181, 'yadav ganesh', 'sai.vetclinic@yahoo.com', 'USER', '9833552217', 'PETS', 'yadav ganesh', 'Rachana Park Kyn.e', '', '4', '9833552217', ''),
(182, '.mukesh warap', 'sai.vetclinic@yahoo.com', 'USER', '9764301013', 'PETS', '.mukesh warap', 'warap', '', '4', '9764301013', ''),
(183, 'kamble netivali', 'sai.vetclinic@yahoo.com', 'USER', '9987212268', 'PETS', 'kamble netivali', 'netivali', '', '4', '9987212268', ''),
(184, '.lahasa apso krishna enclave', 'sai.vetclinic@yahoo.com', 'USER', '+91 96647 00573', 'PETS', '.lahasa apso krishna enclave', 'rai residency nr 100 foot road  kalyan.e', '', '4', '+91 96647 00573', ''),
(185, 'nitish Dhumal', 'sai.vetclinic@yahoo.com', 'USER', '7208733006', 'PETS', 'nitish Dhumal', 'Sai Dham  Apt  Netivali ', '', '4', '7208733006', ''),
(186, 'mahendran pug', 'sai.vetclinic@yahoo.com', 'USER', '9821737235', 'PETS', 'mahendran pug', '307 back of hotel prasadam kalyan.e', '', '4', '7208747833', ''),
(187, '.pug Anjankar', 'sai.vetclinic@yahoo.com', 'USER', '9960555900', 'PETS', '.pug Anjankar', 'tajpal nageri netivali kalyan.e', '', '4', '9960555900', ''),
(188, '.Pug Sai Ganga Apt', 'sai.vetclinic@yahoo.com', 'USER', '9503287238', 'PETS', '.Pug Sai Ganga Apt ', 'Sai ganga apt 2 floor 204 flat near jhulelal school or kumar mutton road or white house building roa', '', '4', '9503287238', ''),
(189, '.rajan Lab', 'sai.vetclinic@yahoo.com', 'USER', '9892778855', 'PETS', '.rajan Lab', 'bhagirathi apt lockgram kalyan.e', '', '4', '9892778855', ''),
(190, '.tyre ritesh anmol opp', 'sai.vetclinic@yahoo.com', 'USER', '7738229970', 'PETS', '.tyre ritesh anmol opp', '', '', '4', '7738229970', ''),
(191, '.shinde dipak pom', 'sai.vetclinic@yahoo.com', 'USER', '9320039253', 'PETS', '.shinde dipak pom', '', '', '4', '9320039253', ''),
(192, 'rajput dipak', 'sai.vetclinic@yahoo.com', 'ADMIN', '9773428855', 'PETS', 'rajput dipak', '', '', '4', '8082244445', ''),
(193, 'pandit', 'sai.vetclinic@yahoo.com', 'USER', '9209291243', 'PETS', 'pandit', 'yash shree complex', '', '4', '9209291243', ''),
(194, 'nilam lab', 'sai.vetclinic@yahoo.com', 'USER', '9820004150', 'PETS', 'nilam lab', '', '', '4', '9820004150', ''),
(195, 'mishra Dattu Gs', 'sai.vetclinic@yahoo.com', 'USER', '7208945533', 'PETS', 'mishra Dattu Gs', '', '', '4', '7208945533', ''),
(196, 'mani nandivali', 'sai.vetclinic@yahoo.com', 'USER', '7303095189', 'PETS', 'mani nandivali', 'nandivali', '', '4', '9773772351', ''),
(197, 'mahtre vandar', 'sai.vetclinic@yahoo.com', 'USER', '9833837700', 'PETS', 'mahtre vandar', 'chakki naka', '', '4', '9833837700', ''),
(198, 'kawale kaku samarth math', 'sai.vetclinic@yahoo.com', 'USER', '9222079096', 'PETS', 'kawale kaku samarth math', 'Samarth Math Kolsewadi', '', '4', '9222079096', ''),
(199, '.jagtap nandivali', 'sai.vetclinic@yahoo.com', 'USER', '8108936090', 'PETS', '.jagtap nandivali', '', '', '4', '8108936090', ''),
(200, '.jadhav newdli', 'sai.vetclinic@yahoo.com', 'USER', '9702976255', 'PETS', '.jadhav newdli', '', '', '4', '9702976255', ''),
(201, '.aruna jadhav sidharth nager', 'sai.vetclinic@yahoo.com', 'USER', '9167409838', 'PETS', '.aruna jadhav sidharth nager', '', '', '4', '9167409838', ''),
(202, 'Gosavi mohan', 'sai.vetclinic@yahoo.com', 'USER', '9730635615', 'PETS', 'Gosavi mohan', '', '', '4', '9730635615', ''),
(203, 'gokul nageri', 'sai.vetclinic@yahoo.com', 'USER', '9930415265', 'PETS', 'gokul nageri', '', '', '4', '9930415265', ''),
(204, 'bhosale netivali', 'sai.vetclinic@yahoo.com', 'USER', '9096068232', 'PETS', 'bhosale netivali', 'netivali, godawon ', '', '4', '9096068232', ''),
(205, 'pandhare pranay', 'sai.vetclinic@yahoo.com', 'USER', '9819159429', 'PETS', 'pandhare pranay', '', '', '4', '9819159429', ''),
(206, 'sagar driving', 'sai.vetclinic@yahoo.com', 'USER', '9867455588', 'PETS', 'sagar driving', '', '', '4', '9867455588', ''),
(207, 'rajesh k p wire', 'sai.vetclinic@yahoo.com', 'USER', '9820995895', 'PETS', 'rajesh k p wire', 'dana market', '', '4', '9323315895', ''),
(208, 'arvind dune news', 'sai.vetclinic@yahoo.com', 'USER', '7208200300', 'PETS', 'arvind dune news', '', '', '4', '7208200300', ''),
(209, 'tushar sawant', 'sai.vetclinic@yahoo.com', 'USER', '9892892744', 'PETS', 'tushar sawant', 'netivali naka', '', '4', '9892892744', ''),
(210, 'shinde mohane', 'sai.vetclinic@yahoo.com', 'USER', '9029815929', 'PETS', 'shinde mohane', 'ambivali', '', '4', '9029815929', ''),
(211, 'shekar bhoir', 'sai.vetclinic@yahoo.com', 'USER', '7506161772', 'PETS', 'shekar bhoir', 'B.11 krupa complex kailash nager', '', '4', '7506161772', ''),
(212, 'sharma', 'sai.vetclinic@yahoo.com', 'USER', '8080013113', 'PETS', 'sharma ', '5/402 sarwade garden kalyan.e', '', '4', '8080011195', ''),
(213, 'shakes hear', 'sai.vetclinic@yahoo.com', 'USER', '9867676508', 'PETS', 'shakes hear', '', '', '4', '9867676508', ''),
(214, 'sexsena lab', 'sai.vetclinic@yahoo.com', 'USER', '9730600671', 'PETS', 'sexsena lab', 'ula', '', '4', '9730600671', ''),
(215, 'saurabh gsd', 'sai.vetclinic@yahoo.com', 'USER', '7666986787', 'PETS', 'saurabh gsd', 'devgiri kock gram kalyan.e', '', '4', '7666986787', ''),
(216, 'aquarium salim', 'sai.vetclinic@yahoo.com', 'USER', '8424998123', 'PETS', 'aquarium salim', '', '', '4', '8424998123', ''),
(217, 'sachin shakya pom', 'sai.vetclinic@yahoo.com', 'USER', '9867550066', 'PETS', 'sachin shakya pom', '1/c/c304 laxmi park kanchangon thakurli', '', '4', '9867550066', ''),
(218, 'rajput lodha', 'sai.vetclinic@yahoo.com', 'USER', '8793641599', 'PETS', 'rajput lodha', 'shanti upwan B wing 102 lodha', '', '4', '8793641599', '8108701981'),
(219, 'pug jain society', 'sai.vetclinic@yahoo.com', 'USER', '9870720396', 'PETS', 'pug jain society', 'kala talav', '', '4', '9870720396', ''),
(220, 'asha madam ula', 'sai.vetclinic@yahoo.com', 'USER', '9421625496', 'PETS', 'asha madam ula', 'ula', '', '4', '9421625496', ''),
(221, 'ayar kalyani', 'sai.vetclinic@yahoo.com', 'USER', '9049424057', 'PETS', 'ayar kalyani', 'sant ramdas hospital ula-e', '', '4', '9324769408', ''),
(222, 'prajapati hiralal', 'sai.vetclinic@yahoo.com', 'USER', '9820805029', 'PETS', 'prajapati hiralal', 'behind B NO_1073 nr jai bhavani niwas ', '', '4', '9820805029', ''),
(223, 'deshpande', 'sai.vetclinic@yahoo.com', 'USER', '9757078104', 'PETS', 'deshpande', '', '', '4', '9757078104', ''),
(224, 'seth', 'sai.vetclinic@yahoo.com', 'USER', '9004051115', 'PETS', 'seth ', 'thems co-op hsc godrej hill', '', '4', '9004051115', ''),
(225, 'gaikwad', 'sai.vetclinic@yahoo.com', 'USER', '8652662272', 'PETS', 'gaikwad', 'nr tisgon temple kyn-e', '', '4', '8652662272', ''),
(226, 'govind kene', 'sai.vetclinic@yahoo.com', 'USER', '9892550998', 'PETS', 'govind kene', 'gauripada kyn-w', '', '4', '9892550998', ''),
(227, 'kamlesh D.sawant', 'sai.vetclinic@yahoo.com', 'USER', '9769274765', 'PETS', 'kamlesh D.sawant  ', 'mohan regency C H S building no -5 ', '', '4', '9167318666', ''),
(228, 'kholiya', 'sai.vetclinic@yahoo.com', 'USER', '9820430336', 'PETS', 'kholiya', 'room no 202 savita tower nr post office ', '', '4', '9820430336', ''),
(229, 'deepali jadhav', 'sai.vetclinic@yahoo.com', 'USER', '9930841819', 'PETS', 'deepali jadhav', 'shikshak sadan room no 4 poona link road ', '', '4', '9930841819', ''),
(230, 'jayashri kopardekar', 'sai.vetclinic@yahoo.com', 'USER', '9167248736', 'PETS', 'jayashri kopardekar', 'kunal seth chall back ofdeshmukh homes ', '', '4', '9167248736', ''),
(231, 'jyoti', 'sai.vetclinic@yahoo.com', 'USER', '9867928965', 'PETS', 'jyoti ', 'parijat lock watika kyn-e', '', '4', '9867928965', ''),
(232, 'khajid', 'sai.vetclinic@yahoo.com', 'USER', '9867863755', 'PETS', 'khajid ', 'sarvoday garden patri pul kyn-w', '', '4', '9867863755', ''),
(233, 'kuwar', 'sai.vetclinic@yahoo.com', 'USER', '9869630949', 'PETS', 'kuwar', 'krishna apt 304 lock gram kyn-e', '', '4', '9869630949', ''),
(234, 'manisha', 'sai.vetclinic@yahoo.com', 'USER', '9869947818', 'PETS', 'manisha ', 'netivali ', '', '4', '9869947818', ''),
(235, 'omkar', 'sai.vetclinic@yahoo.com', 'USER', '8080820664', 'PETS', 'omkar ', 'vijay nager', '', '4', '8086126044', ''),
(236, 'latica', 'sai.vetclinic@yahoo.com', 'USER', '8976715847', 'PETS', 'latica', 'C-3/30 sai baba nager kyn-e', '', '4', '9321941711', ''),
(237, 'sonali bagde', 'sai.vetclinic@yahoo.com', 'USER', '9820401449', 'PETS', 'sonali bagde', 'dom', '', '4', '9820401449', ''),
(238, 'dr pradhan', 'sai.vetclinic@yahoo.com', 'USER', '9930505036', 'PETS', 'dr pradhan ', 'dom e nrcorp bank atm ', '', '4', '9930505036', ''),
(239, 'tripathi neha', 'sai.vetclinic@yahoo.com', 'USER', '9768162066', 'PETS', 'tripathi neha', 'B.4 /14 shivalay omkar nager netivali kalyan.e ', '', '4', '9768162066', ''),
(240, 'ganesh', 'sai.vetclinic@yahoo.com', 'USER', '9664941441', 'PETS', 'ganesh ', 'ambivali.w', '', '4', '9664941441', ''),
(241, 'rajput', 'sai.vetclinic@yahoo.com', 'USER', '8793641599', 'PETS', 'rajput', 'lodha complex', '', '4', '8828388773', ''),
(242, 'ashwini wayale', 'sai.vetclinic@yahoo.com', 'USER', '9767377051', 'PETS', 'ashwini wayale', 'ashwini dhaba', '', '4', '932289887', ''),
(243, 'mini', 'sai.vetclinic@yahoo.com', 'USER', '9821660144', 'PETS', 'mini ', 'beauty parlour om kar nager kyn.e', '', '4', '9821660144', ''),
(244, 'rubina shaikh', 'sai.vetclinic@yahoo.com', 'USER', '9833557701', 'PETS', 'rubina shaikh', 'nr bajar peth kyn.w', '', '4', '9833557701', ''),
(245, '.amarjeet Sing Cat', 'sai.vetclinic@yahoo.com', 'USER', '+91 87964 37200', 'PETS', '.amarjeet Sing Cat', 'nandivali kalyan .e', '', '4', '+91 87964 37200', ''),
(246, 'meany buty parlour', 'sai.vetclinic@yahoo.com', 'USER', '9821660144', 'PETS', 'meany buty parlour', 'om kar nager kalyan.e', '', '4', '9821660144', ''),
(247, 'shinde vinayak', 'sai.vetclinic@yahoo.com', 'USER', '8879402588', 'PETS', 'shinde vinayak', '301,vikash darshan nandivali gon NR p & T ', '', '4', '8879402588', ''),
(248, 'rupesh mahtre', 'sai.vetclinic@yahoo.com', 'USER', '9222228122', 'PETS', 'rupesh mahtre', 'pagdyacha pada taloja road ', '', '4', '9820868971', ''),
(249, 'kathwate', 'sai.vetclinic@yahoo.com', 'USER', '9270843413', 'PETS', 'kathwate ', 'pali chinchwali taloja kyn road', '', '4', '9270843413', ''),
(250, 'vithal mane', 'sai.vetclinic@yahoo.com', 'USER', '9273343290', 'PETS', 'vithal mane', 'netivali kyn-e', '', '4', '9273343290', ''),
(251, 'tushar (bandu) patil', 'sai.vetclinic@yahoo.com', 'USER', '9321141010', 'PETS', 'tushar (bandu) patil', 'laxmikant farm house kyn-murbad road ', '', '4', '9320654555', ''),
(252, 'jitu', 'sai.vetclinic@yahoo.com', 'USER', '8898351476', 'PETS', 'jitu', 'chiknepada kalyan.e', '', '421306', '8898351476', ''),
(253, 'janvi bhosale', 'sai.vetclinic@yahoo.com', 'USER', '7666678910', 'PETS', 'janvi bhosale', 'venkatesh hospital shahad', '', '4', '7666678910', ''),
(254, 'Gauri dugie', 'sai.vetclinic@yahoo.com', 'USER', '8850696772', 'PETS', 'GAURI DUGIE', 'ganesh vidyalay kolsewadi kalyan.e', '', '421306', '8850636772', ''),
(255, 'anand shivaji kamble', 'sai.vetclinic@yahoo.com', 'USER', '7021072528', 'PETS', 'anand shivaji kamble', 'nagsen colony shanti nager ulasnager.3', '', '4', '7021072528', ''),
(256, 'baby mahatre', 'sai.vetclinic@yahoo.com', 'USER', '9867550066', 'PETS', 'baby mahatre', 'chakki naka', '', '421306', '9869584852', ''),
(257, 'Aarti ambolkar', 'sai.vetclinic@yahoo.com', 'USER', '8652255074', 'PETS', 'Aarti ambolkar', '705 sarvoday shrushtri building no-3', '', '4', '8652255074', ''),
(258, 'Abhijit chawan', 'sai.vetclinic@yahoo.com', 'USER', '9699166323', 'PETS', 'Abhijit chawan', '', 'n', '4', '', '9699166323'),
(259, 'Abhijit netivali', 'sai.vetclinic@yahoo.com', 'USER', '8108422861', 'PETS', 'Abhijit netivali', 'opp metro moll netivali kalyan.e', '', '421306', '8108422861', ''),
(260, 'Achal Gupta', 'sai.vetclinic@yahoo.com', 'USER', '9594978182', 'PETS', 'achal gupta', '205 sai dham back side 50 -50 ', '', '421306', '8169394363', ''),
(261, 'ajay .sugit', 'sai.vetclinic@yahoo.com', 'USER', '7678092225', 'PETS', 'ajay.sujit', 'khadakpada ', '', '421301', '7678092225', ''),
(262, 'ajay gupta dob', 'sai.vetclinic@yahoo.com', 'USER', '8452072852', 'PETS', 'Ajay gupta dob', '', 'n', '4', '8452078852', ''),
(263, 'Ajay kanojiya', 'sai.vetclinic@yahoo.com', 'USER', '9833550348', 'PETS', 'Ajay kanojiya', 'om shiv ganga complex khadagolvali', '', '421306', '9833550348', ''),
(264, 'kamath', 'sai.vetclinic@yahoo.com', 'USER', '9960334305', 'PETS', 'kamath ', 'sabarmati 302 lockgram kyn-e', '', '4', '9960334305', ''),
(265, 'bhatav', 'sai.vetclinic@yahoo.com', 'USER', '9920031005', 'PETS', 'bhatav', 'omkar nager kyn-e', '', '4', '9920031005', ''),
(266, 'solanki amita', 'sai.vetclinic@yahoo.com', 'USER', '9870741176', 'PETS', 'solanki amita', '704 /705 shatrunjay tower opp anant', '', '4', '9870741176', ''),
(267, 'chawan chaitali', 'sai.vetclinic@yahoo.com', 'USER', '9867536293', 'PETS', 'chawan chaitali', 'shivam society rajaram patil nager room no B-21 opp', '', '4', '9867536293', ''),
(268, 'sajid', 'sai.vetclinic@yahoo.com', 'USER', '8097020109', 'PETS', 'sajid', '', '', '4', '8097020109', '8097020109'),
(269, 'goat farm', 'sai.vetclinic@yahoo.com', 'USER', '998745866', 'PETS', 'goat farm', 'post khardi palashin villeage shahapur ', '', '4', '998745866', ''),
(270, 'ram wayale', 'sai.vetclinic@yahoo.com', 'USER', '9321359111', 'PETS', 'ram wayale', 'ashvini dhaba badlapur link road ', '', '4', '8308922888', '9321359111'),
(271, 'Akshay lab', 'sai.vetclinic@yahoo.com', 'USER', '7021917732', 'PETS', 'Akshay lab', 'G-1/302  shankeshwar tawari pada kalyan.w', '', '421301', '8779767791', ''),
(272, 'akshay sugar cane', 'sai.vetclinic@yahoo.com', 'USER', '7666399984', 'PETS', 'akshay sugar cane', 'Zunjarrav market', '', '421301', '7666399984', ''),
(273, 'Akshay surve', 'sai.vetclinic@yahoo.com', 'USER', '8097819779', 'PETS', 'akshay surve', 'kalyan', '', '4', '8097819779', ''),
(274, 'alayam pritesh', 'sai.vetclinic@yahoo.com', 'USER', '9167106801', 'PETS', 'alalyam pritesh', 'k', '', '4', '9167106801', ''),
(275, 'amarjit sing', 'sai.vetclinic@yahoo.com', 'USER', '8169436225', 'PETS', 'Amarjit sing', 'nandivali kalyan .e', '', '4', '8169436225', ''),
(276, 'amarjit sing diva', 'sai.vetclinic@yahoo.com', 'USER', '9664136263', 'PETS', 'Amarjit sing diva', 'B- 2 /202 sai shrushti height dawale diva.e', '', '400612', '9664132263', ''),
(277, 'Amandeep parrot', 'sai.vetclinic@yahoo.com', 'USER', '8046800187', 'PETS', 'amandeep parrot', 'k', '', '421306', '', '8046800187'),
(278, 'Amit gaikwad', 'sai.vetclinic@yahoo.com', 'USER', '9930430223', 'PETS', 'Amit gaikwad', 'The friends 104 opp RTO kalyan.w', '', '421301', '9930430223', ''),
(279, 'amit karpe', 'sai.vetclinic@yahoo.com', 'USER', '9004301430', 'PETS', 'amit karpe', 'karpe wadi kalyan.e', '', '421306', '9004301430', ''),
(280, 'Amit dhaware lift', 'sai.vetclinic@yahoo.com', 'USER', '9833056964', 'PETS', 'Amit dhaware', 'tejpal nageri', '', '421306', '', '9833056964'),
(281, 'Anand jadhav', 'sai.vetclinic@yahoo.com', 'USER', '9920841294', 'PETS', 'Anand jadhav', 'shree complex', '', '421301', '9920841294', ''),
(282, 'Aniket surve', 'sai.vetclinic@yahoo.com', 'USER', '8898905388', 'PETS', 'ANIKET SURVE', 'kalyan', '', '4', '8898905388', ''),
(283, 'Anish diva', 'sai.vetclinic@yahoo.com', 'USER', '9870503096', 'PETS', 'Anish diva', 'diva', '', '4', '9870503096', ''),
(284, 'anita nandivali', 'sai.vetclinic@yahoo.com', 'USER', '9892615414', 'PETS', 'anita nandivali', 'nandivali', '', '4', '', '9892615414'),
(285, 'Anna a pritham hotel', 'sai.vetclinic@yahoo.com', 'USER', '9011154269', 'PETS', 'anna A pritham hotel', 'ambernath', '', '4', '9011154269', ''),
(286, 'Anurag modi', 'sai.vetclinic@yahoo.com', 'USER', '7021853545', 'PETS', 'Anurag modi', 'Kachore villeage', '', '4', '', '7021853545'),
(287, 'Appa manere', 'sai.vetclinic@yahoo.com', 'USER', '9004310046', 'PETS', 'appa manere', '', 'manere', '4', '', '9004310046'),
(288, 'Arjun jalal baba', 'sai.vetclinic@yahoo.com', 'USER', '9004241470', 'PETS', 'arjun jalal baba', 'netivali', '', '421306', '', '9004241470'),
(289, 'arvind utekar', 'sai.vetclinic@yahoo.com', 'USER', '9594176159', 'PETS', 'Arvind utekar', 'kalyan', '', '421301', '', '9594176159'),
(290, 'Ashish karira ula', 'sai.vetclinic@yahoo.com', 'USER', '9637176644', 'PETS', 'Ashish karira', '701 , TerraceFlat , Classic Apts , Nehru Chowk , Ulhasnagar - 2', '', '4', '9637176644', ''),
(291, 'avi barge', 'sai.vetclinic@yahoo.com', 'USER', '9004087245', 'PETS', 'avi barge', 'rb railay quarter kalyan.e', '', '421306', '9004087245', ''),
(292, 'avinash goat fulore', 'sai.vetclinic@yahoo.com', 'USER', '9821352176', 'PETS', 'avinash goat fulore', 'malang goat farm', '', '421306', '98821352176', '9137024477'),
(293, 'awale maharal', 'sai.vetclinic@yahoo.com', 'USER', '7977529678', 'PETS', 'awale maharal', 'maharal villeage', '', '4', '7977529678', ''),
(294, 'Azahar cat', 'sai.vetclinic@yahoo.com', 'USER', '7039668500', 'PETS', 'azahar cat', 'netivali', '', '421306', '7039668500', ''),
(295, 'baba naidu', 'sai.vetclinic@yahoo.com', 'USER', '9321834833', 'PETS', 'baba naidu', 'palava', '', '4', '9321834833', ''),
(296, 'Baban gawas', 'sai.vetclinic@yahoo.com', 'USER', '9819021170', 'PETS', 'baban gawas', 'pawase chowk kolsewadi', '', '421306', '9819021170', '9619353976'),
(297, 'bani thakre', 'sai.vetclinic@yahoo.com', 'USER', '8369412415', 'PETS', 'bani thakre', 'radha nager kalyan.w', '4', '', '8369412415', ''),
(298, 'bhagyashree salvi', 'sai.vetclinic@yahoo.com', 'USER', '7798663932', 'PETS', 'bhagyashree salvi', 'E-104 lodha park near lodha regency sandap', '', '4 ', '7798663932', ''),
(299, 'Bharati shinde cat', 'sai.vetclinic@yahoo.com', 'USER', '9220100203', 'PETS', 'bharati shinde', '701 , TerraceFlat , Classic Apts , Nehru Chowk , Ulhasnagar - 2', '', '421306', '9220100203', '9029420244'),
(300, 'Bhavesh manera', 'sai.vetclinic@yahoo.com', 'USER', '7208022778', 'PETS', 'bhavesh manera', '704 /705 shatrunjay tower opp anant', '', '421306', '7208022778', '8097700770'),
(301, 'Bhoir CNG', 'sai.vetclinic@yahoo.com', 'USER', '8356061166', 'PETS', 'Bhoir CNG', 'netivali kyn-e', '', '421306', '8356061166', ''),
(302, 'Bhopi stray', 'sai.vetclinic@yahoo.com', 'USER', '8108098346', 'PETS', 'bhopi stray', 'masoba chowk', '', '421306', '8108098346', ''),
(303, 'Bhushan shetty', 'sai.vetclinic@yahoo.com', 'USER', '9594229868', 'PETS', 'bhushan shetty', 'nr fortish hospital kalyan.w', '', '4', '9594229868', ''),
(304, 'Bhutkar daughter', 'sai.vetclinic@yahoo.com', 'USER', '8356860050', 'PETS', 'bhutkar daughter', 'kopar', '', '4', '8356860050', ''),
(305, 'Bindu alexzender', 'sai.vetclinic@yahoo.com', 'USER', '9833381384', 'PETS', 'bindu alexzender', 'shree sai dham apt nr anmol garden kalyan.e', '', '421306', '9833381384', ''),
(306, 'jagtap kiran cat', 'sai.vetclinic@yahoo.com', 'USER', '9326776442', 'PETS', 'kiran jagtap cat', 'tisgon', '', '421306', '9326776442', ''),
(307, 'kanishk wagh', 'sai.vetclinic@yahoo.com', 'USER', '9987030077', 'PETS', 'kanishk wagh', 'railway colony nr anmol garden kalyan.e', '', '421306', '9987030077', ''),
(308, 'bhavesh peshwani ula', 'sai.vetclinic@yahoo.com', 'USER', '7499290345', 'PETS', 'bhavesh peshwani ula', 'ula', '', '4', '', '7499290345'),
(309, 'boadke cat', 'sai.vetclinic@yahoo.com', 'USER', '9421780471', 'PETS', 'boadke cat', 'kolsewadi kalyan.e', '', '421306', '9421780471', ''),
(310, 'khare devika', 'sai.vetclinic@yahoo.com', 'USER', '9820228428', 'PETS', 'khare devika', 'dil bhandup .w', '', '4', '9820228428', ''),
(311, 'cat ambivali', 'sai.vetclinic@yahoo.com', 'USER', '7045937144', 'PETS', 'cat ambivali', 'ambivali', '', '4', '', '7045937144'),
(312, 'chamunda temple ula', 'sai.vetclinic@yahoo.com', 'USER', '7208432191', 'PETS', 'chamunda temple ula', 'ula', '', '4', '7208432191', ''),
(313, 'chawan milind', 'sai.vetclinic@yahoo.com', 'USER', '8691942727', 'PETS', 'chawan milind', '', 'k', '4', '8691942727', ''),
(314, 'chawada dob', 'sai.vetclinic@yahoo.com', 'USER', '7977870654', 'PETS', 'chawada dob', 'nr hotel ramdev kalyan.w', '', '4', '', '7977870654'),
(315, 'chitra yadav', 'sai.vetclinic@yahoo.com', 'USER', '8097099955', 'PETS', 'chitra yadav', 'k', '', '4', '8097099955', ''),
(316, 'choudhary pratiksha', 'sai.vetclinic@yahoo.com', 'USER', '8108597543', 'PETS', 'choudhary pratiksha', 'jimmi baug', '', '421306', '8108597543', ''),
(317, 'choudhary sasa murbad', 'sai.vetclinic@yahoo.com', 'USER', '8888172576', 'PETS', 'choudhary sasa murbad', 'murbad', '', '4', '8888172576', ''),
(318, 'Datta naik', 'sai.vetclinic@yahoo.com', 'USER', '90292929', 'PETS', 'Datta naik', 'nevali naik', '', '421306', '9029290029', ''),
(319, 'dinesh chawan cat', 'sai.vetclinic@yahoo.com', 'USER', '9773477707', 'PETS', 'dinesh chawan', '', '', '4', '', ''),
(320, 'dipak', 'sai.vetclinic@yahoo.com', 'USER', '9930725113', 'PETS', 'dipak lab gosavipura', 'gosavipura', '', '421306', '', ''),
(321, 'dipti nair', 'sai.vetclinic@yahoo.com', 'USER', '8082207809', 'PETS', 'dipti nair', 'sai nager vithalwadi kalyan.e', '', '421306', '', ''),
(322, 'dogra lab', 'sai.vetclinic@yahoo.com', 'USER', '8806100827', 'PETS', 'dogra lab', 'flat no 303 ganpati palace C block road nr  gurudwara ula-3', '', '4', '', ''),
(323, 'dongre lab', 'sai.vetclinic@yahoo.com', 'USER', '8976869853', 'PETS', 'dongre lab', 'netivali opp shriram medical', '', '421306', '', ''),
(324, 'Dr kasturi kadam', 'sai.vetclinic@yahoo.com', 'USER', '7397841105', 'PETS', 'dr kasturi kadam', 'E 002 chandresh lodha heritage bhopar road dombivali .e', '', '4', '7397841105', ''),
(325, 'dr sachin patil', 'sai.vetclinic@yahoo.com', 'USER', '8855970436', 'PETS', 'dr sachin patil', 'B- 204 / Dev ashish co hsc near rajni marble kalyan mohane shahad station ', '', '4', '8855970436', ''),
(326, 'dube krishna lab', 'sai.vetclinic@yahoo.com', 'USER', '8898539190', 'PETS', 'dube krishna lab', '', '', '4', '8898539190', ''),
(327, 'dugie stray', 'sai.vetclinic@yahoo.com', 'USER', '9004358306', 'PETS', 'dugie stray', 'nr ganesh vidyalay kolsewadi', '', '4', '9004358306', ''),
(328, 'dyana', 'sai.vetclinic@yahoo.com', 'USER', '7710014121', 'PETS', 'dyana', '702 shankeshwar saigon dombivali ', '', '4', '7710014121', ''),
(329, 'emtihaj goat', 'sai.vetclinic@yahoo.com', 'USER', '7738852977', 'PETS', 'emtihaj goat', 'netivali anand nager', '', '421306', '7738852977', ''),
(330, 'waghchore sunil', 'sai.vetclinic@yahoo.com', 'USER', '7972166323', 'PETS', 'waghchore sunil', 'shanti nager ulasnager 3', '', '4', '7972166323', ''),
(331, 'acharya rohit rotriwer', 'saivetclinic@yahoo.com', 'USER', '8976497850', 'PETS', 'achary rohit rotriwer', 'mahadu height tisai kalyan.e', '', '421306', '8976497850', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
